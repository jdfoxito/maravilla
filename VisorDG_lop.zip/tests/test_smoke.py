"""Pruebas de humo del backend del visor (sin base de datos)."""

import sys
from pathlib import Path

# Los módulos del backend viven planos en app/backend (sin src/app)
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app" / "backend"))


def test_consultas_cubren_secciones_del_monitor():
    """El paquete TV debe incluir todas las secciones que el frontend consume."""
    from main import CONSULTAS_TV

    esperadas = {"mes_corriente", "hist_ventas", "hist_recaudacion",
                 "hist_brigadas", "hist_capacitaciones", "ventas_provincias"}
    assert esperadas <= set(CONSULTAS_TV)


def test_token_jwt_se_firma_y_verifica():
    """El token emitido debe decodificarse con el secreto del settings.toml."""
    import jwt

    import main
    token = main.crear_token("00000000-0000-0000-0000-000000000000", "VISOR")
    payload = jwt.decode(token, main.JWT_SECRET, algorithms=[main.JWT_ALG])
    assert payload["perfil"] == "VISOR"
