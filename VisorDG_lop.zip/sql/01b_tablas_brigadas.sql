-- =============================================================
-- PARCHE INCREMENTAL: crea SOLO las tablas de brigadas y la
-- marca de agua, sin tocar lo demás. Usar en máquinas donde el
-- 01_esquema_visordg.sql quedó de una versión anterior (error:
-- 'no existe la relación visordg.brigadas_atendidos').
-- Es idempotente: se puede correr las veces que sea.
--   psql -U postgres -d detalles -f 01b_tablas_brigadas.sql
-- =============================================================

BEGIN;

CREATE TABLE IF NOT EXISTS visordg.brigadas_atendidos (
    id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    zona       TEXT NOT NULL,
    provincia  TEXT NOT NULL,
    agencia    TEXT,
    anio       SMALLINT NOT NULL,
    mes        SMALLINT NOT NULL CHECK (mes BETWEEN 1 AND 12),
    atendidos  INTEGER NOT NULL DEFAULT 0,
    cargado_en TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (agencia, anio, mes)
);
CREATE INDEX IF NOT EXISTS ix_brigadas_periodo ON visordg.brigadas_atendidos (anio, mes);

CREATE TABLE IF NOT EXISTS visordg.brigadas_eventos (
    id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    zona       TEXT NOT NULL,
    provincia  TEXT NOT NULL,
    anio       SMALLINT NOT NULL,
    mes        SMALLINT NOT NULL CHECK (mes BETWEEN 1 AND 12),
    eventos    INTEGER NOT NULL DEFAULT 0,
    cargado_en TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (provincia, anio, mes)
);
CREATE INDEX IF NOT EXISTS ix_brigadas_ev_periodo ON visordg.brigadas_eventos (anio, mes);

-- Por si la marca de agua quedó sin su fila (el monitor la consulta):
INSERT INTO visordg.visor_refresh (id) VALUES (1) ON CONFLICT DO NOTHING;

COMMIT;
