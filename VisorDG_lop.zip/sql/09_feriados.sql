BEGIN;

CREATE TABLE IF NOT EXISTS visordg.feriados (
    anio          SMALLINT NOT NULL,
    fecha_feriado DATE     NOT NULL PRIMARY KEY,
    CONSTRAINT chk_feriado_anio CHECK (anio = EXTRACT(YEAR FROM fecha_feriado))
);
CREATE INDEX IF NOT EXISTS ix_feriados_anio ON visordg.feriados (anio);

CREATE OR REPLACE FUNCTION visordg.ultimo_dia_laborable(
    p_ref DATE DEFAULT (now() AT TIME ZONE 'America/Guayaquil')::date)
RETURNS DATE LANGUAGE sql STABLE AS $$
    SELECT max(d)::date
    FROM generate_series(p_ref - 31, p_ref - 1, INTERVAL '1 day') AS d
    WHERE EXTRACT(ISODOW FROM d) < 6
      AND NOT EXISTS (SELECT 1 FROM visordg.feriados f WHERE f.fecha_feriado = d::date)
$$;

INSERT INTO visordg.feriados (anio, fecha_feriado) VALUES
    (2026, '2026-01-01'),
    (2026, '2026-02-16'),
    (2026, '2026-02-17'),
    (2026, '2026-04-03'),
    (2026, '2026-05-01'),
    (2026, '2026-05-25'),
    (2026, '2026-08-10'),
    (2026, '2026-10-09'),
    (2026, '2026-11-02'),
    (2026, '2026-11-03'),
    (2026, '2026-12-25'),
    (2027, '2027-01-01'),
    (2027, '2027-02-08'),
    (2027, '2027-02-09'),
    (2027, '2027-03-26'),
    (2027, '2027-05-01'),
    (2027, '2027-05-24'),
    (2027, '2027-08-10'),
    (2027, '2027-10-09'),
    (2027, '2027-11-02'),
    (2027, '2027-11-03'),
    (2027, '2027-12-25')
ON CONFLICT (fecha_feriado) DO NOTHING;

COMMIT;
