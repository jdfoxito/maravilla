CREATE TABLE IF NOT EXISTS visordg.recaudacion_raw_dos (
    id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    fecha      DATE NOT NULL,
    sector     TEXT,
    provincia  TEXT,
    impuesto   TEXT,
    recaudado  NUMERIC(18,2) NOT NULL DEFAULT 0,
    cargado_en TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_recaudacion_dos_fecha ON visordg.recaudacion_raw_dos (fecha);
CREATE INDEX IF NOT EXISTS ix_recaudacion_dos_prov  ON visordg.recaudacion_raw_dos (provincia);

CREATE TABLE IF NOT EXISTS visordg.ventas_raw_dos (
    id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    fecha      DATE NOT NULL,
    provincia  TEXT,
    sector     TEXT,
    ventas     NUMERIC(18,2) NOT NULL DEFAULT 0,
    cargado_en TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_ventas_dos_fecha ON visordg.ventas_raw_dos (fecha);
CREATE INDEX IF NOT EXISTS ix_ventas_dos_prov  ON visordg.ventas_raw_dos (provincia);
