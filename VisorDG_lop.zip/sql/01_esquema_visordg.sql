BEGIN;

CREATE SCHEMA IF NOT EXISTS visordg;
CREATE SCHEMA IF NOT EXISTS seg;

CREATE TABLE IF NOT EXISTS visordg.recaudacion_raw (
    id                BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    ae_codigo_familia TEXT,
    ae_codigo_grupo   TEXT,
    cod_n6            TEXT,
    fecha             DATE NOT NULL,
    impuesto_pk       INTEGER,
    provincia         TEXT,
    gc                TEXT,
    pago              TEXT,
    m_fuente          TEXT,
    carga             TEXT,
    recaudado         NUMERIC(14,2) NOT NULL DEFAULT 0,
    cargado_en        TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_rec_raw_fecha     ON visordg.recaudacion_raw (fecha);
CREATE INDEX IF NOT EXISTS ix_rec_raw_provincia ON visordg.recaudacion_raw (provincia);
CREATE INDEX IF NOT EXISTS ix_rec_raw_impuesto  ON visordg.recaudacion_raw (impuesto_pk);

CREATE TABLE IF NOT EXISTS visordg.cat_impuestos (
    id                      BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    impuesto_pk             INTEGER UNIQUE,
    impuesto_grupo          TEXT,
    impuesto_detalle        TEXT,
    codigo_opera_impuesto   TEXT,
    descripcion_impuesto    TEXT,
    cargado_en              TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS visordg.cat_provincias (
    id           BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    provincia_pk INTEGER UNIQUE,
    provincia    TEXT,
    zona         TEXT,
    cargado_en   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS visordg.cat_fuentes (
    id                  BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    mar_fuente          TEXT UNIQUE,
    descripcion_fuente  TEXT,
    cargado_en          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS visordg.cat_actividad_economica (
    id                          BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    codigo_opera_familia        TEXT,
    descripcion_familia         TEXT,
    codigo_opera_grupo          TEXT,
    descripcion_grupo           TEXT,
    codigo_opera_subgrupo       TEXT,
    descripcion_subgrupo        TEXT,
    codigo_opera_clase          TEXT,
    descripcion_clase           TEXT,
    codigo_opera_subclase       TEXT,
    descripcion_subclase        TEXT,
    actividad_economica_pk      INTEGER,
    codigo_opera_actividad_eco  TEXT,
    descripcion_actividad_eco   TEXT,
    sector                      TEXT,
    sector_nuevo                TEXT,
    cargado_en                  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_cat_actividad_pk ON visordg.cat_actividad_economica (actividad_economica_pk);

CREATE TABLE IF NOT EXISTS visordg.capacitaciones_raw (
    id                BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    zonal             TEXT,
    provincia         TEXT,
    lugar             TEXT,
    fecha             TIMESTAMP NOT NULL,
    tema              TEXT,
    instructor        TEXT,
    total_capacitados INTEGER NOT NULL DEFAULT 0,
    horario           TEXT,
    modalidad         TEXT,
    tipo              TEXT,
    cargado_en        TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_cap_raw_fecha ON visordg.capacitaciones_raw (fecha);

CREATE TABLE IF NOT EXISTS visordg.brigadas_atendidos (
    id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    zona       TEXT NOT NULL,
    provincia  TEXT NOT NULL,
    agencia    TEXT,
    anio       SMALLINT NOT NULL,
    mes        SMALLINT NOT NULL CHECK (mes BETWEEN 1 AND 12),
    atendidos  INTEGER NOT NULL DEFAULT 0,
    cargado_en TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT brigadas_atendidos_prov_agencia_anio_mes_key UNIQUE (provincia, agencia, anio, mes)
);
CREATE INDEX IF NOT EXISTS ix_brigadas_periodo ON visordg.brigadas_atendidos (anio, mes);

CREATE TABLE IF NOT EXISTS visordg.brigadas_eventos (
    id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    zona       TEXT NOT NULL,
    provincia  TEXT NOT NULL,
    anio       SMALLINT NOT NULL,
    mes        SMALLINT NOT NULL CHECK (mes BETWEEN 1 AND 12),
    eventos    INTEGER NOT NULL DEFAULT 0,
    cargado_en TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (provincia, anio, mes)
);
CREATE INDEX IF NOT EXISTS ix_brigadas_ev_periodo ON visordg.brigadas_eventos (anio, mes);

CREATE TABLE IF NOT EXISTS visordg.cargas_archivo (
    id             BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    fuente         TEXT NOT NULL,
    nombre_archivo TEXT NOT NULL,
    filas_ok       INTEGER NOT NULL DEFAULT 0,
    filas_error    INTEGER NOT NULL DEFAULT 0,
    estado         TEXT NOT NULL DEFAULT 'OK',
    mensaje        TEXT,
    anio           SMALLINT,
    archivo_modificado TIMESTAMPTZ,
    total_declarado NUMERIC,
    total_cargado   NUMERIC,
    cargado_en     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS visordg.dash_mes_corriente (
    fecha               DATE PRIMARY KEY,
    ventas_hace_dos_anios        NUMERIC(18,6) DEFAULT 0,
    ventas_anio_anterior         NUMERIC(18,6) DEFAULT 0,
    ventas_anio_actual           NUMERIC(18,6) DEFAULT 0,
    recaudacion_anio_anterior    NUMERIC(18,6) DEFAULT 0,
    recaudacion_anio_actual      NUMERIC(18,6) DEFAULT 0,
    brigadas_anio_anterior       INTEGER DEFAULT 0,
    brigadas_anio_actual         INTEGER DEFAULT 0,
    capacitaciones_anio_anterior INTEGER DEFAULT 0,
    capacitaciones_anio_actual   INTEGER DEFAULT 0,
    cargado_en          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS visordg.dash_ventas_provincia (
    id          BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    periodo     TEXT NOT NULL,
    provincia   TEXT NOT NULL,
    hace_dos_anios NUMERIC(18,6) DEFAULT 0,
    anio_anterior  NUMERIC(18,6) DEFAULT 0,
    anio_actual    NUMERIC(18,6) DEFAULT 0,
    cargado_en  TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (periodo, provincia)
);

CREATE TABLE IF NOT EXISTS visordg.hist_ventas (
    mes        DATE PRIMARY KEY,
    ventas     NUMERIC(18,6) NOT NULL DEFAULT 0,
    fecha_corte        DATE,
    archivo            TEXT,
    archivo_modificado TIMESTAMPTZ,
    cargado_en TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS visordg.hist_recaudacion (
    mes         DATE PRIMARY KEY,
    recaudacion NUMERIC(18,6) NOT NULL DEFAULT 0,
    fecha_corte        DATE,
    archivo            TEXT,
    archivo_modificado TIMESTAMPTZ,
    cargado_en  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS visordg.hist_brigadas (
    mes        DATE PRIMARY KEY,
    brigadas   INTEGER NOT NULL DEFAULT 0,
    fecha_corte        DATE,
    archivo            TEXT,
    archivo_modificado TIMESTAMPTZ,
    total_declarado    INTEGER,
    cargado_en TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS visordg.hist_capacitaciones (
    mes            DATE PRIMARY KEY,
    capacitaciones INTEGER NOT NULL DEFAULT 0,
    fecha_corte        DATE,
    archivo            TEXT,
    archivo_modificado TIMESTAMPTZ,
    total_declarado    INTEGER,
    cargado_en     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE OR REPLACE VIEW visordg.v_fecha_corte AS
SELECT 'ventas'::text AS fuente, h.fecha_corte, h.archivo, h.archivo_modificado
FROM (SELECT fecha_corte, archivo, archivo_modificado, mes FROM visordg.hist_ventas
      WHERE fecha_corte IS NOT NULL ORDER BY fecha_corte DESC, mes DESC LIMIT 1) h
UNION ALL
SELECT 'recaudacion', h.fecha_corte, h.archivo, h.archivo_modificado
FROM (SELECT fecha_corte, archivo, archivo_modificado, mes FROM visordg.hist_recaudacion
      WHERE fecha_corte IS NOT NULL ORDER BY fecha_corte DESC, mes DESC LIMIT 1) h
UNION ALL
SELECT 'brigadas', h.fecha_corte, h.archivo, h.archivo_modificado
FROM (SELECT fecha_corte, archivo, archivo_modificado, mes FROM visordg.hist_brigadas
      WHERE fecha_corte IS NOT NULL ORDER BY fecha_corte DESC, mes DESC LIMIT 1) h
UNION ALL
SELECT 'capacitaciones', h.fecha_corte, h.archivo, h.archivo_modificado
FROM (SELECT fecha_corte, archivo, archivo_modificado, mes FROM visordg.hist_capacitaciones
      WHERE fecha_corte IS NOT NULL ORDER BY fecha_corte DESC, mes DESC LIMIT 1) h;

CREATE TABLE IF NOT EXISTS visordg.meta_recaudacion (
    anio       INT NOT NULL,
    mes        INT NOT NULL,
    valor_meta NUMERIC(15,2) NOT NULL,
    creado_en  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT pk_meta_recaudacion PRIMARY KEY (anio, mes),
    CONSTRAINT chk_mes CHECK (mes BETWEEN 1 AND 12),
    CONSTRAINT chk_anio CHECK (anio >= 2020)
);

CREATE TABLE IF NOT EXISTS visordg.feriados (
    anio          SMALLINT NOT NULL,
    fecha_feriado DATE     NOT NULL PRIMARY KEY,
    CONSTRAINT chk_feriado_anio CHECK (anio = EXTRACT(YEAR FROM fecha_feriado))
);
CREATE INDEX IF NOT EXISTS ix_feriados_anio ON visordg.feriados (anio);
CREATE OR REPLACE FUNCTION visordg.ultimo_dia_laborable(
    p_ref DATE DEFAULT (now() AT TIME ZONE 'America/Guayaquil')::date)
RETURNS DATE LANGUAGE sql STABLE AS $$
    SELECT max(d)::date
    FROM generate_series(p_ref - 31, p_ref - 1, INTERVAL '1 day') AS d
    WHERE EXTRACT(ISODOW FROM d) < 6
      AND NOT EXISTS (SELECT 1 FROM visordg.feriados f WHERE f.fecha_feriado = d::date)
$$;

CREATE TABLE IF NOT EXISTS visordg.visor_refresh (
    id            SMALLINT PRIMARY KEY DEFAULT 1 CHECK (id = 1),
    actualizado_en TIMESTAMPTZ NOT NULL DEFAULT now()
);
INSERT INTO visordg.visor_refresh (id) VALUES (1) ON CONFLICT DO NOTHING;

CREATE TABLE IF NOT EXISTS seg.perfiles (
    id          SMALLINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    codigo      TEXT NOT NULL UNIQUE,
    nombre      TEXT NOT NULL,
    descripcion TEXT
);

CREATE TABLE IF NOT EXISTS seg.permisos (
    id          SMALLINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    codigo      TEXT NOT NULL UNIQUE,
    descripcion TEXT
);

CREATE TABLE IF NOT EXISTS seg.perfil_permiso (
    perfil_id  SMALLINT NOT NULL REFERENCES seg.perfiles(id) ON DELETE CASCADE,
    permiso_id SMALLINT NOT NULL REFERENCES seg.permisos(id) ON DELETE CASCADE,
    PRIMARY KEY (perfil_id, permiso_id)
);

CREATE TABLE IF NOT EXISTS seg.usuarios (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    username       TEXT NOT NULL UNIQUE,
    email          TEXT UNIQUE,
    password_hash  TEXT NOT NULL,
    perfil_id      SMALLINT NOT NULL REFERENCES seg.perfiles(id),
    activo         BOOLEAN NOT NULL DEFAULT TRUE,
    ultimo_login   TIMESTAMPTZ,
    creado_en      TIMESTAMPTZ NOT NULL DEFAULT now(),
    actualizado_en TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS seg.refresh_tokens (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    usuario_id UUID NOT NULL REFERENCES seg.usuarios(id) ON DELETE CASCADE,
    token_hash TEXT NOT NULL,
    expira_en  TIMESTAMPTZ NOT NULL,
    revocado   BOOLEAN NOT NULL DEFAULT FALSE,
    ip         INET,
    user_agent TEXT,
    creado_en  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_refresh_usuario ON seg.refresh_tokens (usuario_id);

CREATE TABLE IF NOT EXISTS seg.auditoria (
    id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    usuario_id UUID REFERENCES seg.usuarios(id) ON DELETE SET NULL,
    accion     TEXT NOT NULL,
    detalle    JSONB,
    ip         INET,
    creado_en  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_auditoria_fecha ON seg.auditoria (creado_en);

INSERT INTO seg.perfiles (codigo, nombre, descripcion) VALUES
    ('ADMIN',    'Administrador', 'Acceso total: usuarios, cargas y visualización'),
    ('ANALISTA', 'Analista',      'Carga de archivos y visualización'),
    ('VISOR',    'Visor',         'Solo visualización del panel')
ON CONFLICT (codigo) DO NOTHING;

INSERT INTO seg.permisos (codigo, descripcion) VALUES
    ('datos:ver',      'Consultar métricas del visor'),
    ('datos:cargar',   'Subir archivos de las fuentes'),
    ('usuarios:admin', 'Crear/editar usuarios y perfiles')
ON CONFLICT (codigo) DO NOTHING;

INSERT INTO seg.perfil_permiso (perfil_id, permiso_id)
SELECT p.id, pe.id FROM seg.perfiles p, seg.permisos pe
WHERE p.codigo = 'ADMIN'
   OR (p.codigo = 'ANALISTA' AND pe.codigo IN ('datos:ver', 'datos:cargar'))
   OR (p.codigo = 'VISOR'    AND pe.codigo IN ('datos:ver'))
ON CONFLICT DO NOTHING;

COMMIT;
