BEGIN;

INSERT INTO visordg.hist_brigadas (mes, brigadas, cargado_en)
SELECT make_date(anio, mes, 1),
       SUM(eventos),
       now()
FROM visordg.brigadas_eventos
GROUP BY 1
ON CONFLICT (mes) DO UPDATE
SET brigadas = EXCLUDED.brigadas, cargado_en = now();

INSERT INTO visordg.hist_capacitaciones (mes, capacitaciones, cargado_en)
SELECT date_trunc('month', fecha)::date,
       COUNT(*),
       now()
FROM visordg.capacitaciones_raw
GROUP BY 1
ON CONFLICT (mes) DO UPDATE
SET capacitaciones = EXCLUDED.capacitaciones, cargado_en = now();

UPDATE visordg.visor_refresh SET actualizado_en = now() WHERE id = 1;

COMMIT;
