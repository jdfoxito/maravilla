\if :{?meta}
\else
  \set meta 0
\endif

\echo '=== 1. VENTAS — barras del gráfico (millones USD por mes) ==='
WITH p AS (SELECT EXTRACT(YEAR FROM max(fecha))::int AS a FROM visordg.ventas_raw_dos)
SELECT EXTRACT(MONTH FROM v.fecha)::int AS mes,
       round(SUM(v.ventas) FILTER (WHERE EXTRACT(YEAR FROM v.fecha) = p.a - 1) / 1e6) AS anio_previo,
       round(SUM(v.ventas) FILTER (WHERE EXTRACT(YEAR FROM v.fecha) = p.a)     / 1e6) AS anio_actual
FROM visordg.ventas_raw_dos v, p
WHERE EXTRACT(YEAR FROM v.fecha) >= p.a - 1
GROUP BY 1 ORDER BY 1;

\echo '=== 2. VENTAS — tarjeta (acumulado enero -> último mes, y variación) ==='
WITH p AS (SELECT EXTRACT(YEAR FROM max(fecha))::int AS a, EXTRACT(MONTH FROM max(fecha))::int AS m
           FROM visordg.ventas_raw_dos),
t AS (SELECT SUM(ventas) FILTER (WHERE EXTRACT(YEAR FROM fecha) = p.a)     / 1e6 AS actual,
             SUM(ventas) FILTER (WHERE EXTRACT(YEAR FROM fecha) = p.a - 1) / 1e6 AS previo
      FROM visordg.ventas_raw_dos, p WHERE EXTRACT(MONTH FROM fecha) <= p.m)
SELECT round(actual) AS tarjeta_millones, round(previo) AS mismo_periodo_previo,
       round((actual / previo - 1) * 100, 1) AS variacion_pct
FROM t;

\echo '=== 3. VENTAS — ticker en modo mensual: mes en curso a MISMOS DÍAS ==='
WITH p AS (SELECT max(fecha) AS f, date_trunc('month', max(fecha))::date AS m0 FROM visordg.ventas_raw_dos)
SELECT to_char(p.f, 'DD/MM/YYYY') AS ultimo_dia_con_dato,
       round(SUM(v.ventas) FILTER (WHERE v.fecha BETWEEN p.m0 AND p.f) / 1e6) AS mes_actual,
       round(SUM(v.ventas) FILTER (WHERE v.fecha BETWEEN (p.m0 - INTERVAL '1 year')::date
                                                     AND (p.f - INTERVAL '1 year')::date) / 1e6) AS mismos_dias_previo,
       round((SUM(v.ventas) FILTER (WHERE v.fecha BETWEEN p.m0 AND p.f)
            / NULLIF(SUM(v.ventas) FILTER (WHERE v.fecha BETWEEN (p.m0 - INTERVAL '1 year')::date
                                                             AND (p.f - INTERVAL '1 year')::date), 0) - 1) * 100, 1) AS variacion_pct
FROM visordg.ventas_raw_dos v, p
GROUP BY p.f, p.m0;

\echo '=== 4. RECAUDACIÓN — línea del gráfico (millones USD por mes) ==='
WITH p AS (SELECT EXTRACT(YEAR FROM max(fecha))::int AS a FROM visordg.recaudacion_raw_dos)
SELECT EXTRACT(MONTH FROM r.fecha)::int AS mes,
       round(SUM(r.recaudado) FILTER (WHERE EXTRACT(YEAR FROM r.fecha) = p.a - 1) / 1e6) AS anio_previo,
       round(SUM(r.recaudado) FILTER (WHERE EXTRACT(YEAR FROM r.fecha) = p.a)     / 1e6) AS anio_actual
FROM visordg.recaudacion_raw_dos r, p
WHERE EXTRACT(YEAR FROM r.fecha) >= p.a - 1
GROUP BY 1 ORDER BY 1;

\echo '=== 5. RECAUDACIÓN — tarjeta y cumplimiento de meta (pantalla 4) ==='
\echo '    meta anual (millones USD, de [metas].meta_anual_recaudacion; 0 = sin meta):' :meta
WITH p AS (SELECT EXTRACT(YEAR FROM max(fecha))::int AS a, EXTRACT(MONTH FROM max(fecha))::int AS m
           FROM visordg.recaudacion_raw_dos),
t AS (SELECT SUM(recaudado) FILTER (WHERE EXTRACT(YEAR FROM fecha) = p.a)     / 1e6 AS actual,
             SUM(recaudado) FILTER (WHERE EXTRACT(YEAR FROM fecha) = p.a - 1) / 1e6 AS previo
      FROM visordg.recaudacion_raw_dos, p WHERE EXTRACT(MONTH FROM fecha) <= p.m)
SELECT round(actual) AS tarjeta_millones, round(previo) AS mismo_periodo_previo,
       round((actual / previo - 1) * 100, 1) AS variacion_pct,
       round(actual / NULLIF(:meta, 0) * 100, 1) AS cumplimiento_meta_pct
FROM t;

\echo '=== 5b. META DE RECAUDACIÓN (pantalla 4) ==='
\echo '    Avance = recaudación / meta x 100. Acumulado: 1 de enero -> FECHA DE CORTE (no mes cerrado).'
\echo '    Meta anual = suma de visordg.meta_recaudacion del año; si no hay filas, :meta del settings.'
WITH p AS (SELECT max(fecha) AS fmax, EXTRACT(YEAR FROM max(fecha))::int AS a,
                  EXTRACT(MONTH FROM max(fecha))::int AS m FROM visordg.recaudacion_raw_dos),
r AS (SELECT p.a, p.m, p.fmax,
             SUM(x.recaudado) FILTER (WHERE x.fecha >= make_date(p.a, 1, 1)) / 1e6       AS acum,
             SUM(x.recaudado) FILTER (WHERE x.fecha >= date_trunc('month', p.fmax)) / 1e6 AS mes
      FROM visordg.recaudacion_raw_dos x, p GROUP BY p.a, p.m, p.fmax),
t AS (SELECT SUM(valor_meta) / 1e6 AS anual_tabla,
             SUM(valor_meta) FILTER (WHERE mes = (SELECT m FROM r)) / 1e6 AS del_mes
      FROM visordg.meta_recaudacion WHERE anio = (SELECT a FROM r))
SELECT to_char(r.fmax, 'DD/MM/YYYY') AS fecha_corte, round(r.acum) AS acumulado,
       round(COALESCE(t.anual_tabla, NULLIF(:meta, 0))) AS meta_anual,
       CASE WHEN t.anual_tabla IS NOT NULL THEN 'tabla' WHEN :meta > 0 THEN 'settings' END AS fuente_meta,
       round(r.acum / NULLIF(COALESCE(t.anual_tabla, :meta), 0) * 100, 1) AS avance_anual_pct,
       round(COALESCE(t.anual_tabla, NULLIF(:meta, 0)) - r.acum) AS falta_anual,
       round(r.mes) AS mes_en_curso, round(t.del_mes) AS meta_del_mes,
       round(r.mes / NULLIF(t.del_mes, 0) * 100, 1) AS avance_mes_pct
FROM r, t;

\echo '=== 6. BRIGADAS — EVENTOS (brigadas realizadas) por mes y acumulado ==='
WITH p AS (SELECT max(anio) AS a FROM visordg.brigadas_eventos),
m AS (SELECT max(mes) AS m FROM visordg.brigadas_eventos, p WHERE anio = p.a)
SELECT e.mes,
       SUM(e.eventos) FILTER (WHERE e.anio = p.a - 1) AS anio_previo,
       SUM(e.eventos) FILTER (WHERE e.anio = p.a)     AS anio_actual,
       SUM(SUM(e.eventos) FILTER (WHERE e.anio = p.a)) OVER (ORDER BY e.mes) AS acumulado_actual
FROM visordg.brigadas_eventos e, p, m
WHERE e.anio >= p.a - 1 AND e.mes <= m.m
GROUP BY e.mes ORDER BY e.mes;

\echo '=== 7. BRIGADAS — PERSONAS ATENDIDAS por mes y acumulado (Shift+Alt+Q) ==='
WITH p AS (SELECT max(anio) AS a FROM visordg.brigadas_atendidos),
m AS (SELECT max(mes) AS m FROM visordg.brigadas_atendidos, p WHERE anio = p.a)
SELECT a.mes,
       SUM(a.atendidos) FILTER (WHERE a.anio = p.a - 1) AS anio_previo,
       SUM(a.atendidos) FILTER (WHERE a.anio = p.a)     AS anio_actual,
       SUM(SUM(a.atendidos) FILTER (WHERE a.anio = p.a)) OVER (ORDER BY a.mes) AS acumulado_actual
FROM visordg.brigadas_atendidos a, p, m
WHERE a.anio >= p.a - 1 AND a.mes <= m.m
GROUP BY a.mes ORDER BY a.mes;

\echo '=== 8. CAPACITACIONES — EVENTOS (lo que dibuja el gráfico) y CAPACITADOS ==='
WITH p AS (SELECT EXTRACT(YEAR FROM max(fecha))::int AS a, EXTRACT(MONTH FROM max(fecha))::int AS m
           FROM visordg.capacitaciones_raw)
SELECT EXTRACT(MONTH FROM c.fecha)::int AS mes,
       COUNT(*) FILTER (WHERE EXTRACT(YEAR FROM c.fecha) = p.a - 1)               AS eventos_previo,
       COUNT(*) FILTER (WHERE EXTRACT(YEAR FROM c.fecha) = p.a)                   AS eventos_actual,
       SUM(c.total_capacitados) FILTER (WHERE EXTRACT(YEAR FROM c.fecha) = p.a - 1) AS capacitados_previo,
       SUM(c.total_capacitados) FILTER (WHERE EXTRACT(YEAR FROM c.fecha) = p.a)     AS capacitados_actual
FROM visordg.capacitaciones_raw c, p
WHERE EXTRACT(YEAR FROM c.fecha) >= p.a - 1 AND EXTRACT(MONTH FROM c.fecha) <= p.m
GROUP BY 1 ORDER BY 1;

\echo '=== 9. FECHA DE CORTE de cada tarjeta (precalculada en hist_*.fecha_corte, la lee la API) ==='
SELECT fuente, to_char(fecha_corte, 'DD/MM/YYYY') AS fecha_corte, archivo,
       to_char(archivo_modificado AT TIME ZONE 'America/Guayaquil', 'DD/MM/YYYY HH24:MI') AS archivo_modificado
FROM visordg.v_fecha_corte;

\echo '=== 9a. CORTE LABORABLE de brigadas y capacitaciones ([monitor].corte_mensual = "laborable") ==='
SELECT to_char((now() AT TIME ZONE 'America/Guayaquil')::date, 'DD/MM/YYYY') AS hoy,
       to_char(visordg.ultimo_dia_laborable(), 'DD/MM/YYYY')               AS ultimo_dia_laborable,
       (SELECT string_agg(to_char(fecha_feriado, 'DD/MM'), ', ' ORDER BY fecha_feriado)
          FROM visordg.feriados WHERE anio = EXTRACT(YEAR FROM now())) AS feriados_del_anio;

\echo '=== 9b. CONTROL fecha de corte: hist_* vs tabla cruda (debe salir 0 en todas) ==='
SELECT 'ventas' AS fuente, count(*) AS anios_con_diferencia
FROM (SELECT EXTRACT(YEAR FROM fecha)::int a, MAX(fecha) f FROM visordg.ventas_raw_dos GROUP BY 1) r
LEFT JOIN (SELECT DISTINCT EXTRACT(YEAR FROM mes)::int a, fecha_corte FROM visordg.hist_ventas) h USING (a)
WHERE h.fecha_corte IS DISTINCT FROM r.f
UNION ALL
SELECT 'recaudacion', count(*)
FROM (SELECT EXTRACT(YEAR FROM fecha)::int a, MAX(fecha) f FROM visordg.recaudacion_raw_dos GROUP BY 1) r
LEFT JOIN (SELECT DISTINCT EXTRACT(YEAR FROM mes)::int a, fecha_corte FROM visordg.hist_recaudacion) h USING (a)
WHERE h.fecha_corte IS DISTINCT FROM r.f
UNION ALL
SELECT 'capacitaciones', count(*)
FROM (SELECT EXTRACT(YEAR FROM fecha)::int a, MAX(fecha)::date f FROM visordg.capacitaciones_raw GROUP BY 1) r
LEFT JOIN (SELECT DISTINCT EXTRACT(YEAR FROM mes)::int a, fecha_corte FROM visordg.hist_capacitaciones) h USING (a)
WHERE h.fecha_corte IS DISTINCT FROM r.f
UNION ALL
SELECT 'brigadas (años sin fecha de archivo)', count(DISTINCT EXTRACT(YEAR FROM mes))
FROM visordg.hist_brigadas WHERE fecha_corte IS NULL;

\echo '=== 9c. Historial de archivos cargados por año ==='
SELECT DISTINCT ON (fuente, anio) fuente, anio, nombre_archivo,
       to_char(archivo_modificado AT TIME ZONE 'America/Guayaquil', 'DD/MM/YYYY HH24:MI') AS archivo_modificado,
       to_char(cargado_en, 'DD/MM/YYYY HH24:MI') AS cargado_en,
       filas_ok
FROM visordg.cargas_archivo
WHERE anio IS NOT NULL AND estado = 'OK'
ORDER BY fuente, anio DESC, cargado_en DESC;

\echo '=== 10. CONTROL: lo que el panel lee (hist_*) debe ser igual a la fuente ==='
SELECT 'ventas' AS indicador, count(*) AS meses_con_diferencia
FROM visordg.hist_ventas h
JOIN (SELECT date_trunc('month', fecha)::date AS mes, SUM(ventas) / 1e6 AS v FROM visordg.ventas_raw_dos GROUP BY 1) f
  ON f.mes = h.mes WHERE abs(h.ventas - f.v) > 0.000001
UNION ALL
SELECT 'recaudacion', count(*) FROM visordg.hist_recaudacion h
JOIN (SELECT date_trunc('month', fecha)::date AS mes, SUM(recaudado) / 1e6 AS v FROM visordg.recaudacion_raw_dos GROUP BY 1) f
  ON f.mes = h.mes WHERE abs(h.recaudacion - f.v) > 0.000001
UNION ALL
SELECT 'brigadas', count(*) FROM visordg.hist_brigadas h
JOIN (SELECT make_date(anio, mes, 1) AS mes, SUM(eventos) AS v FROM visordg.brigadas_eventos GROUP BY 1) f
  ON f.mes = h.mes WHERE h.brigadas <> f.v
UNION ALL
SELECT 'capacitaciones', count(*) FROM visordg.hist_capacitaciones h
JOIN (SELECT date_trunc('month', fecha)::date AS mes, COUNT(*) AS v FROM visordg.capacitaciones_raw GROUP BY 1) f
  ON f.mes = h.mes WHERE h.capacitaciones <> f.v;
\echo '    (todas deben dar 0; si no, correr: pdm run refrescar)'
