BEGIN;

DO $$
DECLARE r record;
BEGIN
    FOR r IN SELECT * FROM (VALUES
        ('dash_mes_corriente',    'ventas_2024',         'ventas_hace_dos_anios'),
        ('dash_mes_corriente',    'ventas_2025',         'ventas_anio_anterior'),
        ('dash_mes_corriente',    'ventas',              'ventas_anio_actual'),
        ('dash_mes_corriente',    'recaudacion_2025',    'recaudacion_anio_anterior'),
        ('dash_mes_corriente',    'recaudacion',         'recaudacion_anio_actual'),
        ('dash_mes_corriente',    'brigadas_2025',       'brigadas_anio_anterior'),
        ('dash_mes_corriente',    'brigadas',            'brigadas_anio_actual'),
        ('dash_mes_corriente',    'capacitaciones_2025', 'capacitaciones_anio_anterior'),
        ('dash_mes_corriente',    'capacitaciones',      'capacitaciones_anio_actual'),
        ('dash_ventas_provincia', 'v2024',               'hace_dos_anios'),
        ('dash_ventas_provincia', 'v2025',               'anio_anterior'),
        ('dash_ventas_provincia', 'v2026',               'anio_actual')
    ) AS t(tabla, viejo, nuevo)
    LOOP
        IF EXISTS (SELECT 1 FROM information_schema.columns
                   WHERE table_schema = 'visordg' AND table_name = r.tabla AND column_name = r.viejo)
           AND NOT EXISTS (SELECT 1 FROM information_schema.columns
                   WHERE table_schema = 'visordg' AND table_name = r.tabla AND column_name = r.nuevo) THEN
            EXECUTE format('ALTER TABLE visordg.%I RENAME COLUMN %I TO %I', r.tabla, r.viejo, r.nuevo);
        END IF;
    END LOOP;
END $$;

COMMIT;
