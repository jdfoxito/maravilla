BEGIN;

ALTER TABLE visordg.hist_ventas         ADD COLUMN IF NOT EXISTS fecha_corte DATE;
ALTER TABLE visordg.hist_recaudacion    ADD COLUMN IF NOT EXISTS fecha_corte DATE;
ALTER TABLE visordg.hist_capacitaciones ADD COLUMN IF NOT EXISTS fecha_corte DATE;
ALTER TABLE visordg.hist_brigadas       ADD COLUMN IF NOT EXISTS fecha_corte DATE;

COMMENT ON COLUMN visordg.hist_ventas.fecha_corte         IS 'Último día con dato de ventas de ese año (MAX(fecha) de ventas_raw_dos). Lo llena el 05.';
COMMENT ON COLUMN visordg.hist_recaudacion.fecha_corte    IS 'Último día con dato de recaudación de ese año (AÑO+MES+DIA). Lo llena el 05.';
COMMENT ON COLUMN visordg.hist_capacitaciones.fecha_corte IS 'Última FECHA CAPACITACION de ese año. Lo llena el 05.';
COMMENT ON COLUMN visordg.hist_brigadas.fecha_corte       IS 'Fecha de modificación del Excel de brigadas de ese año (hora Ecuador). Lo llena el 05.';

CREATE OR REPLACE VIEW visordg.v_fecha_corte AS
SELECT 'ventas'::text AS fuente, h.fecha_corte, h.archivo, h.archivo_modificado
FROM (SELECT fecha_corte, archivo, archivo_modificado, mes FROM visordg.hist_ventas WHERE fecha_corte IS NOT NULL
      ORDER BY fecha_corte DESC, mes DESC LIMIT 1) h
UNION ALL
SELECT 'recaudacion', h.fecha_corte, h.archivo, h.archivo_modificado
FROM (SELECT fecha_corte, archivo, archivo_modificado, mes FROM visordg.hist_recaudacion WHERE fecha_corte IS NOT NULL
      ORDER BY fecha_corte DESC, mes DESC LIMIT 1) h
UNION ALL
SELECT 'brigadas', h.fecha_corte, h.archivo, h.archivo_modificado
FROM (SELECT fecha_corte, archivo, archivo_modificado, mes FROM visordg.hist_brigadas WHERE fecha_corte IS NOT NULL
      ORDER BY fecha_corte DESC, mes DESC LIMIT 1) h
UNION ALL
SELECT 'capacitaciones', h.fecha_corte, h.archivo, h.archivo_modificado
FROM (SELECT fecha_corte, archivo, archivo_modificado, mes FROM visordg.hist_capacitaciones WHERE fecha_corte IS NOT NULL
      ORDER BY fecha_corte DESC, mes DESC LIMIT 1) h;

COMMENT ON VIEW visordg.v_fecha_corte IS 'Fecha de corte por fuente (la usa /tv-data). Precalculada por 05_refrescar_dos.sql.';

DO $$
DECLARE c record;
BEGIN
    FOR c IN
        SELECT con.conname
        FROM pg_constraint con
        WHERE con.conrelid = 'visordg.brigadas_atendidos'::regclass
          AND con.contype = 'u'
          AND (SELECT array_agg(att.attname::text ORDER BY att.attname)
               FROM unnest(con.conkey) k
               JOIN pg_attribute att ON att.attrelid = con.conrelid AND att.attnum = k)
              = ARRAY['agencia', 'anio', 'mes']
    LOOP
        EXECUTE format('ALTER TABLE visordg.brigadas_atendidos DROP CONSTRAINT %I', c.conname);
        RAISE NOTICE 'brigadas_atendidos: se quitó la clave vieja %', c.conname;
    END LOOP;

    IF NOT EXISTS (SELECT 1 FROM pg_constraint
                   WHERE conname = 'brigadas_atendidos_prov_agencia_anio_mes_key') THEN
        ALTER TABLE visordg.brigadas_atendidos
            ADD CONSTRAINT brigadas_atendidos_prov_agencia_anio_mes_key
            UNIQUE (provincia, agencia, anio, mes);
    END IF;
END $$;

COMMIT;
