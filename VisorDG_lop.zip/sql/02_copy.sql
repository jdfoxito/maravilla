-- =============================================================
-- CARGA DE FUENTES | psql -U postgres -d detalles -f 02_copy.sql
-- =============================================================
-- \copy es un comando de psql (cliente); la ruta es la de TU PC.
-- IMPORTANTE: el nombre del archivo SIN tilde (BDD_Recaudacion_Jul26.csv)
-- porque la consola de Windows corrompe las tildes en la ruta.
-- =============================================================

-- -----------------------------------------------------------
-- BDD_Recaudacion_Jul26.csv  ->  visordg.recaudacion_raw
-- FECHA: AAAAMMDD (texto -> date)
-- RECAUDADO: puede venir con separador de miles '2.438.379'
--            -> se quitan los puntos antes de convertir a numeric
-- -----------------------------------------------------------
BEGIN;

CREATE TEMP TABLE stg_recaudacion (
    ae_codigo_familia TEXT,
    ae_codigo_grupo   TEXT,
    cod_n6            TEXT,
    fecha             TEXT,
    impuesto_pk       TEXT,
    provincia         TEXT,
    gc                TEXT,
    pago              TEXT,
    m_fuente          TEXT,
    carga             TEXT,
    recaudado         TEXT
);

\copy stg_recaudacion FROM 'D:/sri/soluciones/DG/VisorDG/data/input/BDD_Recaudacion_Jul26.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');

INSERT INTO visordg.recaudacion_raw (
    ae_codigo_familia, ae_codigo_grupo, cod_n6, fecha, impuesto_pk,
    provincia, gc, pago, m_fuente, carga, recaudado
)
SELECT
    ae_codigo_familia, ae_codigo_grupo, cod_n6,
    to_date(fecha, 'YYYYMMDD'),
    NULLIF(impuesto_pk, '')::int,
    provincia, gc, pago, m_fuente, carga,
    -- '2.438.379' -> 2438379 | '1.234,56' -> 1234.56 | '419' -> 419
    COALESCE(NULLIF(replace(replace(recaudado, '.', ''), ',', '.'), '')::numeric, 0)
FROM stg_recaudacion;

INSERT INTO visordg.cargas_archivo (fuente, nombre_archivo, filas_ok, estado)
SELECT 'recaudacion', 'BDD_Recaudacion_Jul26.csv', count(*), 'OK'
FROM stg_recaudacion;

COMMIT;

-- -----------------------------------------------------------
-- Excel (catálogo, capacitaciones, brigadas): \copy NO lee Excel.
-- Usa el cargador Python (lee settings.toml, no requiere nada más):
--
--    cd D:\sri\soluciones\DG\VisorDG\app\backend
--    pdm run cargar catalogo       "..\..\data\input\Catalogo_Recaudación.xlsx"
--    pdm run cargar capacitaciones "..\..\data\input\Capacitaciones enero a sep 2026.xls"
--    pdm run cargar brigadas       "..\..\data\input\Atenciones_brigadas.xlsx" 2026
--
-- Después de cargar, refresca las tablas del visor:
--    psql -U postgres -d detalles -f D:\sri\soluciones\DG\VisorDG\sql\03_refrescar_visor.sql
-- -----------------------------------------------------------
