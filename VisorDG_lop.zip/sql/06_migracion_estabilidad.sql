BEGIN;

ALTER TABLE visordg.brigadas_atendidos
    DROP CONSTRAINT IF EXISTS brigadas_atendidos_agencia_anio_mes_key;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint
                   WHERE conname = 'brigadas_atendidos_prov_agencia_anio_mes_key') THEN
        ALTER TABLE visordg.brigadas_atendidos
            ADD CONSTRAINT brigadas_atendidos_prov_agencia_anio_mes_key
            UNIQUE (provincia, agencia, anio, mes);
    END IF;
END $$;

COMMIT;
