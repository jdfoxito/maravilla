-- =============================================================
-- FUENTE VENTAS: tabla cruda + carga del CSV mensual
--   Archivo : D:\sri\soluciones\DG\VisorDG\data\input\Ago2026.csv
--   Columnas: Fecha (yyyymmdd), Provincia, Codigo_Sector,
--             Contri_tipo, Ventas ("4.443.262,7" -> formato EC)
--   ~76.191 filas; cubre ago-2024 en adelante (mensual, día 01).
-- Uso:
--   psql -U postgres -d detalles -f 04_ventas.sql
-- Es re-ejecutable: limpia ventas_raw y vuelve a copiar.
-- =============================================================

BEGIN;

CREATE TABLE IF NOT EXISTS visordg.ventas_raw (
    id            BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    fecha         DATE NOT NULL,
    provincia     TEXT NOT NULL,
    codigo_sector TEXT,
    contri_tipo   TEXT,
    ventas        NUMERIC(18,2) NOT NULL DEFAULT 0,
    cargado_en    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_ventas_fecha     ON visordg.ventas_raw (fecha);
CREATE INDEX IF NOT EXISTS ix_ventas_provincia ON visordg.ventas_raw (provincia);

-- Staging todo-TEXT: el CSV trae números con formato ecuatoriano
-- (miles con '.', decimales con ',') que hay que normalizar.
CREATE TEMP TABLE stg_ventas (
    fecha TEXT, provincia TEXT, codigo_sector TEXT, contri_tipo TEXT, ventas TEXT
) ON COMMIT DROP;

COPY stg_ventas FROM 'D:/sri/soluciones/DG/VisorDG/data/input/Ago2026.csv'
    WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
-- Si falla por codificación (CAÑAR, tildes), cambiar ENCODING a 'WIN1252'.

TRUNCATE visordg.ventas_raw;

INSERT INTO visordg.ventas_raw (fecha, provincia, codigo_sector, contri_tipo, ventas)
SELECT to_date(fecha, 'YYYYMMDD'),
       upper(trim(provincia)),
       nullif(trim(codigo_sector), ''),
       nullif(trim(contri_tipo), ''),
       COALESCE(NULLIF(replace(replace(ventas, '.', ''), ',', '.'), '')::numeric, 0)
FROM stg_ventas
WHERE fecha ~ '^\d{8}$';          -- descarta filas sin fecha válida

INSERT INTO visordg.cargas_archivo (fuente, nombre_archivo, filas_ok, estado)
SELECT 'ventas', 'Ago2026.csv', COUNT(*), 'OK' FROM stg_ventas;

UPDATE visordg.visor_refresh SET actualizado_en = now() WHERE id = 1;

COMMIT;

-- Recordatorio: tras este script correr SIEMPRE el refresco:
--   psql -U postgres -d detalles -f 03_refrescar_visor.sql
