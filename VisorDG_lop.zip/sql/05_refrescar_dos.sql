\if :{?anio_actual}
\else
  \set anio_actual 0
\endif

BEGIN;

ALTER TABLE visordg.cargas_archivo      ADD COLUMN IF NOT EXISTS anio SMALLINT,
                                        ADD COLUMN IF NOT EXISTS archivo_modificado TIMESTAMPTZ,
                                        ADD COLUMN IF NOT EXISTS total_declarado NUMERIC,
                                        ADD COLUMN IF NOT EXISTS total_cargado NUMERIC;
ALTER TABLE visordg.hist_ventas         ADD COLUMN IF NOT EXISTS archivo TEXT, ADD COLUMN IF NOT EXISTS archivo_modificado TIMESTAMPTZ;
ALTER TABLE visordg.hist_recaudacion    ADD COLUMN IF NOT EXISTS archivo TEXT, ADD COLUMN IF NOT EXISTS archivo_modificado TIMESTAMPTZ;
ALTER TABLE visordg.hist_brigadas       ADD COLUMN IF NOT EXISTS archivo TEXT, ADD COLUMN IF NOT EXISTS archivo_modificado TIMESTAMPTZ,
                                        ADD COLUMN IF NOT EXISTS total_declarado INTEGER;
ALTER TABLE visordg.hist_capacitaciones ADD COLUMN IF NOT EXISTS archivo TEXT, ADD COLUMN IF NOT EXISTS archivo_modificado TIMESTAMPTZ,
                                        ADD COLUMN IF NOT EXISTS total_declarado INTEGER;
ALTER TABLE visordg.hist_ventas         ADD COLUMN IF NOT EXISTS fecha_corte DATE;
ALTER TABLE visordg.hist_recaudacion    ADD COLUMN IF NOT EXISTS fecha_corte DATE;
ALTER TABLE visordg.hist_brigadas       ADD COLUMN IF NOT EXISTS fecha_corte DATE;
ALTER TABLE visordg.hist_capacitaciones ADD COLUMN IF NOT EXISTS fecha_corte DATE;

DO $$
DECLARE r record;
BEGIN
    FOR r IN SELECT * FROM (VALUES
        ('dash_mes_corriente',    'ventas_2024',         'ventas_hace_dos_anios'),
        ('dash_mes_corriente',    'ventas_2025',         'ventas_anio_anterior'),
        ('dash_mes_corriente',    'ventas',              'ventas_anio_actual'),
        ('dash_mes_corriente',    'recaudacion_2025',    'recaudacion_anio_anterior'),
        ('dash_mes_corriente',    'recaudacion',         'recaudacion_anio_actual'),
        ('dash_mes_corriente',    'brigadas_2025',       'brigadas_anio_anterior'),
        ('dash_mes_corriente',    'brigadas',            'brigadas_anio_actual'),
        ('dash_mes_corriente',    'capacitaciones_2025', 'capacitaciones_anio_anterior'),
        ('dash_mes_corriente',    'capacitaciones',      'capacitaciones_anio_actual'),
        ('dash_ventas_provincia', 'v2024',               'hace_dos_anios'),
        ('dash_ventas_provincia', 'v2025',               'anio_anterior'),
        ('dash_ventas_provincia', 'v2026',               'anio_actual')
    ) AS t(tabla, viejo, nuevo)
    LOOP
        IF EXISTS (SELECT 1 FROM information_schema.columns
                   WHERE table_schema = 'visordg' AND table_name = r.tabla AND column_name = r.viejo)
           AND NOT EXISTS (SELECT 1 FROM information_schema.columns
                   WHERE table_schema = 'visordg' AND table_name = r.tabla AND column_name = r.nuevo) THEN
            EXECUTE format('ALTER TABLE visordg.%I RENAME COLUMN %I TO %I', r.tabla, r.viejo, r.nuevo);
        END IF;
    END LOOP;
END $$;

CREATE TEMP TABLE _p ON COMMIT DROP AS
WITH v AS (SELECT max(fecha) AS fmax FROM visordg.ventas_raw_dos)
SELECT a.anio_actual,
       a.anio_actual - 1                                   AS anio_prev,
       a.anio_actual - 2                                   AS anio_prev2,
       COALESCE(date_trunc('month', v.fmax)::date, make_date(a.anio_actual, 1, 1)) AS m0,
       EXTRACT(DAY FROM (COALESCE(date_trunc('month', v.fmax), make_date(a.anio_actual, 1, 1))
                         + INTERVAL '1 month - 1 day'))::int AS dia_fin_mes
FROM v,
     LATERAL (SELECT COALESCE(NULLIF(:anio_actual, 0),
                              EXTRACT(YEAR FROM v.fmax)::int,
                              EXTRACT(YEAR FROM current_date)::int) AS anio_actual) a;

DELETE FROM visordg.hist_ventas WHERE EXISTS (SELECT 1 FROM visordg.ventas_raw_dos);
INSERT INTO visordg.hist_ventas (mes, ventas, fecha_corte, cargado_en)
SELECT mes, valor, MAX(fmax) OVER (PARTITION BY EXTRACT(YEAR FROM mes)), now()
FROM (SELECT date_trunc('month', fecha)::date AS mes, SUM(ventas) / 1e6 AS valor, MAX(fecha) AS fmax
      FROM visordg.ventas_raw_dos GROUP BY 1) t;

DELETE FROM visordg.hist_recaudacion WHERE EXISTS (SELECT 1 FROM visordg.recaudacion_raw_dos);
INSERT INTO visordg.hist_recaudacion (mes, recaudacion, fecha_corte, cargado_en)
SELECT mes, valor, MAX(fmax) OVER (PARTITION BY EXTRACT(YEAR FROM mes)), now()
FROM (SELECT date_trunc('month', fecha)::date AS mes, SUM(recaudado) / 1e6 AS valor, MAX(fecha) AS fmax
      FROM visordg.recaudacion_raw_dos GROUP BY 1) t;

DELETE FROM visordg.hist_brigadas WHERE EXISTS (SELECT 1 FROM visordg.brigadas_eventos);
INSERT INTO visordg.hist_brigadas (mes, brigadas, cargado_en)
SELECT make_date(anio, mes, 1), SUM(eventos), now()
FROM visordg.brigadas_eventos GROUP BY 1;

DELETE FROM visordg.hist_capacitaciones WHERE EXISTS (SELECT 1 FROM visordg.capacitaciones_raw);
INSERT INTO visordg.hist_capacitaciones (mes, capacitaciones, fecha_corte, cargado_en)
SELECT mes, valor, MAX(fmax) OVER (PARTITION BY EXTRACT(YEAR FROM mes)), now()
FROM (SELECT date_trunc('month', fecha)::date AS mes, COUNT(*) AS valor, MAX(fecha)::date AS fmax
      FROM visordg.capacitaciones_raw GROUP BY 1) t;

CREATE TEMP TABLE _archivo ON COMMIT DROP AS
SELECT DISTINCT ON (fuente, anio) fuente, anio, nombre_archivo, archivo_modificado, total_declarado
FROM visordg.cargas_archivo
WHERE anio IS NOT NULL AND estado = 'OK'
ORDER BY fuente, anio, cargado_en DESC;

UPDATE visordg.hist_ventas h SET archivo = a.nombre_archivo, archivo_modificado = a.archivo_modificado
FROM _archivo a WHERE a.fuente = 'ventas_dos' AND a.anio = EXTRACT(YEAR FROM h.mes);
UPDATE visordg.hist_recaudacion h SET archivo = a.nombre_archivo, archivo_modificado = a.archivo_modificado
FROM _archivo a WHERE a.fuente = 'recaudacion_dos' AND a.anio = EXTRACT(YEAR FROM h.mes);
UPDATE visordg.hist_brigadas h SET archivo = a.nombre_archivo, archivo_modificado = a.archivo_modificado,
                                   total_declarado = a.total_declarado,
                                   fecha_corte = (a.archivo_modificado AT TIME ZONE 'America/Guayaquil')::date
FROM _archivo a WHERE a.fuente = 'brigadas' AND a.anio = EXTRACT(YEAR FROM h.mes);
UPDATE visordg.hist_capacitaciones h SET archivo = a.nombre_archivo, archivo_modificado = a.archivo_modificado,
                                         total_declarado = a.total_declarado
FROM _archivo a WHERE a.fuente = 'capacitaciones' AND a.anio = EXTRACT(YEAR FROM h.mes);

DELETE FROM visordg.dash_mes_corriente;

WITH
dias AS (
    SELECT v.fecha, EXTRACT(DAY FROM v.fecha)::int AS dia
    FROM visordg.ventas_raw_dos v, _p
    WHERE date_trunc('month', v.fecha) = _p.m0
    GROUP BY v.fecha
),
vnt AS (
    SELECT (EXTRACT(YEAR FROM v.fecha)::int) AS anio,
           LEAST(EXTRACT(DAY FROM v.fecha)::int, _p.dia_fin_mes) AS dia,
           SUM(v.ventas) / 1e6 AS valor
    FROM visordg.ventas_raw_dos v, _p
    WHERE date_trunc('month', v.fecha) IN (_p.m0, (_p.m0 - INTERVAL '1 year')::date, (_p.m0 - INTERVAL '2 years')::date)
    GROUP BY 1, 2
),
rec_hay AS (
    SELECT EXISTS (SELECT 1 FROM visordg.recaudacion_raw_dos r, _p
                   WHERE date_trunc('month', r.fecha) = _p.m0) AS si
),
rec AS (
    SELECT (EXTRACT(YEAR FROM r.fecha)::int) AS anio,
           LEAST(EXTRACT(DAY FROM r.fecha)::int, _p.dia_fin_mes) AS dia,
           SUM(r.recaudado) / 1e6 AS valor
    FROM visordg.recaudacion_raw_dos r, _p, rec_hay
    WHERE rec_hay.si
      AND date_trunc('month', r.fecha) IN (_p.m0, (_p.m0 - INTERVAL '1 year')::date)
    GROUP BY 1, 2
),
brig AS (
    SELECT anio, SUM(eventos) AS valor
    FROM visordg.brigadas_eventos, _p
    WHERE mes = EXTRACT(MONTH FROM _p.m0) AND anio IN (_p.anio_actual, _p.anio_prev)
    GROUP BY anio
),
cap AS (
    SELECT EXTRACT(YEAR FROM fecha)::int AS anio, COUNT(*) AS valor
    FROM visordg.capacitaciones_raw, _p
    WHERE date_trunc('month', fecha) IN (_p.m0, (_p.m0 - INTERVAL '1 year')::date)
    GROUP BY 1
)
INSERT INTO visordg.dash_mes_corriente (
    fecha, ventas_hace_dos_anios, ventas_anio_anterior, ventas_anio_actual,
    recaudacion_anio_anterior, recaudacion_anio_actual,
    brigadas_anio_anterior, brigadas_anio_actual,
    capacitaciones_anio_anterior, capacitaciones_anio_actual, cargado_en)
SELECT d.fecha,
       COALESCE(v2.valor, 0),
       COALESCE(v1.valor, 0),
       COALESCE(v0.valor, 0),
       COALESCE(r1.valor, 0),
       COALESCE(r0.valor, 0),
       COALESCE(b1.valor, 0), COALESCE(b0.valor, 0),
       COALESCE(c1.valor, 0), COALESCE(c0.valor, 0),
       now()
FROM dias d CROSS JOIN _p
LEFT JOIN vnt v0 ON v0.anio = _p.anio_actual AND v0.dia = d.dia
LEFT JOIN vnt v1 ON v1.anio = _p.anio_prev   AND v1.dia = d.dia
LEFT JOIN vnt v2 ON v2.anio = _p.anio_prev2  AND v2.dia = d.dia
LEFT JOIN rec r0 ON r0.anio = _p.anio_actual AND r0.dia = d.dia
LEFT JOIN rec r1 ON r1.anio = _p.anio_prev   AND r1.dia = d.dia
LEFT JOIN brig b0 ON b0.anio = _p.anio_actual
LEFT JOIN brig b1 ON b1.anio = _p.anio_prev
LEFT JOIN cap  c0 ON c0.anio = _p.anio_actual
LEFT JOIN cap  c1 ON c1.anio = _p.anio_prev;

DELETE FROM visordg.dash_ventas_provincia WHERE EXISTS (SELECT 1 FROM visordg.ventas_raw_dos);
INSERT INTO visordg.dash_ventas_provincia (periodo, provincia, hace_dos_anios, anio_anterior, anio_actual, cargado_en)
SELECT to_char(_p.m0, 'YYYY-MM'), upper(btrim(v.provincia)),
       COALESCE(SUM(v.ventas) FILTER (WHERE date_trunc('month', v.fecha) = _p.m0 - INTERVAL '2 years'), 0) / 1e6,
       COALESCE(SUM(v.ventas) FILTER (WHERE date_trunc('month', v.fecha) = _p.m0 - INTERVAL '1 year'), 0) / 1e6,
       COALESCE(SUM(v.ventas) FILTER (WHERE date_trunc('month', v.fecha) = _p.m0), 0) / 1e6,
       now()
FROM visordg.ventas_raw_dos v CROSS JOIN _p
WHERE v.fecha >= (_p.m0 - INTERVAL '2 years')::date
GROUP BY 1, 2;

UPDATE visordg.visor_refresh SET actualizado_en = now() WHERE id = 1;

COMMIT;
