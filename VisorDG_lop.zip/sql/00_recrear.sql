-- =============================================================
-- RECREAR ESQUEMA visordg DESDE CERO (borra TODO lo que tenga)
-- psql -U postgres -d detalles -f 00_recrear.sql
-- y luego:  psql -U postgres -d detalles -f 01_esquema_visordg.sql
-- =============================================================
DROP SCHEMA IF EXISTS visordg CASCADE;
-- La seguridad (seg) NO se borra: usuarios y auditoría sobreviven.
