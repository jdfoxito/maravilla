import asyncio
import csv
import os
import re
import shutil
import subprocess
import unicodedata
from datetime import date, datetime, timezone
from io import StringIO
from pathlib import Path

import asyncpg
import click
import pandas as pd

from config import cargar_settings, construir_dsn

SETTINGS = cargar_settings()
PG_DSN = construir_dsn(SETTINGS)
RUTA_SQL = Path(__file__).resolve().parents[2] / "sql"
ORIGENES = ("local", "fileserver")

MIN_FILAS_VALIDAS = 10

MESES = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
         "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]

def leer_hoja(ruta: str, hoja: str | int, encabezado: int = 0) -> pd.DataFrame:
    frame = pd.read_excel(ruta, sheet_name=hoja, header=encabezado)
    frame.columns = [str(c).strip() for c in frame.columns]
    return frame.dropna(how="all")

def texto(valor) -> str:
    if valor is None or (isinstance(valor, float) and pd.isna(valor)):
        return ""
    return str(valor).strip()

def anio_declarado(ruta: str, hoja: str, max_filas: int = 8) -> int | None:
    crudo = pd.read_excel(ruta, sheet_name=hoja, header=None, nrows=max_filas)
    for _, fila in crudo.iterrows():
        celdas = [texto(c) for c in fila]
        linea = " ".join(c for c in celdas if c)
        hallado = re.search(r"a[ñn]o\D{0,3}(20\d{2})", linea, re.IGNORECASE)
        if hallado:
            return int(hallado.group(1))
    return None

_ISO = re.compile(r"^\d{4}-\d{1,2}-\d{1,2}")

def fecha_robusta(valor):
    try:
        if valor is None or pd.isna(valor):
            return None
    except (TypeError, ValueError):
        pass
    if isinstance(valor, (pd.Timestamp, datetime, date)):
        return pd.Timestamp(valor)
    if isinstance(valor, (int, float)) and not isinstance(valor, bool):
        return pd.Timestamp("1899-12-30") + pd.Timedelta(days=float(valor)) if 20000 < valor < 80000 else None
    texto = str(valor).strip()
    if not texto:
        return None
    if _ISO.match(texto):
        f = pd.to_datetime(texto, format="ISO8601", errors="coerce")
    else:
        f = pd.to_datetime(texto, dayfirst=True, errors="coerce")
    return None if pd.isna(f) else f

def fila_encabezado(ruta: str, hoja: str, columna_clave: str, max_filas: int = 10) -> int:
    crudo = pd.read_excel(ruta, sheet_name=hoja, header=None, nrows=max_filas)
    for i, fila in crudo.iterrows():
        if any(str(c).strip().lower() == columna_clave.lower() for c in fila if pd.notna(c)):
            return int(i)
    return 0

def entero(valor) -> int:
    if valor is None or (isinstance(valor, float) and pd.isna(valor)):
        return 0
    if isinstance(valor, (int, float)):
        return int(valor)
    return int(round(_ec_num(valor)))

AJUSTES_ESQUEMA = """
DO $$
DECLARE c record;
BEGIN
    FOR c IN
        SELECT con.conname FROM pg_constraint con
        WHERE con.conrelid = 'visordg.brigadas_atendidos'::regclass AND con.contype = 'u'
          AND (SELECT array_agg(att.attname::text ORDER BY att.attname)
               FROM unnest(con.conkey) k
               JOIN pg_attribute att ON att.attrelid = con.conrelid AND att.attnum = k)
              = ARRAY['agencia', 'anio', 'mes']
    LOOP
        EXECUTE format('ALTER TABLE visordg.brigadas_atendidos DROP CONSTRAINT %I', c.conname);
    END LOOP;
END $$;
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'brigadas_atendidos_prov_agencia_anio_mes_key') THEN
        ALTER TABLE visordg.brigadas_atendidos
            ADD CONSTRAINT brigadas_atendidos_prov_agencia_anio_mes_key UNIQUE (provincia, agencia, anio, mes);
    END IF;
END $$;
ALTER TABLE visordg.cargas_archivo      ADD COLUMN IF NOT EXISTS anio SMALLINT,
                                        ADD COLUMN IF NOT EXISTS archivo_modificado TIMESTAMPTZ,
                                        ADD COLUMN IF NOT EXISTS total_declarado NUMERIC,
                                        ADD COLUMN IF NOT EXISTS total_cargado NUMERIC;
ALTER TABLE visordg.hist_ventas         ADD COLUMN IF NOT EXISTS archivo TEXT,
                                        ADD COLUMN IF NOT EXISTS archivo_modificado TIMESTAMPTZ;
ALTER TABLE visordg.hist_recaudacion    ADD COLUMN IF NOT EXISTS archivo TEXT,
                                        ADD COLUMN IF NOT EXISTS archivo_modificado TIMESTAMPTZ;
ALTER TABLE visordg.hist_brigadas       ADD COLUMN IF NOT EXISTS archivo TEXT,
                                        ADD COLUMN IF NOT EXISTS archivo_modificado TIMESTAMPTZ,
                                        ADD COLUMN IF NOT EXISTS total_declarado INTEGER;
ALTER TABLE visordg.hist_capacitaciones ADD COLUMN IF NOT EXISTS archivo TEXT,
                                        ADD COLUMN IF NOT EXISTS archivo_modificado TIMESTAMPTZ,
                                        ADD COLUMN IF NOT EXISTS total_declarado INTEGER;
ALTER TABLE visordg.hist_ventas         ADD COLUMN IF NOT EXISTS fecha_corte DATE;
ALTER TABLE visordg.hist_recaudacion    ADD COLUMN IF NOT EXISTS fecha_corte DATE;
ALTER TABLE visordg.hist_brigadas       ADD COLUMN IF NOT EXISTS fecha_corte DATE;
ALTER TABLE visordg.hist_capacitaciones ADD COLUMN IF NOT EXISTS fecha_corte DATE;
CREATE OR REPLACE VIEW visordg.v_fecha_corte AS
SELECT 'ventas'::text AS fuente, h.fecha_corte, h.archivo, h.archivo_modificado
FROM (SELECT fecha_corte, archivo, archivo_modificado, mes FROM visordg.hist_ventas
      WHERE fecha_corte IS NOT NULL ORDER BY fecha_corte DESC, mes DESC LIMIT 1) h
UNION ALL
SELECT 'recaudacion', h.fecha_corte, h.archivo, h.archivo_modificado
FROM (SELECT fecha_corte, archivo, archivo_modificado, mes FROM visordg.hist_recaudacion
      WHERE fecha_corte IS NOT NULL ORDER BY fecha_corte DESC, mes DESC LIMIT 1) h
UNION ALL
SELECT 'brigadas', h.fecha_corte, h.archivo, h.archivo_modificado
FROM (SELECT fecha_corte, archivo, archivo_modificado, mes FROM visordg.hist_brigadas
      WHERE fecha_corte IS NOT NULL ORDER BY fecha_corte DESC, mes DESC LIMIT 1) h
UNION ALL
SELECT 'capacitaciones', h.fecha_corte, h.archivo, h.archivo_modificado
FROM (SELECT fecha_corte, archivo, archivo_modificado, mes FROM visordg.hist_capacitaciones
      WHERE fecha_corte IS NOT NULL ORDER BY fecha_corte DESC, mes DESC LIMIT 1) h;
CREATE TABLE IF NOT EXISTS visordg.meta_recaudacion (
    anio       INT NOT NULL,
    mes        INT NOT NULL,
    valor_meta NUMERIC(15,2) NOT NULL,
    creado_en  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT pk_meta_recaudacion PRIMARY KEY (anio, mes),
    CONSTRAINT chk_mes CHECK (mes BETWEEN 1 AND 12),
    CONSTRAINT chk_anio CHECK (anio >= 2020)
);
CREATE TABLE IF NOT EXISTS visordg.feriados (
    anio          SMALLINT NOT NULL,
    fecha_feriado DATE     NOT NULL PRIMARY KEY,
    CONSTRAINT chk_feriado_anio CHECK (anio = EXTRACT(YEAR FROM fecha_feriado))
);
CREATE INDEX IF NOT EXISTS ix_feriados_anio ON visordg.feriados (anio);
CREATE OR REPLACE FUNCTION visordg.ultimo_dia_laborable(
    p_ref DATE DEFAULT (now() AT TIME ZONE 'America/Guayaquil')::date)
RETURNS DATE LANGUAGE sql STABLE AS $$
    SELECT max(d)::date
    FROM generate_series(p_ref - 31, p_ref - 1, INTERVAL '1 day') AS d
    WHERE EXTRACT(ISODOW FROM d) < 6
      AND NOT EXISTS (SELECT 1 FROM visordg.feriados f WHERE f.fecha_feriado = d::date)
$$;
DO $$
DECLARE r record;
BEGIN
    FOR r IN SELECT * FROM (VALUES
        ('dash_mes_corriente',    'ventas_2024',         'ventas_hace_dos_anios'),
        ('dash_mes_corriente',    'ventas_2025',         'ventas_anio_anterior'),
        ('dash_mes_corriente',    'ventas',              'ventas_anio_actual'),
        ('dash_mes_corriente',    'recaudacion_2025',    'recaudacion_anio_anterior'),
        ('dash_mes_corriente',    'recaudacion',         'recaudacion_anio_actual'),
        ('dash_mes_corriente',    'brigadas_2025',       'brigadas_anio_anterior'),
        ('dash_mes_corriente',    'brigadas',            'brigadas_anio_actual'),
        ('dash_mes_corriente',    'capacitaciones_2025', 'capacitaciones_anio_anterior'),
        ('dash_mes_corriente',    'capacitaciones',      'capacitaciones_anio_actual'),
        ('dash_ventas_provincia', 'v2024',               'hace_dos_anios'),
        ('dash_ventas_provincia', 'v2025',               'anio_anterior'),
        ('dash_ventas_provincia', 'v2026',               'anio_actual')
    ) AS t(tabla, viejo, nuevo)
    LOOP
        IF EXISTS (SELECT 1 FROM information_schema.columns
                   WHERE table_schema = 'visordg' AND table_name = r.tabla AND column_name = r.viejo)
           AND NOT EXISTS (SELECT 1 FROM information_schema.columns
                   WHERE table_schema = 'visordg' AND table_name = r.tabla AND column_name = r.nuevo) THEN
            EXECUTE format('ALTER TABLE visordg.%I RENAME COLUMN %I TO %I', r.tabla, r.viejo, r.nuevo);
        END IF;
    END LOOP;
END $$;
"""

async def asegurar_esquema(con: asyncpg.Connection | None = None) -> None:
    propia = con is None
    con = con or await asyncpg.connect(PG_DSN)
    try:
        await con.execute(AJUSTES_ESQUEMA)
    finally:
        if propia:
            await con.close()

def fecha_modificacion(ruta: str | Path) -> datetime:
    ruta = Path(ruta)
    mtime = datetime.fromtimestamp(ruta.stat().st_mtime).astimezone()
    if ruta.suffix.lower() not in (".xlsx", ".xlsm"):
        return mtime
    try:
        from openpyxl import load_workbook
        libro = load_workbook(ruta, read_only=True)
        interna = libro.properties.modified
        libro.close()
    except Exception:
        return mtime
    if interna is None:
        return mtime
    interna = interna.replace(tzinfo=timezone.utc).astimezone()
    return interna if interna <= mtime else mtime

async def registrar_carga(con: asyncpg.Connection, fuente: str, archivo: str,
                          filas_ok: int, estado: str, ruta: str | Path | None = None,
                          anio: int | None = None, total_declarado: float | None = None,
                          total_cargado: float | None = None) -> None:
    await con.execute(
        """INSERT INTO visordg.cargas_archivo (fuente, nombre_archivo, filas_ok, estado, anio, archivo_modificado,
                                               total_declarado, total_cargado)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8)""",
        fuente, archivo, filas_ok, estado, anio, fecha_modificacion(ruta) if ruta else None,
        total_declarado, total_cargado)
    await con.execute("UPDATE visordg.visor_refresh SET actualizado_en = now() WHERE id = 1")

async def _copiar(con: asyncpg.Connection, tabla: str, columnas: list[str], registros: list) -> None:
    await con.execute(f"TRUNCATE visordg.{tabla}")
    await con.copy_records_to_table(tabla, records=registros, schema_name="visordg", columns=columnas)

async def _cargar_catalogo(ruta: str) -> None:
    nombre = Path(ruta).name
    con = await asyncpg.connect(PG_DSN)
    try:
        imp = leer_hoja(ruta, "IMPUESTOS")
        registros = [(entero(f.get("IMPUESTO_PK")), str(f.get("Impuesto_Grupo") or "").strip(),
                      str(f.get("Impuesto_detalle") or "").strip(), str(f.get("CODIGO_OPERA_IMPUESTO") or "").strip(),
                      str(f.get("DESCRIPCION_IMPUESTO") or "").strip())
                     for _, f in imp.iterrows() if pd.notna(f.get("IMPUESTO_PK"))]
        await _copiar(con, "cat_impuestos",
                      ["impuesto_pk", "impuesto_grupo", "impuesto_detalle",
                       "codigo_opera_impuesto", "descripcion_impuesto"], registros)
        click.echo(f"  IMPUESTOS: {len(registros)}")

        prov = leer_hoja(ruta, "PROVINCIA_PK")
        prov.columns = ["provincia_pk", "provincia", "zona"]
        registros = [(entero(f["provincia_pk"]), str(f["provincia"]).strip(), str(f["zona"]).strip())
                     for _, f in prov.iterrows() if pd.notna(f["provincia_pk"])]
        await _copiar(con, "cat_provincias", ["provincia_pk", "provincia", "zona"], registros)
        click.echo(f"  PROVINCIA_PK: {len(registros)}")

        fnt = leer_hoja(ruta, "FUENTES")
        registros = [(str(f.iloc[0]).strip(), str(f.iloc[1]).strip())
                     for _, f in fnt.iterrows() if pd.notna(f.iloc[0])]
        await _copiar(con, "cat_fuentes", ["mar_fuente", "descripcion_fuente"], registros)
        click.echo(f"  FUENTES: {len(registros)}")

        act = leer_hoja(ruta, "ACTIVIDAD_ECONOMICA")
        columnas_act = [c.lower() for c in act.columns]
        registros = [tuple(None if pd.isna(v) else (entero(v) if c == "actividad_economica_pk" else str(v).strip())
                           for c, v in zip(columnas_act, fila))
                     for _, fila in act.iterrows()]
        await _copiar(con, "cat_actividad_economica", columnas_act, registros)
        click.echo(f"  ACTIVIDAD_ECONOMICA: {len(registros)}")

        await registrar_carga(con, "catalogo", nombre, len(registros), "OK")
    finally:
        await con.close()
    click.echo("Catálogo cargado en las 4 tablas cat_*")

_PIE_CAPACITACIONES = re.compile(r"^\W*(TOTAL|CAPACITADOS|EVENTOS)\b")


def _miles(n) -> str:
    return f"{n:,}".replace(",", ".")


def _celda_texto(valor) -> str:
    try:
        if valor is None or pd.isna(valor):
            return ""
    except (TypeError, ValueError):
        pass
    if isinstance(valor, float) and valor.is_integer():
        return str(int(valor))
    return texto(valor)


def _numero_tras(rotulo: str, palabra: str) -> int | None:
    resto = rotulo.split(palabra, 1)[1] if palabra in rotulo else ""
    numero = re.search(r"(\d[\d.]*)", resto)
    return entero(numero.group(1)) if numero else None


def _filas_capacitaciones(ruta: str, avisar: bool = True) -> tuple[list[tuple], int | None, int | None]:
    hojas = pd.ExcelFile(ruta).sheet_names
    hoja = "Hoja1" if "Hoja1" in hojas else ("Sheet1" if "Sheet1" in hojas else hojas[0])
    frame = leer_hoja(ruta, hoja, encabezado=fila_encabezado(ruta, hoja, "ZONAL"))
    frame.columns = [str(c).strip().lower().replace(" ", "_") for c in frame.columns]
    col_fecha = next((c for c in frame.columns if "fecha" in c), "fecha_capacitacion")
    col_total = next((c for c in frame.columns if "capacitados" in c), None)
    anio_max = date.today().year + 1
    registros, sin_fecha, fuera_rango, pie = [], [], [], []
    declarado_eventos = declarado_capacitados = None
    for n, f in frame.iterrows():
        rotulo = " ".join(t for t in (_celda_texto(c) for c in f.values) if t).upper()
        if _PIE_CAPACITACIONES.match(rotulo):
            pie.append(rotulo)
            if "EVENTOS" in rotulo:
                declarado_eventos = _numero_tras(rotulo, "EVENTOS")
            elif "CAPACITADOS" in rotulo:
                declarado_capacitados = _numero_tras(rotulo, "CAPACITADOS")
            elif col_total:
                declarado_capacitados = entero(f.get(col_total))
            continue
        fecha = fecha_robusta(f.get(col_fecha))
        if fecha is None:
            if texto(f.get("provincia")):
                sin_fecha.append((n, f.get(col_fecha)))
            continue
        if not 2015 <= fecha.year <= anio_max:
            fuera_rango.append((n, f.get(col_fecha)))
            continue
        registros.append((
            texto(f.get("zonal")), texto(f.get("provincia")), texto(f.get("lugar")),
            fecha.to_pydatetime(), texto(f.get("tema")), texto(f.get("instructor")),
            entero(f.get(col_total)) if col_total else 0,
            texto(f.get("horario")), texto(f.get("modalidad")), texto(f.get("tipo"))))
    if avisar:
        nombre = Path(ruta).name
        if pie:
            click.echo(f"  {nombre}: {len(pie)} fila(s) de resumen al pie, no se cargan: " + " · ".join(pie))
        _avisar_descartes(nombre, sin_fecha, "sin fecha legible")
        _avisar_descartes(nombre, fuera_rango, f"fecha fuera de rango (antes de 2015 o después de {anio_max})")
    return registros, declarado_eventos, declarado_capacitados


async def _cargar_capacitaciones(ruta: str) -> None:
    registros, declarado_eventos, declarado_capacitados = _filas_capacitaciones(ruta)
    nombre = Path(ruta).name
    eventos, capacitados = len(registros), sum(r[6] for r in registros)
    click.echo(f"  {nombre}: {_miles(eventos)} eventos (filas) y {_miles(capacitados)} capacitados "
               f"(suma de TOTAL CAPACITADOS)")
    for etiqueta, declarado, cargado in (("EVENTOS", declarado_eventos, eventos),
                                         ("CAPACITADOS", declarado_capacitados, capacitados)):
        if declarado is None:
            continue
        if declarado != cargado:
            click.echo(f"  [AVISO] {nombre}: el resumen del Excel dice {etiqueta} = {_miles(declarado)}, pero las "
                       f"filas dan {_miles(cargado)}; se cargó lo que dan las filas.")
        else:
            click.echo(f"  {nombre}: coincide con el resumen del Excel ({etiqueta}) ✓")
    if len(registros) < MIN_FILAS_VALIDAS:
        click.echo(f"  [ALERTA] {Path(ruta).name}: solo {len(registros)} filas válidas; "
                   "se mantiene lo cargado antes.")
        return
    anios = sorted({r[3].year for r in registros})
    con = await asyncpg.connect(PG_DSN)
    try:
        async with con.transaction():
            await con.execute(
                "DELETE FROM visordg.capacitaciones_raw WHERE EXTRACT(YEAR FROM fecha)::int = ANY($1::int[])", anios)
            await con.copy_records_to_table(
                "capacitaciones_raw", records=registros, schema_name="visordg",
                columns=["zonal", "provincia", "lugar", "fecha", "tema", "instructor",
                         "total_capacitados", "horario", "modalidad", "tipo"])
            await registrar_carga(con, "capacitaciones", Path(ruta).name, len(registros), "OK",
                                  ruta=ruta, anio=max(anios),
                                  total_declarado=declarado_eventos, total_cargado=eventos)
    finally:
        await con.close()
    click.echo(f"  {Path(ruta).name}: {len(registros)} registros, año(s) {anios} reemplazado(s)")

async def _cargar_brigadas(ruta: str, anio: int) -> None:
    hojas_reales = pd.ExcelFile(ruta).sheet_names

    hoja_atendidos = next((h for h in hojas_reales if "atendidos" in h.lower()), None)

    hoja_eventos = next((h for h in hojas_reales if "eventos" in h.lower()), None)
    if not hoja_eventos:
        hoja_eventos = next((h for h in hojas_reales if "total" in h.lower()), None)

    if not hoja_atendidos or not hoja_eventos:
        raise click.ClickException(f"Estructura de pestañas inválida en: {Path(ruta).name}")

    declarado = anio_declarado(ruta, hoja_eventos) or anio_declarado(ruta, hoja_atendidos)
    if declarado and declarado != anio:
        click.echo(f"  [AVISO] {Path(ruta).name}: se esperaba {anio} pero el archivo dice Año {declarado}; "
                   f"se carga como {declarado}.")
        anio = declarado

    ctl_at, ctl_ev = {}, {}
    crudo_at = _despivotar_brigadas(ruta, hoja_atendidos, anio, con_agencia=True, control=ctl_at)
    crudo_ev = _despivotar_brigadas(ruta, hoja_eventos, anio, con_agencia=False, control=ctl_ev)
    _cotejar_total(Path(ruta).name, hoja_atendidos, crudo_at, ctl_at)
    _cotejar_total(Path(ruta).name, hoja_eventos, crudo_ev, ctl_ev)

    def _consolidar(filas, llave_de, meta_de) -> tuple[dict, list]:
        mapa, repetidas = {}, []
        for fila in filas:
            llave = llave_de(fila)
            if llave in mapa:
                repetidas.append(llave)
                mapa[llave]["valor"] += fila[-1]
            else:
                mapa[llave] = {**meta_de(fila), "valor": fila[-1]}
        return mapa, repetidas

    atendidos, rep_at = _consolidar(
        crudo_at,
        lambda f: (str(f[1] or "").strip(), str(f[2] or "").strip(), f[3], f[4]),
        lambda f: {"zona": f[0]})
    registros_at = [(m["zona"], k[0], k[1], k[2], k[3], m["valor"]) for k, m in atendidos.items()]

    eventos, rep_ev = _consolidar(
        crudo_ev,
        lambda f: (str(f[1] or "").strip(), f[2], f[3]),
        lambda f: {"zona": f[0]})
    registros_ev = [(m["zona"], k[0], k[1], k[2], m["valor"]) for k, m in eventos.items()]

    for hoja, repetidas in (("Atendidos", rep_at), ("Eventos", rep_ev)):
        if repetidas:
            ejemplos = ", ".join(f"{k[0]} {'/'.join(map(str, k[1:]))}" for k in repetidas[:5])
            click.echo(f"  [AVISO] {Path(ruta).name} ({hoja}): {len(repetidas)} fila(s) con clave repetida "
                       f"se SUMARON. Revisar el Excel. Ej.: {ejemplos}")

    if len(registros_ev) < MIN_FILAS_VALIDAS:
        click.echo(f"  [ALERTA] {Path(ruta).name}: solo {len(registros_ev)} filas de eventos; "
                   f"se mantiene lo cargado de {anio}.")
        return

    con = await asyncpg.connect(PG_DSN)
    try:
        await asegurar_esquema(con)
        async with con.transaction():
            await con.execute("DELETE FROM visordg.brigadas_atendidos WHERE anio = $1", anio)
            await con.copy_records_to_table(
                "brigadas_atendidos", records=registros_at, schema_name="visordg",
                columns=["zona", "provincia", "agencia", "anio", "mes", "atendidos"])
            await con.execute("DELETE FROM visordg.brigadas_eventos WHERE anio = $1", anio)
            await con.copy_records_to_table(
                "brigadas_eventos", records=registros_ev, schema_name="visordg",
                columns=["zona", "provincia", "anio", "mes", "eventos"])
            await registrar_carga(con, "brigadas", Path(ruta).name, len(registros_at) + len(registros_ev), "OK",
                                  ruta=ruta, anio=anio,
                                  total_declarado=sum(ctl_ev.values()) if ctl_ev else None,
                                  total_cargado=sum(r[-1] for r in registros_ev))
    finally:
        await con.close()

    click.echo(f"  {Path(ruta).name}: Procesado y consolidado con éxito.")

def _despivotar_brigadas(ruta: str, hoja: str, anio: int, con_agencia: bool,
                         control: dict | None = None) -> list:
    frame = leer_hoja(ruta, hoja, encabezado=fila_encabezado(ruta, hoja, "Zona"))
    nombres = {m.lower(): i + 1 for i, m in enumerate(MESES)}
    nombres["setiembre"] = 9
    idx_meses = {c: nombres[str(c).strip().lower()] for c in frame.columns
                 if str(c).strip().lower() in nombres}
    if not idx_meses:
        raise click.ClickException(f"No se encontraron columnas de meses en '{hoja}'")
    registros = []
    for _, f in frame.iterrows():
        zona, provincia = texto(f.get("Zona")), texto(f.get("Provincia"))
        if zona.lower().startswith("total") or provincia.lower().startswith("total"):
            if control is not None:
                for col, mes in idx_meses.items():
                    control[mes] = entero(f.get(col))
            continue
        if not provincia:
            continue
        for col, mes in idx_meses.items():
            if con_agencia:
                registros.append((zona, provincia, texto(f.get("Agencia")), anio, mes, entero(f.get(col))))
            else:
                registros.append((zona, provincia, anio, mes, entero(f.get(col))))
    return registros

def _cotejar_total(archivo: str, hoja: str, registros: list, control: dict) -> None:
    if not control:
        click.echo(f"  [AVISO] {archivo} [{hoja}]: sin fila 'Total general' para cotejar.")
        return
    suma = {}
    for *_, mes, valor in registros:
        suma[mes] = suma.get(mes, 0) + valor
    dif = [f"{MESES[m - 1][:3]} {suma.get(m, 0)} vs {t}" for m, t in sorted(control.items()) if suma.get(m, 0) != t]
    if dif:
        click.echo(f"  [AVISO] {archivo} [{hoja}]: la suma de provincias NO coincide con el 'Total general' "
                   f"del Excel en: {'; '.join(dif)}")
    else:
        click.echo(f"  {archivo} [{hoja}]: coincide con el 'Total general' del Excel ✓ ({sum(control.values()):,})"
                   .replace(",", "."))

MESES_ABR = {"ene": 1, "feb": 2, "mar": 3, "abr": 4, "may": 5, "jun": 6,
             "jul": 7, "ago": 8, "sep": 9, "oct": 10, "nov": 11, "dic": 12}

_COLUMNAS_REC = ["ae_codigo_familia", "ae_codigo_grupo", "cod_n6", "fecha",
                 "impuesto_pk", "provincia", "gc", "pago", "m_fuente", "carga", "recaudado"]

def _mes_de_nombre(nombre: str) -> tuple[int, int] | None:
    import re
    hallado = re.search(r"_(Ene|Feb|Mar|Abr|May|Jun|Jul|Ago|Sep|Oct|Nov|Dic)(\d{2})",
                        nombre, re.IGNORECASE)
    if not hallado:
        return None
    return 2000 + int(hallado.group(2)), MESES_ABR[hallado.group(1).lower()]

async def _cargar_recaudacion_carpeta(carpeta: str) -> None:
    archivos = sorted(Path(carpeta).glob("BDD_Recauda*.csv"))
    if not archivos:
        raise click.ClickException(f"No hay CSV BDD_Recaudación_* en {carpeta}")
    con = await asyncpg.connect(PG_DSN)
    total = 0
    try:
        for ruta in archivos:
            anio_mes = _mes_de_nombre(ruta.name)
            if not anio_mes:
                click.echo(f"  [OMITIDO] {ruta.name}: no se deduce el mes del nombre")
                continue
            anio, mes = anio_mes
            async with con.transaction():
                await con.execute(
                    "CREATE TEMP TABLE stg_rec ("
                    + ", ".join(f"{c} TEXT" for c in _COLUMNAS_REC) + ") ON COMMIT DROP")
                with open(ruta, "rb") as fh:
                    await con.copy_to_table("stg_rec", source=fh, format="csv", header=True)
                await con.execute(
                    "DELETE FROM visordg.recaudacion_raw "
                    "WHERE date_trunc('month', fecha) = make_date($1, $2, 1)", anio, mes)
                await con.execute(
                    """INSERT INTO visordg.recaudacion_raw (""" + ", ".join(_COLUMNAS_REC) + """)
                       SELECT ae_codigo_familia, ae_codigo_grupo, cod_n6,
                              to_date(fecha, 'YYYYMMDD'), NULLIF(impuesto_pk, '')::int,
                              provincia, gc, pago, m_fuente, carga,
                              COALESCE(NULLIF(replace(replace(recaudado, '.', ''), ',', '.'), '')::numeric, 0)
                       FROM stg_rec WHERE fecha ~ '^\\d{8}$'""")
                filas = await con.fetchval("SELECT COUNT(*) FROM stg_rec")
                await registrar_carga(con, "recaudacion", ruta.name, filas, "OK")
            total += filas
            click.echo(f"  {ruta.name}: {filas} filas -> {anio}-{mes:02d} (mes reemplazado)")
    finally:
        await con.close()
    click.echo(f"Recaudación: {total} filas cargadas desde {carpeta}. "
               "Ahora corre: pdm run refrescar")

@click.group()
def cli() -> None:
    """Cargas de archivos del visor gerencial."""
    asyncio.run(asegurar_esquema())

OPCION_ORIGEN = click.option("--origen", type=click.Choice(ORIGENES), default=None,
                             help="Fuerza el origen (por defecto: [fuentes].origen del settings)")
ARG_CARPETA = click.argument("carpeta", required=False, type=click.Path(exists=True, file_okay=False))

@cli.command()
@click.argument("carpeta", type=click.Path(exists=True, file_okay=False))
def recaudacion(carpeta: str) -> None:
    """Carga TODOS los BDD_Recaudación_*.csv de una carpeta (un archivo por mes)."""
    asyncio.run(_cargar_recaudacion_carpeta(carpeta))

@cli.command()
@click.argument("archivo", required=False, type=click.Path(exists=True))
@OPCION_ORIGEN
def catalogo(archivo: str | None, origen: str | None) -> None:
    """Carga las 4 pestañas de Catalogo_Recaudación.xlsx (ruta explícita o la del origen)."""
    if not archivo:
        archivo = str(base_origen(origen) / SETTINGS["fuentes"]["archivos"]["catalogo"])
    asyncio.run(_cargar_catalogo(archivo))

def _elegir_base(carpeta: str, patron: str) -> Path:
    candidatos = sorted(Path(carpeta).glob(patron))
    if not candidatos:
        raise click.ClickException(f"No se encontró '{patron}' en {carpeta}")
    return min(candidatos, key=lambda c: (len(c.stem), -c.stat().st_mtime))

def _ec_num(valor) -> float:
    if valor is None or (isinstance(valor, float) and pd.isna(valor)):
        return 0.0
    if isinstance(valor, (int, float)) and not isinstance(valor, bool):
        return float(valor)
    texto = str(valor).replace("$", "").replace(" ", "").strip()
    if not texto:
        return 0.0
    if "," in texto:
        texto = texto.replace(".", "").replace(",", ".")
    elif texto.count(".") == 1 and len(texto.split(".")[1]) != 3:
        pass
    else:
        texto = texto.replace(".", "")
    try:
        return float(texto)
    except ValueError:
        return 0.0

def _desenvolver_lineas(contenido: str) -> tuple[str, int]:
    salida, corregidas = [], 0
    for linea in contenido.splitlines():
        limpia = linea.strip()
        if len(limpia) >= 2 and limpia[0] == '"' and limpia[-1] == '"':
            try:
                campos = next(csv.reader([limpia]))
            except csv.Error:
                campos = []
            if len(campos) == 1 and ("," in campos[0] or ";" in campos[0]):
                salida.append(campos[0])
                corregidas += 1
                continue
        salida.append(linea)
    return "\n".join(salida), corregidas


def _leer_csv(ruta: Path) -> pd.DataFrame:
    raw = Path(ruta).read_bytes()
    contenido = None
    for codificacion in ("utf-8-sig", "cp1252"):
        try:
            contenido = raw.decode(codificacion)
            break
        except UnicodeDecodeError:
            continue
    if contenido is None:
        contenido = raw.decode("cp1252", errors="replace")
    contenido, corregidas = _desenvolver_lineas(contenido)
    if corregidas:
        click.echo(f"  [AVISO] {Path(ruta).name}: {_miles(corregidas)} línea(s) venían envueltas entre comillas "
                   f"(lo hace Excel al guardar); se leyeron como líneas normales.")
    return pd.read_csv(StringIO(contenido), dtype=str, sep=None, engine="python")

def _avisar_descartes(archivo: str, filas: list, motivo: str) -> None:
    if filas:
        ejemplos = ", ".join(f"fila {n + 2}: {v!r}" for n, v in filas[:3])
        click.echo(f"  [AVISO] {archivo}: {len(filas)} fila(s) descartada(s) por {motivo}. Ej.: {ejemplos}")

def _norm_col(nombre) -> str:
    txt = unicodedata.normalize("NFKD", str(nombre)).encode("ascii", "ignore").decode()
    return re.sub(r"[^A-Z0-9]", "", txt.upper())

def _columna(frame: pd.DataFrame, *alias: str) -> str | None:
    reales = {_norm_col(c): c for c in frame.columns}
    return next((reales[_norm_col(a)] for a in alias if _norm_col(a) in reales), None)

COLUMNAS_RECAUDACION = {
    "anio":      ("AÑO", "ANIO", "YEAR"),
    "mes":       ("MES", "MONTH"),
    "dia":       ("DIA", "DAY"),
    "sector":    ("SECTOR", "SECTOR_ECONOMICO"),
    "provincia": ("Provincia",),
    "impuesto":  ("Reporte_Presidencia", "IMPUESTO", "IMPUESTOS", "DESCRIPCION_IMPUESTO", "TIPO_IMPUESTO"),
    "recaudado": ("RECAUDADO", "RECAUDACION", "VALOR"),
}

def _filas_recaudacion(ruta: Path) -> list[tuple]:
    frame = _leer_csv(ruta)
    frame.columns = [str(c).strip() for c in frame.columns]
    col = {k: _columna(frame, *alias) for k, alias in COLUMNAS_RECAUDACION.items()}
    faltan = [k for k, v in col.items() if v is None]
    if faltan:
        click.echo(f"  [AVISO] {ruta.name}: no se encontró la(s) columna(s) {', '.join(faltan)}. "
                   f"Encabezados del archivo: {list(frame.columns)}")

    def celda(f, clave):
        return f.get(col[clave]) if col[clave] else None

    registros, malas = [], []
    for n, f in frame.iterrows():
        try:
            fecha = date(int(celda(f, "anio")), int(celda(f, "mes")), int(celda(f, "dia")))
        except (KeyError, TypeError, ValueError):
            malas.append((n, f"{celda(f, 'anio')}-{celda(f, 'mes')}-{celda(f, 'dia')}"))
            continue
        registros.append((
            fecha,
            texto(celda(f, "sector")),
            texto(celda(f, "provincia")),
            texto(celda(f, "impuesto")),
            _ec_num(celda(f, "recaudado"))))
    _avisar_descartes(ruta.name, malas, "fecha inválida (AÑO/MES/DIA)")
    sin_impuesto = sum(1 for r in registros if not r[3])
    if registros and sin_impuesto / len(registros) > 0.05:
        click.echo(f"  [AVISO] {ruta.name}: {sin_impuesto:,} de {len(registros):,} fila(s) SIN impuesto "
                   f"(columna {col['impuesto'] or 'no encontrada'}). P4 'Por impuesto' saldrá incompleta; "
                   f"revisar el archivo con el área.".replace(",", "."))
    return registros

def _filas_ventas(ruta: Path) -> list[tuple]:
    frame = _leer_csv(ruta)
    frame.columns = [str(c).strip() for c in frame.columns]
    registros, malas = [], []
    for n, f in frame.iterrows():
        fecha_txt = str(f.get("Fecha") or "").strip()
        try:
            if not re.fullmatch(r"\d{8}", fecha_txt):
                raise ValueError
            fecha = date(int(fecha_txt[:4]), int(fecha_txt[4:6]), int(fecha_txt[6:8]))
        except ValueError:
            malas.append((n, fecha_txt))
            continue
        registros.append((
            fecha,
            str(f.get("Provincia") or "").strip(),
            str(f.get("Sector") or "").strip(),
            _ec_num(f.get("Ventas"))))
    _avisar_descartes(ruta.name, malas, "fecha inválida (se espera AAAAMMDD)")
    return registros

async def _reemplazar_tabla(tabla: str, fuente: str, columnas: list[str],
                            por_archivo: list[tuple]) -> int:
    por_archivo = [(item[0], item[1], item[2] if len(item) > 2 else item[0].name) for item in por_archivo]
    for ruta, registros, nombre in por_archivo:
        if len(registros) < MIN_FILAS_VALIDAS:
            raise click.ClickException(
                f"{nombre}: solo {len(registros)} filas válidas; no se tocó {tabla} (revisar el archivo)")
    con = await asyncpg.connect(PG_DSN)
    try:
        async with con.transaction():
            await con.execute(f"DELETE FROM visordg.{tabla}")
            for ruta, registros, nombre in por_archivo:
                await con.copy_records_to_table(tabla, schema_name="visordg", records=registros, columns=columnas)
                await registrar_carga(con, fuente, nombre, len(registros), "OK",
                                      ruta=ruta, anio=max(r[0].year for r in registros))
        await con.execute(f"ANALYZE visordg.{tabla}")
    finally:
        await con.close()
    return sum(len(r) for _, r, _ in por_archivo)

def grupos_divididos(carpeta: str | Path, prefijo: str, etiqueta: str) -> list[tuple[int, list[Path]]]:
    patron = re.compile(rf"^{prefijo}_(\d{{4}})(?:_(Acum|Mes))?\.csv$", re.IGNORECASE)
    por_anio: dict[int, dict[str, Path]] = {}
    for ruta in sorted(Path(carpeta).glob(f"{prefijo}_*.csv")):
        if ruta.name.startswith("~$"):
            continue
        m = patron.match(ruta.name)
        if not m:
            click.echo(f"  [AVISO] {ruta.name}: nombre no reconocido (se espera {prefijo}_AAAA.csv, "
                       f"{prefijo}_AAAA_Acum.csv o {prefijo}_AAAA_Mes.csv); se ignora.")
            continue
        por_anio.setdefault(int(m.group(1)), {})[(m.group(2) or "unico").lower()] = ruta
    grupos = []
    for anio, partes in sorted(por_anio.items()):
        divididos = [partes[k] for k in ("acum", "mes") if k in partes]
        if len(divididos) == 2:
            if "unico" in partes:
                click.echo(f"  [AVISO] {etiqueta} {anio}: hay {prefijo}_{anio}_Acum.csv y {prefijo}_{anio}_Mes.csv; "
                           f"se ignora {partes['unico'].name} para no duplicar.")
            grupos.append((anio, divididos))
        elif "unico" in partes:
            if divididos:
                click.echo(f"  [AVISO] {etiqueta} {anio}: solo vino {divididos[0].name}, falta su par; "
                           f"se usa {partes['unico'].name}.")
            grupos.append((anio, [partes["unico"]]))
        else:
            falta = f"{prefijo}_{anio}_Mes.csv" if "acum" in partes else f"{prefijo}_{anio}_Acum.csv"
            raise click.ClickException(f"{etiqueta} {anio}: vino {divididos[0].name} pero falta {falta}; "
                                       f"no se tocó {etiqueta.lower()} (cargar los dos archivos juntos)")
    return grupos


def filas_grupo(rutas: list[Path], lector) -> list[tuple]:
    if len(rutas) == 1:
        return lector(rutas[0])
    acum, mes = lector(rutas[0]), lector(rutas[1])
    meses_mes = {(r[0].year, r[0].month) for r in mes}
    repetidas = [r for r in acum if (r[0].year, r[0].month) in meses_mes]
    if repetidas:
        etiquetas = ", ".join(sorted(f"{a}-{m:02d}" for a, m in {(r[0].year, r[0].month) for r in repetidas}))
        click.echo(f"  [AVISO] {rutas[0].name} trae {_miles(len(repetidas))} fila(s) de {etiquetas}, que también "
                   f"vienen en {rutas[1].name}; para ese mes se usa {rutas[1].name}.")
    return [r for r in acum if (r[0].year, r[0].month) not in meses_mes] + mes


def grupos_recaudacion(carpeta: str | Path) -> list[tuple[int, list[Path]]]:
    return grupos_divididos(carpeta, "Reca", "Recaudación")


def filas_recaudacion_grupo(rutas: list[Path]) -> list[tuple]:
    return filas_grupo(rutas, _filas_recaudacion)


def filas_recaudacion_carpeta(carpeta: str | Path) -> list[tuple]:
    return [r for _, rutas in grupos_recaudacion(carpeta) for r in filas_recaudacion_grupo(rutas)]


def grupos_ventas(carpeta: str | Path) -> list[tuple[int, list[Path]]]:
    return grupos_divididos(carpeta, "CEL", "Ventas")


def filas_ventas_grupo(rutas: list[Path]) -> list[tuple]:
    return filas_grupo(rutas, _filas_ventas)


def filas_ventas_carpeta(carpeta: str | Path) -> list[tuple]:
    return [r for _, rutas in grupos_ventas(carpeta) for r in filas_ventas_grupo(rutas)]


async def _cargar_dividido(carpeta: str, grupos, lector_grupo, tabla: str, fuente: str, columnas: list[str],
                           etiqueta: str, prefijo: str) -> None:
    if not grupos:
        raise click.ClickException(f"No hay archivos '{prefijo}_*.csv' en {carpeta}")
    por_archivo = []
    for anio, rutas in grupos:
        registros = lector_grupo(rutas)
        reciente = max(rutas, key=lambda r: r.stat().st_mtime)
        por_archivo.append((reciente, registros, " + ".join(r.name for r in rutas)))
        click.echo(f"  {etiqueta.lower()} {anio}: {' + '.join(r.name for r in rutas)} -> {_miles(len(registros))} filas")
    total = await _reemplazar_tabla(tabla, fuente, columnas, por_archivo)
    click.echo(f"{etiqueta} (nueva): {total} filas desde {sum(len(r) for _, r in grupos)} archivo(s), reemplazo total")


async def _cargar_recaudacion_dos(carpeta: str) -> None:
    await _cargar_dividido(carpeta, grupos_recaudacion(carpeta), filas_recaudacion_grupo, "recaudacion_raw_dos",
                           "recaudacion_dos", ["fecha", "sector", "provincia", "impuesto", "recaudado"],
                           "Recaudación", "Reca")


async def _cargar_ventas_dos(carpeta: str) -> None:
    await _cargar_dividido(carpeta, grupos_ventas(carpeta), filas_ventas_grupo, "ventas_raw_dos",
                           "ventas_dos", ["fecha", "provincia", "sector", "ventas"], "Ventas", "CEL")


def filas_solo_mes(grupos, lector) -> tuple[Path, list[tuple], set[tuple[int, int]]]:
    anio, rutas = grupos[-1]
    ruta = rutas[-1]
    registros = lector(ruta)
    if len(rutas) == 1:
        ultimo = max(((r[0].year, r[0].month) for r in registros), default=None)
        registros = [r for r in registros if (r[0].year, r[0].month) == ultimo]
    meses = {(r[0].year, r[0].month) for r in registros}
    return ruta, registros, meses


async def _cargar_solo_mes(carpeta: str, grupos, lector, tabla: str, fuente: str, columnas: list[str],
                           etiqueta: str, prefijo: str) -> None:
    if not grupos:
        raise click.ClickException(f"No hay archivos '{prefijo}_*.csv' en {carpeta}")
    ruta, registros, meses = filas_solo_mes(grupos, lector)
    if len(registros) < MIN_FILAS_VALIDAS:
        raise click.ClickException(
            f"{ruta.name}: solo {len(registros)} filas válidas; no se tocó {tabla} (revisar el archivo)")
    etiquetas = ", ".join(f"{a}-{m:02d}" for a, m in sorted(meses))
    con = await asyncpg.connect(PG_DSN)
    try:
        async with con.transaction():
            borradas = await con.execute(
                f"DELETE FROM visordg.{tabla} WHERE (EXTRACT(YEAR FROM fecha)::int, EXTRACT(MONTH FROM fecha)::int) "
                f"IN (SELECT * FROM unnest($1::int[], $2::int[]))",
                [a for a, _ in meses], [m for _, m in meses])
            await con.copy_records_to_table(tabla, schema_name="visordg", records=registros, columns=columnas)
            await registrar_carga(con, fuente, f"{ruta.name} (solo mes)", len(registros), "OK",
                                  ruta=ruta, anio=max(r[0].year for r in registros))
        await con.execute(f"ANALYZE visordg.{tabla}")
    finally:
        await con.close()
    click.echo(f"{etiqueta} solo del mes {etiquetas}: {ruta.name} -> {_miles(len(registros))} filas "
               f"(reemplazan {_miles(int(borradas.split()[-1]))}); los demás meses no se tocan")


async def _cargar_ventas_mes(carpeta: str) -> None:
    await _cargar_solo_mes(carpeta, grupos_ventas(carpeta), _filas_ventas, "ventas_raw_dos", "ventas_dos",
                           ["fecha", "provincia", "sector", "ventas"], "Ventas", "CEL")


async def _cargar_recaudacion_mes(carpeta: str) -> None:
    await _cargar_solo_mes(carpeta, grupos_recaudacion(carpeta), _filas_recaudacion, "recaudacion_raw_dos",
                           "recaudacion_dos", ["fecha", "sector", "provincia", "impuesto", "recaudado"],
                           "Recaudación", "Reca")


@cli.command()
@click.argument("archivo", type=click.Path(exists=True))
def capacitaciones(archivo: str) -> None:
    """Carga Hoja1 de Capacitaciones enero a sep 2026.xls."""
    asyncio.run(_cargar_capacitaciones(archivo))

def base_origen(origen: str | None = None) -> Path:
    fuentes = SETTINGS["fuentes"]
    origen = origen or fuentes.get("origen", "local")
    if origen not in ORIGENES:
        raise click.ClickException(f"Origen inválido '{origen}': use {' | '.join(ORIGENES)}")
    base = Path(fuentes[origen])
    if not base.is_dir():
        pista = " (¿fileserver o red disponibles?)" if origen == "fileserver" else ""
        raise click.ClickException(f"Origen '{origen}' no accesible: {base}{pista}")
    return base

def carpetas_fuente(base: Path, fuente: str) -> list[Path]:
    nombres = SETTINGS["fuentes"]["carpetas"][fuente]
    nombres = [nombres] if isinstance(nombres, str) else list(nombres)
    existentes = [base / n for n in nombres if (base / n).is_dir()]
    if not existentes:
        raise click.ClickException(f"No existe carpeta de {fuente} en {base}: {', '.join(nombres)}")
    return existentes

def buscar_archivo(carpetas: list[Path], patron: str) -> Path | None:
    hallados = [p for carpeta in carpetas for p in carpeta.glob(patron)
                if p.is_file() and not p.name.startswith("~$")]
    return max(hallados, key=lambda p: p.stat().st_mtime) if hallados else None

async def anio_vigente() -> int:
    fijo = int(SETTINGS.get("periodo", {}).get("anio_actual", 0) or 0)
    if fijo:
        return fijo
    con = await asyncpg.connect(PG_DSN)
    try:
        anio = await con.fetchval("SELECT EXTRACT(YEAR FROM max(fecha))::int FROM visordg.ventas_raw_dos")
    finally:
        await con.close()
    return anio or date.today().year

async def _cargar_por_anio(carpetas: list[Path], fuente: str, cargador) -> None:
    archivos = SETTINGS["fuentes"]["archivos"]
    anio = await anio_vigente()
    for anio_archivo, clave, obligatorio in ((anio, f"{fuente}_actual", True),
                                             (anio - 1, f"{fuente}_previo", False)):
        patron = archivos[clave].format(anio=anio_archivo)
        ruta = buscar_archivo(carpetas, patron)
        if ruta is None:
            msg = f"{fuente} {anio_archivo}: no se encontró '{patron}' en {', '.join(map(str, carpetas))}"
            if obligatorio:
                raise click.ClickException(msg)
            click.echo(f"  [OMITIDO] {msg}")
            continue
        click.echo(f"  {fuente} {anio_archivo}: {ruta.name}")
        await cargador(str(ruta), anio_archivo)

async def cargar_brigadas_fuente(carpetas: list[Path]) -> None:
    await _cargar_por_anio(carpetas, "brigadas", _cargar_brigadas)

async def cargar_capacitaciones_fuente(carpetas: list[Path]) -> None:
    async def _cap(ruta: str, _anio: int) -> None:
        await _cargar_capacitaciones(ruta)
    await _cargar_por_anio(carpetas, "capacitaciones", _cap)

FUENTES = ("ventas", "recaudacion", "brigadas", "capacitaciones")
FUENTES_MES = ("ventas_mes", "recaudacion_mes")

async def cargar_todo(origen: str | None = None, fuentes: tuple[str, ...] | list[str] | None = None) -> dict[str, str]:
    base = base_origen(origen)
    cargadores = {
        "ventas": lambda c: _cargar_ventas_dos(str(c[0])),
        "recaudacion": lambda c: _cargar_recaudacion_dos(str(c[0])),
        "brigadas": cargar_brigadas_fuente,
        "capacitaciones": cargar_capacitaciones_fuente,
        "ventas_mes": lambda c: _cargar_ventas_mes(str(c[0])),
        "recaudacion_mes": lambda c: _cargar_recaudacion_mes(str(c[0])),
    }
    pedidas = set(fuentes or FUENTES)
    pasos = [(f, cargadores[f]) for f in FUENTES + FUENTES_MES if f in pedidas]
    resultado = {}
    for fuente, cargar in pasos:
        try:
            click.echo(f"[{fuente}]")
            await cargar(carpetas_fuente(base, fuente.removesuffix("_mes")))
            resultado[fuente] = "ok"
        except Exception as exc:
            click.echo(f"  [ERROR] {fuente}: {exc}")
            resultado[fuente] = f"error: {exc}"
    return resultado

def variables_sql() -> dict[str, str]:
    anio = int(SETTINGS.get("periodo", {}).get("anio_actual", 0) or 0)
    meta = float(SETTINGS.get("metas", {}).get("meta_anual_recaudacion", 0) or 0)
    return {"anio_actual": str(anio), "meta": f"{meta:g}"}

def ubicar_psql() -> str:
    configurado = str(SETTINGS.get("database", {}).get("psql", "") or "").strip()
    if configurado:
        if Path(configurado).is_file():
            return configurado
        raise RuntimeError(f"[database].psql apunta a un archivo que no existe: {configurado}")
    en_path = shutil.which("psql")
    if en_path:
        return en_path
    candidatos = []
    for raiz in (os.environ.get("ProgramFiles", r"C:\Program Files"), r"C:\Program Files", r"D:\Program Files"):
        candidatos += sorted(Path(raiz).glob("PostgreSQL/*/bin/psql.exe"),
                             key=lambda p: int(p.parent.parent.name) if p.parent.parent.name.isdigit() else 0,
                             reverse=True)
    if candidatos:
        return str(candidatos[0])
    raise RuntimeError("no se encontró psql. Poner su ruta en [database].psql del settings.toml, "
                       "por ejemplo psql = \"C:/Program Files/PostgreSQL/18/bin/psql.exe\"")

def correr_sql(nombre: str, mostrar: bool = False) -> None:
    psql = ubicar_psql()
    db = SETTINGS["database"]
    entorno = os.environ.copy()
    entorno["PGPASSWORD"] = str(db["password"])
    entorno["PGCLIENTENCODING"] = "UTF8"
    args = [psql, "-v", "ON_ERROR_STOP=1"]
    for clave, valor in variables_sql().items():
        args += ["-v", f"{clave}={valor}"]
    args += [] if mostrar else ["-q"]
    args += ["-h", str(db["host"]), "-p", str(db["port"]), "-U", str(db["user"]), "-d", str(db["name"]),
             "-f", str(RUTA_SQL / nombre)]
    res = subprocess.run(args, env=entorno, capture_output=True, text=True,
                         encoding="utf-8", errors="replace", check=False)
    if mostrar and res.stdout:
        click.echo(res.stdout)
    if res.returncode != 0:
        raise RuntimeError(f"{nombre} falló: {res.stderr.strip()[-500:]}")

SCRIPTS_REFRESCO = ("05_refrescar_dos.sql",)

async def _marcar_actualizado() -> None:
    con = await asyncpg.connect(PG_DSN)
    try:
        await con.execute("UPDATE visordg.visor_refresh SET actualizado_en = now() WHERE id = 1")
    finally:
        await con.close()

def refrescar_sql() -> None:
    for script in SCRIPTS_REFRESCO:
        correr_sql(script)
        click.echo(f"  {script}: OK")
    asyncio.run(_marcar_actualizado())

def _carpetas_cli(carpeta: str | None, origen: str | None, fuente: str) -> list[Path]:
    return [Path(carpeta)] if carpeta else carpetas_fuente(base_origen(origen), fuente)

@cli.command()
@OPCION_ORIGEN
@click.option("--sin-refresco", is_flag=True, help="Solo carga; no corre el refresco")
def todo(origen: str | None, sin_refresco: bool) -> None:
    """Carga ventas, recaudación, brigadas y capacitaciones, y refresca."""
    resultado = asyncio.run(cargar_todo(origen))
    if not sin_refresco:
        click.echo("[refresco]")
        refrescar_sql()
    click.echo("Resumen: " + " · ".join(f"{k}={v}" for k, v in resultado.items()))
    if any(v != "ok" for v in resultado.values()):
        raise SystemExit(1)

def _tabla_verificacion(titulo: str, filas: list[tuple], columnas: list[str], tolerancia: float) -> int:
    click.echo(f"\n=== {titulo} ===")
    click.echo("  " + " | ".join(c.rjust(18) if i else c.ljust(8) for i, c in enumerate(columnas)))
    malos = 0
    for etiqueta, archivo, base, *extra in filas:
        ok = abs((archivo or 0) - (base or 0)) <= tolerancia
        malos += 0 if ok else 1
        celdas = [f"{v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".") if isinstance(v, float)
                  else f"{v:,}".replace(",", ".") if isinstance(v, int) else str(v)
                  for v in (archivo, base, *extra)]
        click.echo(f"  {etiqueta:<8} | " + " | ".join(c.rjust(18) for c in celdas) + ("   ✓" if ok else "   ✗ NO CUADRA"))
    return malos

async def _base(sql: str, *args) -> list:
    con = await asyncpg.connect(PG_DSN)
    try:
        return await con.fetch(sql, *args)
    finally:
        await con.close()

async def _verificar_csv(carpeta: Path, patron: str, tabla: str, col_valor: str, lector,
                         todas_las_filas=None) -> int:
    archivo = {}
    filas_archivo = (todas_las_filas(carpeta) if todas_las_filas
                     else [r for ruta in sorted(carpeta.glob(patron)) for r in lector(ruta)])
    for fecha, *_, valor in filas_archivo:
        k = (fecha.year, fecha.month)
        n, v = archivo.get(k, (0, 0.0))
        archivo[k] = (n + 1, v + float(valor))
    base = {(r["a"], r["m"]): (r["n"], float(r["v"])) for r in await _base(
        f"""SELECT EXTRACT(YEAR FROM fecha)::int a, EXTRACT(MONTH FROM fecha)::int m,
                   COUNT(*)::int n, SUM({col_valor}) v FROM visordg.{tabla} GROUP BY 1, 2""")}
    claves = sorted(set(archivo) | set(base))
    filas = [(f"{a}-{m:02d}", archivo.get((a, m), (0, 0.0))[1], base.get((a, m), (0, 0.0))[1],
              archivo.get((a, m), (0, 0))[0], base.get((a, m), (0, 0))[0]) for a, m in claves]
    malos = _tabla_verificacion(f"{tabla}: archivos {patron} vs base", filas,
                                ["año-mes", "suma archivo", "suma base", "filas archivo", "filas base"], 0.01)
    malos += sum(1 for f in filas if f[3] != f[4])
    return malos

async def _verificar_brigadas(carpetas: list[Path]) -> int:
    archivos, anio = SETTINGS["fuentes"]["archivos"], await anio_vigente()
    malos = 0
    for anio_arch, clave in ((anio, "brigadas_actual"), (anio - 1, "brigadas_previo")):
        ruta = buscar_archivo(carpetas, archivos[clave].format(anio=anio_arch))
        if not ruta:
            click.echo(f"\n(brigadas {anio_arch}: sin archivo, se omite)")
            continue
        hojas = pd.ExcelFile(ruta).sheet_names
        for tabla, campo, hoja in (
                ("brigadas_eventos", "eventos",
                 next((h for h in hojas if "eventos" in h.lower()), None) or next((h for h in hojas if "total" in h.lower()), None)),
                ("brigadas_atendidos", "atendidos", next((h for h in hojas if "atendidos" in h.lower()), None))):
            if not hoja:
                continue
            total_excel = {}
            detalle = {}
            for *_, mes, valor in _despivotar_brigadas(str(ruta), hoja, anio_arch, con_agencia=(campo == "atendidos"),
                                                       control=total_excel):
                detalle[mes] = detalle.get(mes, 0) + valor
            base = {r["mes"]: r["v"] for r in await _base(
                f"SELECT mes, SUM({campo})::int v FROM visordg.{tabla} WHERE anio = $1 GROUP BY mes", anio_arch)}
            filas = [(f"{anio_arch}-{m:02d}", detalle.get(m, 0), base.get(m, 0),
                      total_excel.get(m, "—")) for m in sorted(set(detalle) | set(base))]
            malos += _tabla_verificacion(f"{campo} {anio_arch}: {ruta.name} [{hoja}] vs base", filas,
                                         ["año-mes", "detalle Excel", "base", "Total general Excel"], 0)
            dif_total = [f"{a}" for a, d, _, t in filas if isinstance(t, int) and t != d]
            if dif_total:
                click.echo(f"  [AVISO] En el Excel, la fila 'Total general' no coincide con la suma de sus "
                           f"provincias en: {', '.join(dif_total)} (revisar el archivo con el área)")
    return malos

async def _verificar_capacitaciones(carpetas: list[Path]) -> int:
    archivos, anio = SETTINGS["fuentes"]["archivos"], await anio_vigente()
    archivo = {}
    for anio_arch, clave in ((anio, "capacitaciones_actual"), (anio - 1, "capacitaciones_previo")):
        ruta = buscar_archivo(carpetas, archivos[clave].format(anio=anio_arch))
        if not ruta:
            continue
        registros, _, _ = _filas_capacitaciones(str(ruta), avisar=False)
        for r in registros:
            k = (r[3].year, r[3].month)
            n, c = archivo.get(k, (0, 0))
            archivo[k] = (n + 1, c + r[6])
    base = {(r["a"], r["m"]): (r["n"], r["c"]) for r in await _base(
        """SELECT EXTRACT(YEAR FROM fecha)::int a, EXTRACT(MONTH FROM fecha)::int m,
                  COUNT(*)::int n, SUM(total_capacitados)::int c FROM visordg.capacitaciones_raw GROUP BY 1, 2""")}
    claves = sorted(set(archivo) | set(base))
    malos = _tabla_verificacion("capacitaciones (EVENTOS = filas) vs base", [
        (f"{a}-{m:02d}", archivo.get((a, m), (0, 0))[0], base.get((a, m), (0, 0))[0]) for a, m in claves],
        ["año-mes", "eventos archivo", "eventos base"], 0)
    malos += _tabla_verificacion("capacitaciones (CAPACITADOS) vs base", [
        (f"{a}-{m:02d}", archivo.get((a, m), (0, 0))[1], base.get((a, m), (0, 0))[1]) for a, m in claves],
        ["año-mes", "capac. archivo", "capac. base"], 0)
    return malos

OPCION_SOLO = click.option("--solo", "solo", type=click.Choice(FUENTES), multiple=True,
                           help="Solo esta(s) fuente(s); se puede repetir: --solo ventas --solo brigadas")

@cli.command()
@OPCION_ORIGEN
@OPCION_SOLO
def verificar(origen: str | None, solo: tuple[str, ...]) -> None:
    """Compara, mes a mes, los archivos fuente contra lo cargado en la base (solo lectura).

    Si todo marca ✓, lo que muestra el visor es exactamente lo que suman los
    archivos. En brigadas cruza además contra la fila 'Total general' del Excel.
    Con --solo se verifica solo esa(s) fuente(s).
    """
    pedidas = set(solo or FUENTES)

    async def _todo() -> int:
        base = base_origen(origen)
        malos = 0
        if "ventas" in pedidas:
            malos += await _verificar_csv(carpetas_fuente(base, "ventas")[0], "CEL_*.csv",
                                          "ventas_raw_dos", "ventas", _filas_ventas,
                                          todas_las_filas=filas_ventas_carpeta)
        if "recaudacion" in pedidas:
            malos += await _verificar_csv(carpetas_fuente(base, "recaudacion")[0], "Reca_*.csv",
                                          "recaudacion_raw_dos", "recaudado", _filas_recaudacion,
                                          todas_las_filas=filas_recaudacion_carpeta)
        if "brigadas" in pedidas:
            malos += await _verificar_brigadas(carpetas_fuente(base, "brigadas"))
        if "capacitaciones" in pedidas:
            malos += await _verificar_capacitaciones(carpetas_fuente(base, "capacitaciones"))
        return malos
    malos = asyncio.run(_todo())
    click.echo("\n" + ("RESULTADO: todo cuadra ✓ (archivo = base en todos los meses)" if not malos
                       else f"RESULTADO: {malos} diferencia(s) ✗ — si recién se actualizó un archivo, "
                            "recargar esa fuente (pdm run cargar solo <fuente>) y verificar de nuevo"))
    if malos:
        raise SystemExit(1)

@cli.command()
def refrescar() -> None:
    """Corre el refresco único (05_refrescar_dos.sql)."""
    refrescar_sql()

@cli.command()
@click.argument("fuentes", nargs=-1, required=True, type=click.Choice(FUENTES + FUENTES_MES))
@OPCION_ORIGEN
@click.option("--sin-refresco", is_flag=True, help="Solo carga; no corre el refresco")
def solo(fuentes: tuple[str, ...], origen: str | None, sin_refresco: bool) -> None:
    """Carga SOLO la(s) fuente(s) indicada(s) y refresca (igual que 'todo', pero parcial).

    \b
    Ejemplos:
      pdm run cargar solo ventas --origen local
      pdm run cargar solo brigadas capacitaciones
      pdm run cargar solo ventas_mes recaudacion_mes   (solo el mes en curso)
    Atajos: pdm run cargar-ventas | cargar-recaudacion | cargar-brigadas | cargar-capacitaciones
    """
    resultado = asyncio.run(cargar_todo(origen, fuentes))
    if not sin_refresco:
        click.echo("[refresco]")
        refrescar_sql()
    click.echo("Resumen: " + " · ".join(f"{k}={v}" for k, v in resultado.items()))
    if any(v != "ok" for v in resultado.values()):
        raise SystemExit(1)

@cli.command()
def auditar() -> None:
    """Corre sql/auditoria_panel.sql (solo lectura) con año y meta del settings.toml."""
    correr_sql("auditoria_panel.sql", mostrar=True)

@cli.command("capacitaciones-dos")
@ARG_CARPETA
@OPCION_ORIGEN
def capacitaciones_dos(carpeta: str | None, origen: str | None) -> None:
    """Capacitaciones año actual + previo."""
    asyncio.run(cargar_capacitaciones_fuente(_carpetas_cli(carpeta, origen, "capacitaciones")))

@cli.command("brigadas-dos")
@ARG_CARPETA
@OPCION_ORIGEN
def brigadas_dos(carpeta: str | None, origen: str | None) -> None:
    """Brigadas año actual + previo (busca en todas las carpetas configuradas)."""
    asyncio.run(cargar_brigadas_fuente(_carpetas_cli(carpeta, origen, "brigadas")))

@cli.command("recaudacion-dos")
@ARG_CARPETA
@OPCION_ORIGEN
def recaudacion_dos(carpeta: str | None, origen: str | None) -> None:
    """Todos los Reca_*.csv -> recaudacion_raw_dos (reemplazo total atómico)."""
    asyncio.run(_cargar_recaudacion_dos(str(_carpetas_cli(carpeta, origen, "recaudacion")[0])))

@cli.command("ventas-dos")
@ARG_CARPETA
@OPCION_ORIGEN
def ventas_dos(carpeta: str | None, origen: str | None) -> None:
    """Todos los CEL_*.csv -> ventas_raw_dos (reemplazo total atómico)."""
    asyncio.run(_cargar_ventas_dos(str(_carpetas_cli(carpeta, origen, "ventas")[0])))

@cli.command()
@click.argument("archivo", type=click.Path(exists=True))
@click.argument("anio", type=int, required=False, default=None)
def brigadas(archivo: str, anio: int | None) -> None:
    """Carga Atendidos_brigadas de Atenciones_brigadas.xlsx.

    ANIO es opcional: si no se pasa, se usa el año vigente del visor
    ([periodo].anio_actual o el del último dato de ventas). Nada fijo.
    """
    async def _correr() -> None:
        await _cargar_brigadas(archivo, anio or await anio_vigente())
    asyncio.run(_correr())

@cli.command()
def medir() -> None:
    """Mide cuánto tarda cada consulta de las pantallas (solo lectura), de la más lenta a la más rápida."""
    import time
    import main as api

    async def _medir():
        con = await asyncpg.connect(PG_DSN, server_settings={"search_path": "visordg,seg,public"})
        tiempos = []
        try:
            consultas = [(f"tv-data: {k}", sql, ()) for k, sql in api.CONSULTAS_TV.items()]
            kv, kr = api.anios_atras("grafica_venta_mensual_presi"), api.anios_atras("grafica_reca_mensual_presi")
            kt, kc = api.anios_atras("tablas_pan2_ventas"), api.anios_atras("tablas_pan3_reca")
            consultas.append(("diario-mes", api.SQL_DIARIO_MES, (kv, kr)))
            consultas.append(("ventas-por-meses", api.SQL_VENTAS_POR_MESES, (kt,)))
            for nombre, clave in (("provincias", "upper(btrim(v.provincia))"), ("sectores", "v.sector")):
                consultas.append((f"ventas-tablas: {nombre}", api.SQL_TABLAS_POR_ANIO.format(
                    tabla="ventas_raw_dos", valor="ventas", clave=clave), (kt,)))
            for nombre, clave in (("provincias", "upper(btrim(v.provincia))"), ("sectores", "upper(btrim(v.sector))"),
                                  ("impuestos", "COALESCE(NULLIF(upper(btrim(v.impuesto)), ''), 'SIN IMPUESTO')")):
                consultas.append((f"recaudacion-tablas: {nombre}", api.SQL_TABLAS_POR_ANIO.format(
                    tabla="recaudacion_raw_dos", valor="recaudado", clave=clave), (kc,)))
            for nombre, sql, args in consultas:
                inicio = time.perf_counter()
                filas = await con.fetch(sql, *args)
                tiempos.append((time.perf_counter() - inicio, nombre, len(filas)))
            for tabla in ("ventas_raw_dos", "recaudacion_raw_dos", "capacitaciones_raw"):
                n = await con.fetchval(f"SELECT count(*) FROM visordg.{tabla}")
                click.echo(f"  {tabla}: {_miles(n)} filas")
        finally:
            await con.close()
        click.echo("")
        for segundos, nombre, n in sorted(tiempos, reverse=True):
            click.echo(f"  {segundos * 1000:8.0f} ms  {nombre}  ({n} filas)")
        click.echo(f"  {sum(t for t, _, _ in tiempos) * 1000:8.0f} ms  TOTAL (una tras otra; el API las corre en paralelo)")

    asyncio.run(_medir())

if __name__ == "__main__":
    cli()
