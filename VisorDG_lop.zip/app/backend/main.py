import asyncio
import json
import logging
import time
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path

import asyncpg
import jwt
from fastapi import Depends, FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from pwdlib import PasswordHash
from uvicorn.logging import AccessFormatter, DefaultFormatter

from config import cargar_settings, construir_dsn
from cargas import FUENTES, FUENTES_MES, ORIGENES, SCRIPTS_REFRESCO, asegurar_esquema, cargar_todo, correr_sql

SETTINGS = cargar_settings()
PG_DSN = construir_dsn(SETTINGS)

SEG = SETTINGS["seguridad"]
JWT_SECRET = SEG["jwt_secret"]
JWT_ALG = "HS256"
JWT_MINUTOS = int(SEG.get("jwt_minutos", 30))
ADMIN_PASSWORD = SEG.get("admin_password_inicial", "Cambiar.2026")

MONITOR = SETTINGS.get("monitor", {})

CORTE_MENSUAL = (MONITOR.get("corte_mensual", "laborable")
                 if MONITOR.get("corte_mensual", "laborable") in ("laborable", "datos") else "laborable")

RUTA_BACKEND = Path(__file__).resolve().parent

CANDADO_RECARGA = asyncio.Lock()

FORMATO_HORA = "%Y-%m-%d %H:%M:%S"


def log_con_hora() -> None:
    for nombre, clase, formato in (
            ("uvicorn", DefaultFormatter, "%(asctime)s %(levelprefix)s %(message)s"),
            ("uvicorn.access", AccessFormatter,
             '%(asctime)s %(levelprefix)s %(client_addr)s - "%(request_line)s" %(status_code)s')):
        for manejador in logging.getLogger(nombre).handlers:
            manejador.setFormatter(clase(formato, datefmt=FORMATO_HORA))


def registro(mensaje: str) -> None:
    print(f"{datetime.now():{FORMATO_HORA}} {mensaje}", flush=True)


log_con_hora()


def _hora(valor) -> tuple[int, int] | None:
    if valor is None or valor is False or (isinstance(valor, str) and not valor.strip()):
        return None
    texto = str(valor).strip()
    partes = texto.split(":") if ":" in texto else [texto, "0"]
    try:
        h, m = int(partes[0]), int(partes[1])
    except ValueError:
        return None
    if h == 24 and m == 0:
        h = 0
    return (h, m) if 0 <= h <= 23 and 0 <= m <= 59 else None


def horas_recarga() -> list[tuple[int, int]]:
    fuentes = SETTINGS.get("fuentes", {})
    valores = (fuentes.get("hora_recarga_automatico", 23), fuentes.get("hora_recarga_automatico_suplementaria"))
    return sorted({h for h in (_hora(v) for v in valores) if h is not None})


def proxima_recarga(horas: list[tuple[int, int]], desde: datetime) -> datetime:
    candidatos = [datetime.combine(desde.date() + timedelta(days=d), datetime.min.time()).replace(hour=h, minute=m)
                  for h, m in horas for d in (0, 1)]
    return min(c for c in candidatos if c > desde)

pwd_hasher = PasswordHash.recommended()
bearer = HTTPBearer(auto_error=False)

CONSULTAS_TV = {
    "mes_corriente": """
        SELECT fecha,
               ventas_anio_anterior, ventas_anio_actual,
               recaudacion_anio_anterior, recaudacion_anio_actual,
               brigadas_anio_anterior, brigadas_anio_actual,
               capacitaciones_anio_anterior, capacitaciones_anio_actual
        FROM visordg.dash_mes_corriente ORDER BY fecha""",
    "hist_ventas": """
        SELECT to_char(mes, 'YYYY-MM') AS fecha, ventas,
               archivo AS archivo_ventas,
               to_char(max(fecha_corte) OVER (), 'YYYY-MM-DD') AS corte_ventas
        FROM visordg.hist_ventas ORDER BY mes""",
    "hist_recaudacion": """
        SELECT to_char(mes, 'YYYY-MM') AS fecha, recaudacion,
               archivo AS archivo_recaudacion,
               to_char(max(fecha_corte) OVER (), 'YYYY-MM-DD') AS corte_recaudacion
        FROM visordg.hist_recaudacion ORDER BY mes""",
    "hist_brigadas": """
        SELECT to_char(mes, 'YYYY-MM') AS fecha, brigadas,
               archivo AS archivo_brigadas,
               to_char(fecha_corte, 'YYYY-MM-DD') AS corte_brigadas
        FROM visordg.hist_brigadas ORDER BY mes""",
    "hist_capacitaciones": """
        SELECT to_char(mes, 'YYYY-MM') AS fecha, capacitaciones,
               archivo AS archivo_capacitaciones,
               to_char(max(fecha_corte) OVER (), 'YYYY-MM-DD') AS corte_capacitaciones
        FROM visordg.hist_capacitaciones ORDER BY mes""",
    "ticker_mes": """
        WITH cortes AS (
          SELECT
            (SELECT max(fecha_corte) FROM visordg.hist_ventas
              WHERE mes >= date_trunc('year', CURRENT_DATE)::date) AS c_ventas,
            (SELECT max(fecha_corte) FROM visordg.hist_recaudacion
              WHERE mes >= date_trunc('year', CURRENT_DATE)::date) AS c_recaudacion,
            (SELECT max(fecha_corte) FROM visordg.hist_capacitaciones
              WHERE mes >= date_trunc('year', CURRENT_DATE)::date) AS c_capacitaciones,
            (SELECT max(fecha_corte) FROM visordg.hist_brigadas) AS c_brigadas
        )
        SELECT 'ventas' AS fuente, to_char(c.c_ventas, 'YYYY-MM-DD') AS corte,
               (SELECT sum(v.ventas) FROM visordg.ventas_raw_dos v
                 WHERE v.fecha BETWEEN date_trunc('month', c.c_ventas)::date AND c.c_ventas) AS actual,
               (SELECT sum(v.ventas) FROM visordg.ventas_raw_dos v
                 WHERE v.fecha BETWEEN (date_trunc('month', c.c_ventas) - interval '1 year')::date
                                   AND (c.c_ventas - interval '1 year')::date) AS previo
        FROM cortes c
        UNION ALL
        SELECT 'recaudacion', to_char(c.c_recaudacion, 'YYYY-MM-DD'),
               (SELECT sum(r.recaudado) FROM visordg.recaudacion_raw_dos r
                 WHERE r.fecha BETWEEN date_trunc('month', c.c_recaudacion)::date AND c.c_recaudacion),
               (SELECT sum(r.recaudado) FROM visordg.recaudacion_raw_dos r
                 WHERE r.fecha BETWEEN (date_trunc('month', c.c_recaudacion) - interval '1 year')::date
                                   AND (c.c_recaudacion - interval '1 year')::date)
        FROM cortes c
        UNION ALL
        SELECT 'capacitaciones', to_char(c.c_capacitaciones, 'YYYY-MM-DD'),
               (SELECT count(*) FROM visordg.capacitaciones_raw ca
                 WHERE ca.fecha::date BETWEEN date_trunc('month', c.c_capacitaciones)::date AND c.c_capacitaciones),
               (SELECT count(*) FROM visordg.capacitaciones_raw ca
                 WHERE ca.fecha::date BETWEEN (date_trunc('month', c.c_capacitaciones) - interval '1 year')::date
                                          AND (c.c_capacitaciones - interval '1 year')::date)
        FROM cortes c
        UNION ALL
        SELECT 'brigadas', to_char(c.c_brigadas, 'YYYY-MM-DD'),
               (SELECT sum(b.eventos) FROM visordg.brigadas_eventos b
                 WHERE b.anio = extract(year from c.c_brigadas)::smallint
                   AND b.mes  = extract(month from c.c_brigadas)::smallint),
               NULL
        FROM cortes c
        UNION ALL
        SELECT 'brigadas_atendidos', to_char(c.c_brigadas, 'YYYY-MM-DD'),
               (SELECT sum(b.atendidos) FROM visordg.brigadas_atendidos b
                 WHERE b.anio = extract(year from c.c_brigadas)::smallint
                   AND b.mes  = extract(month from c.c_brigadas)::smallint),
               NULL
        FROM cortes c""",
    "ventas_provincias": """
        WITH per AS (
            SELECT date_trunc('month', max(fecha))::date AS m0,
                   EXTRACT(DAY FROM max(fecha))::int     AS dia_corte,
                   max(fecha)                            AS fmax,
                   CASE WHEN (date_trunc('month', CURRENT_DATE) - INTERVAL '1 day')::date
                             >= date_trunc('year', max(fecha))::date
                        THEN LEAST(max(fecha), (date_trunc('month', CURRENT_DATE) - INTERVAL '1 day')::date)
                        ELSE max(fecha) END              AS facum
            FROM visordg.ventas_raw_dos)
        SELECT upper(btrim(v.provincia)) AS provincia,
               COALESCE(SUM(v.ventas) FILTER (
                   WHERE date_trunc('month', v.fecha) = per.m0 - INTERVAL '2 years'
                     AND EXTRACT(DAY FROM v.fecha) <= per.dia_corte), 0) / 1e6 AS mes_hace_dos_anios,
               COALESCE(SUM(v.ventas) FILTER (
                   WHERE date_trunc('month', v.fecha) = per.m0 - INTERVAL '1 year'
                     AND EXTRACT(DAY FROM v.fecha) <= per.dia_corte), 0) / 1e6 AS mes_anio_anterior,
               COALESCE(SUM(v.ventas) FILTER (
                   WHERE date_trunc('month', v.fecha) = per.m0
                     AND EXTRACT(DAY FROM v.fecha) <= per.dia_corte), 0) / 1e6 AS mes_anio_actual,
               COALESCE(SUM(v.ventas) FILTER (
                   WHERE v.fecha >= date_trunc('year', per.fmax) - INTERVAL '1 year'
                     AND v.fecha <= per.facum - INTERVAL '1 year'), 0) / 1e6 AS acum_anio_anterior,
               COALESCE(SUM(v.ventas) FILTER (
                   WHERE v.fecha >= date_trunc('year', per.fmax)
                     AND v.fecha <= per.facum), 0) / 1e6 AS acum_anio_actual
        FROM visordg.ventas_raw_dos v CROSS JOIN per
        WHERE v.fecha >= (per.m0 - INTERVAL '2 years')::date
        GROUP BY upper(btrim(v.provincia))
        ORDER BY mes_anio_actual DESC""",
    "ventas_sector_full": """
        WITH per AS (
            SELECT date_trunc('month', max(fecha))::date AS m0,
                   EXTRACT(DAY FROM max(fecha))::int     AS dia_corte,
                   max(fecha)                            AS fmax,
                   CASE WHEN (date_trunc('month', CURRENT_DATE) - INTERVAL '1 day')::date
                             >= date_trunc('year', max(fecha))::date
                        THEN LEAST(max(fecha), (date_trunc('month', CURRENT_DATE) - INTERVAL '1 day')::date)
                        ELSE max(fecha) END              AS facum
            FROM visordg.ventas_raw_dos)
        SELECT v.sector AS sector,
               COALESCE(SUM(v.ventas) FILTER (
                   WHERE date_trunc('month', v.fecha) = per.m0 - INTERVAL '2 years'
                     AND EXTRACT(DAY FROM v.fecha) <= per.dia_corte), 0) / 1e6 AS mes_hace_dos_anios,
               COALESCE(SUM(v.ventas) FILTER (
                   WHERE date_trunc('month', v.fecha) = per.m0 - INTERVAL '1 year'
                     AND EXTRACT(DAY FROM v.fecha) <= per.dia_corte), 0) / 1e6 AS mes_anio_anterior,
               COALESCE(SUM(v.ventas) FILTER (
                   WHERE date_trunc('month', v.fecha) = per.m0
                     AND EXTRACT(DAY FROM v.fecha) <= per.dia_corte), 0) / 1e6 AS mes_anio_actual,
               COALESCE(SUM(v.ventas) FILTER (
                   WHERE v.fecha >= date_trunc('year', per.fmax) - INTERVAL '1 year'
                     AND v.fecha <= per.facum - INTERVAL '1 year'), 0) / 1e6 AS acum_anio_anterior,
               COALESCE(SUM(v.ventas) FILTER (
                   WHERE v.fecha >= date_trunc('year', per.fmax)
                     AND v.fecha <= per.facum), 0) / 1e6 AS acum_anio_actual
        FROM visordg.ventas_raw_dos v CROSS JOIN per
        WHERE v.fecha >= (per.m0 - INTERVAL '2 years')::date
        GROUP BY v.sector
        ORDER BY mes_anio_actual DESC""",
    "rec_provincia": """
        WITH per AS (
            SELECT date_trunc('month', max(fecha))::date AS m0,
                   EXTRACT(DAY FROM max(fecha))::int     AS dia_corte,
                   max(fecha)                            AS fmax
            FROM visordg.recaudacion_raw_dos)
        SELECT upper(btrim(r.provincia)) AS provincia,
               COALESCE(SUM(r.recaudado) FILTER (
                   WHERE date_trunc('month', r.fecha) = per.m0 - INTERVAL '1 year'
                     AND EXTRACT(DAY FROM r.fecha) <= per.dia_corte), 0) / 1e6 AS mes_anio_anterior,
               COALESCE(SUM(r.recaudado) FILTER (
                   WHERE date_trunc('month', r.fecha) = per.m0), 0) / 1e6 AS mes_anio_actual,
               COALESCE(SUM(r.recaudado) FILTER (
                   WHERE r.fecha >= date_trunc('year', per.fmax) - INTERVAL '1 year'
                     AND r.fecha <= per.fmax - INTERVAL '1 year'), 0) / 1e6 AS acum_anio_anterior,
               COALESCE(SUM(r.recaudado) FILTER (
                   WHERE r.fecha >= date_trunc('year', per.fmax)), 0) / 1e6 AS acum_anio_actual
        FROM visordg.recaudacion_raw_dos r CROSS JOIN per
        WHERE r.fecha >= (date_trunc('year', per.fmax) - INTERVAL '1 year')::date
        GROUP BY upper(btrim(r.provincia))
        ORDER BY mes_anio_actual DESC""",
    "rec_actividad": """
        WITH per AS (
            SELECT date_trunc('month', max(fecha))::date AS m0,
                   EXTRACT(DAY FROM max(fecha))::int     AS dia_corte,
                   max(fecha)                            AS fmax
            FROM visordg.recaudacion_raw_dos)
        SELECT upper(btrim(r.sector)) AS sector,
               COALESCE(SUM(r.recaudado) FILTER (
                   WHERE date_trunc('month', r.fecha) = per.m0 - INTERVAL '1 year'
                     AND EXTRACT(DAY FROM r.fecha) <= per.dia_corte), 0) / 1e6 AS mes_anio_anterior,
               COALESCE(SUM(r.recaudado) FILTER (
                   WHERE date_trunc('month', r.fecha) = per.m0), 0) / 1e6 AS mes_anio_actual,
               COALESCE(SUM(r.recaudado) FILTER (
                   WHERE r.fecha >= date_trunc('year', per.fmax) - INTERVAL '1 year'
                     AND r.fecha <= per.fmax - INTERVAL '1 year'), 0) / 1e6 AS acum_anio_anterior,
               COALESCE(SUM(r.recaudado) FILTER (
                   WHERE r.fecha >= date_trunc('year', per.fmax)), 0) / 1e6 AS acum_anio_actual
        FROM visordg.recaudacion_raw_dos r CROSS JOIN per
        WHERE r.fecha >= (date_trunc('year', per.fmax) - INTERVAL '1 year')::date
        GROUP BY upper(btrim(r.sector))
        ORDER BY mes_anio_actual DESC""",
    "rec_impuesto": """
        WITH per AS (
            SELECT date_trunc('month', max(fecha))::date AS m0,
                   EXTRACT(DAY FROM max(fecha))::int     AS dia_corte,
                   max(fecha)                            AS fmax
            FROM visordg.recaudacion_raw_dos)
        SELECT COALESCE(NULLIF(upper(btrim(r.impuesto)), ''), 'SIN IMPUESTO') AS impuesto,
               COALESCE(SUM(r.recaudado) FILTER (
                   WHERE date_trunc('month', r.fecha) = per.m0 - INTERVAL '1 year'
                     AND EXTRACT(DAY FROM r.fecha) <= per.dia_corte), 0) / 1e6 AS mes_anio_anterior,
               COALESCE(SUM(r.recaudado) FILTER (
                   WHERE date_trunc('month', r.fecha) = per.m0), 0) / 1e6 AS mes_anio_actual,
               COALESCE(SUM(r.recaudado) FILTER (
                   WHERE r.fecha >= date_trunc('year', per.fmax) - INTERVAL '1 year'
                     AND r.fecha <= per.fmax - INTERVAL '1 year'), 0) / 1e6 AS acum_anio_anterior,
               COALESCE(SUM(r.recaudado) FILTER (
                   WHERE r.fecha >= date_trunc('year', per.fmax)), 0) / 1e6 AS acum_anio_actual
        FROM visordg.recaudacion_raw_dos r CROSS JOIN per
        WHERE r.fecha >= (date_trunc('year', per.fmax) - INTERVAL '1 year')::date
        GROUP BY 1
        ORDER BY mes_anio_actual DESC""",
    "hist_brigadas_atendidos": """
        SELECT to_char(make_date(anio::int, mes::int, 1), 'YYYY-MM') AS fecha,
               SUM(atendidos)::int AS brigadas_atendidos
        FROM visordg.brigadas_atendidos
        GROUP BY 1 ORDER BY 1""",
    "brigadas_provincia": """
        WITH pm AS (
            SELECT anio, max(mes) AS mes,
                   LEAST(max(mes), EXTRACT(MONTH FROM (date_trunc('month', CURRENT_DATE)
                         - interval '1 day'))::smallint) AS macum
            FROM visordg.brigadas_eventos
            WHERE anio = (SELECT max(anio) FROM visordg.brigadas_eventos) GROUP BY anio),
        ev AS (
            SELECT upper(btrim(e.provincia)) AS prov, max(e.zona) AS zona,
                   SUM(e.eventos) FILTER (WHERE e.anio = pm.anio - 1 AND e.mes = pm.mes)  AS m_ant,
                   SUM(e.eventos) FILTER (WHERE e.anio = pm.anio     AND e.mes = pm.mes)  AS m_act,
                   SUM(e.eventos) FILTER (WHERE e.anio = pm.anio - 1 AND e.mes <= pm.macum) AS a_ant,
                   SUM(e.eventos) FILTER (WHERE e.anio = pm.anio     AND e.mes <= pm.macum) AS a_act
            FROM visordg.brigadas_eventos e CROSS JOIN pm
            WHERE e.anio >= pm.anio - 1
              AND e.provincia IS NOT NULL AND btrim(e.provincia) <> '' AND lower(btrim(e.provincia)) <> 'nan'
            GROUP BY 1),
        att AS (
            SELECT upper(btrim(a.provincia)) AS prov, max(a.zona) AS zona,
                   SUM(a.atendidos) FILTER (WHERE a.anio = pm.anio - 1 AND a.mes = pm.mes)  AS m_ant,
                   SUM(a.atendidos) FILTER (WHERE a.anio = pm.anio     AND a.mes = pm.mes)  AS m_act,
                   SUM(a.atendidos) FILTER (WHERE a.anio = pm.anio - 1 AND a.mes <= pm.macum) AS a_ant,
                   SUM(a.atendidos) FILTER (WHERE a.anio = pm.anio     AND a.mes <= pm.macum) AS a_act
            FROM visordg.brigadas_atendidos a CROSS JOIN pm
            WHERE a.anio >= pm.anio - 1
              AND a.provincia IS NOT NULL AND btrim(a.provincia) <> '' AND lower(btrim(a.provincia)) <> 'nan'
            GROUP BY 1)
        SELECT COALESCE(ev.zona, att.zona) AS zonal, COALESCE(ev.prov, att.prov) AS provincia,
               COALESCE(ev.m_ant, 0)  AS ev_mes_anio_anterior,  COALESCE(ev.m_act, 0)  AS ev_mes_anio_actual,
               COALESCE(ev.a_ant, 0)  AS ev_acum_anio_anterior, COALESCE(ev.a_act, 0)  AS ev_acum_anio_actual,
               COALESCE(att.m_ant, 0) AS at_mes_anio_anterior,  COALESCE(att.m_act, 0) AS at_mes_anio_actual,
               COALESCE(att.a_ant, 0) AS at_acum_anio_anterior, COALESCE(att.a_act, 0) AS at_acum_anio_actual
        FROM ev FULL OUTER JOIN att ON att.prov = ev.prov
        ORDER BY provincia""",
    "cap_provincia": """
        WITH p AS (
            SELECT max(fecha)::date AS fmax,
                   date_trunc('month', max(fecha))::date AS m0,
                   EXTRACT(DAY FROM max(fecha))::int AS dia,
                   date_trunc('year', max(fecha))::date AS y0,
                   LEAST(max(fecha)::date, (date_trunc('month', CURRENT_DATE)
                         - interval '1 day')::date) AS facum
            FROM visordg.capacitaciones_raw),
        c AS (
            SELECT r.zonal, upper(btrim(r.provincia)) AS prov, r.fecha::date AS f,
                   r.total_capacitados AS cap, p.*
            FROM visordg.capacitaciones_raw r CROSS JOIN p
            WHERE r.fecha::date >= (p.y0 - INTERVAL '1 year')::date AND r.provincia IS NOT NULL AND btrim(r.provincia) <> '' AND lower(btrim(r.provincia)) <> 'nan')
        SELECT max(zonal) AS zonal, prov AS provincia,
               COUNT(*) FILTER (WHERE date_trunc('month', f) = m0 - INTERVAL '1 year'
                                  AND EXTRACT(DAY FROM f) <= dia)                        AS ev_mes_anio_anterior,
               COUNT(*) FILTER (WHERE date_trunc('month', f) = m0 AND f <= fmax)          AS ev_mes_anio_actual,
               COUNT(*) FILTER (WHERE f >= y0 - INTERVAL '1 year' AND f <= (facum - INTERVAL '1 year')::date) AS ev_acum_anio_anterior,
               COUNT(*) FILTER (WHERE f >= y0 AND f <= facum)                             AS ev_acum_anio_actual,
               COALESCE(SUM(cap) FILTER (WHERE date_trunc('month', f) = m0 - INTERVAL '1 year'
                                           AND EXTRACT(DAY FROM f) <= dia), 0)            AS cp_mes_anio_anterior,
               COALESCE(SUM(cap) FILTER (WHERE date_trunc('month', f) = m0 AND f <= fmax), 0) AS cp_mes_anio_actual,
               COALESCE(SUM(cap) FILTER (WHERE f >= y0 - INTERVAL '1 year'
                                           AND f <= (facum - INTERVAL '1 year')::date), 0) AS cp_acum_anio_anterior,
               COALESCE(SUM(cap) FILTER (WHERE f >= y0 AND f <= facum), 0)                AS cp_acum_anio_actual
        FROM c GROUP BY prov ORDER BY prov""",
}

SQL_PERIODO_CAPACITACIONES = "SELECT to_char(max(mes), 'YYYY-MM') FROM visordg.hist_capacitaciones"

_LABORAL = "visordg.ultimo_dia_laborable()"
_MES_BRIG = "(SELECT max(mes) FROM visordg.hist_brigadas)"
_CORTE_BRIG = (f"GREATEST({_MES_BRIG}, LEAST({_LABORAL}, "
               f"({_MES_BRIG} + INTERVAL '1 month - 1 day')::date))")

def _cambiar(clave: str, viejo: str, nuevo: str) -> None:
    if CONSULTAS_TV[clave].count(viejo) != 1:
        raise RuntimeError(f"corte_mensual: no se pudo ajustar la consulta {clave}")
    CONSULTAS_TV[clave] = CONSULTAS_TV[clave].replace(viejo, nuevo)

_cambiar("hist_brigadas", "to_char(fecha_corte, 'YYYY-MM-DD') AS corte_brigadas",
         "to_char(fecha_corte, 'YYYY-MM-DD') AS corte_datos_brigadas,\n"
         "               to_char(fecha_corte, 'YYYY-MM-DD') AS corte_brigadas")
_cambiar("hist_capacitaciones", "to_char(max(fecha_corte) OVER (), 'YYYY-MM-DD') AS corte_capacitaciones",
         "to_char(max(fecha_corte) OVER (), 'YYYY-MM-DD') AS corte_datos_capacitaciones,\n"
         "               to_char(max(fecha_corte) OVER (), 'YYYY-MM-DD') AS corte_capacitaciones")

if CORTE_MENSUAL == "laborable":
    _cambiar("hist_brigadas", "to_char(fecha_corte, 'YYYY-MM-DD') AS corte_brigadas",
             "to_char(GREATEST(max(mes) OVER (), LEAST(visordg.ultimo_dia_laborable(), "
             "(max(mes) OVER () + INTERVAL '1 month - 1 day')::date)), 'YYYY-MM-DD') AS corte_brigadas")
    _cambiar("hist_capacitaciones", "to_char(max(fecha_corte) OVER (), 'YYYY-MM-DD') AS corte_capacitaciones",
             "to_char(visordg.ultimo_dia_laborable(), 'YYYY-MM-DD') AS corte_capacitaciones")
    _cambiar("ticker_mes", """            (SELECT max(fecha_corte) FROM visordg.hist_capacitaciones
              WHERE mes >= date_trunc('year', CURRENT_DATE)::date) AS c_capacitaciones,
            (SELECT max(fecha_corte) FROM visordg.hist_brigadas) AS c_brigadas""",
             f"""            {_LABORAL} AS c_capacitaciones,
            {_CORTE_BRIG} AS c_brigadas""")
    _cambiar("cap_provincia", "            FROM visordg.capacitaciones_raw),",
             "            FROM (SELECT visordg.ultimo_dia_laborable() AS fecha) corte_laborable),")
    SQL_PERIODO_CAPACITACIONES = "SELECT to_char(visordg.ultimo_dia_laborable(), 'YYYY-MM')"

async def _init_db(pool: asyncpg.Pool) -> None:
    async with pool.acquire() as con:
        total = await con.fetchval("SELECT count(*) FROM seg.usuarios")
        if total == 0:
            await con.execute(
                """INSERT INTO seg.usuarios (username, email, password_hash, perfil_id)
                   SELECT 'admin', 'admin@sri.gob.ec', $1, id
                   FROM seg.perfiles WHERE codigo = 'ADMIN'""",
                pwd_hasher.hash(ADMIN_PASSWORD))
            registro(f"[INIT] Usuario 'admin' creado (clave inicial del settings.toml) - CAMBIALA de inmediato")

@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.pool = await asyncpg.create_pool(
        PG_DSN, min_size=2, max_size=20,
        server_settings={"search_path": "visordg,seg,public"})
    app.state.ws_clients = set()
    await _init_db(app.state.pool)
    async with app.state.pool.acquire() as con:
        await asegurar_esquema(con)
    log_con_hora()
    app.state.tarea_nocturna = asyncio.create_task(tarea_recarga_automatica())
    app.state.tarea_cache = asyncio.create_task(tarea_precalentar()) if CACHE_SEGUNDOS else None
    yield
    app.state.tarea_nocturna.cancel()
    if app.state.tarea_cache:
        app.state.tarea_cache.cancel()
    await app.state.pool.close()

app = FastAPI(title="Visor Gerencial SRI", version="0.3.0", lifespan=lifespan)

app.add_middleware(GZipMiddleware, minimum_size=1024)

class StaticFilesConCache(StaticFiles):

    async def get_response(self, path, scope):
        respuesta = await super().get_response(path, scope)
        if respuesta.status_code == 200:
            respuesta.headers["Cache-Control"] = "public, max-age=86400"
        return respuesta

app.mount("/font", StaticFilesConCache(directory=RUTA_BACKEND.parent / "frontend" / "dist" / "font"), name="font")

class LoginIn(BaseModel):

    username: str
    password: str

def crear_token(user_id: str, perfil: str) -> str:
    payload = {"sub": user_id, "perfil": perfil,
               "exp": datetime.now(timezone.utc) + timedelta(minutes=JWT_MINUTOS)}
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALG)

async def usuario_actual(cred: HTTPAuthorizationCredentials = Depends(bearer)) -> dict:
    if not cred:
        raise HTTPException(401, "Token requerido")
    try:
        return jwt.decode(cred.credentials, JWT_SECRET, algorithms=[JWT_ALG])
    except jwt.PyJWTError as exc:
        raise HTTPException(401, "Token inválido o expirado") from exc

async def solo_admin(usuario: dict = Depends(usuario_actual)) -> dict:
    if usuario.get("perfil") != "ADMIN":
        raise HTTPException(403, "Requiere perfil ADMIN")
    return usuario

@app.post("/api/v1/auth/login")
async def login(body: LoginIn) -> dict:
    async with app.state.pool.acquire() as con:
        row = await con.fetchrow(
            """SELECT u.id, u.password_hash, u.activo, p.codigo AS perfil
               FROM seg.usuarios u JOIN seg.perfiles p ON p.id = u.perfil_id
               WHERE u.username = $1""", body.username)
        if not row or not row["activo"] or not pwd_hasher.verify(body.password, row["password_hash"]):
            await con.execute("INSERT INTO seg.auditoria (accion, detalle) VALUES ('login_fail', $1)",
                              json.dumps({"username": body.username}))
            raise HTTPException(401, "Credenciales incorrectas")
        await con.execute("UPDATE seg.usuarios SET ultimo_login = now() WHERE id = $1", row["id"])
        await con.execute("INSERT INTO seg.auditoria (usuario_id, accion) VALUES ($1, 'login_ok')", row["id"])
    return {"access_token": crear_token(str(row["id"]), row["perfil"]),
            "token_type": "bearer", "expira_min": JWT_MINUTOS}

def _fila_a_dict(row: asyncpg.Record) -> dict:
    salida = {}
    for clave, valor in dict(row).items():
        if hasattr(valor, "isoformat"):
            valor = valor.isoformat()[:10]
        elif hasattr(valor, "__float__") and not isinstance(valor, (int, float)):
            valor = float(valor)
        salida[clave] = valor
    return salida

@app.get("/api/v1/health")
async def health() -> dict:
    async with app.state.pool.acquire() as con:
        await con.fetchval("SELECT 1")
    return {"status": "ok", "ts": datetime.now(timezone.utc).isoformat()}

@app.get("/api/v1/config")
async def config_publica() -> dict:
    return {
        "sondeo_ms": int(MONITOR.get("sondeo_segundos", 60)) * 1000,
        "pantalla_ms": int(MONITOR.get("pantalla_segundos", 20)) * 1000,
        "pagina_ms": int(MONITOR.get("pagina_segundos", 7)) * 1000,
        "formato_moneda": str(MONITOR.get("formato_moneda", "B")),
        "visibilidad_barra": bool(MONITOR.get("visibilidad_barra", True)),
        "visibilidad_barras_mini": bool(MONITOR.get("visibilidad_barras_mini", True)),
        "ventas_mensual": bool(MONITOR.get("ventas_mensual", True)),
        "ocultar_hace_dos_anios": bool(MONITOR.get("ocultar_hace_dos_anios",
                                                   MONITOR.get("ocultar_historico_2024", True))),
        "visibilidad_estado": bool(MONITOR.get("visibilidad_estado", True)),
        "meta_anual_recaudacion": float(SETTINGS.get("metas", {}).get("meta_anual_recaudacion", 0) or 0),
        "brigadas_panel": MONITOR.get("brigadas_panel", "eventos")
                          if MONITOR.get("brigadas_panel") in ("eventos", "atendidos") else "eventos",
        "brigadas_comparar": MONITOR.get("brigadas_comparar", "eventos")
                             if MONITOR.get("brigadas_comparar") in ("eventos", "atendidos") else "eventos",
        "capacitaciones_comparar": MONITOR.get("capacitaciones_comparar", "eventos")
                                   if MONITOR.get("capacitaciones_comparar") in ("eventos", "capacitados") else "eventos",
        "tablas_modo": (lambda m: m if m in ("mes", "acumulado") else "acumulado")(
            MONITOR.get("tablas_modo", MONITOR.get("ventas_tablas_modo", "acumulado"))),
        "origen_cargas": SETTINGS.get("fuentes", {}).get("origen", "fileserver"),
        "corte_mensual": CORTE_MENSUAL,
        "recarga_automatica": [f"{h:02d}:{m:02d}" for h, m in horas_recarga()],
        "escala_tablas": (lambda v: v if 0.8 <= v <= 3 else 1.0)(
            float(MONITOR.get("escala_tablas", 1) or 1)),
        "letra_filas": (lambda v: v if 0.7 <= v <= 1.3 else 1.0)(
            float(MONITOR.get("letra_filas", 1) or 1)),
        "presidencia_grafico_mes": (lambda v: v if v in ("acumulado", "por_tramos") else "acumulado")(
            SETTINGS.get("presidencia", {}).get("grafico_mes", "acumulado")),
        "presidencia_frecuencia_dias": (lambda v: v if 1 <= v <= 7 else 1)(
            int(SETTINGS.get("presidencia", {}).get("frecuencia_dias",
                SETTINGS.get("presidencia", {}).get("dias_por_punto", 1)) or 1)),
        **{f"presidencia_{clave}": (lambda v: v if 0.3 <= v <= 2 else 1.0)(
            float(SETTINGS.get("presidencia", {}).get(f"velocidad_{clave}_presidencia", 1) or 1))
           for clave in ("diapositivas", "deslizante_superior", "rollup_tablas")},
        **{f"presidencia_{clave}": anios_atras(clave) for clave in (
            "grafica_venta_acumula_presi", "grafica_reca_acumula_presi",
            "grafica_venta_mensual_presi", "grafica_reca_mensual_presi", "tablas_pan2_ventas", "tablas_pan3_reca")},
        **{f"presidencia_letra_{t}": letra_px(f"pres_pan2_tab_{t}", d)
           for t, d in (("xmeses", "auto"), ("xprovincia", 14.0), ("xsector", "auto"))},
        "presidencia_alto_xmeses": (lambda v: v if 30 <= v <= 90 else 70)(
            int(PRESIDENCIA.get("pres_pan2_alto_xmeses", 70) or 70)),
        **{f"presidencia_rollup_{clave}": int(SETTINGS.get("presidencia", {}).get(
               f"rollup_{clave}_acu_venta_presidencia", defecto) or 0) == 1
           for clave, defecto in (("meses", 0), ("provincia", 1), ("sector", 0))},
        "ventas_paleta": (MONITOR.get("ventas_paleta", "azul")
                          if MONITOR.get("ventas_paleta")
                          in ("azul", "verde", "amarilla", "violeta", "coral") else "azul"),
        "deslizante_acumulado": (MONITOR.get("deslizante_acumulado", "anual_al_dia")
                                 if MONITOR.get("deslizante_acumulado") in ("mensual_actual_al_dia", "anual_al_dia")
                                 else "anual_al_dia"),
    }

async def _fetch(clave, sql):
    async with app.state.pool.acquire() as con:
        return clave, await con.fetch(sql)

async def _fetchval(sql):
    async with app.state.pool.acquire() as con:
        return await con.fetchval(sql)

CACHE_SEGUNDOS = max(0, int(MONITOR.get("cache_segundos", 300) or 0))
_CACHE: dict[str, tuple[str, float, object]] = {}
_CANDADOS_CACHE: dict[str, asyncio.Lock] = {}

def _vigente(clave: str, marca: str):
    guardado = _CACHE.get(clave)
    if guardado and guardado[0] == marca and time.monotonic() - guardado[1] < CACHE_SEGUNDOS:
        return guardado
    return None

async def en_cache(clave: str, calcular):
    if not CACHE_SEGUNDOS:
        return await calcular()
    marca = str(await _fetchval("SELECT actualizado_en FROM visordg.visor_refresh WHERE id = 1"))
    guardado = _vigente(clave, marca)
    if guardado:
        return guardado[2]
    async with _CANDADOS_CACHE.setdefault(clave, asyncio.Lock()):
        guardado = _vigente(clave, marca)
        if guardado:
            return guardado[2]
        valor = await calcular()
        _CACHE[clave] = (marca, time.monotonic(), valor)
        return valor

@app.get("/api/v1/tv-data")
async def tv_data() -> dict:
    return await en_cache("tv-data", _tv_data)

async def _tv_data() -> dict:
    consultas = dict(CONSULTAS_TV)
    consultas["metas_recaudacion"] = """
        SELECT m.anio, m.mes, m.valor_meta::float AS valor_meta
        FROM visordg.meta_recaudacion m
        WHERE m.anio = (SELECT EXTRACT(YEAR FROM max(mes))::int FROM visordg.hist_recaudacion)
        ORDER BY m.mes"""
    consultas["feriados"] = """
        SELECT anio, fecha_feriado FROM visordg.feriados
        WHERE anio BETWEEN EXTRACT(YEAR FROM now() AT TIME ZONE 'America/Guayaquil')::int
                       AND EXTRACT(YEAR FROM now() AT TIME ZONE 'America/Guayaquil')::int + 1
        ORDER BY fecha_feriado"""
    consultas["corte_laboral"] = "SELECT visordg.ultimo_dia_laborable() AS fecha"
    resultados = await asyncio.gather(*[_fetch(c, s) for c, s in consultas.items()])
    datos = {clave: [_fila_a_dict(f) for f in filas] for clave, filas in resultados}

    corte_laboral = datos.pop("corte_laboral")
    datos["corte_laboral"] = corte_laboral[0]["fecha"] if corte_laboral else None
    metas = datos.pop("metas_recaudacion")
    datos["metas_recaudacion"] = {m["mes"]: m["valor_meta"] for m in metas}
    datos["metas_anio"] = metas[0]["anio"] if metas else None
    meta_settings = float(SETTINGS.get("metas", {}).get("meta_anual_recaudacion", 0) or 0)
    if metas:
        datos["meta_anual_recaudacion"] = sum(m["valor_meta"] for m in metas) / 1e6
        datos["meta_anual_fuente"] = "tabla"
    else:
        datos["meta_anual_recaudacion"] = meta_settings or None
        datos["meta_anual_fuente"] = "settings" if meta_settings else None

    periodo, per_rec, per_brig, per_cap = await asyncio.gather(
        _fetchval("SELECT periodo FROM visordg.dash_ventas_provincia ORDER BY cargado_en DESC LIMIT 1"),
        _fetchval("SELECT to_char(max(mes), 'YYYY-MM') FROM visordg.hist_recaudacion"),
        _fetchval("SELECT to_char(max(mes), 'YYYY-MM') FROM visordg.hist_brigadas"),
        _fetchval(SQL_PERIODO_CAPACITACIONES))
    datos["periodo_provincias"] = periodo or ""
    datos["periodo_recaudacion"] = per_rec or ""
    datos["periodo_brigadas"] = per_brig or ""
    datos["periodo_capacitaciones"] = per_cap or ""
    datos["actualizado_en"] = datetime.now(timezone.utc).isoformat()
    return datos

PRESIDENCIA = SETTINGS.get("presidencia", {})

def letra_px(clave: str, defecto: float | str) -> float | str:
    valor = str(PRESIDENCIA.get(clave, defecto)).strip().lower().removesuffix("px").strip()
    if valor == "auto":
        return "auto"
    try:
        return min(max(float(valor), 8.0), 30.0)
    except ValueError:
        return defecto

def anios_atras(clave: str, defecto: int = -1) -> int:
    try:
        valor = int(PRESIDENCIA.get(clave, defecto))
    except (TypeError, ValueError):
        valor = defecto
    return min(abs(valor), 5)

async def _consulta(sql: str, *args) -> list:
    async with app.state.pool.acquire() as con:
        return await con.fetch(sql, *args)

SQL_DIARIO_MES = """
    WITH tramos AS (
        SELECT fuente, corte, date_trunc('month', corte)::date AS ini
        FROM (SELECT 'ventas' AS fuente,
                     (SELECT max(fecha_corte) FROM visordg.hist_ventas
                       WHERE mes >= date_trunc('year', CURRENT_DATE)::date) AS corte
              UNION ALL
              SELECT 'recaudacion',
                     (SELECT max(fecha_corte) FROM visordg.hist_recaudacion
                       WHERE mes >= date_trunc('year', CURRENT_DATE)::date)) c
        WHERE corte IS NOT NULL
    ),
    ventanas AS (
        SELECT t.fuente, t.corte, k.k,
               (t.ini - make_interval(years => k.k))::date   AS ini_k,
               (t.corte - make_interval(years => k.k))::date AS corte_k
        FROM tramos t
        CROSS JOIN generate_series(0, CASE WHEN t.fuente = 'ventas' THEN $1::int ELSE $2::int END) AS k(k)
    )
    SELECT w.fuente, to_char(w.corte, 'YYYY-MM-DD') AS corte, w.k,
           EXTRACT(DAY FROM x.fecha)::int AS dia, (sum(x.valor) / 1e6)::float AS valor
    FROM ventanas w
    JOIN LATERAL (
        SELECT v.fecha, v.ventas AS valor FROM visordg.ventas_raw_dos v
        WHERE w.fuente = 'ventas' AND v.fecha BETWEEN w.ini_k AND w.corte_k
        UNION ALL
        SELECT r.fecha, r.recaudado FROM visordg.recaudacion_raw_dos r
        WHERE w.fuente = 'recaudacion' AND r.fecha BETWEEN w.ini_k AND w.corte_k) x ON true
    GROUP BY w.fuente, w.corte, w.k, 4
    ORDER BY w.fuente, 4, w.k"""

SQL_TABLAS_POR_ANIO = """
    WITH anios AS (
        SELECT EXTRACT(YEAR FROM p.fmax)::int - k AS anio,
               (p.fmax - make_interval(years => k))::date AS corte_k
        FROM (SELECT max(fecha) AS fmax FROM visordg.{tabla}) p, generate_series(0, $1) AS k
        WHERE p.fmax IS NOT NULL)
    SELECT {clave} AS nombre, a.anio,
           (COALESCE(SUM(v.{valor}) FILTER (
               WHERE date_trunc('month', v.fecha) = date_trunc('month', a.corte_k)), 0) / 1e6)::float AS mes,
           (SUM(v.{valor}) / 1e6)::float AS acum
    FROM visordg.{tabla} v
    JOIN anios a ON v.fecha BETWEEN make_date(a.anio, 1, 1) AND a.corte_k
    GROUP BY 1, 2"""

def _agrupar_por_anio(filas) -> list[dict]:
    grupos = {}
    for f in filas:
        g = grupos.setdefault(f["nombre"], {"nombre": f["nombre"], "mes": {}, "acum": {}})
        g["mes"][f["anio"]] = f["mes"]
        g["acum"][f["anio"]] = f["acum"]
    return list(grupos.values())

async def _tablas_por_anio(tabla: str, valor: str, claves: dict, k: int) -> dict:
    consultas = [_consulta(SQL_TABLAS_POR_ANIO.format(tabla=tabla, valor=valor, clave=c), k) for c in claves.values()]
    resultados = await asyncio.gather(
        *consultas, _fetchval(f"SELECT to_char(max(fecha), 'YYYY-MM-DD') FROM visordg.{tabla}"))
    corte = resultados[-1]
    datos = {"corte": corte, "anios": _anios_de(corte, k)}
    for nombre, filas in zip(claves, resultados[:-1]):
        datos[nombre] = _agrupar_por_anio(filas)
    return datos

SQL_VENTAS_POR_MESES = """
    WITH p AS (
        SELECT max(fecha) AS fmax,
               EXTRACT(YEAR FROM max(fecha))::int  AS anio,
               EXTRACT(MONTH FROM max(fecha))::int AS mes,
               EXTRACT(DAY FROM max(fecha))::int   AS dia
        FROM visordg.ventas_raw_dos)
    SELECT EXTRACT(YEAR FROM v.fecha)::int AS anio, EXTRACT(MONTH FROM v.fecha)::int AS mes,
           (SUM(v.ventas) / 1e6)::float AS valor
    FROM visordg.ventas_raw_dos v, p
    WHERE v.fecha >= make_date(p.anio - $1, 1, 1) AND v.fecha <= p.fmax
      AND (EXTRACT(MONTH FROM v.fecha) < p.mes
           OR (EXTRACT(MONTH FROM v.fecha) = p.mes AND EXTRACT(DAY FROM v.fecha) <= p.dia))
    GROUP BY 1, 2"""

SQL_CORTE_VENTAS = "SELECT to_char(max(fecha), 'YYYY-MM-DD') FROM visordg.ventas_raw_dos"

def _anios_de(corte: str | None, k: int) -> list[int]:
    return list(range(int(corte[:4]) - k, int(corte[:4]) + 1)) if corte else []

@app.get("/api/v1/ventas-tablas")
async def ventas_tablas() -> dict:
    return await en_cache("ventas-tablas", _ventas_tablas)

async def _ventas_tablas() -> dict:
    return await _tablas_por_anio("ventas_raw_dos", "ventas", {
        "provincias": "upper(btrim(v.provincia))",
        "sectores": "v.sector"}, anios_atras("tablas_pan2_ventas"))

@app.get("/api/v1/recaudacion-tablas")
async def recaudacion_tablas() -> dict:
    return await en_cache("recaudacion-tablas", _recaudacion_tablas)

async def _recaudacion_tablas() -> dict:
    return await _tablas_por_anio("recaudacion_raw_dos", "recaudado", {
        "provincias": "upper(btrim(v.provincia))",
        "sectores": "upper(btrim(v.sector))",
        "impuestos": "COALESCE(NULLIF(upper(btrim(v.impuesto)), ''), 'SIN IMPUESTO')"}, anios_atras("tablas_pan3_reca"))

@app.get("/api/v1/ventas-por-meses")
async def ventas_por_meses() -> dict:
    return await en_cache("ventas-por-meses", _ventas_por_meses)

async def _ventas_por_meses() -> dict:
    k = anios_atras("tablas_pan2_ventas")
    filas, corte = await asyncio.gather(_consulta(SQL_VENTAS_POR_MESES, k), _fetchval(SQL_CORTE_VENTAS))
    meses = {}
    for f in filas:
        meses.setdefault(f["mes"], {})[f["anio"]] = f["valor"]
    return {"corte": corte, "anios": _anios_de(corte, k),
            "filas": [{"mes": m, "valores": meses[m]} for m in sorted(meses)]}

@app.get("/api/v1/diario-mes")
async def diario_mes() -> list[dict]:
    return await en_cache("diario-mes", _diario_mes)

async def _diario_mes() -> list[dict]:
    kv = anios_atras("grafica_venta_mensual_presi")
    kr = anios_atras("grafica_reca_mensual_presi")
    dias = {}
    for f in await _consulta(SQL_DIARIO_MES, kv, kr):
        k_max = kv if f["fuente"] == "ventas" else kr
        d = dias.setdefault((f["fuente"], f["dia"]), {
            "fuente": f["fuente"], "corte": f["corte"], "dia": f["dia"], "valores": [None] * (k_max + 1)})
        d["valores"][f["k"]] = f["valor"]
    filas = [dias[c] for c in sorted(dias)]
    for d in filas:
        d["actual"] = d["valores"][0]
        d["previo"] = d["valores"][1] if len(d["valores"]) > 1 else None
    return filas

@app.get("/api/v1/actualizado")
async def actualizado() -> dict:
    async with app.state.pool.acquire() as con:
        marca = await con.fetchval("SELECT actualizado_en FROM visordg.visor_refresh WHERE id = 1")
    return {"actualizado_en": marca.isoformat() if marca else None}

def _precalculables() -> dict:
    return {"tv-data": _tv_data, "diario-mes": _diario_mes, "ventas-tablas": _ventas_tablas,
            "ventas-por-meses": _ventas_por_meses, "recaudacion-tablas": _recaudacion_tablas}

async def precalentar() -> None:
    if not CACHE_SEGUNDOS:
        return
    marca = str(await _fetchval("SELECT actualizado_en FROM visordg.visor_refresh WHERE id = 1"))
    inicio = time.monotonic()
    for clave, calcular in _precalculables().items():
        try:
            async with _CANDADOS_CACHE.setdefault(clave, asyncio.Lock()):
                _CACHE[clave] = (marca, time.monotonic(), await calcular())
        except Exception as exc:
            registro(f"[CACHE] No se pudo preparar {clave}: {exc}")
    registro(f"[CACHE] Datos de las pantallas listos en memoria ({time.monotonic() - inicio:.1f} s)")

async def tarea_precalentar() -> None:
    while True:
        try:
            await precalentar()
        except Exception as exc:
            registro(f"[CACHE] Error al preparar los datos: {exc}")
        await asyncio.sleep(max(60, CACHE_SEGUNDOS - 30))

async def notificar_refresh() -> None:
    _CACHE.clear()
    async with app.state.pool.acquire() as con:
        await con.execute("UPDATE visordg.visor_refresh SET actualizado_en = now() WHERE id = 1")
    await precalentar()
    muertos = []
    for ws in app.state.ws_clients:
        try:
            await ws.send_text("refresh")
        except Exception:
            muertos.append(ws)
    for ws in muertos:
        app.state.ws_clients.discard(ws)

@app.websocket("/api/v1/stream")
async def stream(ws: WebSocket) -> None:
    await ws.accept()
    app.state.ws_clients.add(ws)
    try:
        while True:
            await asyncio.sleep(30)
            await ws.send_text("ping")
    except (WebSocketDisconnect, RuntimeError):
        app.state.ws_clients.discard(ws)

async def refrescar_todo() -> None:
    for script in SCRIPTS_REFRESCO:
        await asyncio.to_thread(correr_sql, script)

async def recargar(origen: str | None, fuentes: list[str] | None, quien: str, accion: str,
                   detalle: dict) -> dict:
    que = ", ".join(fuentes) if fuentes else "todas las fuentes"
    registro(f"[RECARGA] {quien}: {que} desde {origen or 'el origen del settings'}")
    async with app.state.pool.acquire() as con:
        await con.execute("INSERT INTO seg.auditoria (accion, detalle) VALUES ($1, $2)", accion,
                          json.dumps({**detalle, "origen": origen, "fuentes": fuentes or list(FUENTES)}))
    resultado = await asyncio.to_thread(asyncio.run, cargar_todo(origen, fuentes))
    await refrescar_todo()
    await notificar_refresh()
    registro("[RECARGA] Terminada: " + " · ".join(f"{k}={v}" for k, v in resultado.items()))
    return resultado


async def tarea_recarga_automatica() -> None:
    ultima = None
    while True:
        horas = horas_recarga()
        if not horas:
            registro("[AUTO] Sin horas de recarga automática en [fuentes]; no se programa ninguna.")
            return
        ahora = datetime.now()
        objetivo = proxima_recarga(horas, max(ahora, ultima) if ultima else ahora)
        espera = (objetivo - ahora).total_seconds()
        registro(f"[AUTO] Próxima recarga automática: {objetivo:%Y-%m-%d %H:%M} "
                 f"(en {int(espera // 3600)} h {int(espera % 3600 // 60)} min)")
        await asyncio.sleep(max(0.0, espera))
        while datetime.now() < objetivo:
            await asyncio.sleep(0.5)
        ultima = objetivo
        if CANDADO_RECARGA.locked():
            registro("[AUTO] Hay una recarga en curso; se omite esta recarga automática.")
            continue
        try:
            async with CANDADO_RECARGA:
                await recargar(None, None, "Recarga automática", "recarga_automatica",
                               {"programada": f"{objetivo:%Y-%m-%d %H:%M}"})
        except Exception as exc:
            registro(f"[AUTO] Error en la recarga automática: {exc}")


@app.post("/api/v1/recargar-total")
async def recargar_total_manual(origen: str | None = None, fuente: str | None = None,
                                usuario: dict = Depends(solo_admin)) -> dict:
    if origen is not None and origen not in ORIGENES:
        raise HTTPException(422, f"origen debe ser: {' | '.join(ORIGENES)}")
    if fuente is not None and fuente not in FUENTES + FUENTES_MES:
        raise HTTPException(422, f"fuente debe ser: {' | '.join(FUENTES + FUENTES_MES)}")
    if CANDADO_RECARGA.locked():
        raise HTTPException(409, "Ya hay una recarga o refresco en curso")
    fuentes_pedidas = [fuente] if fuente else None
    async with CANDADO_RECARGA:
        try:
            fuentes = await recargar(origen, fuentes_pedidas, f"Usuario {usuario.get('sub')}", "recarga_total",
                                     {"usuario": usuario.get("sub")})
        except Exception as exc:
            registro(f"[RECARGA] Falla: {exc}")
            raise HTTPException(500, f"Falla en la recarga: {exc}") from exc
    errores = {k: v for k, v in fuentes.items() if v != "ok"}
    if len(errores) == len(fuentes):
        raise HTTPException(500, "No se cargó: " + "; ".join(f"{k}: {v}" for k, v in errores.items()))
    return {"status": "parcial" if errores else "success", "fuentes": fuentes}
