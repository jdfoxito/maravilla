from pathlib import Path
import tomllib

RUTA_SETTINGS = Path(__file__).resolve().parents[2] / "config" / "settings.toml"

def cargar_settings() -> dict:
    if not RUTA_SETTINGS.exists():
        raise FileNotFoundError(f"No se encontró el archivo de configuración: {RUTA_SETTINGS}")
    with open(RUTA_SETTINGS, "rb") as fh:
        return tomllib.load(fh)

def construir_dsn(cfg: dict) -> str:
    db = cfg["database"]
    return (f"postgresql://{db['user']}:{db['password']}"
            f"@{db['host']}:{db['port']}/{db['name']}")
