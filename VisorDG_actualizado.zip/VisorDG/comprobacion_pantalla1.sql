-- ============================================================================
-- VisorDG | COMPROBACIÓN DE LA PANTALLA 1 (gráficos y tarjetas)
-- 07/10/2026
--
-- Para qué sirve: verificar que los valores de cada gráfica y la SUMA TOTAL
-- del costado izquierdo de cada tarjeta son correctos.
--
-- Regla del tablero: todo acumula de ENERO al último MES CERRADO (mes que ya
-- pasó completo sus 28/29/30/31 días). Si hoy es 07/10/2026, lo último
-- cerrado es septiembre: las tarjetas muestran Ene–Sep 2026 vs. Ene–Sep 2025.
-- OJO: si una fuente se rezaga (su último dato es de agosto), el tablero usa
-- su propio corte; estos SELECTs asumen fuente al día.
--
-- Uso:  psql -U postgres -d detalles -f comprobacion_pantalla1.sql
-- ============================================================================

\set QUIET on
\pset footer off

-- Parámetro reutilizable: fin del último mes cerrado
-- (en octubre de 2026 -> 30/09/2026)
SELECT (date_trunc('month', CURRENT_DATE) - interval '1 day')::date
       AS fin_mes_cerrado;

-- ============================================================================
-- 1) VENTAS TOTALES CEL  (fuente: visordg.ventas_raw_dos)
--    Gráfica: barras por mes (2025 vs. 2026), enero -> mes cerrado.
--    Tarjeta: suma Ene -> mes cerrado, en MILLONES (la pantalla divide /1e6).
-- ============================================================================

-- 1a. Valores mensuales de la gráfica (lo que dibuja cada barra)
SELECT anio, mes,
       to_char(sum(ventas), 'FM999G999G999G990')        AS ventas_crudas,
       round(sum(ventas) / 1e6, 0)                      AS ventas_millones
FROM (
    SELECT extract(year  from fecha)::int AS anio,
           extract(month from fecha)::int AS mes, ventas
    FROM visordg.ventas_raw_dos
) t
WHERE mes <= extract(month from (date_trunc('month', CURRENT_DATE) - interval '1 day')::date)::int
  AND anio IN (extract(year from CURRENT_DATE)::int - 1,
               extract(year from CURRENT_DATE)::int)
GROUP BY anio, mes
ORDER BY anio DESC, mes;

-- 1b. SUMA TOTAL de la tarjeta (costado izquierdo) y su variación
WITH p AS (
    SELECT extract(year from CURRENT_DATE)::int AS anio_act,
           (date_trunc('month', CURRENT_DATE) - interval '1 day')::date AS fin_cerrado
), tot AS (
    SELECT
      sum(CASE WHEN extract(year from v.fecha) = p.anio_act
                AND v.fecha <= p.fin_cerrado THEN v.ventas END) AS act,
      sum(CASE WHEN extract(year from v.fecha) = p.anio_act - 1
                AND extract(month from v.fecha) <= extract(month from p.fin_cerrado)
               THEN v.ventas END) AS ant
    FROM visordg.ventas_raw_dos v, p
)
SELECT round(act / 1e6, 0)                                  AS tarjeta_millones,   -- comparar con la tarjeta
       round(ant / 1e6, 0)                                  AS anio_previo_millones,
       round((act / ant - 1) * 100, 1)                      AS variacion_pct        -- la de debajo del total
FROM tot;

-- ============================================================================
-- 2) RECAUDACIÓN  (fuente: visordg.recaudacion_raw_dos)
-- ============================================================================

-- 2a. Valores mensuales de la gráfica (línea dorada)
SELECT anio, mes,
       to_char(sum(recaudado), 'FM999G999G999G990')        AS recaudado_crudo,
       round(sum(recaudado) / 1e6, 0)                       AS recaudado_millones
FROM (
    SELECT extract(year  from fecha)::int AS anio,
           extract(month from fecha)::int AS mes, recaudado
    FROM visordg.recaudacion_raw_dos
) t
WHERE mes <= extract(month from (date_trunc('month', CURRENT_DATE) - interval '1 day')::date)::int
  AND anio IN (extract(year from CURRENT_DATE)::int - 1,
               extract(year from CURRENT_DATE)::int)
GROUP BY anio, mes
ORDER BY anio DESC, mes;

-- 2b. SUMA TOTAL de la tarjeta y variación
WITH p AS (
    SELECT extract(year from CURRENT_DATE)::int AS anio_act,
           (date_trunc('month', CURRENT_DATE) - interval '1 day')::date AS fin_cerrado
), tot AS (
    SELECT
      sum(CASE WHEN extract(year from r.fecha) = p.anio_act
                AND r.fecha <= p.fin_cerrado THEN r.recaudado END) AS act,
      sum(CASE WHEN extract(year from r.fecha) = p.anio_act - 1
                AND extract(month from r.fecha) <= extract(month from p.fin_cerrado)
               THEN r.recaudado END) AS ant
    FROM visordg.recaudacion_raw_dos r, p
)
SELECT round(act / 1e6, 0)                                  AS tarjeta_millones,
       round(ant / 1e6, 0)                                  AS anio_previo_millones,
       round((act / ant - 1) * 100, 1)                      AS variacion_pct
FROM tot;

-- ============================================================================
-- 3) BRIGADAS EJECUTADAS  (fuente: visordg.brigadas_eventos; mensual)
--    La tarjeta NO muestra variación (decisión del 07/10/2026).
-- ============================================================================

-- 3a. Valores mensuales de la gráfica (línea celeste)
SELECT anio, mes, sum(eventos) AS eventos
FROM visordg.brigadas_eventos
WHERE mes <= extract(month from (date_trunc('month', CURRENT_DATE) - interval '1 day')::date)::int
  AND anio IN (extract(year from CURRENT_DATE)::int - 1,
               extract(year from CURRENT_DATE)::int)
GROUP BY anio, mes
ORDER BY anio DESC, mes;

-- 3b. SUMA TOTAL de la tarjeta (Ene -> mes cerrado)
SELECT sum(CASE WHEN anio = extract(year from CURRENT_DATE)::int THEN eventos END) AS tarjeta_eventos,
       sum(CASE WHEN anio = extract(year from CURRENT_DATE)::int - 1 THEN eventos END) AS anio_previo
FROM visordg.brigadas_eventos
WHERE mes <= extract(month from (date_trunc('month', CURRENT_DATE) - interval '1 day')::date)::int;

-- 3c. (Extra) Atenciones en brigadas, por si la tarjeta está en modo atendidos
SELECT anio, mes, sum(atendidos) AS atendidos
FROM visordg.brigadas_atendidos
WHERE mes <= extract(month from (date_trunc('month', CURRENT_DATE) - interval '1 day')::date)::int
  AND anio IN (extract(year from CURRENT_DATE)::int - 1,
               extract(year from CURRENT_DATE)::int)
GROUP BY anio, mes
ORDER BY anio DESC, mes;

-- ============================================================================
-- 4) CAPACITACIONES REALIZADAS  (fuente: visordg.capacitaciones_raw)
--    Gráfica y tarjeta cuentan EVENTOS (filas); la tabla de P6 además suma
--    ciudadanos capacitados (total_capacitados).
-- ============================================================================

-- 4a. Valores mensuales de la gráfica (línea morada) = número de eventos
SELECT extract(year  from fecha)::int  AS anio,
       extract(month from fecha)::int  AS mes,
       count(*)                        AS capacitaciones,
       sum(total_capacitados)          AS ciudadanos_capacitados
FROM visordg.capacitaciones_raw
WHERE extract(month from fecha) <= extract(month from (date_trunc('month', CURRENT_DATE) - interval '1 day')::date)
  AND extract(year from fecha) IN (extract(year from CURRENT_DATE)::int - 1,
                                   extract(year from CURRENT_DATE)::int)
GROUP BY 1, 2
ORDER BY 1 DESC, 2;

-- 4b. SUMA TOTAL de la tarjeta y variación (eventos)
WITH p AS (
    SELECT extract(year from CURRENT_DATE)::int AS anio_act,
           (date_trunc('month', CURRENT_DATE) - interval '1 day')::date AS fin_cerrado
), tot AS (
    SELECT
      count(*) FILTER (WHERE extract(year from c.fecha) = p.anio_act
                         AND c.fecha::date <= p.fin_cerrado) AS act,
      count(*) FILTER (WHERE extract(year from c.fecha) = p.anio_act - 1
                         AND extract(month from c.fecha) <= extract(month from p.fin_cerrado)) AS ant
    FROM visordg.capacitaciones_raw c, p
)
SELECT act                                            AS tarjeta_eventos,
       ant                                            AS anio_previo,
       round((act::numeric / ant - 1) * 100, 1)       AS variacion_pct
FROM tot;

-- ============================================================================
-- 5) RESUMEN EN UNA SOLA FILA POR INDICADOR (vista rápida de las 4 tarjetas)
-- ============================================================================
WITH p AS (
    SELECT extract(year from CURRENT_DATE)::int AS anio_act,
           (date_trunc('month', CURRENT_DATE) - interval '1 day')::date AS fin_cerrado
)
SELECT 'Ventas (millones)' AS indicador,
       round(sum(v.ventas) FILTER (WHERE extract(year from v.fecha) = p.anio_act
                                    AND v.fecha <= p.fin_cerrado) / 1e6, 0)::text AS valor_tarjeta
FROM visordg.ventas_raw_dos v, p
UNION ALL
SELECT 'Recaudación (millones)',
       round(sum(r.recaudado) FILTER (WHERE extract(year from r.fecha) = p.anio_act
                                       AND r.fecha <= p.fin_cerrado) / 1e6, 0)::text
FROM visordg.recaudacion_raw_dos r, p
UNION ALL
SELECT 'Brigadas ejecutadas',
       sum(b.eventos) FILTER (WHERE b.anio = p.anio_act
                                AND b.mes <= extract(month from p.fin_cerrado))::text
FROM visordg.brigadas_eventos b, p
UNION ALL
SELECT 'Capacitaciones realizadas',
       count(*) FILTER (WHERE extract(year from c.fecha) = p.anio_act
                         AND c.fecha::date <= p.fin_cerrado)::text
FROM visordg.capacitaciones_raw c, p;
