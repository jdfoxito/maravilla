-- =====================================================================
-- VisorDG - Comprobación PANTALLA 2 (Ventas CEL mensual) y PANTALLA 3
-- (Ventas CEL acumulada). Tablas del dashboard frente a la base.
-- Tablas en base: visordg.ventas_raw_dos(fecha, provincia, sector, ventas)
-- En pantalla los valores van en MILLONES con 1 decimal: aquí igual.
--
-- Criterios (idénticos al dashboard):
--  * P2 mensual:   mes de la fecha de corte, día 1 -> corte. El año
--                  anterior se compara A MISMOS DÍAS (día <= día del corte).
--  * P3 acumulada: 01/01 -> fin acumulado, donde fin acumulado =
--                  min( máxima fecha 2026 en base, fin del mes cerrado ).
--                  Año anterior a mismos días (hasta mismo mes/día).
--  * Mes cerrado:  el último mes que ya pasó completo
--                  (date_trunc('month', CURRENT_DATE) - interval '1 day').
-- =====================================================================

WITH params AS (
  SELECT
    (date_trunc('month', CURRENT_DATE) - interval '1 day')::date AS fin_mes_cerrado,
    (SELECT max(fecha) FROM visordg.ventas_raw_dos
      WHERE fecha >= date_trunc('year', CURRENT_DATE)::date)      AS corte
), r AS (
  SELECT
    -- P2 mensual: [día 1 del mes del corte, corte]
    date_trunc('month', corte)::date AS mes_ini, corte AS mes_fin,
    -- P3 acumulada: [01/01, min(corte, fin mes cerrado)]
    date_trunc('year', corte)::date  AS acum_ini,
    LEAST(corte, fin_mes_cerrado)    AS acum_fin
  FROM params
)
SELECT 'P2 mensual: '  || mes_ini || ' -> ' || mes_fin AS rango_pantalla_2,
       'P3 acumulada: ' || acum_ini || ' -> ' || acum_fin AS rango_pantalla_3
FROM r;

-- =====================================================================
-- PANTALLA 2 - VENTAS POR PROVINCIA (mes de la fecha de corte)
-- Columnas esperadas en pantalla: provincia, AÑO ANTERIOR, AÑO EN CURSO,
-- VAR NOMINAL, VAR %   (millones, 1 decimal)
-- =====================================================================
WITH p AS (
  SELECT date_trunc('month', max(fecha) FILTER (
           WHERE fecha >= date_trunc('year', CURRENT_DATE)::date))::date AS ini,
         max(fecha) FILTER (
           WHERE fecha >= date_trunc('year', CURRENT_DATE)::date)        AS fin
  FROM visordg.ventas_raw_dos
)
SELECT v.provincia,
       round(sum(v.ventas) FILTER (
         WHERE v.fecha >= (p.ini - interval '1 year')::date
           AND v.fecha <= (p.fin - interval '1 year')::date) / 1e6, 1) AS anio_anterior,
       round(sum(v.ventas) FILTER (
         WHERE v.fecha BETWEEN p.ini AND p.fin) / 1e6, 1)              AS anio_en_curso,
       round((sum(v.ventas) FILTER (WHERE v.fecha BETWEEN p.ini AND p.fin)
            - sum(v.ventas) FILTER (WHERE v.fecha >= (p.ini - interval '1 year')::date
                                    AND v.fecha <= (p.fin - interval '1 year')::date)) / 1e6, 1) AS var_nominal,
       round((100 * sum(v.ventas) FILTER (WHERE v.fecha BETWEEN p.ini AND p.fin)
            / nullif(sum(v.ventas) FILTER (WHERE v.fecha >= (p.ini - interval '1 year')::date
                                    AND v.fecha <= (p.fin - interval '1 year')::date), 0) - 100)::numeric, 1) AS var_pct
FROM visordg.ventas_raw_dos v, p
GROUP BY v.provincia
ORDER BY anio_en_curso DESC NULLS LAST;

-- =====================================================================
-- PANTALLA 3 - VENTAS POR SECTOR (acumulado 01/01 -> fin acumulado)
-- =====================================================================
WITH p AS (
  SELECT date_trunc('year', CURRENT_DATE)::date AS ini,
         LEAST(max(fecha) FILTER (WHERE fecha >= date_trunc('year', CURRENT_DATE)::date),
               (date_trunc('month', CURRENT_DATE) - interval '1 day')::date) AS fin
  FROM visordg.ventas_raw_dos
)
SELECT v.sector,
       round(sum(v.ventas) FILTER (
         WHERE v.fecha >= (p.ini - interval '1 year')::date
           AND v.fecha <= (p.fin - interval '1 year')::date) / 1e6, 1) AS anio_anterior,
       round(sum(v.ventas) FILTER (
         WHERE v.fecha BETWEEN p.ini AND p.fin) / 1e6, 1)              AS anio_en_curso,
       round((sum(v.ventas) FILTER (WHERE v.fecha BETWEEN p.ini AND p.fin)
            - sum(v.ventas) FILTER (WHERE v.fecha >= (p.ini - interval '1 year')::date
                                    AND v.fecha <= (p.fin - interval '1 year')::date)) / 1e6, 1) AS var_nominal,
       round((100 * sum(v.ventas) FILTER (WHERE v.fecha BETWEEN p.ini AND p.fin)
            / nullif(sum(v.ventas) FILTER (WHERE v.fecha >= (p.ini - interval '1 year')::date
                                    AND v.fecha <= (p.fin - interval '1 year')::date), 0) - 100)::numeric, 1) AS var_pct
FROM visordg.ventas_raw_dos v, p
GROUP BY v.sector
ORDER BY anio_en_curso DESC NULLS LAST;

-- =====================================================================
-- TOTALES de cada pantalla (última fila de cada tabla en pantalla)
-- =====================================================================
WITH p2 AS (
  SELECT date_trunc('month', max(fecha) FILTER (
           WHERE fecha >= date_trunc('year', CURRENT_DATE)::date))::date AS ini,
         max(fecha) FILTER (
           WHERE fecha >= date_trunc('year', CURRENT_DATE)::date)        AS fin
  FROM visordg.ventas_raw_dos
), p3 AS (
  SELECT date_trunc('year', CURRENT_DATE)::date AS ini,
         LEAST(max(fecha) FILTER (WHERE fecha >= date_trunc('year', CURRENT_DATE)::date),
               (date_trunc('month', CURRENT_DATE) - interval '1 day')::date) AS fin
  FROM visordg.ventas_raw_dos
)
SELECT 'P2 TOTAL (mes)' AS fila,
       round(sum(v.ventas) FILTER (
         WHERE v.fecha >= (p2.ini - interval '1 year')::date
           AND v.fecha <= (p2.fin - interval '1 year')::date) / 1e6, 1) AS anio_anterior,
       round(sum(v.ventas) FILTER (WHERE v.fecha BETWEEN p2.ini AND p2.fin) / 1e6, 1) AS anio_en_curso
FROM visordg.ventas_raw_dos v, p2
UNION ALL
SELECT 'P3 TOTAL (acumulado)',
       round(sum(v.ventas) FILTER (
         WHERE v.fecha >= (p3.ini - interval '1 year')::date
           AND v.fecha <= (p3.fin - interval '1 year')::date) / 1e6, 1),
       round(sum(v.ventas) FILTER (WHERE v.fecha BETWEEN p3.ini AND p3.fin) / 1e6, 1)
FROM visordg.ventas_raw_dos v, p3;
