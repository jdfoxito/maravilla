"""Carga de configuración del Visor Gerencial desde config/settings.toml.

TODA la parametrización (credenciales incluidas) vive en el TOML:
    VisorDG/config/settings.toml
No se leen variables de entorno del sistema operativo.
"""

from pathlib import Path
import tomllib

# app/backend/config.py -> VisorDG/config/settings.toml
RUTA_SETTINGS = Path(__file__).resolve().parents[2] / "config" / "settings.toml"


def cargar_settings() -> dict:
    """Lee el TOML de configuración; falla rápido y claro si no existe."""
    if not RUTA_SETTINGS.exists():
        raise FileNotFoundError(f"No se encontró el archivo de configuración: {RUTA_SETTINGS}")
    with open(RUTA_SETTINGS, "rb") as fh:
        return tomllib.load(fh)


def construir_dsn(cfg: dict) -> str:
    """Arma el DSN de PostgreSQL a partir de las secciones del TOML."""
    db = cfg["database"]
    return (f"postgresql://{db['user']}:{db['password']}"
            f"@{db['host']}:{db['port']}/{db['name']}")
