"""API del Visor Gerencial SRI.

Sirve las series del monitor TV desde el esquema ``visordg`` de la base
``detalles``, con WebSocket para refresco en tiempo real y autenticación
JWT (Argon2id).

Toda la configuración (credenciales incluidas) se lee de
``config/settings.toml``; NO se usan variables de entorno.

Arranque (desde app/backend):  pdm run start
"""

import asyncio
import json
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path

import asyncpg
import jwt
from fastapi import Depends, FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from pwdlib import PasswordHash

from config import cargar_settings, construir_dsn
from cargas import ORIGENES, SCRIPTS_REFRESCO, asegurar_esquema, cargar_todo, correr_sql


SETTINGS = cargar_settings()
PG_DSN = construir_dsn(SETTINGS)

SEG = SETTINGS["seguridad"]
JWT_SECRET = SEG["jwt_secret"]
JWT_ALG = "HS256"
JWT_MINUTOS = int(SEG.get("jwt_minutos", 30))
ADMIN_PASSWORD = SEG.get("admin_password_inicial", "Cambiar.2026")

MONITOR = SETTINGS.get("monitor", {})

# Rutas absolutas desde ESTE archivo (no dependen de dónde se lance uvicorn)
RUTA_BACKEND = Path(__file__).resolve().parent

# Una sola recarga/refresco a la vez (API manual y tarea nocturna comparten candado)
CANDADO_RECARGA = asyncio.Lock()

pwd_hasher = PasswordHash.recommended()  # Argon2id
bearer = HTTPBearer(auto_error=False)

CONSULTAS_TV = {
    "mes_corriente": """
        SELECT fecha,
               ventas_anio_anterior, ventas_anio_actual,
               recaudacion_anio_anterior, recaudacion_anio_actual,
               brigadas_anio_anterior, brigadas_anio_actual,
               capacitaciones_anio_anterior, capacitaciones_anio_actual
        FROM visordg.dash_mes_corriente ORDER BY fecha""",
    "hist_ventas": """
        SELECT to_char(mes, 'YYYY-MM') AS fecha, ventas,
               archivo AS archivo_ventas,
               -- Fecha de corte = última fecha de los DATOS (no la del archivo)
               to_char((SELECT max(fecha) FROM visordg.ventas_raw_dos), 'YYYY-MM-DD') AS corte_ventas
        FROM visordg.hist_ventas ORDER BY mes""",
    "hist_recaudacion": """
        SELECT to_char(mes, 'YYYY-MM') AS fecha, recaudacion,
               archivo AS archivo_recaudacion,
               -- Fecha de corte = última fecha de los DATOS (no la del archivo)
               to_char((SELECT max(fecha) FROM visordg.recaudacion_raw_dos), 'YYYY-MM-DD') AS corte_recaudacion
        FROM visordg.hist_recaudacion ORDER BY mes""",
    "hist_brigadas": """
        SELECT to_char(mes, 'YYYY-MM') AS fecha, brigadas,
               archivo AS archivo_brigadas, to_char(archivo_modificado, 'YYYY-MM-DD') AS corte_brigadas
        FROM visordg.hist_brigadas ORDER BY mes""",
    "hist_capacitaciones": """
        SELECT to_char(mes, 'YYYY-MM') AS fecha, capacitaciones,
               archivo AS archivo_capacitaciones,
               -- Fecha de corte = última FECHA CAPACITACION de los datos
               to_char((SELECT max(fecha)::date FROM visordg.capacitaciones_raw), 'YYYY-MM-DD') AS corte_capacitaciones
        FROM visordg.hist_capacitaciones ORDER BY mes""",
    # Ventas por provincia (pantalla 2 - solo provincias)
    "ventas_provincias": """
        WITH per AS (
            SELECT date_trunc('month', max(fecha))::date AS m0,
                   EXTRACT(DAY FROM max(fecha))::int     AS dia_corte,
                   max(fecha)                            AS fmax
            FROM visordg.ventas_raw_dos)
        SELECT upper(btrim(v.provincia)) AS provincia,
               COALESCE(SUM(v.ventas) FILTER (
                   WHERE date_trunc('month', v.fecha) = per.m0 - INTERVAL '2 years'
                     AND EXTRACT(DAY FROM v.fecha) <= per.dia_corte), 0) / 1e6 AS mes_hace_dos_anios,
               COALESCE(SUM(v.ventas) FILTER (
                   WHERE date_trunc('month', v.fecha) = per.m0 - INTERVAL '1 year'
                     AND EXTRACT(DAY FROM v.fecha) <= per.dia_corte), 0) / 1e6 AS mes_anio_anterior,
               COALESCE(SUM(v.ventas) FILTER (
                   WHERE date_trunc('month', v.fecha) = per.m0
                     AND EXTRACT(DAY FROM v.fecha) <= per.dia_corte), 0) / 1e6 AS mes_anio_actual,
               -- Acumulado del año (enero -> día de corte), a mismos días en el año previo
               COALESCE(SUM(v.ventas) FILTER (
                   WHERE v.fecha >= date_trunc('year', per.fmax) - INTERVAL '1 year'
                     AND v.fecha <= per.fmax - INTERVAL '1 year'), 0) / 1e6 AS acum_anio_anterior,
               COALESCE(SUM(v.ventas) FILTER (
                   WHERE v.fecha >= date_trunc('year', per.fmax)
                     AND v.fecha <= per.fmax), 0) / 1e6 AS acum_anio_actual
        FROM visordg.ventas_raw_dos v CROSS JOIN per
        WHERE v.fecha >= (per.m0 - INTERVAL '2 years')::date
        GROUP BY upper(btrim(v.provincia))
        ORDER BY mes_anio_actual DESC""",
    # Ventas por actividad económica (pantalla 3 - con comparativa 3 años)
    "ventas_sector_full": """
        WITH per AS (
            SELECT date_trunc('month', max(fecha))::date AS m0,
                   EXTRACT(DAY FROM max(fecha))::int     AS dia_corte,
                   max(fecha)                            AS fmax
            FROM visordg.ventas_raw_dos)
        SELECT v.sector AS sector,
               COALESCE(SUM(v.ventas) FILTER (
                   WHERE date_trunc('month', v.fecha) = per.m0 - INTERVAL '2 years'
                     AND EXTRACT(DAY FROM v.fecha) <= per.dia_corte), 0) / 1e6 AS mes_hace_dos_anios,
               COALESCE(SUM(v.ventas) FILTER (
                   WHERE date_trunc('month', v.fecha) = per.m0 - INTERVAL '1 year'
                     AND EXTRACT(DAY FROM v.fecha) <= per.dia_corte), 0) / 1e6 AS mes_anio_anterior,
               COALESCE(SUM(v.ventas) FILTER (
                   WHERE date_trunc('month', v.fecha) = per.m0
                     AND EXTRACT(DAY FROM v.fecha) <= per.dia_corte), 0) / 1e6 AS mes_anio_actual,
               -- Acumulado del año (enero -> día de corte), a mismos días en el año previo
               COALESCE(SUM(v.ventas) FILTER (
                   WHERE v.fecha >= date_trunc('year', per.fmax) - INTERVAL '1 year'
                     AND v.fecha <= per.fmax - INTERVAL '1 year'), 0) / 1e6 AS acum_anio_anterior,
               COALESCE(SUM(v.ventas) FILTER (
                   WHERE v.fecha >= date_trunc('year', per.fmax)
                     AND v.fecha <= per.fmax), 0) / 1e6 AS acum_anio_actual
        FROM visordg.ventas_raw_dos v CROSS JOIN per
        WHERE v.fecha >= (per.m0 - INTERVAL '2 years')::date
        GROUP BY v.sector
        ORDER BY mes_anio_actual DESC""",
    # Recaudación por provincia (pantalla 4)
    # mes_* = último mes de recaudación a mismos días; acum_* = enero -> día de corte (mismos días)
    "rec_provincia": """
        WITH per AS (
            SELECT date_trunc('month', max(fecha))::date AS m0,
                   EXTRACT(DAY FROM max(fecha))::int     AS dia_corte,
                   max(fecha)                            AS fmax
            FROM visordg.recaudacion_raw_dos)
        SELECT upper(btrim(r.provincia)) AS provincia,
               COALESCE(SUM(r.recaudado) FILTER (
                   WHERE date_trunc('month', r.fecha) = per.m0 - INTERVAL '1 year'
                     AND EXTRACT(DAY FROM r.fecha) <= per.dia_corte), 0) / 1e6 AS mes_anio_anterior,
               COALESCE(SUM(r.recaudado) FILTER (
                   WHERE date_trunc('month', r.fecha) = per.m0), 0) / 1e6 AS mes_anio_actual,
               COALESCE(SUM(r.recaudado) FILTER (
                   WHERE r.fecha >= date_trunc('year', per.fmax) - INTERVAL '1 year'
                     AND r.fecha <= per.fmax - INTERVAL '1 year'), 0) / 1e6 AS acum_anio_anterior,
               COALESCE(SUM(r.recaudado) FILTER (
                   WHERE r.fecha >= date_trunc('year', per.fmax)), 0) / 1e6 AS acum_anio_actual
        FROM visordg.recaudacion_raw_dos r CROSS JOIN per
        WHERE r.fecha >= (date_trunc('year', per.fmax) - INTERVAL '1 year')::date
        GROUP BY upper(btrim(r.provincia))
        ORDER BY mes_anio_actual DESC""",
    # Recaudación por sector económico (pantalla 4)
    # mes_* = último mes de recaudación a mismos días; acum_* = enero -> día de corte (mismos días)
    "rec_actividad": """
        WITH per AS (
            SELECT date_trunc('month', max(fecha))::date AS m0,
                   EXTRACT(DAY FROM max(fecha))::int     AS dia_corte,
                   max(fecha)                            AS fmax
            FROM visordg.recaudacion_raw_dos)
        SELECT upper(btrim(r.sector)) AS sector,
               COALESCE(SUM(r.recaudado) FILTER (
                   WHERE date_trunc('month', r.fecha) = per.m0 - INTERVAL '1 year'
                     AND EXTRACT(DAY FROM r.fecha) <= per.dia_corte), 0) / 1e6 AS mes_anio_anterior,
               COALESCE(SUM(r.recaudado) FILTER (
                   WHERE date_trunc('month', r.fecha) = per.m0), 0) / 1e6 AS mes_anio_actual,
               COALESCE(SUM(r.recaudado) FILTER (
                   WHERE r.fecha >= date_trunc('year', per.fmax) - INTERVAL '1 year'
                     AND r.fecha <= per.fmax - INTERVAL '1 year'), 0) / 1e6 AS acum_anio_anterior,
               COALESCE(SUM(r.recaudado) FILTER (
                   WHERE r.fecha >= date_trunc('year', per.fmax)), 0) / 1e6 AS acum_anio_actual
        FROM visordg.recaudacion_raw_dos r CROSS JOIN per
        WHERE r.fecha >= (date_trunc('year', per.fmax) - INTERVAL '1 year')::date
        GROUP BY upper(btrim(r.sector))
        ORDER BY mes_anio_actual DESC""",
    # Recaudación por impuesto (pantalla 4)
    # mes_* = último mes de recaudación a mismos días; acum_* = enero -> día de corte (mismos días)
    "rec_impuesto": """
        WITH per AS (
            SELECT date_trunc('month', max(fecha))::date AS m0,
                   EXTRACT(DAY FROM max(fecha))::int     AS dia_corte,
                   max(fecha)                            AS fmax
            FROM visordg.recaudacion_raw_dos)
        -- Normalizado: 2025 y 2026 pueden escribir distinto el mismo impuesto
        -- ('IVA Operaciones Internas' vs 'Iva Operaciones Internas'); vacío -> 'SIN IMPUESTO'.
        SELECT COALESCE(NULLIF(upper(btrim(r.impuesto)), ''), 'SIN IMPUESTO') AS impuesto,
               COALESCE(SUM(r.recaudado) FILTER (
                   WHERE date_trunc('month', r.fecha) = per.m0 - INTERVAL '1 year'
                     AND EXTRACT(DAY FROM r.fecha) <= per.dia_corte), 0) / 1e6 AS mes_anio_anterior,
               COALESCE(SUM(r.recaudado) FILTER (
                   WHERE date_trunc('month', r.fecha) = per.m0), 0) / 1e6 AS mes_anio_actual,
               COALESCE(SUM(r.recaudado) FILTER (
                   WHERE r.fecha >= date_trunc('year', per.fmax) - INTERVAL '1 year'
                     AND r.fecha <= per.fmax - INTERVAL '1 year'), 0) / 1e6 AS acum_anio_anterior,
               COALESCE(SUM(r.recaudado) FILTER (
                   WHERE r.fecha >= date_trunc('year', per.fmax)), 0) / 1e6 AS acum_anio_actual
        FROM visordg.recaudacion_raw_dos r CROSS JOIN per
        WHERE r.fecha >= (date_trunc('year', per.fmax) - INTERVAL '1 year')::date
        GROUP BY 1
        ORDER BY mes_anio_actual DESC""",
    # Panel: brigadas por PERSONAS ATENDIDAS (mensual). Alterna con eventos en la
    # tarjeta de brigadas (Shift+Alt+Q / [monitor].brigadas_panel).
    "hist_brigadas_atendidos": """
        SELECT to_char(make_date(anio::int, mes::int, 1), 'YYYY-MM') AS fecha,
               SUM(atendidos)::int AS brigadas_atendidos
        FROM visordg.brigadas_atendidos
        GROUP BY 1 ORDER BY 1""",
    # ---- Pantalla 5: BRIGADAS por provincia ----
    # Mensual (las fuentes no tienen día): mes = último mes con dato del año vigente;
    # acumulado = enero -> ese mes. Año previo: mismos meses.
    # ev_* = eventos (brigadas), at_* = atendidos; mes_* = mes, acum_* = acumulado;
    # *_anio_actual / *_anio_anterior (sin años fijos en los nombres).
    "brigadas_provincia": """
        WITH pm AS (
            SELECT anio, max(mes) AS mes FROM visordg.brigadas_eventos
            WHERE anio = (SELECT max(anio) FROM visordg.brigadas_eventos) GROUP BY anio),
        ev AS (
            SELECT upper(btrim(e.provincia)) AS prov, max(e.zona) AS zona,
                   SUM(e.eventos) FILTER (WHERE e.anio = pm.anio - 1 AND e.mes = pm.mes)  AS m_ant,
                   SUM(e.eventos) FILTER (WHERE e.anio = pm.anio     AND e.mes = pm.mes)  AS m_act,
                   SUM(e.eventos) FILTER (WHERE e.anio = pm.anio - 1 AND e.mes <= pm.mes) AS a_ant,
                   SUM(e.eventos) FILTER (WHERE e.anio = pm.anio     AND e.mes <= pm.mes) AS a_act
            FROM visordg.brigadas_eventos e CROSS JOIN pm
            WHERE e.anio >= pm.anio - 1
              AND e.provincia IS NOT NULL AND btrim(e.provincia) <> '' AND lower(btrim(e.provincia)) <> 'nan'
            GROUP BY 1),
        att AS (
            SELECT upper(btrim(a.provincia)) AS prov, max(a.zona) AS zona,
                   SUM(a.atendidos) FILTER (WHERE a.anio = pm.anio - 1 AND a.mes = pm.mes)  AS m_ant,
                   SUM(a.atendidos) FILTER (WHERE a.anio = pm.anio     AND a.mes = pm.mes)  AS m_act,
                   SUM(a.atendidos) FILTER (WHERE a.anio = pm.anio - 1 AND a.mes <= pm.mes) AS a_ant,
                   SUM(a.atendidos) FILTER (WHERE a.anio = pm.anio     AND a.mes <= pm.mes) AS a_act
            FROM visordg.brigadas_atendidos a CROSS JOIN pm
            WHERE a.anio >= pm.anio - 1
              AND a.provincia IS NOT NULL AND btrim(a.provincia) <> '' AND lower(btrim(a.provincia)) <> 'nan'
            GROUP BY 1)
        SELECT COALESCE(ev.zona, att.zona) AS zonal, COALESCE(ev.prov, att.prov) AS provincia,
               COALESCE(ev.m_ant, 0)  AS ev_mes_anio_anterior,  COALESCE(ev.m_act, 0)  AS ev_mes_anio_actual,
               COALESCE(ev.a_ant, 0)  AS ev_acum_anio_anterior, COALESCE(ev.a_act, 0)  AS ev_acum_anio_actual,
               COALESCE(att.m_ant, 0) AS at_mes_anio_anterior,  COALESCE(att.m_act, 0) AS at_mes_anio_actual,
               COALESCE(att.a_ant, 0) AS at_acum_anio_anterior, COALESCE(att.a_act, 0) AS at_acum_anio_actual
        FROM ev FULL OUTER JOIN att ON att.prov = ev.prov
        ORDER BY provincia""",
    # ---- Pantalla 6: CAPACITACIONES por provincia ----
    # Diario: mes = mes de la última fecha a mismos días; acumulado = enero -> última fecha
    # (año previo a mismos días). ev_* = eventos (filas), cp_* = capacitados;
    # mes_* / acum_* y *_anio_actual / *_anio_anterior (sin años fijos).
    "cap_provincia": """
        WITH p AS (
            SELECT max(fecha)::date AS fmax,
                   date_trunc('month', max(fecha))::date AS m0,
                   EXTRACT(DAY FROM max(fecha))::int AS dia,
                   date_trunc('year', max(fecha))::date AS y0
            FROM visordg.capacitaciones_raw),
        c AS (
            SELECT r.zonal, upper(btrim(r.provincia)) AS prov, r.fecha::date AS f,
                   r.total_capacitados AS cap, p.*
            FROM visordg.capacitaciones_raw r CROSS JOIN p
            WHERE r.fecha::date >= (p.y0 - INTERVAL '1 year')::date AND r.provincia IS NOT NULL AND btrim(r.provincia) <> '' AND lower(btrim(r.provincia)) <> 'nan')
        SELECT max(zonal) AS zonal, prov AS provincia,
               COUNT(*) FILTER (WHERE date_trunc('month', f) = m0 - INTERVAL '1 year'
                                  AND EXTRACT(DAY FROM f) <= dia)                        AS ev_mes_anio_anterior,
               COUNT(*) FILTER (WHERE date_trunc('month', f) = m0 AND f <= fmax)          AS ev_mes_anio_actual,
               COUNT(*) FILTER (WHERE f >= y0 - INTERVAL '1 year' AND f <= fmax - INTERVAL '1 year') AS ev_acum_anio_anterior,
               COUNT(*) FILTER (WHERE f >= y0 AND f <= fmax)                              AS ev_acum_anio_actual,
               COALESCE(SUM(cap) FILTER (WHERE date_trunc('month', f) = m0 - INTERVAL '1 year'
                                           AND EXTRACT(DAY FROM f) <= dia), 0)            AS cp_mes_anio_anterior,
               COALESCE(SUM(cap) FILTER (WHERE date_trunc('month', f) = m0 AND f <= fmax), 0) AS cp_mes_anio_actual,
               COALESCE(SUM(cap) FILTER (WHERE f >= y0 - INTERVAL '1 year'
                                           AND f <= fmax - INTERVAL '1 year'), 0)          AS cp_acum_anio_anterior,
               COALESCE(SUM(cap) FILTER (WHERE f >= y0 AND f <= fmax), 0)                 AS cp_acum_anio_actual
        FROM c GROUP BY prov ORDER BY prov""",
}


async def _init_db(pool: asyncpg.Pool) -> None:
    """Crea el usuario admin si no existe ninguno."""
    async with pool.acquire() as con:
        total = await con.fetchval("SELECT count(*) FROM seg.usuarios")
        if total == 0:
            await con.execute(
                """INSERT INTO seg.usuarios (username, email, password_hash, perfil_id)
                   SELECT 'admin', 'admin@sri.gob.ec', $1, id
                   FROM seg.perfiles WHERE codigo = 'ADMIN'""",
                pwd_hasher.hash(ADMIN_PASSWORD))
            print(f"[INIT] Usuario 'admin' creado (clave inicial del settings.toml) - CAMBIALA de inmediato")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Ciclo de vida: pool de conexiones con search_path a visordg."""
    app.state.pool = await asyncpg.create_pool(
        PG_DSN, min_size=2, max_size=20,   # tv-data lanza sus consultas en paralelo
        server_settings={"search_path": "visordg,seg,public"})
    app.state.ws_clients = set()
    await _init_db(app.state.pool)
    async with app.state.pool.acquire() as con:
        await asegurar_esquema(con)   # ajustes de estructura idempotentes (sin migraciones manuales)
    # Se guarda la referencia: una tarea sin referencia puede ser recolectada por el GC
    app.state.tarea_nocturna = asyncio.create_task(tarea_programada_23hs())
    yield
    app.state.tarea_nocturna.cancel()
    await app.state.pool.close()


app = FastAPI(title="Visor Gerencial SRI", version="0.3.0", lifespan=lifespan)

# gzip para las respuestas grandes (el paquete tv-data): menos bytes por la red
app.add_middleware(GZipMiddleware, minimum_size=1024)

# Fuentes del frontend (ruta absoluta desde este archivo), con caché de 24 h:
# no cambian entre recargas y eran lo más pesado de cada Ctrl+F5
class StaticFilesConCache(StaticFiles):
    """StaticFiles + Cache-Control: el navegador no las vuelve a bajar en 24 h."""

    async def get_response(self, path, scope):
        respuesta = await super().get_response(path, scope)
        if respuesta.status_code == 200:
            respuesta.headers["Cache-Control"] = "public, max-age=86400"
        return respuesta


app.mount("/font", StaticFilesConCache(directory=RUTA_BACKEND.parent / "frontend" / "dist" / "font"), name="font")

# ------------------------------------------------------------------
# Autenticación
# ------------------------------------------------------------------
class LoginIn(BaseModel):
    """Credenciales de acceso."""

    username: str
    password: str


def crear_token(user_id: str, perfil: str) -> str:
    """Firma un JWT de corta duración."""
    payload = {"sub": user_id, "perfil": perfil,
               "exp": datetime.now(timezone.utc) + timedelta(minutes=JWT_MINUTOS)}
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALG)


async def usuario_actual(cred: HTTPAuthorizationCredentials = Depends(bearer)) -> dict:
    """Valida el Bearer token de endpoints protegidos."""
    if not cred:
        raise HTTPException(401, "Token requerido")
    try:
        return jwt.decode(cred.credentials, JWT_SECRET, algorithms=[JWT_ALG])
    except jwt.PyJWTError as exc:
        raise HTTPException(401, "Token inválido o expirado") from exc


async def solo_admin(usuario: dict = Depends(usuario_actual)) -> dict:
    """Exige token válido Y perfil ADMIN (operaciones que borran/recargan datos)."""
    if usuario.get("perfil") != "ADMIN":
        raise HTTPException(403, "Requiere perfil ADMIN")
    return usuario


@app.post("/api/v1/auth/login")
async def login(body: LoginIn) -> dict:
    """Autentica contra seg.usuarios y devuelve un JWT."""
    async with app.state.pool.acquire() as con:
        row = await con.fetchrow(
            """SELECT u.id, u.password_hash, u.activo, p.codigo AS perfil
               FROM seg.usuarios u JOIN seg.perfiles p ON p.id = u.perfil_id
               WHERE u.username = $1""", body.username)
        if not row or not row["activo"] or not pwd_hasher.verify(body.password, row["password_hash"]):
            await con.execute("INSERT INTO seg.auditoria (accion, detalle) VALUES ('login_fail', $1)",
                              json.dumps({"username": body.username}))
            raise HTTPException(401, "Credenciales incorrectas")
        await con.execute("UPDATE seg.usuarios SET ultimo_login = now() WHERE id = $1", row["id"])
        await con.execute("INSERT INTO seg.auditoria (usuario_id, accion) VALUES ($1, 'login_ok')", row["id"])
    return {"access_token": crear_token(str(row["id"]), row["perfil"]),
            "token_type": "bearer", "expira_min": JWT_MINUTOS}


# ------------------------------------------------------------------
# Datos del monitor TV
# ------------------------------------------------------------------
def _fila_a_dict(row: asyncpg.Record) -> dict:
    """Convierte un Record a dict JSON-serializable."""
    salida = {}
    for clave, valor in dict(row).items():
        if hasattr(valor, "isoformat"):
            valor = valor.isoformat()[:10]
        elif hasattr(valor, "__float__") and not isinstance(valor, (int, float)):
            valor = float(valor)
        salida[clave] = valor
    return salida


@app.get("/api/v1/health")
async def health() -> dict:
    """Latido de la API y de la base."""
    async with app.state.pool.acquire() as con:
        await con.fetchval("SELECT 1")
    return {"status": "ok", "ts": datetime.now(timezone.utc).isoformat()}


@app.get("/api/v1/config")
async def config_publica() -> dict:
    """Parámetros de refresco del monitor (desde settings.toml)."""
    return {
        "sondeo_ms": int(MONITOR.get("sondeo_segundos", 60)) * 1000,
        "pantalla_ms": int(MONITOR.get("pantalla_segundos", 20)) * 1000,
        "pagina_ms": int(MONITOR.get("pagina_segundos", 7)) * 1000,
        "formato_moneda": str(MONITOR.get("formato_moneda", "B")),  # "B" | "mill"
        "visibilidad_barra": bool(MONITOR.get("visibilidad_barra", True)),
        "visibilidad_barras_mini": bool(MONITOR.get("visibilidad_barras_mini", True)),
        # Tarjeta de ventas: True = acumulado mensual (como antes);
        # False = acumulado día a día del mes en curso
        "ventas_mensual": bool(MONITOR.get("ventas_mensual", True)),
        # Serie de hace dos años en los gráficos: True = oculta. Acepta también
        # el nombre anterior ocultar_historico_2024 del settings.
        "ocultar_hace_dos_anios": bool(MONITOR.get("ocultar_hace_dos_anios",
                                                   MONITOR.get("ocultar_historico_2024", True))),
        # Insignia inferior "en vivo · hh:mm": False = oculta mientras todo va bien
        # (si hay error de conexión igual aparece). Shift+Alt+E la alterna en pantalla.
        "visibilidad_estado": bool(MONITOR.get("visibilidad_estado", True)),
        # Meta anual de recaudación (millones USD) para "Avance Recaudación Acumulada" (P4)
        "meta_anual_recaudacion": float(SETTINGS.get("metas", {}).get("meta_anual_recaudacion", 0) or 0),
        # Tarjeta de brigadas del panel: "eventos" (brigadas realizadas) | "atendidos"
        "brigadas_panel": MONITOR.get("brigadas_panel", "eventos")
                          if MONITOR.get("brigadas_panel") in ("eventos", "atendidos") else "eventos",
        # Columnas año anterior / año actual / Var % de P5 y P6: qué métrica comparan
        "brigadas_comparar": MONITOR.get("brigadas_comparar", "eventos")
                             if MONITOR.get("brigadas_comparar") in ("eventos", "atendidos") else "eventos",
        "capacitaciones_comparar": MONITOR.get("capacitaciones_comparar", "eventos")
                                   if MONITOR.get("capacitaciones_comparar") in ("eventos", "capacitados") else "eventos",
        # Tablas de ventas y recaudación (P2, P3, P4): "mes" (mes en curso) |
        # "acumulado" (enero -> día de corte). Acepta también el nombre anterior ventas_tablas_modo.
        "tablas_modo": (lambda m: m if m in ("mes", "acumulado") else "acumulado")(
            MONITOR.get("tablas_modo", MONITOR.get("ventas_tablas_modo", "acumulado"))),
        # Paleta de las barras del gráfico de ventas de P1 (07/10/2026)
        "ventas_paleta": (MONITOR.get("ventas_paleta", "azul")
                          if MONITOR.get("ventas_paleta")
                          in ("azul", "verde", "amarilla", "violeta", "coral") else "azul"),
        # Barra deslizante: "mensual_actual_al_dia" (solo el mes en curso) |
        #                   "anual_al_dia" (enero -> día actual)
        "deslizante_acumulado": (MONITOR.get("deslizante_acumulado", "anual_al_dia")
                                 if MONITOR.get("deslizante_acumulado") in ("mensual_actual_al_dia", "anual_al_dia")
                                 else "anual_al_dia"),
    }


async def _fetch(clave, sql):
    """Una consulta del paquete TV en su propia conexión del pool."""
    async with app.state.pool.acquire() as con:
        return clave, await con.fetch(sql)


async def _fetchval(sql):
    async with app.state.pool.acquire() as con:
        return await con.fetchval(sql)


@app.get("/api/v1/tv-data")
async def tv_data() -> dict:
    """Devuelve el paquete completo del monitor desde las tablas visordg.

    Público de solo lectura para pantallas TV; cargas y auth sí exigen token.
    Las consultas corren EN PARALELO (antes en serie): el tiempo de respuesta
    pasa a ser el de la consulta más lenta, no la suma de todas.
    """
    resultados = await asyncio.gather(*[_fetch(c, s) for c, s in CONSULTAS_TV.items()])
    datos = {clave: [_fila_a_dict(f) for f in filas] for clave, filas in resultados}
    # 'YYYY-MM': el nombre del mes lo arma el frontend en español
    # (TMMonth depende del lc_time del servidor y salía "August de 2026")
    periodo, per_rec, per_brig, per_cap = await asyncio.gather(
        _fetchval("SELECT periodo FROM visordg.dash_ventas_provincia ORDER BY cargado_en DESC LIMIT 1"),
        _fetchval("SELECT to_char(date_trunc('month', max(fecha)), 'YYYY-MM') FROM visordg.recaudacion_raw_dos"),
        _fetchval("""SELECT to_char(make_date(anio::int, max(mes)::int, 1), 'YYYY-MM') FROM visordg.brigadas_eventos
                     WHERE anio = (SELECT max(anio) FROM visordg.brigadas_eventos) GROUP BY anio"""),
        _fetchval("SELECT to_char(date_trunc('month', max(fecha)), 'YYYY-MM') FROM visordg.capacitaciones_raw"))
    datos["periodo_provincias"] = periodo or ""
    datos["periodo_recaudacion"] = per_rec or ""
    datos["periodo_brigadas"] = per_brig or ""
    datos["periodo_capacitaciones"] = per_cap or ""
    datos["actualizado_en"] = datetime.now(timezone.utc).isoformat()
    return datos


@app.get("/api/v1/actualizado")
async def actualizado() -> dict:
    """Marca de agua del último refresco (para sondeo ligero del frontend)."""
    async with app.state.pool.acquire() as con:
        marca = await con.fetchval("SELECT actualizado_en FROM visordg.visor_refresh WHERE id = 1")
    return {"actualizado_en": marca.isoformat() if marca else None}


# ------------------------------------------------------------------
# WebSocket: aviso de refresco a las pantallas
# ------------------------------------------------------------------
async def notificar_refresh() -> None:
    """Avisa a todas las pantallas conectadas que hay datos nuevos."""
    async with app.state.pool.acquire() as con:
        await con.execute("UPDATE visordg.visor_refresh SET actualizado_en = now() WHERE id = 1")
    muertos = []
    for ws in app.state.ws_clients:
        try:
            await ws.send_text("refresh")
        except Exception:  # noqa: BLE001 - cliente desconectado a mitad de envío
            muertos.append(ws)
    for ws in muertos:
        app.state.ws_clients.discard(ws)


@app.websocket("/api/v1/stream")
async def stream(ws: WebSocket) -> None:
    """Canal de eventos: el servidor envía 'refresh' tras cada carga."""
    await ws.accept()
    app.state.ws_clients.add(ws)
    try:
        while True:
            await asyncio.sleep(30)
            await ws.send_text("ping")
    except (WebSocketDisconnect, RuntimeError):
        app.state.ws_clients.discard(ws)


# ------------------------------------------------------------------
# Refresco SQL y recargas
# ------------------------------------------------------------------
async def refrescar_todo() -> None:
    """Refresco único (05, que absorbió al 03).

    Se corre en un hilo: no bloquea el event loop y funciona con cualquier
    loop de Windows (el SelectorEventLoop no soporta subprocesos asyncio).
    """
    for script in SCRIPTS_REFRESCO:
        await asyncio.to_thread(correr_sql, script)


async def tarea_programada_23hs() -> None:
    """Refresco nocturno automático a las 23:00 (hora del servidor)."""
    while True:
        ahora = datetime.now()
        objetivo = ahora.replace(hour=23, minute=0, second=0, microsecond=0)
        if ahora >= objetivo:
            objetivo += timedelta(days=1)
        espera = (objetivo - ahora).total_seconds()
        print(f"[DEMONIO] Próximo refresco en {espera:.0f} s.")
        await asyncio.sleep(espera)
        if CANDADO_RECARGA.locked():
            print("[DEMONIO] Hay una recarga en curso; se omite el refresco de hoy.")
            continue
        try:
            async with CANDADO_RECARGA:
                print("[DEMONIO] Refresco nocturno...")
                await refrescar_todo()
                await notificar_refresh()
                print("[DEMONIO] Refresco nocturno completado.")
        except Exception as exc:  # noqa: BLE001 - el demonio no debe morir
            print(f"[DEMONIO] Error en el refresco nocturno: {exc}")


@app.post("/api/v1/recargar-total")
async def recargar_total_manual(origen: str | None = None, usuario: dict = Depends(solo_admin)) -> dict:
    """Recarga las 4 fuentes desde el origen (local | fileserver; por defecto el del
    settings) y refresca. Solo ADMIN, una a la vez.

    Cada fuente es atómica: si una falla conserva sus datos y las demás siguen.
    Las cargas corren en un hilo aparte para no congelar a los TV.
    """
    if origen is not None and origen not in ORIGENES:
        raise HTTPException(422, f"origen debe ser: {' | '.join(ORIGENES)}")
    if CANDADO_RECARGA.locked():
        raise HTTPException(409, "Ya hay una recarga o refresco en curso")
    async with CANDADO_RECARGA:
        try:
            print(f"[API] Recarga total (origen={origen or 'settings'}) por usuario {usuario.get('sub')}.")
            async with app.state.pool.acquire() as con:
                await con.execute("INSERT INTO seg.auditoria (accion, detalle) VALUES ('recarga_total', $1)",
                                  json.dumps({"usuario": usuario.get("sub"), "origen": origen}))
            fuentes = await asyncio.to_thread(asyncio.run, cargar_todo(origen))
            await refrescar_todo()
            await notificar_refresh()
        except Exception as exc:  # noqa: BLE001 - origen inaccesible, refresco fallido, etc.
            print(f"[API] Falla en recarga total: {exc}")
            raise HTTPException(500, f"Falla en la recarga: {exc}") from exc
    errores = {k: v for k, v in fuentes.items() if v != "ok"}
    if len(errores) == len(fuentes):
        raise HTTPException(500, "Ninguna fuente se cargó: " + "; ".join(f"{k}: {v}" for k, v in errores.items()))
    return {"status": "parcial" if errores else "success", "fuentes": fuentes}
