"""Cargador de fuentes hacia el esquema visordg (base detalles).

Dos orígenes, configurados en [fuentes] de config/settings.toml:
    local      -> carpeta del disco (data/input)
    fileserver -> ruta UNC institucional

Uso (desde app/backend):
    pdm run cargar todo                       # todas las fuentes + refresco, origen del settings
    pdm run cargar todo --origen local        # fuerza el origen para esta corrida
    pdm run cargar ventas-dos                 # una fuente, origen del settings
    pdm run cargar ventas-dos "D:/.../Ventas CEL"   # una fuente, carpeta explícita
    pdm run refrescar                         # 05 (refresco único)

Cada carga REEMPLAZA su tabla (o su año) dentro de una transacción; si el
archivo trae menos de MIN_FILAS_VALIDAS filas, no se toca lo que ya había.
No se usan variables de entorno: todo sale del settings.toml.
"""

import asyncio
import os
import re
import shutil
import subprocess
import unicodedata
from datetime import date, datetime
from io import StringIO
from pathlib import Path

import asyncpg
import click
import pandas as pd

from config import cargar_settings, construir_dsn

SETTINGS = cargar_settings()
PG_DSN = construir_dsn(SETTINGS)
RUTA_SQL = Path(__file__).resolve().parents[2] / "sql"
ORIGENES = ("local", "fileserver")

# Umbral de protección: si un archivo trae menos filas válidas que esto, NO se
# borra lo que hay en la base (evita dejar el visor vacío por un archivo roto).
MIN_FILAS_VALIDAS = 10

MESES = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
         "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]


def leer_hoja(ruta: str, hoja: str | int, encabezado: int = 0) -> pd.DataFrame:
    """Lee una pestaña de Excel con encabezados normalizados y sin filas vacías."""
    frame = pd.read_excel(ruta, sheet_name=hoja, header=encabezado)
    frame.columns = [str(c).strip() for c in frame.columns]
    return frame.dropna(how="all")


def texto(valor) -> str:
    """Celda -> texto limpio. Una celda VACÍA de Excel llega como NaN y
    str(NaN or "") da 'nan' (NaN es "verdadero" en Python): así la fila
    'Total general' de brigadas (Provincia vacía) entraba como provincia
    'nan' y DUPLICABA todos los totales. Aquí vacío es siempre ''."""
    if valor is None or (isinstance(valor, float) and pd.isna(valor)):
        return ""
    return str(valor).strip()


def anio_declarado(ruta: str, hoja: str, max_filas: int = 8) -> int | None:
    """Año que declara el encabezado de la hoja ('Año | 2026' o 'Año 2025')."""
    crudo = pd.read_excel(ruta, sheet_name=hoja, header=None, nrows=max_filas)
    for _, fila in crudo.iterrows():
        celdas = [texto(c) for c in fila]
        linea = " ".join(c for c in celdas if c)
        hallado = re.search(r"a[ñn]o\D{0,3}(20\d{2})", linea, re.IGNORECASE)
        if hallado:
            return int(hallado.group(1))
    return None


_ISO = re.compile(r"^\d{4}-\d{1,2}-\d{1,2}")


def fecha_robusta(valor):
    """Fecha de una celda de Excel sin invertir nunca día y mes.

    - fecha real de Excel (datetime)  -> tal cual
    - texto ISO '2026-04-10[ hh:mm]'  -> año-mes-día (antes, con dayfirst=True,
                                          pandas lo leía como 4 de OCTUBRE)
    - texto '10/04/2026'              -> día/mes/año (formato local)
    - número de serie de Excel (45757) -> fecha
    Devuelve pd.Timestamp o None.
    """
    try:
        if valor is None or pd.isna(valor):     # None, NaN y NaT (fecha vacía de pandas)
            return None
    except (TypeError, ValueError):
        pass
    if isinstance(valor, (pd.Timestamp, datetime, date)):
        return pd.Timestamp(valor)
    if isinstance(valor, (int, float)) and not isinstance(valor, bool):
        return pd.Timestamp("1899-12-30") + pd.Timedelta(days=float(valor)) if 20000 < valor < 80000 else None
    texto = str(valor).strip()
    if not texto:
        return None
    if _ISO.match(texto):
        f = pd.to_datetime(texto, format="ISO8601", errors="coerce")
    else:
        f = pd.to_datetime(texto, dayfirst=True, errors="coerce")
    return None if pd.isna(f) else f


def fila_encabezado(ruta: str, hoja: str, columna_clave: str, max_filas: int = 10) -> int:
    """Detecta en qué fila está el encabezado buscando una columna conocida."""
    crudo = pd.read_excel(ruta, sheet_name=hoja, header=None, nrows=max_filas)
    for i, fila in crudo.iterrows():
        if any(str(c).strip().lower() == columna_clave.lower() for c in fila if pd.notna(c)):
            return int(i)
    return 0


def entero(valor) -> int:
    """Entero tolerante: números directo; texto con separador de miles ('1.186' -> 1186).

    los floats de Excel (19.0) NO pasan por texto, porque
    str(19.0) = '19.0' y quitar el punto daría 190.
    """
    if valor is None or (isinstance(valor, float) and pd.isna(valor)):
        return 0
    if isinstance(valor, (int, float)):
        return int(valor)
    return int(round(_ec_num(valor)))   # texto: misma regla que los montos ('1.186' -> 1186; '12,0' -> 12)


# Ajustes de estructura que el sistema aplica SOLO (idempotentes, no borran datos).
# Evitan pasos manuales de "migración": la API los corre al arrancar y la consola
# antes de cada comando. Las instalaciones nuevas ya los traen en 01_esquema_visordg.sql.
AJUSTES_ESQUEMA = """
ALTER TABLE visordg.brigadas_atendidos DROP CONSTRAINT IF EXISTS brigadas_atendidos_agencia_anio_mes_key;
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'brigadas_atendidos_prov_agencia_anio_mes_key') THEN
        ALTER TABLE visordg.brigadas_atendidos
            ADD CONSTRAINT brigadas_atendidos_prov_agencia_anio_mes_key UNIQUE (provincia, agencia, anio, mes);
    END IF;
END $$;
ALTER TABLE visordg.cargas_archivo      ADD COLUMN IF NOT EXISTS anio SMALLINT,
                                        ADD COLUMN IF NOT EXISTS archivo_modificado TIMESTAMPTZ,
                                        ADD COLUMN IF NOT EXISTS total_declarado NUMERIC,
                                        ADD COLUMN IF NOT EXISTS total_cargado NUMERIC;
ALTER TABLE visordg.hist_ventas         ADD COLUMN IF NOT EXISTS archivo TEXT,
                                        ADD COLUMN IF NOT EXISTS archivo_modificado TIMESTAMPTZ;
ALTER TABLE visordg.hist_recaudacion    ADD COLUMN IF NOT EXISTS archivo TEXT,
                                        ADD COLUMN IF NOT EXISTS archivo_modificado TIMESTAMPTZ;
ALTER TABLE visordg.hist_brigadas       ADD COLUMN IF NOT EXISTS archivo TEXT,
                                        ADD COLUMN IF NOT EXISTS archivo_modificado TIMESTAMPTZ,
                                        ADD COLUMN IF NOT EXISTS total_declarado INTEGER;
ALTER TABLE visordg.hist_capacitaciones ADD COLUMN IF NOT EXISTS archivo TEXT,
                                        ADD COLUMN IF NOT EXISTS archivo_modificado TIMESTAMPTZ,
                                        ADD COLUMN IF NOT EXISTS total_declarado INTEGER;
-- Años RELATIVOS (29/09/2026): columnas sin año en el nombre.
-- Renombra las columnas viejas (ventas_2025, v2026, ...) si todavía existen.
DO $$
DECLARE r record;
BEGIN
    FOR r IN SELECT * FROM (VALUES
        ('dash_mes_corriente',    'ventas_2024',         'ventas_hace_dos_anios'),
        ('dash_mes_corriente',    'ventas_2025',         'ventas_anio_anterior'),
        ('dash_mes_corriente',    'ventas',              'ventas_anio_actual'),
        ('dash_mes_corriente',    'recaudacion_2025',    'recaudacion_anio_anterior'),
        ('dash_mes_corriente',    'recaudacion',         'recaudacion_anio_actual'),
        ('dash_mes_corriente',    'brigadas_2025',       'brigadas_anio_anterior'),
        ('dash_mes_corriente',    'brigadas',            'brigadas_anio_actual'),
        ('dash_mes_corriente',    'capacitaciones_2025', 'capacitaciones_anio_anterior'),
        ('dash_mes_corriente',    'capacitaciones',      'capacitaciones_anio_actual'),
        ('dash_ventas_provincia', 'v2024',               'hace_dos_anios'),
        ('dash_ventas_provincia', 'v2025',               'anio_anterior'),
        ('dash_ventas_provincia', 'v2026',               'anio_actual')
    ) AS t(tabla, viejo, nuevo)
    LOOP
        IF EXISTS (SELECT 1 FROM information_schema.columns
                   WHERE table_schema = 'visordg' AND table_name = r.tabla AND column_name = r.viejo)
           AND NOT EXISTS (SELECT 1 FROM information_schema.columns
                   WHERE table_schema = 'visordg' AND table_name = r.tabla AND column_name = r.nuevo) THEN
            EXECUTE format('ALTER TABLE visordg.%I RENAME COLUMN %I TO %I', r.tabla, r.viejo, r.nuevo);
        END IF;
    END LOOP;
END $$;
"""


async def asegurar_esquema(con: asyncpg.Connection | None = None) -> None:
    """Aplica AJUSTES_ESQUEMA (rápido si ya están aplicados)."""
    propia = con is None
    con = con or await asyncpg.connect(PG_DSN)
    try:
        await con.execute(AJUSTES_ESQUEMA)
    finally:
        if propia:
            await con.close()


def fecha_modificacion(ruta: str | Path) -> datetime:
    """Fecha de última modificación del archivo (la que se ve en el Explorador de Windows).

    Copiar del fileserver a la carpeta local con el Explorador CONSERVA esta fecha,
    así que es la misma en ambos orígenes: la fecha en que el área dejó el archivo.
    """
    return datetime.fromtimestamp(Path(ruta).stat().st_mtime).astimezone()


async def registrar_carga(con: asyncpg.Connection, fuente: str, archivo: str,
                          filas_ok: int, estado: str, ruta: str | Path | None = None,
                          anio: int | None = None, total_declarado: float | None = None,
                          total_cargado: float | None = None) -> None:
    """Deja trazabilidad (con año y fecha de modificación del archivo) y actualiza la marca de agua.

    El refresco 05 copia archivo + fecha de modificación a los hist_* de ese año.
    Esa fecha del archivo es la "fecha de corte" SOLO de brigadas (su Excel no
    trae fechas); ventas, recaudación y capacitaciones usan la última fecha de
    sus propios datos (la calcula la API en main.py).
    """
    await con.execute(
        """INSERT INTO visordg.cargas_archivo (fuente, nombre_archivo, filas_ok, estado, anio, archivo_modificado,
                                               total_declarado, total_cargado)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8)""",
        fuente, archivo, filas_ok, estado, anio, fecha_modificacion(ruta) if ruta else None,
        total_declarado, total_cargado)
    await con.execute("UPDATE visordg.visor_refresh SET actualizado_en = now() WHERE id = 1")


async def _copiar(con: asyncpg.Connection, tabla: str, columnas: list[str], registros: list) -> None:
    """TRUNCATE + COPY masivo a una tabla del esquema visordg."""
    await con.execute(f"TRUNCATE visordg.{tabla}")
    await con.copy_records_to_table(tabla, records=registros, schema_name="visordg", columns=columnas)


# ------------------------------------------------------------------
# Catálogo de recaudación: 4 pestañas -> 4 tablas
# ------------------------------------------------------------------
async def _cargar_catalogo(ruta: str) -> None:
    nombre = Path(ruta).name
    con = await asyncpg.connect(PG_DSN)
    try:
        imp = leer_hoja(ruta, "IMPUESTOS")
        registros = [(entero(f.get("IMPUESTO_PK")), str(f.get("Impuesto_Grupo") or "").strip(),
                      str(f.get("Impuesto_detalle") or "").strip(), str(f.get("CODIGO_OPERA_IMPUESTO") or "").strip(),
                      str(f.get("DESCRIPCION_IMPUESTO") or "").strip())
                     for _, f in imp.iterrows() if pd.notna(f.get("IMPUESTO_PK"))]
        await _copiar(con, "cat_impuestos",
                      ["impuesto_pk", "impuesto_grupo", "impuesto_detalle",
                       "codigo_opera_impuesto", "descripcion_impuesto"], registros)
        click.echo(f"  IMPUESTOS: {len(registros)}")

        prov = leer_hoja(ruta, "PROVINCIA_PK")
        prov.columns = ["provincia_pk", "provincia", "zona"]  # la 1ª viene con typo en el archivo
        registros = [(entero(f["provincia_pk"]), str(f["provincia"]).strip(), str(f["zona"]).strip())
                     for _, f in prov.iterrows() if pd.notna(f["provincia_pk"])]
        await _copiar(con, "cat_provincias", ["provincia_pk", "provincia", "zona"], registros)
        click.echo(f"  PROVINCIA_PK: {len(registros)}")

        fnt = leer_hoja(ruta, "FUENTES")
        registros = [(str(f.iloc[0]).strip(), str(f.iloc[1]).strip())
                     for _, f in fnt.iterrows() if pd.notna(f.iloc[0])]
        await _copiar(con, "cat_fuentes", ["mar_fuente", "descripcion_fuente"], registros)
        click.echo(f"  FUENTES: {len(registros)}")

        act = leer_hoja(ruta, "ACTIVIDAD_ECONOMICA")
        columnas_act = [c.lower() for c in act.columns]
        registros = [tuple(None if pd.isna(v) else (entero(v) if c == "actividad_economica_pk" else str(v).strip())
                           for c, v in zip(columnas_act, fila))
                     for _, fila in act.iterrows()]
        await _copiar(con, "cat_actividad_economica", columnas_act, registros)
        click.echo(f"  ACTIVIDAD_ECONOMICA: {len(registros)}")

        await registrar_carga(con, "catalogo", nombre, len(registros), "OK")
    finally:
        await con.close()
    click.echo("Catálogo cargado en las 4 tablas cat_*")


# ------------------------------------------------------------------
# Capacitaciones: pestaña Hoja1 (report1 se ignora), fecha TIMESTAMP
# ------------------------------------------------------------------
async def _cargar_capacitaciones(ruta: str) -> None:
    # La pestaña válida se llama "Hoja1" o "Sheet1"; "report1" se descarta.
    hojas = pd.ExcelFile(ruta).sheet_names
    hoja = "Hoja1" if "Hoja1" in hojas else ("Sheet1" if "Sheet1" in hojas else hojas[0])
    frame = leer_hoja(ruta, hoja, encabezado=fila_encabezado(ruta, hoja, "ZONAL"))
    frame.columns = [c.strip().lower().replace(" ", "_") for c in frame.columns]
    col_fecha = next((c for c in frame.columns if "fecha" in c), "fecha_capacitacion")
    col_total = next((c for c in frame.columns if "capacitados" in c), None)
    registros, sin_fecha = [], []
    declarado_eventos = declarado_capacitados = None
    for n, f in frame.iterrows():
        # Pie del Excel: "TOTAL ... 57464" y "TOTAL EVENTOS :1771" -> controles, no datos
        rotulo = " ".join(texto(c) for c in f.values if texto(c)).upper()
        if rotulo.startswith("TOTAL"):
            if "EVENTOS" in rotulo:
                numero = re.search(r"(\d[\d.]*)", rotulo.split("EVENTOS", 1)[1])
                declarado_eventos = entero(numero.group(1)) if numero else None
            elif col_total:
                declarado_capacitados = entero(f.get(col_total))
            continue
        fecha = fecha_robusta(f.get(col_fecha))
        if fecha is None:
            if texto(f.get("provincia")):   # fila con datos pero sin fecha legible
                sin_fecha.append((n, f.get(col_fecha)))
            continue
        registros.append((
            texto(f.get("zonal")), texto(f.get("provincia")), texto(f.get("lugar")),
            fecha.to_pydatetime(), texto(f.get("tema")), texto(f.get("instructor")),
            entero(f.get(col_total)) if col_total else 0,
            texto(f.get("horario")), texto(f.get("modalidad")), texto(f.get("tipo"))))
    _avisar_descartes(Path(ruta).name, sin_fecha, "sin fecha legible")
    nombre = Path(ruta).name
    for etiqueta, declarado, cargado in (("TOTAL EVENTOS", declarado_eventos, len(registros)),
                                         ("TOTAL capacitados", declarado_capacitados, sum(r[6] for r in registros))):
        if declarado is None:
            click.echo(f"  [AVISO] {nombre}: sin fila '{etiqueta}' para cotejar.")
        elif declarado != cargado:
            click.echo(f"  [AVISO] {nombre}: el Excel declara {etiqueta} = {declarado:,} pero se cargaron "
                       f"{cargado:,} (revisar filas sin fecha o duplicadas)".replace(",", "."))
        else:
            click.echo(f"  {nombre}: coincide con '{etiqueta}' del Excel ✓ ({cargado:,})".replace(",", "."))
    if len(registros) < MIN_FILAS_VALIDAS:
        click.echo(f"  [ALERTA] {Path(ruta).name}: solo {len(registros)} filas válidas; "
                   "se mantiene lo cargado antes.")
        return
    # Reemplaza SOLO los años que trae el archivo: cargar 2025 ya no borra 2026
    anios = sorted({r[3].year for r in registros})
    con = await asyncpg.connect(PG_DSN)
    try:
        async with con.transaction():   # borrar + copiar es atómico: si falla, no queda vacío
            await con.execute(
                "DELETE FROM visordg.capacitaciones_raw WHERE EXTRACT(YEAR FROM fecha)::int = ANY($1::int[])", anios)
            await con.copy_records_to_table(
                "capacitaciones_raw", records=registros, schema_name="visordg",
                columns=["zonal", "provincia", "lugar", "fecha", "tema", "instructor",
                         "total_capacitados", "horario", "modalidad", "tipo"])
            await registrar_carga(con, "capacitaciones", Path(ruta).name, len(registros), "OK",
                                  ruta=ruta, anio=max(anios),
                                  total_declarado=declarado_eventos, total_cargado=len(registros))
    finally:
        await con.close()
    click.echo(f"  {Path(ruta).name}: {len(registros)} registros, año(s) {anios} reemplazado(s)")


# ------------------------------------------------------------------
# Brigadas: pestaña Atendidos_brigadas, meses en columnas -> filas
# ------------------------------------------------------------------

async def _cargar_brigadas(ruta: str, anio: int) -> None:
    """Carga las DOS pestañas de Brigadas, detectando variaciones históricas."""
    hojas_reales = pd.ExcelFile(ruta).sheet_names
    
    hoja_atendidos = next((h for h in hojas_reales if "atendidos" in h.lower()), None)
    
    # 🎯 DETECCIÓN INTELIGENTE: Si no halla 'eventos', mapea la pestaña 'total' (2025)
    hoja_eventos = next((h for h in hojas_reales if "eventos" in h.lower()), None)
    if not hoja_eventos:
        hoja_eventos = next((h for h in hojas_reales if "total" in h.lower()), None)
    
    if not hoja_atendidos or not hoja_eventos:
        raise click.ClickException(f"Estructura de pestañas inválida en: {Path(ruta).name}")
        
    # El año lo manda el propio archivo (fila "Año 2026"); el nombre es solo una pista.
    declarado = anio_declarado(ruta, hoja_eventos) or anio_declarado(ruta, hoja_atendidos)
    if declarado and declarado != anio:
        click.echo(f"  [AVISO] {Path(ruta).name}: se esperaba {anio} pero el archivo dice Año {declarado}; "
                   f"se carga como {declarado}.")
        anio = declarado

    ctl_at, ctl_ev = {}, {}
    crudo_at = _despivotar_brigadas(ruta, hoja_atendidos, anio, con_agencia=True, control=ctl_at)
    crudo_ev = _despivotar_brigadas(ruta, hoja_eventos, anio, con_agencia=False, control=ctl_ev)
    _cotejar_total(Path(ruta).name, hoja_atendidos, crudo_at, ctl_at)
    _cotejar_total(Path(ruta).name, hoja_eventos, crudo_ev, ctl_ev)
    
    # Consolidación por la clave única de cada tabla. Si el Excel trae la MISMA
    # clave dos veces (fila repetida, subtotal mal filtrado) se suman, pero
    # ahora se AVISA: una suma silenciosa puede inflar el total (p. ej. un mes
    # que duplica al anterior sin razón).
    #   brigadas_atendidos: UNIQUE (provincia, agencia, anio, mes)  [migración 06]
    #   brigadas_eventos:   UNIQUE (provincia, anio, mes)
    def _consolidar(filas, llave_de, meta_de) -> tuple[dict, list]:
        mapa, repetidas = {}, []
        for fila in filas:
            llave = llave_de(fila)
            if llave in mapa:
                repetidas.append(llave)
                mapa[llave]["valor"] += fila[-1]
            else:
                mapa[llave] = {**meta_de(fila), "valor": fila[-1]}
        return mapa, repetidas

    atendidos, rep_at = _consolidar(
        crudo_at,
        lambda f: (str(f[1] or "").strip(), str(f[2] or "").strip(), f[3], f[4]),   # provincia, agencia, anio, mes
        lambda f: {"zona": f[0]})
    registros_at = [(m["zona"], k[0], k[1], k[2], k[3], m["valor"]) for k, m in atendidos.items()]

    eventos, rep_ev = _consolidar(
        crudo_ev,
        lambda f: (str(f[1] or "").strip(), f[2], f[3]),                             # provincia, anio, mes
        lambda f: {"zona": f[0]})
    registros_ev = [(m["zona"], k[0], k[1], k[2], m["valor"]) for k, m in eventos.items()]

    for hoja, repetidas in (("Atendidos", rep_at), ("Eventos", rep_ev)):
        if repetidas:
            ejemplos = ", ".join(f"{k[0]} {'/'.join(map(str, k[1:]))}" for k in repetidas[:5])
            click.echo(f"  [AVISO] {Path(ruta).name} ({hoja}): {len(repetidas)} fila(s) con clave repetida "
                       f"se SUMARON. Revisar el Excel. Ej.: {ejemplos}")
    
    if len(registros_ev) < MIN_FILAS_VALIDAS:
        click.echo(f"  [ALERTA] {Path(ruta).name}: solo {len(registros_ev)} filas de eventos; "
                   f"se mantiene lo cargado de {anio}.")
        return

    # --- Copiado masivo, atómico por año ---
    con = await asyncpg.connect(PG_DSN)
    try:
        await asegurar_esquema(con)   # clave (provincia, agencia, anio, mes): se ajusta sola
        async with con.transaction():
            await con.execute("DELETE FROM visordg.brigadas_atendidos WHERE anio = $1", anio)
            await con.copy_records_to_table(
                "brigadas_atendidos", records=registros_at, schema_name="visordg",
                columns=["zona", "provincia", "agencia", "anio", "mes", "atendidos"])
            await con.execute("DELETE FROM visordg.brigadas_eventos WHERE anio = $1", anio)
            await con.copy_records_to_table(
                "brigadas_eventos", records=registros_ev, schema_name="visordg",
                columns=["zona", "provincia", "anio", "mes", "eventos"])
            await registrar_carga(con, "brigadas", Path(ruta).name, len(registros_at) + len(registros_ev), "OK",
                                  ruta=ruta, anio=anio,
                                  total_declarado=sum(ctl_ev.values()) if ctl_ev else None,
                                  total_cargado=sum(r[-1] for r in registros_ev))
    finally:
        await con.close()
        
    click.echo(f"  {Path(ruta).name}: Procesado y consolidado con éxito.")




def _despivotar_brigadas(ruta: str, hoja: str, anio: int, con_agencia: bool,
                         control: dict | None = None) -> list:
    """Meses en columnas -> filas. La fila 'Total general' (en Zona o en
    Provincia) NO se carga: si se pasa `control`, sus valores por mes se
    guardan ahí para cotejar contra la suma de provincias."""
    frame = leer_hoja(ruta, hoja, encabezado=fila_encabezado(ruta, hoja, "Zona"))
    # Encabezados de mes sin distinguir mayúsculas y aceptando "Setiembre":
    # antes, "SEPTIEMBRE" o "Setiembre" se ignoraban en silencio (mes en 0).
    nombres = {m.lower(): i + 1 for i, m in enumerate(MESES)}
    nombres["setiembre"] = 9
    idx_meses = {c: nombres[str(c).strip().lower()] for c in frame.columns
                 if str(c).strip().lower() in nombres}
    if not idx_meses:
        raise click.ClickException(f"No se encontraron columnas de meses en '{hoja}'")
    registros = []
    for _, f in frame.iterrows():
        zona, provincia = texto(f.get("Zona")), texto(f.get("Provincia"))
        if zona.lower().startswith("total") or provincia.lower().startswith("total"):
            if control is not None:
                for col, mes in idx_meses.items():
                    control[mes] = entero(f.get(col))
            continue
        if not provincia:
            continue
        for col, mes in idx_meses.items():
            if con_agencia:
                registros.append((zona, provincia, texto(f.get("Agencia")), anio, mes, entero(f.get(col))))
            else:
                registros.append((zona, provincia, anio, mes, entero(f.get(col))))
    return registros


def _cotejar_total(archivo: str, hoja: str, registros: list, control: dict) -> None:
    """Avisa si la suma por mes de las provincias no coincide con el 'Total general' del Excel."""
    if not control:
        click.echo(f"  [AVISO] {archivo} [{hoja}]: sin fila 'Total general' para cotejar.")
        return
    suma = {}
    for *_, mes, valor in registros:
        suma[mes] = suma.get(mes, 0) + valor
    dif = [f"{MESES[m - 1][:3]} {suma.get(m, 0)} vs {t}" for m, t in sorted(control.items()) if suma.get(m, 0) != t]
    if dif:
        click.echo(f"  [AVISO] {archivo} [{hoja}]: la suma de provincias NO coincide con el 'Total general' "
                   f"del Excel en: {'; '.join(dif)}")
    else:
        click.echo(f"  {archivo} [{hoja}]: coincide con el 'Total general' del Excel ✓ ({sum(control.values()):,})"
                   .replace(",", "."))


# ------------------------------------------------------------------
# Recaudación: carpeta con un CSV por MES (BDD_Recaudación_Ene26.csv ...)
# El mes se deduce del nombre; cada carga REEMPLAZA solo ese mes
# (idempotente: recargar el mismo archivo no duplica filas).
# ------------------------------------------------------------------
MESES_ABR = {"ene": 1, "feb": 2, "mar": 3, "abr": 4, "may": 5, "jun": 6,
             "jul": 7, "ago": 8, "sep": 9, "oct": 10, "nov": 11, "dic": 12}

_COLUMNAS_REC = ["ae_codigo_familia", "ae_codigo_grupo", "cod_n6", "fecha",
                 "impuesto_pk", "provincia", "gc", "pago", "m_fuente", "carga", "recaudado"]


def _mes_de_nombre(nombre: str) -> tuple[int, int] | None:
    """'BDD_Recaudación_Ago26.csv' -> (2026, 8); None si no calza."""
    import re
    hallado = re.search(r"_(Ene|Feb|Mar|Abr|May|Jun|Jul|Ago|Sep|Oct|Nov|Dic)(\d{2})",
                        nombre, re.IGNORECASE)
    if not hallado:
        return None
    return 2000 + int(hallado.group(2)), MESES_ABR[hallado.group(1).lower()]


async def _cargar_recaudacion_carpeta(carpeta: str) -> None:
    archivos = sorted(Path(carpeta).glob("BDD_Recauda*.csv"))
    if not archivos:
        raise click.ClickException(f"No hay CSV BDD_Recaudación_* en {carpeta}")
    con = await asyncpg.connect(PG_DSN)
    total = 0
    try:
        for ruta in archivos:
            anio_mes = _mes_de_nombre(ruta.name)
            if not anio_mes:
                click.echo(f"  [OMITIDO] {ruta.name}: no se deduce el mes del nombre")
                continue
            anio, mes = anio_mes
            async with con.transaction():
                await con.execute(
                    "CREATE TEMP TABLE stg_rec ("
                    + ", ".join(f"{c} TEXT" for c in _COLUMNAS_REC) + ") ON COMMIT DROP")
                with open(ruta, "rb") as fh:  # la tilde del nombre no molesta en Python
                    await con.copy_to_table("stg_rec", source=fh, format="csv", header=True)
                await con.execute(
                    "DELETE FROM visordg.recaudacion_raw "
                    "WHERE date_trunc('month', fecha) = make_date($1, $2, 1)", anio, mes)
                await con.execute(
                    """INSERT INTO visordg.recaudacion_raw (""" + ", ".join(_COLUMNAS_REC) + """)
                       SELECT ae_codigo_familia, ae_codigo_grupo, cod_n6,
                              to_date(fecha, 'YYYYMMDD'), NULLIF(impuesto_pk, '')::int,
                              provincia, gc, pago, m_fuente, carga,
                              COALESCE(NULLIF(replace(replace(recaudado, '.', ''), ',', '.'), '')::numeric, 0)
                       FROM stg_rec WHERE fecha ~ '^\\d{8}$'""")
                filas = await con.fetchval("SELECT COUNT(*) FROM stg_rec")
                await registrar_carga(con, "recaudacion", ruta.name, filas, "OK")
            total += filas
            click.echo(f"  {ruta.name}: {filas} filas -> {anio}-{mes:02d} (mes reemplazado)")
    finally:
        await con.close()
    click.echo(f"Recaudación: {total} filas cargadas desde {carpeta}. "
               "Ahora corre: pdm run refrescar")


@click.group()
def cli() -> None:
    """Cargas de archivos del visor gerencial."""
    asyncio.run(asegurar_esquema())   # estructura al día antes de cualquier comando


# Opciones comunes de los comandos por fuente
OPCION_ORIGEN = click.option("--origen", type=click.Choice(ORIGENES), default=None,
                             help="Fuerza el origen (por defecto: [fuentes].origen del settings)")
ARG_CARPETA = click.argument("carpeta", required=False, type=click.Path(exists=True, file_okay=False))


@cli.command()
@click.argument("carpeta", type=click.Path(exists=True, file_okay=False))
def recaudacion(carpeta: str) -> None:
    """Carga TODOS los BDD_Recaudación_*.csv de una carpeta (un archivo por mes)."""
    asyncio.run(_cargar_recaudacion_carpeta(carpeta))


@cli.command()
@click.argument("archivo", required=False, type=click.Path(exists=True))
@OPCION_ORIGEN
def catalogo(archivo: str | None, origen: str | None) -> None:
    """Carga las 4 pestañas de Catalogo_Recaudación.xlsx (ruta explícita o la del origen)."""
    if not archivo:
        archivo = str(base_origen(origen) / SETTINGS["fuentes"]["archivos"]["catalogo"])
    asyncio.run(_cargar_catalogo(archivo))


# ------------------------------------------------------------------
# NUEVA ESTRUCTURA DE CARPETAS (17/09/2026)
# Cada carpeta trae el archivo BASE (con lo último acumulado) y
# respaldos con número al final (...1.xls, ...12.xlsx). Se carga
# SIEMPRE el archivo base: el de nombre más corto (sin sufijo de
# número); a empate, el más reciente.
# ------------------------------------------------------------------

def _elegir_base(carpeta: str, patron: str) -> Path:
    """Devuelve el archivo base (sin número final) de una carpeta."""
    candidatos = sorted(Path(carpeta).glob(patron))
    if not candidatos:
        raise click.ClickException(f"No se encontró '{patron}' en {carpeta}")
    return min(candidatos, key=lambda c: (len(c.stem), -c.stat().st_mtime))


def _ec_num(valor) -> float:
    """Monto a float, tolerante al formato del archivo.

    Formato ecuatoriano (el habitual): '1.686.706,50' -> 1686706.5 ; '18.284' -> 18284
    Punto decimal (exportes de otros sistemas): '1234.56' -> 1234.56 ; '7560.00' -> 7560.0
    Regla sin coma: un punto seguido de EXACTAMENTE 3 dígitos (o varios puntos)
    es separador de miles; si no, es punto decimal. Antes todo punto se trataba
    como miles y '1234.56' se leía como 123456 (100 veces más) sin avisar.
    """
    if valor is None or (isinstance(valor, float) and pd.isna(valor)):
        return 0.0
    if isinstance(valor, (int, float)) and not isinstance(valor, bool):
        return float(valor)
    texto = str(valor).replace("$", "").replace(" ", "").strip()
    if not texto:
        return 0.0
    if "," in texto:                       # coma presente: coma decimal, puntos de miles
        texto = texto.replace(".", "").replace(",", ".")
    elif texto.count(".") == 1 and len(texto.split(".")[1]) != 3:
        pass                               # un solo punto que no agrupa 3 dígitos: decimal
    else:
        texto = texto.replace(".", "")     # '18.284', '1.234.567': miles
    try:
        return float(texto)
    except ValueError:
        return 0.0


def _leer_csv(ruta: Path) -> pd.DataFrame:
    """CSV en UTF-8 (con o sin BOM); si trae caracteres latinos, cae a cp1252.

    sep=None + engine='python' hace que pandas DETECTE solo el delimitador
    (coma o punto y coma). Sin esto, CEL_2026.csv (separado por ';') se leía
    como UNA sola columna llamada 'Fecha;Provincia;Sector;Ventas', f.get('Fecha')
    devolvía None y TODAS sus filas se descartaban en silencio en la validación
    de fecha: por eso 2026 nunca entraba y el visor se quedaba en 2025.
    """
    raw = Path(ruta).read_bytes()
    for codificacion in ("utf-8-sig", "cp1252"):
        try:
            return pd.read_csv(StringIO(raw.decode(codificacion)),
                               dtype=str, sep=None, engine="python")
        except UnicodeDecodeError:
            continue
    return pd.read_csv(StringIO(raw.decode("cp1252", errors="replace")),
                       dtype=str, sep=None, engine="python")


def _avisar_descartes(archivo: str, filas: list, motivo: str) -> None:
    """Informa las filas que NO entran al visor (antes se omitían en silencio).
    Con esto, 'filas del Excel' = 'filas cargadas' + 'descartadas' siempre cuadra."""
    if filas:
        ejemplos = ", ".join(f"fila {n + 2}: {v!r}" for n, v in filas[:3])   # +2: encabezado y base 1
        click.echo(f"  [AVISO] {archivo}: {len(filas)} fila(s) descartada(s) por {motivo}. Ej.: {ejemplos}")


def _norm_col(nombre) -> str:
    """'Reporte_Presidencia', 'REPORTE PRESIDENCIA', 'Año' -> 'REPORTEPRESIDENCIA', 'ANO'.
    Sin tildes, sin espacios/guiones/_ y en mayúsculas: el encabezado puede variar
    entre archivos (p. ej. Reca_2025 vs Reca_2026) sin que se pierda la columna."""
    txt = unicodedata.normalize("NFKD", str(nombre)).encode("ascii", "ignore").decode()
    return re.sub(r"[^A-Z0-9]", "", txt.upper())


def _columna(frame: pd.DataFrame, *alias: str) -> str | None:
    """Nombre REAL de la primera columna del frame que calce con algún alias."""
    reales = {_norm_col(c): c for c in frame.columns}
    return next((reales[_norm_col(a)] for a in alias if _norm_col(a) in reales), None)


# Alias aceptados por columna de Reca_*.csv (se comparan normalizados)
COLUMNAS_RECAUDACION = {
    "anio":      ("AÑO", "ANIO", "YEAR"),
    "mes":       ("MES", "MONTH"),
    "dia":       ("DIA", "DAY"),
    "sector":    ("SECTOR", "SECTOR_ECONOMICO"),
    "provincia": ("Provincia",),
    "impuesto":  ("Reporte_Presidencia", "IMPUESTO", "IMPUESTOS", "DESCRIPCION_IMPUESTO", "TIPO_IMPUESTO"),
    "recaudado": ("RECAUDADO", "RECAUDACION", "VALOR"),
}


def _filas_recaudacion(ruta: Path) -> list[tuple]:
    """Un Reca_YYYY.csv -> registros (fecha, sector, provincia, impuesto, recaudado).

    Las columnas se ubican por nombre NORMALIZADO (sin tildes/espacios/_ ni
    mayúsculas) y con alias. Antes se buscaban con el nombre exacto: si un año
    traía p. ej. 'REPORTE_PRESIDENCIA', f.get('Reporte_Presidencia') daba None
    y TODO el impuesto de ese año quedaba vacío en silencio (P4 por impuesto en 0).
    Ahora, si falta una columna o el impuesto llega vacío en más del 5% de las
    filas, la carga lo AVISA mostrando los encabezados reales del archivo.
    """
    frame = _leer_csv(ruta)
    frame.columns = [str(c).strip() for c in frame.columns]
    col = {k: _columna(frame, *alias) for k, alias in COLUMNAS_RECAUDACION.items()}
    faltan = [k for k, v in col.items() if v is None]
    if faltan:
        click.echo(f"  [AVISO] {ruta.name}: no se encontró la(s) columna(s) {', '.join(faltan)}. "
                   f"Encabezados del archivo: {list(frame.columns)}")

    def celda(f, clave):
        return f.get(col[clave]) if col[clave] else None

    registros, malas = [], []
    for n, f in frame.iterrows():
        try:
            fecha = date(int(celda(f, "anio")), int(celda(f, "mes")), int(celda(f, "dia")))
        except (KeyError, TypeError, ValueError):
            malas.append((n, f"{celda(f, 'anio')}-{celda(f, 'mes')}-{celda(f, 'dia')}"))
            continue
        registros.append((
            fecha,
            texto(celda(f, "sector")),
            texto(celda(f, "provincia")),
            texto(celda(f, "impuesto")),
            _ec_num(celda(f, "recaudado"))))
    _avisar_descartes(ruta.name, malas, "fecha inválida (AÑO/MES/DIA)")
    sin_impuesto = sum(1 for r in registros if not r[3])
    if registros and sin_impuesto / len(registros) > 0.05:
        click.echo(f"  [AVISO] {ruta.name}: {sin_impuesto:,} de {len(registros):,} fila(s) SIN impuesto "
                   f"(columna {col['impuesto'] or 'no encontrada'}). P4 'Por impuesto' saldrá incompleta; "
                   f"revisar el archivo con el área.".replace(",", "."))
    return registros


def _filas_ventas(ruta: Path) -> list[tuple]:
    """Un CEL_YYYY.csv -> registros (fecha, provincia, sector, ventas)."""
    frame = _leer_csv(ruta)
    frame.columns = [str(c).strip() for c in frame.columns]
    registros, malas = [], []
    for n, f in frame.iterrows():
        fecha_txt = str(f.get("Fecha") or "").strip()
        try:
            if not re.fullmatch(r"\d{8}", fecha_txt):
                raise ValueError
            fecha = date(int(fecha_txt[:4]), int(fecha_txt[4:6]), int(fecha_txt[6:8]))
        except ValueError:
            malas.append((n, fecha_txt))
            continue
        registros.append((
            fecha,
            str(f.get("Provincia") or "").strip(),
            str(f.get("Sector") or "").strip(),
            _ec_num(f.get("Ventas"))))
    _avisar_descartes(ruta.name, malas, "fecha inválida (se espera AAAAMMDD)")
    return registros


async def _reemplazar_tabla(tabla: str, fuente: str, columnas: list[str],
                            por_archivo: list[tuple[Path, list]]) -> int:
    """Reemplazo total ATÓMICO: primero se leyó todo; aquí DELETE + COPY en una transacción.

    Si algún archivo trae menos de MIN_FILAS_VALIDAS (p. ej. separador mal
    detectado, como pasó con CEL_2026), se aborta SIN tocar la tabla.
    """
    for ruta, registros in por_archivo:
        if len(registros) < MIN_FILAS_VALIDAS:
            raise click.ClickException(
                f"{ruta.name}: solo {len(registros)} filas válidas; no se tocó {tabla} (revisar el archivo)")
    con = await asyncpg.connect(PG_DSN)
    try:
        async with con.transaction():
            await con.execute(f"DELETE FROM visordg.{tabla}")
            for ruta, registros in por_archivo:
                await con.copy_records_to_table(tabla, schema_name="visordg", records=registros, columns=columnas)
                # año del archivo = año de sus fechas (CEL_2026 -> 2026); fecha es la 1a columna
                await registrar_carga(con, fuente, ruta.name, len(registros), "OK",
                                      ruta=ruta, anio=max(r[0].year for r in registros))
        await con.execute(f"ANALYZE visordg.{tabla}")
    finally:
        await con.close()
    return sum(len(r) for _, r in por_archivo)


async def _cargar_recaudacion_dos(carpeta: str) -> None:
    """Reca_2025.csv + Reca_2026.csv -> recaudacion_raw_dos (reemplazo total atómico)."""
    archivos = sorted(Path(carpeta).glob("Reca_*.csv"))
    if not archivos:
        raise click.ClickException(f"No hay archivos 'Reca_*.csv' en {carpeta}")
    por_archivo = [(r, _filas_recaudacion(r)) for r in archivos]
    total = await _reemplazar_tabla("recaudacion_raw_dos", "recaudacion_dos",
                                    ["fecha", "sector", "provincia", "impuesto", "recaudado"], por_archivo)
    click.echo(f"Recaudación (nueva): {total} filas desde {len(archivos)} archivo(s), reemplazo total")


async def _cargar_ventas_dos(carpeta: str) -> None:
    """CEL_2024/2025/2026.csv -> ventas_raw_dos (reemplazo total atómico)."""
    archivos = sorted(Path(carpeta).glob("CEL_*.csv"))
    if not archivos:
        raise click.ClickException(f"No hay archivos 'CEL_*.csv' en {carpeta}")
    por_archivo = [(r, _filas_ventas(r)) for r in archivos]
    total = await _reemplazar_tabla("ventas_raw_dos", "ventas_dos",
                                    ["fecha", "provincia", "sector", "ventas"], por_archivo)
    click.echo(f"Ventas (nueva): {total} filas desde {len(archivos)} archivo(s), reemplazo total")


@cli.command()
@click.argument("archivo", type=click.Path(exists=True))
def capacitaciones(archivo: str) -> None:
    """Carga Hoja1 de Capacitaciones enero a sep 2026.xls."""
    asyncio.run(_cargar_capacitaciones(archivo))


# ------------------------------------------------------------------
# ORÍGENES (local | fileserver) y resolución de carpetas/archivos
# ------------------------------------------------------------------
def base_origen(origen: str | None = None) -> Path:
    """Carpeta raíz del origen pedido (o el por defecto del settings)."""
    fuentes = SETTINGS["fuentes"]
    origen = origen or fuentes.get("origen", "local")
    if origen not in ORIGENES:
        raise click.ClickException(f"Origen inválido '{origen}': use {' | '.join(ORIGENES)}")
    base = Path(fuentes[origen])
    if not base.is_dir():
        pista = " (¿fileserver o red disponibles?)" if origen == "fileserver" else ""
        raise click.ClickException(f"Origen '{origen}' no accesible: {base}{pista}")
    return base


def carpetas_fuente(base: Path, fuente: str) -> list[Path]:
    """Carpetas candidatas de una fuente que EXISTEN, en el orden del settings.

    Ej.: brigadas = ["Brigadas", "Brigada"] -> busca en ambas; los archivos
    se toman de la primera carpeta que los tenga.
    """
    nombres = SETTINGS["fuentes"]["carpetas"][fuente]
    nombres = [nombres] if isinstance(nombres, str) else list(nombres)
    existentes = [base / n for n in nombres if (base / n).is_dir()]
    if not existentes:
        raise click.ClickException(f"No existe carpeta de {fuente} en {base}: {', '.join(nombres)}")
    return existentes


def buscar_archivo(carpetas: list[Path], patron: str) -> Path | None:
    """Archivo que calce el patrón en CUALQUIERA de las carpetas; si hay varios, el más reciente.

    Se mira en todas (no solo en la primera) para no quedarse con una copia vieja:
    si el mismo archivo está en "Brigadas" y en "Brigada", gana el modificado último.
    Ignora los temporales de Office (~$...) que aparecen con el Excel abierto.
    """
    hallados = [p for carpeta in carpetas for p in carpeta.glob(patron)
                if p.is_file() and not p.name.startswith("~$")]
    return max(hallados, key=lambda p: p.stat().st_mtime) if hallados else None


async def anio_vigente() -> int:
    """Año actual del visor: [periodo].anio_actual si es != 0; si no, el del último dato de ventas."""
    fijo = int(SETTINGS.get("periodo", {}).get("anio_actual", 0) or 0)
    if fijo:
        return fijo
    con = await asyncpg.connect(PG_DSN)
    try:
        anio = await con.fetchval("SELECT EXTRACT(YEAR FROM max(fecha))::int FROM visordg.ventas_raw_dos")
    finally:
        await con.close()
    return anio or date.today().year


async def _cargar_por_anio(carpetas: list[Path], fuente: str, cargador) -> None:
    """Archivo del año actual (obligatorio) + del año previo (opcional)."""
    archivos = SETTINGS["fuentes"]["archivos"]
    anio = await anio_vigente()
    for anio_archivo, clave, obligatorio in ((anio, f"{fuente}_actual", True),
                                             (anio - 1, f"{fuente}_previo", False)):
        patron = archivos[clave].format(anio=anio_archivo)
        ruta = buscar_archivo(carpetas, patron)
        if ruta is None:
            msg = f"{fuente} {anio_archivo}: no se encontró '{patron}' en {', '.join(map(str, carpetas))}"
            if obligatorio:
                raise click.ClickException(msg)
            click.echo(f"  [OMITIDO] {msg}")
            continue
        click.echo(f"  {fuente} {anio_archivo}: {ruta.name}")
        await cargador(str(ruta), anio_archivo)


async def cargar_brigadas_fuente(carpetas: list[Path]) -> None:
    """Brigadas año actual + previo; cada archivo reemplaza solo su año."""
    await _cargar_por_anio(carpetas, "brigadas", _cargar_brigadas)


async def cargar_capacitaciones_fuente(carpetas: list[Path]) -> None:
    """Capacitaciones año actual + previo; el año real sale de las fechas del archivo."""
    async def _cap(ruta: str, _anio: int) -> None:
        await _cargar_capacitaciones(ruta)
    await _cargar_por_anio(carpetas, "capacitaciones", _cap)


# Las 4 fuentes, EN ESTE ORDEN: ventas va primero porque de su último dato
# sale el año vigente de brigadas/capacitaciones.
FUENTES = ("ventas", "recaudacion", "brigadas", "capacitaciones")


async def cargar_todo(origen: str | None = None, fuentes: tuple[str, ...] | list[str] | None = None) -> dict[str, str]:
    """Carga las fuentes pedidas (por defecto las 4) del origen dado. Una fuente que
    falla NO frena a las demás (cada carga es atómica: si falla, conserva sus datos).

    fuentes: subconjunto de FUENTES (p. ej. ["ventas"]); se respeta el orden de FUENTES.
    """
    base = base_origen(origen)
    cargadores = {
        "ventas": lambda c: _cargar_ventas_dos(str(c[0])),
        "recaudacion": lambda c: _cargar_recaudacion_dos(str(c[0])),
        "brigadas": cargar_brigadas_fuente,
        "capacitaciones": cargar_capacitaciones_fuente,
    }
    pedidas = set(fuentes or FUENTES)
    pasos = [(f, cargadores[f]) for f in FUENTES if f in pedidas]
    resultado = {}
    for fuente, cargar in pasos:
        try:
            click.echo(f"[{fuente}]")
            await cargar(carpetas_fuente(base, fuente))
            resultado[fuente] = "ok"
        except Exception as exc:  # noqa: BLE001 - se informa y se sigue con la siguiente
            click.echo(f"  [ERROR] {fuente}: {exc}")
            resultado[fuente] = f"error: {exc}"
    return resultado


# ------------------------------------------------------------------
# Refresco SQL con credenciales del settings
# ------------------------------------------------------------------
def variables_sql() -> dict[str, str]:
    """Variables psql que salen del settings.toml (nada fijo en los .sql):
      :anio_actual -> [periodo].anio_actual (0 = automático en el SQL)
      :meta        -> [metas].meta_anual_recaudacion (millones USD; 0 = sin meta)
    """
    anio = int(SETTINGS.get("periodo", {}).get("anio_actual", 0) or 0)
    meta = float(SETTINGS.get("metas", {}).get("meta_anual_recaudacion", 0) or 0)
    return {"anio_actual": str(anio), "meta": f"{meta:g}"}


def correr_sql(nombre: str, mostrar: bool = False) -> None:
    """Ejecuta sql/<nombre> con psql; ON_ERROR_STOP=1 -> código != 0 ante el primer error.

    Pasa las variables de variables_sql(). mostrar=True imprime la salida de psql
    (para scripts de consulta como auditoria_panel.sql).
    """
    psql = shutil.which("psql")
    if not psql:
        raise RuntimeError("psql no está en el PATH")
    db = SETTINGS["database"]
    entorno = os.environ.copy()
    entorno["PGPASSWORD"] = str(db["password"])  # solo para el proceso hijo
    entorno["PGCLIENTENCODING"] = "UTF8"          # salida en UTF-8 (tildes, ✓) sin depender de la consola
    args = [psql, "-v", "ON_ERROR_STOP=1"]
    for clave, valor in variables_sql().items():
        args += ["-v", f"{clave}={valor}"]
    args += [] if mostrar else ["-q"]
    args += ["-h", str(db["host"]), "-p", str(db["port"]), "-U", str(db["user"]), "-d", str(db["name"]),
             "-f", str(RUTA_SQL / nombre)]
    res = subprocess.run(args, env=entorno, capture_output=True, text=True,
                         encoding="utf-8", errors="replace", check=False)
    if mostrar and res.stdout:
        click.echo(res.stdout)
    if res.returncode != 0:
        raise RuntimeError(f"{nombre} falló: {res.stderr.strip()[-500:]}")


# El 05 absorbió al 03 (archivado en sql/_inactivos): un solo refresco.
SCRIPTS_REFRESCO = ("05_refrescar_dos.sql",)


def refrescar_sql() -> None:
    """Recalcula históricos, mes corriente y marca de agua."""
    for script in SCRIPTS_REFRESCO:
        correr_sql(script)
        click.echo(f"  {script}: OK")


# ------------------------------------------------------------------
# Comandos CLI
# ------------------------------------------------------------------


def _carpetas_cli(carpeta: str | None, origen: str | None, fuente: str) -> list[Path]:
    """Carpeta explícita (compatibilidad con el runbook) o la del origen configurado."""
    return [Path(carpeta)] if carpeta else carpetas_fuente(base_origen(origen), fuente)


@cli.command()
@OPCION_ORIGEN
@click.option("--sin-refresco", is_flag=True, help="Solo carga; no corre el refresco")
def todo(origen: str | None, sin_refresco: bool) -> None:
    """Carga ventas, recaudación, brigadas y capacitaciones, y refresca."""
    resultado = asyncio.run(cargar_todo(origen))
    if not sin_refresco:
        click.echo("[refresco]")
        refrescar_sql()
    click.echo("Resumen: " + " · ".join(f"{k}={v}" for k, v in resultado.items()))
    if any(v != "ok" for v in resultado.values()):
        raise SystemExit(1)


# ------------------------------------------------------------------
# VERIFICACIÓN: archivo fuente vs base, mes a mes (solo lectura)
# ------------------------------------------------------------------
def _tabla_verificacion(titulo: str, filas: list[tuple], columnas: list[str], tolerancia: float) -> int:
    """Imprime la comparación y devuelve cuántos meses NO cuadran.
    filas: (etiqueta, valor_archivo, valor_base, [extra...])."""
    click.echo(f"\n=== {titulo} ===")
    click.echo("  " + " | ".join(c.rjust(18) if i else c.ljust(8) for i, c in enumerate(columnas)))
    malos = 0
    for etiqueta, archivo, base, *extra in filas:
        ok = abs((archivo or 0) - (base or 0)) <= tolerancia
        malos += 0 if ok else 1
        celdas = [f"{v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".") if isinstance(v, float)
                  else f"{v:,}".replace(",", ".") if isinstance(v, int) else str(v)
                  for v in (archivo, base, *extra)]
        click.echo(f"  {etiqueta:<8} | " + " | ".join(c.rjust(18) for c in celdas) + ("   ✓" if ok else "   ✗ NO CUADRA"))
    return malos


async def _base(sql: str, *args) -> list:
    con = await asyncpg.connect(PG_DSN)
    try:
        return await con.fetch(sql, *args)
    finally:
        await con.close()


async def _verificar_csv(carpeta: Path, patron: str, tabla: str, col_valor: str, lector) -> int:
    """CSV (ventas/recaudación) vs tabla cruda: filas y suma por año-mes."""
    archivo = {}
    for ruta in sorted(carpeta.glob(patron)):
        for fecha, *_, valor in lector(ruta):
            k = (fecha.year, fecha.month)
            n, v = archivo.get(k, (0, 0.0))
            archivo[k] = (n + 1, v + float(valor))
    base = {(r["a"], r["m"]): (r["n"], float(r["v"])) for r in await _base(
        f"""SELECT EXTRACT(YEAR FROM fecha)::int a, EXTRACT(MONTH FROM fecha)::int m,
                   COUNT(*)::int n, SUM({col_valor}) v FROM visordg.{tabla} GROUP BY 1, 2""")}
    claves = sorted(set(archivo) | set(base))
    filas = [(f"{a}-{m:02d}", archivo.get((a, m), (0, 0.0))[1], base.get((a, m), (0, 0.0))[1],
              archivo.get((a, m), (0, 0))[0], base.get((a, m), (0, 0))[0]) for a, m in claves]
    malos = _tabla_verificacion(f"{tabla}: archivos {patron} vs base", filas,
                                ["año-mes", "suma archivo", "suma base", "filas archivo", "filas base"], 0.01)
    # las filas también deben coincidir
    malos += sum(1 for f in filas if f[3] != f[4])
    return malos


async def _verificar_brigadas(carpetas: list[Path]) -> int:
    """Por archivo y pestaña: detalle del Excel vs fila 'Total general' del Excel vs base."""
    archivos, anio = SETTINGS["fuentes"]["archivos"], await anio_vigente()
    malos = 0
    for anio_arch, clave in ((anio, "brigadas_actual"), (anio - 1, "brigadas_previo")):
        ruta = buscar_archivo(carpetas, archivos[clave].format(anio=anio_arch))
        if not ruta:
            click.echo(f"\n(brigadas {anio_arch}: sin archivo, se omite)")
            continue
        hojas = pd.ExcelFile(ruta).sheet_names
        for tabla, campo, hoja in (
                ("brigadas_eventos", "eventos",
                 next((h for h in hojas if "eventos" in h.lower()), None) or next((h for h in hojas if "total" in h.lower()), None)),
                ("brigadas_atendidos", "atendidos", next((h for h in hojas if "atendidos" in h.lower()), None))):
            if not hoja:
                continue
            total_excel = {}
            detalle = {}
            for *_, mes, valor in _despivotar_brigadas(str(ruta), hoja, anio_arch, con_agencia=(campo == "atendidos"),
                                                       control=total_excel):
                detalle[mes] = detalle.get(mes, 0) + valor
            base = {r["mes"]: r["v"] for r in await _base(
                f"SELECT mes, SUM({campo})::int v FROM visordg.{tabla} WHERE anio = $1 GROUP BY mes", anio_arch)}
            filas = [(f"{anio_arch}-{m:02d}", detalle.get(m, 0), base.get(m, 0),
                      total_excel.get(m, "—")) for m in sorted(set(detalle) | set(base))]
            malos += _tabla_verificacion(f"{campo} {anio_arch}: {ruta.name} [{hoja}] vs base", filas,
                                         ["año-mes", "detalle Excel", "base", "Total general Excel"], 0)
            dif_total = [f"{a}" for a, d, _, t in filas if isinstance(t, int) and t != d]
            if dif_total:
                click.echo(f"  [AVISO] En el Excel, la fila 'Total general' no coincide con la suma de sus "
                           f"provincias en: {', '.join(dif_total)} (revisar el archivo con el área)")
    return malos


async def _verificar_capacitaciones(carpetas: list[Path]) -> int:
    """Eventos (filas) y capacitados por año-mes: archivos vs base."""
    archivos, anio = SETTINGS["fuentes"]["archivos"], await anio_vigente()
    archivo = {}
    for anio_arch, clave in ((anio, "capacitaciones_actual"), (anio - 1, "capacitaciones_previo")):
        ruta = buscar_archivo(carpetas, archivos[clave].format(anio=anio_arch))
        if not ruta:
            continue
        hojas = pd.ExcelFile(ruta).sheet_names
        hoja = "Hoja1" if "Hoja1" in hojas else ("Sheet1" if "Sheet1" in hojas else hojas[0])
        frame = leer_hoja(str(ruta), hoja, encabezado=fila_encabezado(str(ruta), hoja, "ZONAL"))
        frame.columns = [c.strip().lower().replace(" ", "_") for c in frame.columns]
        col_fecha = next((c for c in frame.columns if "fecha" in c), "fecha_capacitacion")
        col_total = next((c for c in frame.columns if "capacitados" in c), None)
        for _, f in frame.iterrows():
            if " ".join(texto(c) for c in f.values if texto(c)).upper().startswith("TOTAL"):
                continue   # pie del Excel (TOTAL / TOTAL EVENTOS): control, no dato
            fecha = fecha_robusta(f.get(col_fecha))
            if fecha is None:
                continue
            k = (fecha.year, fecha.month)
            n, c = archivo.get(k, (0, 0))
            archivo[k] = (n + 1, c + (entero(f.get(col_total)) if col_total else 0))
    base = {(r["a"], r["m"]): (r["n"], r["c"]) for r in await _base(
        """SELECT EXTRACT(YEAR FROM fecha)::int a, EXTRACT(MONTH FROM fecha)::int m,
                  COUNT(*)::int n, SUM(total_capacitados)::int c FROM visordg.capacitaciones_raw GROUP BY 1, 2""")}
    claves = sorted(set(archivo) | set(base))
    malos = _tabla_verificacion("capacitaciones (EVENTOS = filas) vs base", [
        (f"{a}-{m:02d}", archivo.get((a, m), (0, 0))[0], base.get((a, m), (0, 0))[0]) for a, m in claves],
        ["año-mes", "eventos archivo", "eventos base"], 0)
    malos += _tabla_verificacion("capacitaciones (CAPACITADOS) vs base", [
        (f"{a}-{m:02d}", archivo.get((a, m), (0, 0))[1], base.get((a, m), (0, 0))[1]) for a, m in claves],
        ["año-mes", "capac. archivo", "capac. base"], 0)
    return malos


OPCION_SOLO = click.option("--solo", "solo", type=click.Choice(FUENTES), multiple=True,
                           help="Solo esta(s) fuente(s); se puede repetir: --solo ventas --solo brigadas")


@cli.command()
@OPCION_ORIGEN
@OPCION_SOLO
def verificar(origen: str | None, solo: tuple[str, ...]) -> None:
    """Compara, mes a mes, los archivos fuente contra lo cargado en la base (solo lectura).

    Si todo marca ✓, lo que muestra el visor es exactamente lo que suman los
    archivos. En brigadas cruza además contra la fila 'Total general' del Excel.
    Con --solo se verifica solo esa(s) fuente(s).
    """
    pedidas = set(solo or FUENTES)

    async def _todo() -> int:
        base = base_origen(origen)
        malos = 0
        if "ventas" in pedidas:
            malos += await _verificar_csv(carpetas_fuente(base, "ventas")[0], "CEL_*.csv",
                                          "ventas_raw_dos", "ventas", _filas_ventas)
        if "recaudacion" in pedidas:
            malos += await _verificar_csv(carpetas_fuente(base, "recaudacion")[0], "Reca_*.csv",
                                          "recaudacion_raw_dos", "recaudado", _filas_recaudacion)
        if "brigadas" in pedidas:
            malos += await _verificar_brigadas(carpetas_fuente(base, "brigadas"))
        if "capacitaciones" in pedidas:
            malos += await _verificar_capacitaciones(carpetas_fuente(base, "capacitaciones"))
        return malos
    malos = asyncio.run(_todo())
    click.echo("\n" + ("RESULTADO: todo cuadra ✓ (archivo = base en todos los meses)" if not malos
                       else f"RESULTADO: {malos} diferencia(s) ✗ — si recién se actualizó un archivo, "
                            "recargar esa fuente (pdm run cargar solo <fuente>) y verificar de nuevo"))
    if malos:
        raise SystemExit(1)


@cli.command()
def refrescar() -> None:
    """Corre el refresco único (05_refrescar_dos.sql)."""
    refrescar_sql()


@cli.command()
@click.argument("fuentes", nargs=-1, required=True, type=click.Choice(FUENTES))
@OPCION_ORIGEN
@click.option("--sin-refresco", is_flag=True, help="Solo carga; no corre el refresco")
def solo(fuentes: tuple[str, ...], origen: str | None, sin_refresco: bool) -> None:
    """Carga SOLO la(s) fuente(s) indicada(s) y refresca (igual que 'todo', pero parcial).

    \b
    Ejemplos:
      pdm run cargar solo ventas --origen local
      pdm run cargar solo brigadas capacitaciones
    Atajos: pdm run cargar-ventas | cargar-recaudacion | cargar-brigadas | cargar-capacitaciones
    """
    resultado = asyncio.run(cargar_todo(origen, fuentes))
    if not sin_refresco:
        click.echo("[refresco]")
        refrescar_sql()
    click.echo("Resumen: " + " · ".join(f"{k}={v}" for k, v in resultado.items()))
    if any(v != "ok" for v in resultado.values()):
        raise SystemExit(1)


@cli.command()
def auditar() -> None:
    """Corre sql/auditoria_panel.sql (solo lectura) con año y meta del settings.toml."""
    correr_sql("auditoria_panel.sql", mostrar=True)


@cli.command("capacitaciones-dos")
@ARG_CARPETA
@OPCION_ORIGEN
def capacitaciones_dos(carpeta: str | None, origen: str | None) -> None:
    """Capacitaciones año actual + previo."""
    asyncio.run(cargar_capacitaciones_fuente(_carpetas_cli(carpeta, origen, "capacitaciones")))


@cli.command("brigadas-dos")
@ARG_CARPETA
@OPCION_ORIGEN
def brigadas_dos(carpeta: str | None, origen: str | None) -> None:
    """Brigadas año actual + previo (busca en todas las carpetas configuradas)."""
    asyncio.run(cargar_brigadas_fuente(_carpetas_cli(carpeta, origen, "brigadas")))


@cli.command("recaudacion-dos")
@ARG_CARPETA
@OPCION_ORIGEN
def recaudacion_dos(carpeta: str | None, origen: str | None) -> None:
    """Todos los Reca_*.csv -> recaudacion_raw_dos (reemplazo total atómico)."""
    asyncio.run(_cargar_recaudacion_dos(str(_carpetas_cli(carpeta, origen, "recaudacion")[0])))


@cli.command("ventas-dos")
@ARG_CARPETA
@OPCION_ORIGEN
def ventas_dos(carpeta: str | None, origen: str | None) -> None:
    """Todos los CEL_*.csv -> ventas_raw_dos (reemplazo total atómico)."""
    asyncio.run(_cargar_ventas_dos(str(_carpetas_cli(carpeta, origen, "ventas")[0])))


@cli.command()
@click.argument("archivo", type=click.Path(exists=True))
@click.argument("anio", type=int, required=False, default=None)
def brigadas(archivo: str, anio: int | None) -> None:
    """Carga Atendidos_brigadas de Atenciones_brigadas.xlsx.

    ANIO es opcional: si no se pasa, se usa el año vigente del visor
    ([periodo].anio_actual o el del último dato de ventas). Nada fijo.
    """
    async def _correr() -> None:
        await _cargar_brigadas(archivo, anio or await anio_vigente())
    asyncio.run(_correr())


if __name__ == "__main__":
    cli()
