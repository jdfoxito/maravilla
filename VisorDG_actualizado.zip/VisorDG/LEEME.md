# VisorDG — Visor Gerencial SRI
> **Actualización:** 27/09/2026  
> **Entorno:** Producción Institucional — SRI · Dirección General

Panel ejecutivo para proyectar en monitores y TVs las métricas clave de la
gestión institucional: ventas (facturación electrónica CEL), recaudación,
brigadas y capacitaciones. Rota 6 pantallas de forma continua y se actualiza
solo cuando entran datos nuevos, sin intervención en el TV.

Índice
1. Ficha técnica y arquitectura
2. Regla de oro de las cargas
3. Runbook (operación diaria)
4. Configuración (`config/settings.toml`)
5. Atajos en pantalla
6. Estructura de archivos
7. Tablas y qué lee cada pantalla
8. Criterios de cálculo
9. Seguridad
10. Cambios de esta ronda (qué desplegar)
11. Pendientes de estabilidad
12. Objetos a borrar (limpieza)
13. Historia — causa raíz "2026 no entraba"

---

## 1. Ficha técnica y arquitectura

| Capa | Tecnología | Detalle |
|---|---|---|
| Base de datos | PostgreSQL 18 | Base `detalles`, esquema `visordg` (datos) y `seg` (seguridad). Tablas relacionales con índices por fecha y provincia. |
| Backend | Python 3.14 + PDM | Archivos planos en `app/backend/` (`main.py`, `cargas.py`, `config.py`). |
| API | FastAPI + asyncpg | `GET /api/v1/tv-data` entrega un paquete único con todo lo que dibujan las 5 pantallas. P2–P5 se calculan **en vivo** desde las tablas crudas. |
| Sincronización | WebSocket `/api/v1/stream` | Canal servidor → pantallas. Al terminar una recarga el servidor envía `refresh` y los TV se recargan solos. Si el WebSocket cae, el TV sondea cada `sondeo_segundos`. |
| Frontend | HTML + jQuery + ECharts | Estático en `app/frontend/dist/`. |
| Red | Nginx (proxy inverso) | Intranet: `https://10.21.178.245/dashboard/`. |
| Tareas | Demonio interno | Refresco automático todos los días a las **23:00** (hora del servidor). |
| Configuración | `config/settings.toml` | **Única** fuente de parámetros y credenciales. No se usan variables de entorno. |

---

## 2. Regla de oro de las cargas

Las fuentes que entregan las áreas son **acumulativas** (cada archivo trae el
año completo hasta la fecha). Para no duplicar montos, **cada carga
REEMPLAZA** lo anterior; esto ya lo hace el cargador, dentro de una
transacción:

| Fuente | Qué reemplaza |
|---|---|
| Ventas CEL (`CEL_*.csv`) | toda `ventas_raw_dos` |
| Recaudación (`Reca_*.csv`) | toda `recaudacion_raw_dos` |
| Brigadas (`Atenciones_brigadas*.xlsx`) | solo el **año** del archivo en `brigadas_eventos` / `brigadas_atendidos` |
| Capacitaciones (`Capacitaciones*.xls`) | solo los **años** que trae el archivo en `capacitaciones_raw` |

> ⚠️ **Ya NO se hace `TRUNCATE` manual antes de cargar.** Si se trunca a mano
> y el archivo viene roto, el visor queda vacío. Con el reemplazo atómico, si
> un archivo trae menos de 10 filas válidas (p. ej. separador mal detectado),
> la carga se cancela y **se conservan los datos anteriores**.

Después de cargar siempre se refresca: `pdm run refrescar` corre el **refresco
único** `05_refrescar_dos.sql`, que reconstruye históricos, mes corriente y
marca de agua (`pdm run cargar todo` ya lo incluye). El antiguo `03` quedó
absorbido por el `05` y está archivado.

**Sin migraciones manuales.** Los ajustes de estructura (columnas nuevas,
claves) los aplica el propio sistema, de forma idempotente y sin borrar datos:
la API al arrancar y la consola antes de cada comando `pdm run ...`.

Si el Excel de brigadas trae una provincia/mes repetida, la carga la **suma y
avisa** (`[AVISO] ... clave repetida`): revisar el archivo antes de dar el dato
por bueno.

---

## 3. Runbook (operación diaria)

Todos los comandos se corren desde la raíz del backend:
```bat
cd D:/SRI/Soluciones/DG/VisorDG/app/backend
```

### 🟢 CASO 1 — Recarga regular (lo habitual)
Llegaron archivos nuevos al fileserver o a la carpeta local.
```bat
pdm run cargar todo                    :: origen del settings (por defecto: fileserver)
pdm run cargar todo --origen local     :: o forzar la carpeta local para esta corrida
```
Carga las 4 fuentes, refresca y muestra un resumen:
`ventas=ok · recaudacion=ok · brigadas=ok · capacitaciones=ok`.
Si una fuente falla, **las demás igual se cargan**; la que falló conserva sus
datos anteriores y el comando termina con código 1.

Luego, en el TV: **Ctrl+F5** (las cargas por consola no avisan al WebSocket;
ver §11). No hace falta reiniciar el API: lee la base en vivo.

### 🟡 CASO 2 — Actualizar una sola fuente
```bat
pdm run cargar ventas-dos              :: carpeta según el origen del settings
pdm run cargar recaudacion-dos --origen local
pdm run cargar brigadas-dos
pdm run cargar capacitaciones-dos
pdm run cargar ventas-dos "D:/SRI/Soluciones/DG/VisorDG/data/input/Ventas CEL"   :: carpeta explícita
pdm run refrescar
```

### 🔵 CASO 3 — Recarga desde la pantalla (sin consola)
En el TV: **Shift+Alt+R** → usuario y clave de un perfil **ADMIN** → elegir
origen (el configurado, fileserver o local). Carga todo, refresca y los TV
se actualizan solos. Si alguna fuente falla, el aviso dice cuál ("Recarga
PARCIAL") y esa fuente conserva sus datos. Solo corre una recarga a la vez.

### 🔴 CASO 4 — Reconstrucción total desde cero
Cuando se corrompe la base o cambia la estructura (DDL) de las tablas.
1. Si hace falta recrear la base, hacerlo desde pgAdmin con codificación
   regional `Spanish_Ecuador.1252`.
2. Esquema y tablas:
```bat
psql -U postgres -d detalles -f D:/SRI/Soluciones/DG/VisorDG/sql/00_recrear.sql
psql -U postgres -d detalles -f D:/SRI/Soluciones/DG/VisorDG/sql/01_esquema_visordg.sql
psql -U postgres -d detalles -f D:/SRI/Soluciones/DG/VisorDG/sql/01c_tablas_dos.sql
```
3. Catálogo y datos:
```bat
pdm run cargar catalogo      :: toma Catalogo_Recaudación.xlsx de la raíz del origen
pdm run cargar todo
```
4. Reiniciar el API (`pdm run start`) y en los TV **Ctrl+F5** una vez.

### Verificar que el visor refleja exactamente los archivos
```bat
pdm run verificar                  :: origen del settings
pdm run verificar --origen local
```
Vuelve a leer cada archivo y compara **mes a mes** contra la base: filas y
suma en ventas y recaudación; eventos y capacitados en capacitaciones; y en
brigadas tres columnas: **detalle del Excel**, **base** y la fila **"Total
general" del propio Excel** (si esa fila no coincide con sus provincias, lo
avisa: es un error del archivo, no del visor). Termina con "todo cuadra ✓" o
lista los meses con diferencia (código de salida 1). Solo lectura.
Para explicar cada cifra del panel en SQL: `sql/auditoria_panel.sql`.

### Estructura esperada de cada archivo
| Fuente | Estructura | Filas de totales |
|---|---|---|
| Ventas `CEL_AAAA.csv` (año actual, −1 y −2) | encabezado directo `Fecha,Provincia,Sector,Ventas` (`,` o `;`) | no debe traer; si trae, se descarta con aviso |
| Recaudación `Reca_AAAA.csv` | encabezado directo `AÑO,MES,DIA,SECTOR,Provincia,Reporte_Presidencia,RECAUDADO` | no debe traer; si trae, se descarta con aviso |
| Brigadas `Atenciones_brigadas*.xlsx` | 2 pestañas (Atendidos / Eventos o "total"), títulos arriba y fila **Año AAAA**; el encabezado real (`Zona`, `Provincia`, [`Agencia`], meses) se detecta solo | fila **Total general** al pie: **no se carga**; se usa como control |
| Capacitaciones `Capacitaciones*.xls` | pestaña `Hoja1`, encabezado directo (`ZONAL, PROVINCIA, …, FECHA CAPACITACION, …, TOTAL CAPACITADOS …`) | filas **TOTAL** y **TOTAL EVENTOS :N** al pie: **no se cargan**; se usan como control |

**Controles al cargar:** la suma de provincias se coteja con el "Total
general" de cada pestaña de brigadas, y los eventos/capacitados cargados con
"TOTAL EVENTOS"/"TOTAL" de capacitaciones. Cada cotejo muestra ✓ o un aviso
con el mes que difiere. El total declarado queda en
`cargas_archivo.total_declarado` y en `hist_brigadas` / `hist_capacitaciones`
(`total_declarado`, por año). El **año** de brigadas lo manda la fila
"Año AAAA" del propio archivo, no el nombre.

### Cómo se leen los archivos (reglas que garantizan que cuadre con Excel)
- **Montos:** formato ecuatoriano `1.686.706,50`; también acepta punto
  decimal (`1234.56`, `7560.00`). Un punto seguido de exactamente 3 dígitos
  (o varios puntos) es separador de miles.
- **Fechas de capacitaciones:** fecha real de Excel, texto ISO
  `2026-04-10`, `10/04/2026` o número de serie de Excel. Nunca se invierten
  día y mes.
- **Meses de brigadas:** encabezados sin distinguir mayúsculas; acepta
  "Setiembre".
- **Filas descartadas se informan** (`[AVISO] … N fila(s) descartada(s) por …`
  con ejemplos y número de fila del Excel): filas del archivo = cargadas +
  descartadas.
- Brigadas: se excluyen las filas "Total…" y las sin provincia; si una
  provincia/mes se repite, se suma **con aviso**.

### Verificación rápida (qué años hay cargados)
```sql
SELECT 'ventas' f, EXTRACT(YEAR FROM fecha)::int anio, COUNT(*), MAX(fecha)::text FROM visordg.ventas_raw_dos GROUP BY 1,2
UNION ALL SELECT 'recaudacion', EXTRACT(YEAR FROM fecha)::int, COUNT(*), MAX(fecha)::text FROM visordg.recaudacion_raw_dos GROUP BY 1,2
UNION ALL SELECT 'brigadas', anio, COUNT(*), MAX(mes)::text FROM visordg.brigadas_eventos GROUP BY 1,2
UNION ALL SELECT 'capacitaciones', EXTRACT(YEAR FROM fecha)::int, COUNT(*), MAX(fecha)::date::text FROM visordg.capacitaciones_raw GROUP BY 1,2
ORDER BY 1,2;
```

### Atajos PDM (`app/backend/pyproject.toml`)
| Atajo | Qué hace |
|---|---|
| `pdm run start` | API en 127.0.0.1:8000 |
| `pdm run dev` | API con recarga automática (desarrollo) |
| `pdm run cargar <comando>` | `todo`, `ventas-dos`, `recaudacion-dos`, `brigadas-dos`, `capacitaciones-dos`, `catalogo` |
| `pdm run refrescar` | refresco único (05), con credenciales y año del settings |
| `pdm run refrescar-dos` | alias de `refrescar` (compatibilidad con el runbook viejo) |

---

## 4. Configuración (`config/settings.toml`)

| Sección | Para qué |
|---|---|
| `[database]` | Conexión a PostgreSQL (la usan API, cargas y refresco). |
| `[seguridad]` | `jwt_secret`, duración del token y clave inicial del `admin`. |
| `[monitor]` | Tiempos de rotación y sondeo, `formato_moneda` (`mill` \| `B`), visibilidad de ticker, mini-tablas, insignia "en vivo" (`visibilidad_estado`), modo del ticker (`deslizante_acumulado`), vista inicial de las tablas (`tablas_modo`: `mes` \| `acumulado`), métrica comparada en P5/P6 (`brigadas_comparar`, `capacitaciones_comparar`) y línea N-2 (`ocultar_historico_2024`). |
| `[metas]` | `meta_anual_recaudacion` (millones USD): meta del cuadro "Cumplimiento Meta Anual" de P4. |
| `[periodo]` | `anio_actual = 0` → año del último dato de ventas; un número lo fija (transición de enero). |
| `[fuentes]` | `origen` (`local` \| `fileserver`) y la ruta raíz de cada uno. |
| `[fuentes.carpetas]` | Subcarpetas por fuente. Con varias (`["Brigadas", "Brigada"]`) se buscan todas en orden. |
| `[fuentes.archivos]` | Nombres o patrones. `*` = cualquier texto; `{anio}` = año actual o previo. Si calzan varios, se toma el más reciente. Los temporales `~$...` de Excel se ignoran. |

Cambios en `[monitor]`, `[seguridad]` o `[database]` → **reiniciar el API**.
Cambios en `[fuentes]` o `[periodo]` → aplican en la próxima carga.

### Ticker (barra deslizante) — `deslizante_acumulado`
| Valor | Muestra |
|---|---|
| `mensual_actual_al_dia` | Solo el mes en curso de cada indicador: "Acum. septiembre 2026 (al 26)". Al entrar octubre pasa solo a octubre. |
| `anual_al_dia` | De enero al último día con dato: "Acum. ENE–SEP 2026 (al 26)". |

Ventas y recaudación comparan el mes en curso **a mismos días** contra el año
previo. Brigadas y capacitaciones son mensuales (total del mes). Cada
indicador llega hasta su último mes con dato (recaudación puede ir un mes atrás).

### Fecha de corte de cada tarjeta
La nota superior derecha de cada tarjeta del panel dice **"fecha de corte:
dd/mm/aaaa"**. Desde octubre/2026 es la **última fecha de los datos** de cada
fuente, calculada por la API en vivo:

| Fuente | Fecha de corte |
|---|---|
| Ventas CEL | `MAX(fecha)` de `ventas_raw_dos` (columna `Fecha` del CSV) |
| Recaudación | `MAX(fecha)` de `recaudacion_raw_dos` (`AÑO`+`MES`+`DIA` del CSV) |
| Capacitaciones | `MAX(fecha)` de `capacitaciones_raw` (`FECHA CAPACITACION` de Hoja1) |
| Brigadas | **fecha de modificación del archivo** (su Excel no trae fechas; la columna previa a "Total" solo da el mes) |

Pasar el mouse encima muestra el nombre del archivo. La fecha del archivo se
sigue guardando en `cargas_archivo` (`anio`, `archivo_modificado`) y el
refresco la copia a `hist_*` (`archivo`, `archivo_modificado`) por año.

---

## 5. Atajos en pantalla

| Acción | Teclado | Táctil |
|---|---|---|
| Pantalla siguiente / anterior | → / ← | deslizar |
| Pausar / reanudar rotación | botón ❚❚ | doble toque |
| Mostrar/ocultar ticker superior | Shift+Alt+B | — |
| Mostrar/ocultar mini-tablas | Shift+Alt+N | — |
| Mostrar/ocultar insignia "en vivo" | Shift+Alt+E | — |
| Tarjeta de brigadas: eventos ↔ personas atendidas | Shift+Alt+Q | — |
| Tablas: Mes ↔ Acumulado (P4 a P6) | Shift+Alt+M (o el botón de la pantalla) | tocar el botón |
| Ordenar una tabla (P2 a P6) | clic en el encabezado (otro clic invierte) | tocar el encabezado |
| Recarga total (ADMIN) | Shift+Alt+R | — |

La insignia "en vivo" oculta **reaparece sola ante un error** (sin conexión,
recarga fallida).

---

## 6. Estructura de archivos
```
D:\SRI\Soluciones\DG\VisorDG\
├── app\
│   ├── backend\                 FastAPI + PDM (archivos planos)
│   │   ├── main.py              API: tv-data, config, auth, recarga, WebSocket, demonio 23:00
│   │   ├── cargas.py            Cargas (orígenes local/fileserver) + refresco 05
│   │   ├── config.py            Lee settings.toml
│   │   ├── pyproject.toml       Dependencias + atajos pdm
│   │   └── .pylintrc            (150 caracteres por línea)
│   └── frontend\dist\
│       ├── index.html           Las 5 pantallas
│       ├── font\                Inter / JetBrains Mono (servidas por el API en /font)
│       ├── css\monitor.css      Estilos + responsive (TV, tablet, fold, móvil ≤480)
│       └── js\
│           ├── jquery.min.js · axios.min.js · echarts.min.js   (terceros, locales)
│           └── pro\             (lógica propia)
│               ├── config.js            Endpoints + intervalos por defecto
│               ├── api.js               tv-data, actualizado, config, login, recarga
│               ├── format.js            Formatos, COLORES, fechas y periodos
│               ├── echarts_libreria.js  Barras, líneas, barras horizontales
│               ├── tv.js                P1 Panel ejecutivo
│               ├── ventas_provincia.js  P2
│               ├── ventas_actividad.js  P3
│               ├── recaudacion.js       P4
│               ├── tablas.js            Tabla roll-up + botón Mes/Acumulado (compartidos)
│               ├── brigadas_capacitaciones.js  P5 Brigadas y P6 Capacitaciones
│               └── main.js              Orquestador: relojes, rotación, WS, atajos, recarga
├── config\settings.toml         Parámetros y credenciales
├── data\input\                  Origen LOCAL (Ventas CEL, Recaudación, Brigadas, Capacitaciones, catálogo)
├── sql\
│   ├── 00_recrear.sql           Borra el esquema visordg (mantiene seg)
│   ├── 01_esquema_visordg.sql   Tablas crudas, derivadas, catálogos y seg
│   ├── 01c_tablas_dos.sql       ventas_raw_dos / recaudacion_raw_dos
│   ├── 05_refrescar_dos.sql     REFRESCO ÚNICO: hist_* (reconstruidos), dash_mes_corriente,
│   │                            dash_ventas_provincia, marca de agua. Años dinámicos.
│   └── _inactivos\              01b, 02_copy, 03_refrescar_visor, 04_ventas — NO ejecutar
└── tests\
```

---

## 7. Tablas y qué lee cada pantalla

### Flujo
| Fuente | Tabla cruda | Refresco | Pantallas |
|---|---|---|---|
| `Ventas CEL/CEL_*.csv` | `ventas_raw_dos` | 05 → `hist_ventas`, `dash_mes_corriente` | P1, P2, P3 |
| `Recaudación/Reca_*.csv` | `recaudacion_raw_dos` | 05 → `hist_recaudacion` | P1, P4 |
| `Brigadas` o `Brigada`/`Atenciones_brigadas*.xlsx` | `brigadas_eventos` (+ `brigadas_atendidos`) | 05 → `hist_brigadas` | P1, P5 |
| `Capacitaciones/Capacitaciones*.xls` | `capacitaciones_raw` | 05 → `hist_capacitaciones` | P1, P5 |
| `Catalogo_Recaudación.xlsx` | `cat_impuestos`, `cat_provincias`, `cat_fuentes`, `cat_actividad_economica` | — | (reservado: Zonal del Lote B) |

Trazabilidad: cada carga deja una fila en `visordg.cargas_archivo`.
Marca de agua del refresco: `visordg.visor_refresh`.

### Pantallas (`GET /api/v1/tv-data`)
- **P1 Panel ejecutivo** (`tv.js`): `hist_*` + `mes_corriente`. 4 tarjetas con
  acumulado Ene→último mes con dato (año actual vs previo) y gráfico mensual.
- **P2 y P3 — Ventas CEL** (`ventas_provincia.js`, `ventas_actividad.js`,
  sobre el componente compartido `tablas.js`). Título centrado "VENTAS CEL
  (fecha de corte: dd/mm/aaaa)" (el mes ya está en el encabezado general) y
  botón **Mes / Acumulado** a la derecha: *Mes* = mes en curso a mismos días;
  *Acumulado* = enero al día de corte, a mismos días. El botón de cualquiera de
  las dos pantallas cambia ambas.
  - P2: tablas **Por provincia** y **Por sector**.
  - P3: tabla **Por actividad económica** + **Top 10** por monto del año en curso.
  - En todas: clic en un encabezado ordena por esa columna (otro clic
    invierte); por defecto **Var % de mayor a menor**. Al terminar cada vuelta
    del roll-up aparece una línea blanca antes de volver a empezar.
  - Datos: `ventas_provincias` y `ventas_sector_full` traen `v2025/v2026`
    (mes) y `a2025/a2026` (acumulado).
- **Gráficos**: números con punto de miles (1.450) en ejes, etiquetas y
  tooltips; barras con degradado y sombra; línea del año en curso con brillo.
- **Porcentajes**: coma decimal en todo el visor (+16,1%), en tablas,
  tarjetas y ticker.
- **P4 Recaudación** (`recaudacion.js`, sobre `tablas.js`): título centrado
  "RECAUDACIÓN (fecha de corte: …)" y el mismo botón **Mes / Acumulado**
  (compartido con P2 y P3; cada pantalla rotula con su propio mes). Tablas
  **Por provincia**, **Por impuesto** y **Por sector** con las mismas reglas de
  ventas: orden por columna (defecto Var % desc) y línea blanca de vuelta.
  Datos: `rec_provincia`, `rec_impuesto`, `rec_actividad` con `v2025/v2026`
  (último mes a mismos días) y `a2025/a2026` (enero → día de corte).
  **Cumplimiento Meta Anual** (dinámico):
  `(recaudación enero → último mes con dato / meta anual) × 100`. La meta
  sale de `[metas].meta_anual_recaudacion`; la recaudación, de
  `hist_recaudacion` del año en curso (la misma de la tarjeta del panel). El
  rótulo se ajusta solo ("Ene–Ago 2026", "Ene–Sep 2026"…), la barra topa en
  100% si se supera la meta, y no depende del botón Mes/Acumulado.
- **P5 Brigadas** y **P6 Capacitaciones** (`brigadas_capacitaciones.js`,
  una misma definición para las dos). Antes eran una sola pantalla. Mismo
  formato que ventas/recaudación: título centrado con fecha de corte, botón
  **Mes / Acumulado** (compartido), tabla **Por provincia** con roll-up, línea
  blanca de vuelta, orden por columna (defecto Var % desc) y **TOTAL** al pie.
  - Columnas: Zonal · Provincia · Eventos · Atendidos (P5) / Capacitados (P6)
    · 2025 · 2026 · Var %.
  - Eventos y Atendidos/Capacitados: año en curso, en la vista elegida.
  - 2025 / 2026 / Var % comparan la métrica de `brigadas_comparar` /
    `capacitaciones_comparar` (por defecto `eventos`); el título de la tabla
    lo indica ("comparación de eventos").
  - Brigadas es **mensual** (la fuente no trae día): Mes = último mes cargado
    completo contra el mismo mes del año previo. Capacitaciones trae fecha:
    Mes y Acumulado van **a mismos días**.
  - Datos: `brigadas_provincia` (`ev_*` eventos, `at_*` atendidos) y
    `cap_provincia` (`ev_*` eventos, `cp_*` capacitados), con `m25/m26` (mes)
    y `a25/a26` (acumulado); `periodo_brigadas` / `periodo_capacitaciones`.

---

## 8. Criterios de cálculo

### Cómo se calcula cada tarjeta y gráfico del panel (P1)
Todo se puede reproducir con `sql/auditoria_panel.sql` (solo lectura):
`psql -U postgres -d detalles -f D:/SRI/Soluciones/DG/VisorDG/sql/auditoria_panel.sql`.
Auditado contra la base real el 29/09/2026: **todas las cifras cuadran**.

| Tarjeta | Gráfico (por mes) | Número grande | Variación |
|---|---|---|---|
| Ventas CEL | `SUM(ventas)/1e6` por mes, redondeado (20.183.886.042,5 → 20.184) | enero → último mes con dato (hoy ene–sep = 211.471) | vs. los mismos meses del año previo (+9,5%) |
| Recaudación | `SUM(recaudado)/1e6` por mes | enero → último mes (hoy ene–ago = 16.685) | vs. mismos meses (+16,6%) |
| Brigadas (eventos) | `SUM(eventos)` por mes | enero → último mes (2.244) | vs. mismos meses (+37,0%) |
| Brigadas (atendidos, Shift+Alt+Q) | `SUM(atendidos)` por mes | enero → último mes (28.900) | vs. mismos meses (−2,8%) |
| Capacitaciones | `COUNT(*)` = **eventos** (filas del Excel), no personas | enero → último mes (1.771) | vs. mismos meses (+20,3%) |

Notas:
- Ventas incluye la provincia "NO TIENE" en los totales del panel (venta real
  sin provincia asignada); solo se oculta en la tabla por provincia.
- El último mes del año en curso puede estar incompleto (p. ej. septiembre al
  21): la **tarjeta** lo compara contra el mes completo del año previo; el
  **ticker** en modo mensual compara a mismos días.
- `SUM(total_capacitados)` son personas capacitadas (57.464 ene–sep 2026); el
  gráfico de capacitaciones cuenta eventos.

- **"Mismos días" (P2 y P3).** El mes en curso se compara recortado al mismo
  día en los tres años (`día del mes ≤ día de corte`, robusto a bisiestos). Si
  hoy es 14-sep: sep 1→14 de 2026 vs 2025 vs 2024. Con el mes cerrado, el corte
  es el último día y compara el mes completo, sin cambiar nada.
- **Panel (P1).** Acumulado de enero al último mes con dato de **cada**
  indicador (ventas y brigadas a septiembre; recaudación a agosto, cerrado).
- **Año vigente.** `[periodo].anio_actual` o, si es 0, el año del último dato
  de ventas. Lo usan las cargas de brigadas/capacitaciones, P5 y el refresco 05.
- **Mes corriente (`dash_mes_corriente`).** Días del último mes de ventas. Los
  años previos se cruzan por número de día del mismo mes; el 29-feb de un
  bisiesto se suma al último día del febrero actual. Recaudación diaria solo
  se llena si recaudación ya tiene datos de ese mes; si va un mes atrás, el
  panel usa su histórico mensual.
- **Columnas con nombre de año.** `ventas_2025`, `brigadas_2025`… conservan
  el nombre por compatibilidad, pero su contenido ya es relativo
  (`*_2025` = año previo, `*_2024` = hace dos años). Se renombran en el bloque C.
- **Limitación conocida.** Los rótulos y columnas `2024/2025/2026` de SQL,
  API y frontend todavía son fijos o posicionales; ver §11 (bloques B y C).

---

## 9. Seguridad

- Login `POST /api/v1/auth/login` → JWT (Argon2id para las claves).
- `POST /api/v1/recargar-total` exige token con perfil **ADMIN**; cada uso
  queda en `seg.auditoria` (`accion = 'recarga_total'`).
- `GET /api/v1/tv-data`, `/config`, `/health`, `/actualizado` son públicos de
  solo lectura (pantallas TV).
- ⚠️ **Pendiente de operación:**
  1. Rotar la clave de `postgres` (estuvo escrita en el código).
  2. Reemplazar `jwt_secret` por una cadena aleatoria:
     `python -c "import secrets; print(secrets.token_hex(32))"`.
  3. Confirmar que `admin` ya no usa la clave inicial.
  4. No versionar `settings.toml` si la carpeta es compartida.

---

## 10. Cambios de esta ronda (qué desplegar)

| Archivo | Cambio | ¿Reinicia API? |
|---|---|:--:|
| `config/settings.toml` | Nuevas secciones `[periodo]`, `[fuentes]`, `[fuentes.carpetas]`, `[fuentes.archivos]` (reemplazan `[fileserver]`); `visibilidad_estado` | **sí** |
| `app/backend/cargas.py` | Orígenes local/fileserver; `cargar todo`; `refrescar`; cargas atómicas con umbral; brigadas y capacitaciones por año; búsqueda en varias carpetas y por patrón | **sí** |
| `app/backend/main.py` | Recarga solo ADMIN, con candado, auditoría y `?origen=`; cargas en hilo aparte; refresco con control de errores; demonio 23:00 sin clave en el código; P5 filtrada al año vigente | **sí** |
| `app/backend/pyproject.toml` | `refrescar` / `refrescar-dos` → `python cargas.py refrescar` | no |
| `app/frontend/dist/js/pro/main.js` | Recarga con login + selector de origen; insignia "en vivo" ocultable (Shift+Alt+E) | no (Ctrl+F5) |
| `app/frontend/dist/js/pro/api.js` | `recargarTotal(token, origen)` | no (Ctrl+F5) |
| `sql/05_refrescar_dos.sql` | Refresco único (absorbe al 03); `hist_*` reconstruidos; años dinámicos; recaudación diaria coherente; bisiestos | no (correr `pdm run refrescar`) |
| `sql/01_esquema_visordg.sql` | Clave de `brigadas_atendidos` con provincia; columnas de archivo/fecha de corte (instalaciones desde cero) | no |
| `app/frontend/dist/index.html` | "Brigadas realizadas" (unidad "atendidas"), "Capacitaciones realizadas", sin "(Cantidades)" | no (Ctrl+F5) |
| `app/frontend/dist/js/pro/tv.js` | Fecha de corte por tarjeta; ticker mensual/anual al día | no (Ctrl+F5) |
| `app/frontend/dist/js/pro/echarts_libreria.js` | Etiquetas del año previo debajo de su línea | no (Ctrl+F5) |
| `app/frontend/dist/index.html` (P2) | Título central "Ventas CEL · mes (fecha de corte)"; tablas "Por provincia" / "Por sector"; encabezados ordenables | no (Ctrl+F5) |
| `app/frontend/dist/css/monitor.css` | Al final: título central (+4px), encabezados ordenables, separador del roll-up | no (Ctrl+F5) |
| `app/frontend/dist/js/pro/tablas.js` | **nuevo**: `TablaRollup` (orden, separador, triángulo) y `VentasModo` (Mes/Acumulado) compartidos | no (Ctrl+F5) |
| `app/frontend/dist/js/pro/ventas_provincia.js`, `ventas_actividad.js` | P2 y P3 sobre `tablas.js`; P3 igual que P2; Top 10 sigue la vista | no (Ctrl+F5) |
| `app/backend/main.py` | `a2025/a2026` (acumulado) en ventas y recaudación; recaudación "mes" a mismos días; `tablas_modo` en `/config` | **sí** |
| `app/frontend/dist/js/pro/recaudacion.js` | P4 sobre `tablas.js`: título central, botón, orden, separador; meta anual dinámica | no (Ctrl+F5) |
| `app/frontend/dist/js/pro/brigadas_capacitaciones.js` | P5 y P6 separadas, mismo formato que las demás, total al pie | no (Ctrl+F5) |
| `app/frontend/dist/js/pro/tv.js` | Brigadas eventos ↔ atendidos (Shift+Alt+Q) con rótulo correcto; se quitó la sobrescritura redundante del mes en curso | no (Ctrl+F5) |
| `app/frontend/dist/js/pro/echarts_libreria.js` | Etiquetas dentro de las barras de ventas 9 → 11px | no (Ctrl+F5) |
| `app/backend/main.py` | `hist_brigadas_atendidos`; `brigadas_panel` en `/config` | **sí** |
| `sql/auditoria_panel.sql` | **nuevo**: reproduce cada cifra del panel (solo lectura) | — |
| `app/backend/cargas.py` | Lectura robusta (montos con punto decimal, fechas sin inversión día/mes, meses en mayúsculas/"Setiembre"); filas descartadas informadas; comando `verificar` | no (consola) |
| `app/backend/pyproject.toml` | Atajo `pdm run verificar` | no |
| `app/backend/cargas.py` (brigadas) | **Corrige la duplicación**: la fila "Total general" ya no se carga; control contra totales del Excel; año desde el archivo; capacitaciones cotejadas con "TOTAL EVENTOS" | recargar: `pdm run cargar todo` |
| `sql/05_refrescar_dos.sql`, `sql/01_esquema_visordg.sql` | `total_declarado` en `cargas_archivo` y en `hist_brigadas` / `hist_capacitaciones` | no |
| `app/backend/main.py` (P5/P6) | `brigadas_provincia` y `cap_provincia` con mes/acumulado y años comparados; `periodo_brigadas/capacitaciones`; `brigadas_comparar`/`capacitaciones_comparar` en `/config` | **sí** |
| `app/frontend/dist/js/pro/format.js` | Porcentajes con coma decimal (`fmtDec1`) | no (Ctrl+F5) |
| `config/settings.toml` | Sección `[metas]` con `meta_anual_recaudacion = 24088` | **sí** |
| `app/frontend/dist/js/pro/format.js` | `fmtVariacion`, `fmtFechaCorte`, `fechaCorte` compartidos | no (Ctrl+F5) |
| `js/pro/ventas_actividad.js`, `js/pro/recaudacion.js` | Var % con `fmtVariacion` (mismo parámetro del triángulo) | no (Ctrl+F5) |
| `js/pro/config.js`, `js/pro/main.js` | `trianguloVariacion` desde `/config` | no (Ctrl+F5) |
| `sql/03_refrescar_visor.sql` | **mover a `sql/_inactivos/`** | — |
| `format.js`, `tv.js`, `tablas.js`, `main.js`, `main.py`, `settings.toml`, `monitor.css` | Sin triángulos ▲/▼ en ninguna pantalla (tarjetas, ticker, tablas y flechas de orden) y sin signo `+` en los porcentajes: el sentido de la variación lo da solo el color verde/rojo. Se retira el parámetro `poner_triangulo_variacion` | **sí** (reiniciar API) + Ctrl+F5 en los TV |
| `index.html`, `recaudacion.js`, `ayuda.js` | Se quita la palabra "USD" de las tarjetas, títulos de tablas y cuadro de meta anual (los montos llevan `$` o el rótulo "(Millones)") | no (Ctrl+F5) |
| `app/backend/main.py` (hist_*) | Fecha de corte de ventas, recaudación y capacitaciones = **última fecha de los datos** (`MAX(fecha)` de la tabla cruda); brigadas sigue con la fecha de modificación del archivo | **sí** (reiniciar API) |
| `index.html`, `ventas_provincia.js`, `main.js`, `monitor.css`, `tv.js`, `ayuda.js` | P2 de ventas dividida en **dos pantallas fijas** (primero el mes en curso, luego el acumulado; sin botón, con rótulo fijo); pantalla de actividad económica (Top 10) **oculta** de la rotación; "(millones)" en minúsculas y 4px más pequeño; unidades de tarjetas con mayúscula inicial (Brigadas/Eventos/Atendidos); "Fecha de corte" con mayúscula en los títulos | no (Ctrl+F5) |
| `index.html`, `brigadas_capacitaciones.js`, `tablas.js`, `monitor.css`, `settings.toml` | P4: "Cumplimiento Meta Anual" -> **"Avance Recaudación Acumulada"**. P4/P5/P6: botón **Acumulado a la izquierda y activo por defecto** (`tablas_modo = "acumulado"`). P5/P6: título a **dos líneas** (fecha de corte abajo, más pequeña), sin el rótulo "Por provincia"; tabla con **encabezado a dos líneas**: cada métrica (eventos y atendidos/capacitados) con año anterior · año actual · variación propios; `brigadas_comparar`/`capacitaciones_comparar` quedan sin uso (se muestran ambas métricas). P1: tarjetas sin unidad bajo el número; brigadas titula "Brigadas ejecutadas" (alineado con su gráfico) | no (Ctrl+F5) |
| `main.py`, `main.js` | **Carga más rápida**: consultas de `/tv-data` en paralelo (antes en serie), pool 10 -> 20, gzip en respuestas, caché de 24 h para las fuentes, y el refresco por WebSocket usa `reload()` normal (reusa caché) en vez de `reload(true)` | **sí** (reiniciar API) + Ctrl+F5 |
| `echarts_libreria.js`, `main.js`, `main.py`, `settings.toml` | **Paleta del gráfico de ventas (P1) parametrizable**: `[monitor].ventas_paleta` = `azul` (la original) · `verde` (combina con la línea superior de la tarjeta; valor por defecto en el settings) · `amarilla` · `violeta` · `coral`. Cada paleta define el degradado del año pasado (tenue) y del año en curso (fuerte); la leyenda toma el color sola | **sí** (reiniciar API) + Ctrl+F5 |
| `main.js` | **Arranque más rápido**: el config y los datos del TV se piden **en paralelo** (antes el dato esperaba al config) y ya no se construye el gráfico Top 10 de la pantalla oculta P3 | no (Ctrl+F5) |
| `index.html`, `monitor.css`, `tablas.js` | Ventas (mes y acumulado): título a **dos líneas** como Brigadas/Capacitaciones, con la fecha de corte 4px más pequeña que el título (14.5px). Línea blanca del roll-up con **~2cm de aire antes y después** y **halo amarillo** para marcar el fin de vuelta; duración de la animación ajustada (el separador cuenta como 4 filas). Corregido: la subbar de la pantalla acumulada faltaba en la lista con `position: relative`, por eso el rótulo "Acumulado" flotaba a media pantalla | no (Ctrl+F5) |
| `monitor.css` | Recaudación (P4): fecha de corte en la misma línea pero 4px más pequeña (14.5px). Se retiró el override que forzaba el separador de sus tablas a 36px: ahora el separador de **todas** las tablas roll-up es el global (~2cm de aire antes y después, línea blanca con halo amarillo) | no (Ctrl+F5) |
| `monitor.css` | **Tipografía uniforme en todas las tablas roll-up**: encabezados a 13px con su color opaco y en mayúsculas; filas a 11px (el protagonismo lo da el color: filas claras, encabezados opacos). Los nombres ya salen con mayúscula inicial vía `aTitulo()`, que conserva las siglas IVA/ICE/ISD/RENTA en mayúsculas | no (Ctrl+F5) |

---

## 11. Pendientes de estabilidad (antes del grupo de cambios de la DG)

| # | Bloque | Estado |
|---|---|---|
| A | Orígenes local/fileserver, settings reorganizado, patrones de archivo | ✅ esta ronda |
| B | Refresco único (05 absorbe al 03); `hist_*` reconstruidos; años dinámicos en SQL; recaudación diaria coherente; bisiestos | ✅ esta ronda |
| C | **Años dinámicos** en API y frontend (`anio_actual`/`anio_prev` en `/tv-data`; sin 2025/2026 fijos en SQL, `tv.js`, `index.html`, leyenda del Top-10); conectar `ocultar_historico_2024` a la línea N-2 | pendiente |
| D | `brigadas_atendidos`: `UNIQUE (provincia, agencia, anio, mes)` (se ajusta solo); duplicados del Excel se suman **con aviso** | ✅ |
| E | Limpieza (ver §12) | pendiente |
| F | Rótulo "(Billones)" → "(Miles de millones)" con `formato_moneda="B"`; capacitaciones sin año previo no debería dibujar la línea en cero | pendiente |
| G | Cargas por consola → aviso por WebSocket (hoy requieren Ctrl+F5 en el TV) | pendiente |

---

## 12. Objetos a borrar (limpieza, bloque E)

**Frontend**
- Archivos: `js/pro/provincial.js`, `js/pro/echarts_libreria - copia.js`, `js/chart.umd.js` (si existe).
- `echarts_libreria.js`: `renderAnioZonas`.
- `tv.js`:
  - `chartsE`, `charts` y su listener de `resize`.
  - El bloque de `seriesMensual` que lee `_ultimo_raw_mes_corriente` (redundante con `hist_*`).
- Referencias huérfanas: `#clockTimeRec` y `#clockTimeBrigCap` (`main.js`), `#periodoLabelRec` (`recaudacion.js`).
- `monitor.css`, selectores del P2 viejo: `.board-row`, `.bar-*`, `.rank`, `.region-tag`, `.prov-name`, `.var-cell`, `.row-simple`, `.row-prov/-act/-imp`, `.cols-imp`, `.cols-simple`, `.page-dots`, `.page-indicator`, `.dot`, `.range`, `.fade`, `.tablas-trio`, `.col-50`, `.tabla-inferior`, `.board-wrap`, `.btn-mes`, `.card-sub`, `.badge-sim`.
- **Se conservan:** mini-ticker (`.mini-*`, `#div_*_mini`, `visibilidad_barras_mini`) y footnote (`.fn-*`, `#footnote`).

**Backend**
- `cargas.py`:
  - Comandos legacy `recaudacion`, `capacitaciones` y `brigadas`.
  - `_cargar_recaudacion_carpeta`, `_mes_de_nombre`, `MESES_ABR`, `_COLUMNAS_REC` y `_elegir_base`.
- `settings.toml`: sección `[api]` y `pagina_segundos`.

**Base de datos**
- `visordg.recaudacion_raw` y `visordg.ventas_raw` (si existe): pipeline viejo.
- `visordg.dash_ventas_provincia`: la API solo usa su `periodo`, que puede salir de `ventas_raw_dos`.
- **Se conservan:** `cat_*` (Lote B), `brigadas_atendidos` (se corrige en D), `seg.refresh_tokens`, `seg.permisos` y `seg.perfil_permiso` (seguridad futura).

---

## 13. Historia — brigadas duplicadas en el panel (29/09/2026)
La fila final **"Total general"** de las pestañas de brigadas tiene el texto
en la columna *Zona* y la *Provincia* vacía. pandas lee la celda vacía como
`NaN`, y `str(NaN or "")` da `"nan"` (NaN es verdadero en Python): la fila de
totales se cargaba como una provincia llamada "nan" y **duplicaba cada mes**
(ene-2026: 88 eventos → 176; ene–sep: 1.122 → 2.244; atendidos 14.450 →
28.900). La tabla de P5 salía bien porque su consulta filtraba `'nan'`; el
panel (vía `hist_brigadas`) no. Los porcentajes no cambiaban porque ambos
años estaban duplicados igual.
**Solución:** celdas vacías = `''` (`texto()`), la fila Total se reconoce en
Zona o Provincia y se usa como control; `pdm run verificar` la coteja.

## 14. Historia — causa raíz "2026 no entraba" (18/09/2026)
`CEL_2026.csv` venía separado por **`;`** y los demás por **`,`**.
`_leer_csv` asumía coma: 2026 quedaba como UNA columna, `Fecha` salía `None`
y todas sus filas se descartaban en silencio. Resultado: ventas tope
dic-2025, columnas de año corridas y recaudación en $0.
**Solución:** `sep=None, engine="python"` (autodetecta). **Blindaje actual:** si
un archivo vuelve a dar menos de 10 filas válidas, la carga se cancela con
error y no se borra nada.
