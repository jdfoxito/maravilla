# -*- coding: utf-8 -*-
"""Utilidades comunes del sistema: logging, compresión ZIP, detección de cuotas Oracle.

app-da_comunes.py

Historial:
+--------------------+---------+------------------------------------------+
| Autor              | Versión | Cambios                                  |
+--------------------+---------+------------------------------------------+
| Jim A. González    | 1.0.0   | Utilidades básicas, logging simple       |
| Jim A. González    | 2.0.0   | Validación ZIP anti-path-traversal       |
| Jim A. González    | 3.0.0   | CuotaDBDetector tras incidente ORA-12954 |
| Jim A. González    | 4.0.0   | EstimadorCapacidadLocal   v2             |
| Jim A. González    | 5.0.0   | ValidadorSMB multi-protocolo RHEL 10.1   |
| Jim A. González    | 5.1.0   | Ejecutable portable: la raiz es la       |
|                    |         | carpeta del binario, sin rutas fijas     |
+--------------------+---------+------------------------------------------+
"""

from dataclasses import dataclass, field
from datetime import datetime
import logging
import logging.handlers
import os
from pathlib import Path
import re
import socket
import subprocess
import sys
from types import SimpleNamespace
from typing import Annotated, Any, Dict, Iterable, Optional, Tuple
import zipfile

from pydantic import BaseModel, ConfigDict, Field

try:
    import paramiko
    PARAMIKO_DISPONIBLE = True
except ImportError:
    paramiko = None
    PARAMIKO_DISPONIBLE = False

from app.da_excepciones import TrazabilidadExcepciones


@dataclass
class Agregado:
    """Datos agregados de un archivo XML para procesamiento."""

    xml_path: str
    tamanio: int
    tiene_xml: str
    num_archivo: int
    fecha_carga: str
    reprocesado: str
    tiene_firma: str
    directorio_unzip: str
    xsd_validez: bool
    num_productos_directo: int = field(default=0)
    ruta_zip: Optional[str] = None
    nombre_zip: Optional[str] = None
    tamanio_zip_mb: Optional[float] = 0.0
    firma_eliminada: str = 'no'


class ConexionParams(BaseModel):
    """Parámetros de conexión Oracle, clase de control."""

    model_config = ConfigDict(populate_by_name=True)

    homogeneous: bool = Field(False, ge=False)
    externalauth: bool = Field(True, ge=True)
    dsn: Annotated[str, Field(min_length=1, default='STAR_BI_DWH')]
    min_: int = Field(5, ge=1, alias='min')
    max_: int = Field(20, ge=5, alias='max')
    increment: int = Field(1, ge=1)
    timeout: int = Field(30, ge=5)
    wait_timeout: int = Field(120, ge=30)
    max_lifetime_session: int = Field(1800, ge=300)
    max_workers: int = Field(10, ge=1)
    threaded: bool = Field(True, ge=True)


@dataclass
class Parametros:
    """Parámetros de configuración para operaciones."""

    ruta_origen_ftp_aw: str = ''
    ruta_local_destino: str = ''
    operadores: Optional[SimpleNamespace] = None
    credenciales: Optional[SimpleNamespace] = None

    def __post_init__(self):
        """Inicializa valores por defecto de operadores y credenciales."""
        if self.operadores is None:
            self.operadores = SimpleNamespace(fuentes='')
        if self.credenciales is None:
            self.credenciales = SimpleNamespace(etl_nombre='trazabilidad_fiscal', tipo_ext_origen='.zip')


class TrazabilidadLogger:
    """Clase configuradora de logging con rotación por tamaño y doble handler."""

    def __init__(self, directorio_log: str, nombre_etl: str):
        """Inicializa el configurador de logging.

        Args:
            directorio_log: Ruta al directorio donde se crearán los logs.
            nombre_etl: Nombre del proceso ETL (usado en el nombre del archivo).
        """
        self._directorio_log = Path(directorio_log)
        self._nombre_etl = nombre_etl
        self._directorio_log.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _log(logger_inst: logging.Logger, level: int, msg: str, *args: object) -> None:
        """Registra un mensaje con formato lazy % para compatibilidad con Pylint."""
        logger_inst.log(level, msg, *args)

    def configurar(self) -> logging.Logger:
        """Configura el logger con rotación y formato estándar SRI.

        Retorna:
            Logger configurado con handlers de archivo y consola.
        """
        marca_tiempo = datetime.now().strftime('%Y%m%d%H%M%S')
        archivo_log = self._directorio_log / (f'{marca_tiempo}_{self._nombre_etl}.log')

        formato = logging.Formatter(fmt='%(asctime)s - %(levelname)s - %(name)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')

        handler_archivo = logging.handlers.RotatingFileHandler(
            archivo_log,
            maxBytes=10 * 1024 * 1024,
            backupCount=5,
            encoding='utf-8'
        )
        handler_archivo.setFormatter(formato)
        handler_archivo.setLevel(logging.DEBUG)

        handler_consola = logging.StreamHandler()
        handler_consola.setFormatter(formato)
        handler_consola.setLevel(logging.INFO)

        logger_inst = logging.getLogger(self._nombre_etl)
        logger_inst.setLevel(logging.DEBUG)
        logger_inst.addHandler(handler_archivo)
        logger_inst.addHandler(handler_consola)
        logger_inst.propagate = False

        self._log(logger_inst, logging.INFO, 'Logger configurado. Archivo: %s', archivo_log)
        return logger_inst


class Tarea:
    """Clase base para operaciones con archivos ZIP con validaciones de seguridad."""

    def __init__(self, nombre: str, logger_inst: logging.Logger):
        """Inicializa la tarea."""
        self.nombre = nombre
        self.logger = logger_inst
        self.params = None

    @staticmethod
    def es_seguro(nombre_archivo: str) -> bool:
        """Verifica que el nombre no contenga rutas peligrosas."""
        if nombre_archivo.startswith(('/', '\\')):
            return False
        if '..' in nombre_archivo or ':' in nombre_archivo:
            return False
        return True

    def descomprimir(self, zip_obj: SimpleNamespace) -> tuple:
        """Descomprime un archivo ZIP con validación de seguridad anti path-traversal."""
        resultado = zip_obj, False, "Error desconocido", {}

        try:
            ruta_zip = Path(zip_obj.archivo_zip_local)
            dir_destino = Path(zip_obj.ruta_destino)

            error_validacion = self._validar_ruta_zip(ruta_zip)
            if error_validacion:
                resultado = zip_obj, False, error_validacion, {}
            else:
                dir_destino.mkdir(parents=True, exist_ok=True)
                exito, mensaje, archivos = self._procesar_extraccion_zip(ruta_zip, dir_destino)
                resultado = zip_obj, exito, mensaje, archivos

        except zipfile.BadZipFile as exc:
            self.logger.error("ZIP corrupto: %s - %s", exc, zip_obj.nombre_zip)
            resultado = zip_obj, False, f"ZIP corrupto: {exc}", {}
        except OSError as exc:
            self.logger.error("Error de sistema: %s - %s", exc, zip_obj.nombre_zip)
            resultado = zip_obj, False, f"Error de sistema: {exc}", {}
        except TrazabilidadExcepciones.POOL_ERRORS as exc:
            self.logger.error("Error inesperado: %s - %s", exc, zip_obj.nombre_zip)
            resultado = zip_obj, False, f"Error inesperado: {exc}", {}

        return resultado

    @staticmethod
    def _validar_ruta_zip(ruta_zip: Path) -> str | None:
        """Valida la existencia y el formato del archivo ZIP."""
        if not ruta_zip.exists():
            return f"ZIP no existe: {ruta_zip}"

        if not zipfile.is_zipfile(ruta_zip):
            return "Archivo no es un ZIP válido"

        return None

    def _procesar_extraccion_zip(self, ruta_zip: Path, dir_destino: Path) -> tuple:
        """Abre el ZIP, filtra archivos maliciosos y los extrae."""
        with zipfile.ZipFile(ruta_zip, 'r') as zf:
            resultado_test = zf.testzip()
            if resultado_test:
                return False, f"Archivo corrupto: {resultado_test}", {}

            archivos_seguros = []
            archivos_peligrosos = []

            for info in zf.infolist():
                if info.is_dir():
                    continue
                if self.es_seguro(info.filename):
                    archivos_seguros.append(info)
                else:
                    archivos_peligrosos.append(info.filename)
                    self.logger.warning("Archivo peligroso omitido: %s", info.filename)

            for info in archivos_seguros:
                zf.extract(info, dir_destino)

            archivos_extraidos = self._construir_mapa_archivos(archivos_seguros)
            mensaje = self.calificacion_archivos(archivos_peligrosos, archivos_seguros)
            return True, mensaje, archivos_extraidos

    @staticmethod
    def calificacion_archivos(archivos_peligrosos, archivos_seguros):
        """Sirve para calificar los archivos."""
        mensaje = ""
        if archivos_peligrosos and not archivos_seguros:
            mensaje = f'Descompresión incompleta: {len(archivos_peligrosos)} archivos omitidos, 0 válidos'
        elif archivos_peligrosos:
            mensaje = f'Descompresión exitosa ({len(archivos_peligrosos)} archivos peligrosos omitidos)'
        else:
            mensaje = 'Descompresión exitosa'

        return mensaje

    @staticmethod
    def _construir_mapa_archivos(archivos_seguros: list) -> Dict[str, list]:
        """Construye el mapa de archivos extraídos con nombre único.

        Args:
            archivos_seguros: Lista de ZipInfo de archivos válidos.

        Returns:
            Diccionario nombre -> [tamanio, tipo, num_archivo, fecha].
        """
        archivos_extraidos: Dict[str, list] = {}

        for info in archivos_seguros:
            nombre_lower = info.filename.lower()
            if nombre_lower.endswith('.xml'):
                tipo = 'xml'
            elif nombre_lower.endswith('.zip'):
                tipo = 'zip'
            else:
                tipo = 'otro'

            nombre_base = Path(info.filename).name
            nombre_unico = nombre_base
            contador = 1

            while nombre_unico in archivos_extraidos:
                sufijo = f"{contador}{Path(nombre_base).suffix}"
                nombre_unico = f"{Path(nombre_base).stem}_{sufijo}"
                contador += 1

            archivos_extraidos[nombre_unico] = [info.file_size, tipo, 1, '']

        return archivos_extraidos

    def ubicacion_xsd(self) -> str:
        """Retorna la ruta absoluta del archivo XSD de validación.

        Returns:
            Ruta al archivo XSD encontrado.

        Raises:
            FileNotFoundError: Si no se encontró el XSD en ninguna ruta estándar.
        """
        posibles_rutas = [
            Path('app/validacion.xsd'),
            Path('config/validacion.xsd'),
            Path('schemas/validacion.xsd'),
            Path('resources/validacion.xsd'),
        ]

        for ruta in posibles_rutas:
            if ruta.exists():
                self.logger.debug('XSD encontrado en: %s', ruta.absolute())
                return str(ruta.absolute())

        rutas_buscadas = ', '.join(str(ruta) for ruta in posibles_rutas)
        raise FileNotFoundError(f'No se encontró archivo XSD. Buscado en: {rutas_buscadas}')


class CuotaDBDetector:
    """Clase para detener el pipeline de inmediato cuando se alcanza el límite.

    El estado del singleton (patrón factory) se mantiene en el atributo de clase
    _instancia, evitando una variable global de módulo.
    """

    _instancia: Optional['CuotaDBDetector'] = None

    @classmethod
    def obtener_singleton(cls, logger_inst: logging.Logger) -> 'CuotaDBDetector':
        """Retorna la instancia única del detector, creándola si no existe.

        Args:
            logger_inst: Logger activo del proceso.

        Retorna:
            Instancia única de CuotaDBDetector.
        """
        if cls._instancia is None:
            cls._instancia = cls(logger_inst)
        cls._instancia.logger = logger_inst
        return cls._instancia

    _PATRON_LIMITE = re.compile(r'maximum allowed database size of (\d+(?:\.\d+)?)\s*(GB|MB)', re.IGNORECASE)

    def __init__(self, logger_inst: logging.Logger):
        """Inicializa el detector de cuotas.

        Args: logger_inst: Logger para registrar los eventos críticos.
        """
        self.logger = logger_inst

    def parse_mensaje_cuota(self, error_msg: str) -> Tuple[bool, str, float]:
        """Parsea el mensaje ORA-12954 para extraer el límite real.

        Args: error_msg: Mensaje de error de Oracle.
        Retorna:  Tupla (es_cuota, mensaje_formateado, limite_gb).
        """
        if 'ORA-12954' not in error_msg:
            return False, '', 0.0

        coincidencia = self._PATRON_LIMITE.search(error_msg)

        if coincidencia:
            limite = float(coincidencia.group(1))
            unidad = coincidencia.group(2).upper()
            limite_gb = limite / 1024 if unidad == 'MB' else limite
            mensaje = (
                f'CUOTA EXCEDIDA: Límite de {limite_gb:.2f}GB alcanzado. '
                'Contacte al DBA para ampliar cuota.'
            )
            return True, mensaje, limite_gb

        return True, 'CUOTA EXCEDIDA: No se determinó el límite exacto', 0.0

    def detener_por_cuota(self, exc: Exception, contexto: str = '') -> None:
        """Detiene el pipeline cuando se detecta ORA-12954.

        Args: exc: Excepción de Oracle con código ORA-12954.
            contexto: Información adicional (tabla, batch, etc.).

        Raises: RuntimeError: Siempre, para detener el pipeline.
        """
        error_obj, = exc.args

        if error_obj.code != 12954:
            return

        es_cuota, mensaje, limite_gb = self.parse_mensaje_cuota(error_obj.message)

        self.logger.critical('=' * 80)
        self.logger.critical('ORA-12954: LÍMITE DE BASE DE DATOS ALCANZADO')
        self.logger.critical('Cuota: %s | Límite: %.2f GB', es_cuota, limite_gb)
        self.logger.critical('Mensaje: %s', mensaje)
        self.logger.critical('Contexto: %s', contexto)
        self.logger.critical('=' * 80)

        raise RuntimeError(f'Pipeline detenido por cuota: {mensaje}') from exc


def get_cuota_detector(logger_inst: logging.Logger) -> CuotaDBDetector:
    """Retorna el singleton del detector de cuotas.

    Args: logger_inst: Logger activo del proceso.
    Returns: Instancia única de CuotaDBDetector.
    """
    return CuotaDBDetector.obtener_singleton(logger_inst)


@dataclass
class ErrorEspacioBD(Exception):
    """Excepción controlada para errores de espacio con metadatos de recuperación."""

    error_code: str
    mensaje: str
    filas_procesadas: int
    filas_pendientes: int
    gb_estimados_faltantes: float
    tabla_afectada: str
    archivo_pendiente: str = ''

    def __str__(self) -> str:
        """Retorna representación legible del error de espacio."""
        base = (
            f'[{self.error_code}] Espacio agotado en {self.tabla_afectada}. '
            f'Insertadas: {self.filas_procesadas:,}, '
            f'Pendientes: {self.filas_pendientes:,}. '
            f'Se necesitan ~{self.gb_estimados_faltantes:.2f} GB adicionales.'
        )
        if self.archivo_pendiente:
            base += f' Archivo pendiente: {self.archivo_pendiente}.'
        return base


class EstimadorCapacidadLocal:
    """Estimador de espacio en BD basado en estadísticas locales.

    Fórmulas empíricas validadas:
    - 201 MB XML -> 6.04M filas (ratio: 30,069 filas/MB)
    - 684 MB XML -> 48.67M filas (ratio: 71,153 filas/MB)
    Se usa el ratio conservador (35,000) para estimaciones seguras.
    """

    RATIO_CONSERVADOR = 35000
    RATIO_PROMEDIO = 60000
    RATIO_ALTO = 75000
    BYTES_POR_FILA = 300

    def __init__(self, logger_inst: Optional[logging.Logger] = None):
        """Inicializar el Estimador.

        Args:
            logger_inst: Logger opcional para registrar estimaciones.
        """
        self.logger = logger_inst or logging.getLogger(__name__)
        self.historial_ratios: list = []

    def estimar_desde_xml(self, xml_path: str) -> Dict[str, Any]:
        """Estima filas y espacio necesario en BD sin consultar Oracle.

        Args:
            xml_path: Ruta al archivo XML a estimar.

        Returns:
            Diccionario con xml_mb, filas_estimadas, gb_bd_necesarios, ratio_usado.
        """
        try:
            tamanio_mb = os.path.getsize(xml_path) / (1024 * 1024)
        except (OSError, IOError):
            tamanio_mb = 0

        filas_estimadas = int(tamanio_mb * self.RATIO_CONSERVADOR)
        bytes_necesarios = filas_estimadas * self.BYTES_POR_FILA * 1.3
        gb_necesarios = bytes_necesarios / (1024 ** 3)

        return {
            'xml_mb': tamanio_mb,
            'filas_estimadas': filas_estimadas,
            'gb_bd_necesarios': gb_necesarios,
            'ratio_usado': self.RATIO_CONSERVADOR,
        }

    def calcular_espacio_faltante(self, filas_insertadas: int, filas_totales: int) -> float:
        """Calcula cuántos GB faltan para insertar el resto de los registros.

        Args: filas_insertadas: Registros ya insertados.
            filas_totales: Total de registros a procesar.
        Returns: GB estimados necesarios.
        """
        filas_pendientes = filas_totales - filas_insertadas
        bytes_faltantes = filas_pendientes * self.BYTES_POR_FILA * 1.3
        return bytes_faltantes / (1024 ** 3)

    def generar_mensaje_dba(self,
                            xml_name: str,
                            filas_insertadas: int,
                            filas_totales: int,
                            error_code: str,
                            archivo_pendiente: str) -> Tuple[str, float]:
        """Genera el mensaje formal para solicitar espacio al DBA.

        Args:
            xml_name: Nombre del archivo XML afectado.
            filas_insertadas: Registros ya procesados.
            filas_totales: Total de registros del archivo.
            error_code: Código de error Oracle (ORA-XXXXX).
            archivo_pendiente: Archivo con los datos pendientes.

        Returns: Tupla (mensaje_formateado, gb_faltantes).
        """
        gb_faltantes = self.calcular_espacio_faltante(filas_insertadas, filas_totales)
        filas_pendientes = filas_totales - filas_insertadas
        gb_requeridos = max(10, int(gb_faltantes))

        mensaje = (
            '\n'
            '╔════════════════════════════════════════════════════════════╗\n'
            '║        REVISAR: ESPACIO EN BASE DE DATOS AGOTADO           ║\n'
            '╚════════════════════════════════════════════════════════════╝\n'
            '\n'
            f'Archivo afectado : {xml_name}\n'
            f'Error Oracle     : {error_code}\n'
            '\n'
            'SITUACIÓN ACTUAL:\n'
            f'  Filas insertadas : {filas_insertadas:,}\n'
            f'  Filas pendientes : {filas_pendientes:,}\n'
            f'  Total estimado   : {filas_totales:,} filas\n'
            '\n'
            'REQUERIMIENTO PARA DBA:\n'
            f'  Se necesitan aprox. {gb_faltantes:.2f} GB adicionales.\n'
            f'  ALTER TABLESPACE <nombre> ADD DATAFILE SIZE {gb_requeridos}G\n'
            '\n'
            'DATOS PENDIENTES GUARDADOS:\n'
            f'  Archivo   : {archivo_pendiente}\n'
            f'  Registros : {filas_pendientes:,}\n'
        )

        return mensaje, gb_faltantes


def es_error_espacio(exc: Exception) -> Tuple[bool, Optional[str]]:
    """Detecta si el error Oracle es por falta de espacio en disco.

    Args: exc: Excepción a evaluar.
    Returns: Tupla (es_error_espacio, codigo_oracle_o_None).
    """
    error_str = str(exc)
    codigos_espacio = {
        'ORA-65114': 'Uso de espacio en contenedor demasiado alto',
        'ORA-01653': 'No se puede extender tabla',
        'ORA-01654': 'No se puede extender índice',
        'ORA-30036': 'No se puede extender segmento',
        'ORA-12954': 'Solicitud excede tamaño máximo de la base de datos',
    }
    for codigo in codigos_espacio:
        if codigo in error_str:
            return True, codigo

    return False, None


class CuotaDBDetectorSync:
    """Detector de cuota que trabaja con flujo síncrono sin lanzar excepciones.

    Reemplaza excepciones por manejo de estado para no detener el pipeline
    en operaciones que pueden continuar parcialmente.
    """

    def __init__(self, logger_inst: logging.Logger):
        """Inicializa el detector síncrono.

        Args: logger_inst: Logger para registrar alertas de cuota.
        """
        self.logger = logger_inst
        self.cuota_excedida = False
        self.espacio_agotado = False

    def verificar_error_recuperable(self, exc: Exception, contexto: str = '') -> Tuple[bool, str]:
        """Verifica si el error es de espacio y decide si se puede continuar.

        Args:  exc: Excepción a evaluar.
            contexto: Descripción del contexto donde ocurrió el error.
        Returns: Tupla (debe_continuar, codigo_oracle_o_vacio).
        """
        es_espacio, codigo = es_error_espacio(exc)

        if not es_espacio:
            return False, ''
        if codigo == 'ORA-12954':
            self.cuota_excedida = True
            self.logger.critical('CUOTA EXCEDIDA (%s): %s', codigo, contexto)
            return True, codigo

        self.espacio_agotado = True
        self.logger.error('ESPACIO AGOTADO (%s): %s', codigo, contexto)
        return True, codigo

    def obtener_estado(self) -> Dict[str, Any]:
        """Retorna el estado actual de restricciones de espacio."""
        return {
            'cuota_excedida': self.cuota_excedida,
            'espacio_agotado': self.espacio_agotado,
            'bloquear_nuevas_inserciones': self.cuota_excedida or self.espacio_agotado,
        }


class ValidadorSMB:
    """Valida carpetas compartidas SMB antes de montar. Detecta NTLM y permisos."""

    def __init__(self, logger_inst: Optional[logging.Logger] = None):
        """Inicializa el validador SMB.

        Args:
            logger_inst: Logger opcional para registrar resultados.
        """
        self.logger = logger_inst
        self.ultimo_error: Optional[str] = None

    @staticmethod
    def extraer_host_share(ruta_smb: str) -> Tuple[str, str]:
        """Extrae host y share de una ruta SMB tipo //host/share.

        Args:
            ruta_smb: Ruta SMB en formato //host/share.

        Returns:
            Tupla (host, share).
        """
        partes = ruta_smb.replace('//', '').split('/')
        host = partes[0]
        share = partes[1] if len(partes) > 1 else ''
        return host, share

    def validar_acceso_share(self, ruta_original: str, usuario: str, password: str) -> Tuple[bool, Dict[str, Any]]:
        """Valida si el share SMB es accesible antes de montar."""
        if not ruta_original.startswith('//'):
            return True, {'tipo': 'local', 'ruta': ruta_original}

        host, share = self.extraer_host_share(ruta_original)
        if not share:
            resultado = False, {'error': f'No se pudo extraer share de {ruta_original}'}
        else:
            if self.logger:
                self.logger.info('Verificando //%s/%s...', host, share)

            conexion_ok, error_red = self._verificar_conectividad_red(host)
            if not conexion_ok:
                resultado = False, error_red
            else:
                resultado = self._validar_credenciales_smb(host, share, usuario, password)

        return resultado

    def _validar_credenciales_smb(self, host: str, share: str, usuario: str, password: str) -> Tuple[bool, Dict[str, Any]]:
        """Ejecuta la verificación SMB tolerando ausencia de smbclient."""
        try:
            resultado = self._verificar_con_smbclient(host, share, usuario, password)
        except FileNotFoundError:
            if self.logger:
                self.logger.warning('smbclient no instalado, omitiendo validación de shares')
            resultado = True, {
                'tipo': 'smb',
                'host': host,
                'share': share,
                'opciones_recomendadas': 'vers=3.0,sec=ntlmssp,noperm',
                'advertencia': 'No se pudo verificar previamente (smbclient no instalado)',
            }
        return resultado

    def _verificar_conectividad_red(self, host: str) -> Tuple[bool, Dict[str, Any]]:
        """Valida resolución de nombres y puerto 445 en el host remoto."""
        try:
            ip = socket.gethostbyname(host)
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            resultado_conn = sock.connect_ex((ip, 445))
            sock.close()
            if resultado_conn != 0:
                resultado = False, {'error': f'Puerto 445 cerrado en {host} ({ip})'}
            else:
                if self.logger:
                    self.logger.info('Host %s accesible en %s:445', host, ip)
                resultado = True, {}

        except socket.gaierror:
            resultado = False, {'error': f'No se puede resolver DNS: {host}'}
        except TrazabilidadExcepciones.ERRORES_SISTEMA as exc:
            resultado = False, {'error': f'Error de conectividad: {exc}'}

        return resultado

    def _verificar_con_smbclient(self, host: str, share: str, usuario: str, password: str) -> Tuple[bool, Dict[str, Any]]:
        """Verifica el acceso usando smbclient.

        Args:host: Dirección del servidor SMB.
            share: Nombre del share a verificar.
            usuario: Nombre de usuario SMB.
            password: Contraseña SMB.
        Returna: Tupla (accesible, info).
        """
        cmd_lista = [
            'smbclient', '-L', f'//{host}',
            '-U', f'{usuario}%{password}',
            '-g', '--max-protocol=SMB3',
        ]

        try:
            resultado_run = subprocess.run(cmd_lista, capture_output=True, text=True, timeout=20, check=False)

            if resultado_run.returncode != 0:
                resultado = self._analizar_error_smb(resultado_run.stderr)
            else:
                shares_disponibles = [
                    linea.split('|')[1]
                    for linea in resultado_run.stdout.split('\n')
                    if linea.startswith('Disk|')
                ]

                if share not in shares_disponibles:
                    shares_similares = [
                        sh for sh in shares_disponibles
                        if share in sh or sh in share
                    ]
                    sugerencia = (
                        f'Verificar entre: {shares_similares}'
                        if shares_similares
                        else 'Verificar permisos o nombre del share'
                    )
                    resultado = False, {
                        'error': f'Share "{share}" no encontrado',
                        'shares_disponibles': shares_disponibles[:10],
                        'shares_similares': shares_similares,
                        'sugerencia': sugerencia,
                    }
                else:
                    if self.logger:
                        self.logger.info("Share '%s' confirmado en el servidor", share)
                    resultado = self._intentar_acceso_directo(host, share, usuario, password)

        except subprocess.TimeoutExpired:
            resultado = False, {'error': 'Timeout verificando SMB (20s)'}

        return resultado

    @staticmethod
    def _analizar_error_smb(stderr: str) -> Tuple[bool, Dict[str, Any]]:
        """Analiza el stderr de smbclient para clasificar el error.

        Args: stderr: Salida de error de smbclient.

        Retorna: Tupla (False, info_del_error).
        """
        error_lower = stderr.lower()
        if 'ntlm' in error_lower and 'failed' in error_lower:
            info = {
                'error': 'Autenticación NTLM fallida',
                'solucion': 'Intentar con sec=ntlmssp o vers=2.1',
                'tipo_error': 'NTLM',
            }
        elif 'logon failure' in error_lower:
            info = {'error': 'Credenciales incorrectas (Logon failure)'}
        elif 'connection refused' in error_lower:
            info = {'error': 'Conexión rechazada por el servidor SMB'}
        else:
            info = {'error': 'Error desconocido en SMB'}
        return False, info

    def _intentar_acceso_directo(self, host: str, share: str, usuario: str, password: str) -> Tuple[bool, Dict[str, Any]]:
        """Intenta acceder al share para detectar la versión SMB óptima.

        Args:
            host: Dirección del servidor SMB.
            share: Nombre del share.
            usuario: Nombre de usuario SMB.
            password: Contraseña SMB.
        Returns: Tupla (accesible, info_con_opciones_recomendadas).
        """
        ruta = f'//{host}/{share}'
        opciones_prueba = [
            {'sec': 'ntlmssp', 'vers': '3.0', 'desc': 'NTLMSSP v3.0 (moderno)'},
            {'sec': 'ntlmssp', 'vers': '2.1', 'desc': 'NTLMSSP v2.1 (compatible)'},
            {'sec': 'ntlm',    'vers': '2.1', 'desc': 'NTLM v2.1 (legacy)'},
        ]

        for opt in opciones_prueba:
            cmd = [
                'smbclient', ruta,
                '-U', f'{usuario}%{password}',
                '--max-protocol=' + opt['vers'],
                '-c', 'ls',
            ]

            try:
                resultado = subprocess.run(cmd, capture_output=True, text=True, timeout=15, check=False)
                if resultado.returncode == 0:
                    return True, {
                        'estado': 'accesible',
                        'host': host,
                        'share': share,
                        'ruta_completa': ruta,
                        'opciones_recomendadas': {
                            'sec': opt['sec'],
                            'vers': opt['vers'],
                            'string_montaje': (
                                f'sec={opt["sec"]},vers={opt["vers"]},'
                                'noperm,noserverino'
                            ),
                        },
                        'metodo_detectado': opt['desc'],
                    }
                if 'LOGON_FAILURE' in resultado.stderr or 'ACCESS_DENIED' in resultado.stderr:
                    continue

            except TrazabilidadExcepciones.ERRORES_SISTEMA as exc:
                if self.logger:
                    self.logger.warning('Acceso directo SMB: %s', exc)
                continue

        return False, {
            'error': 'No se pudo acceder con ninguna configuración de seguridad',
            'intentos': len(opciones_prueba),
            'recomendacion': 'Verificar permisos del usuario en el servidor SMB',
        }


_RUTAS_WINDOWS = (
    Path(r'D:\sri\soluciones\DatosAbiertosEF\datosabiertos'),
    Path(r'D:\sri\soluciones\idat\datosabiertos'),
    Path(r'D:\SRI\Soluciones\datosabiertos'),
)
_RUTA_LINUX = Path('/home/python/sri_datos_abiertos_facturacion')


def _buscar_primera_ruta_valida(candidatos: Iterable[Path], subcarpeta: str = 'config') -> Optional[Path]:
    """Retorna el primer candidato que contenga la subcarpeta indicada."""
    for candidato in candidatos:
        if (candidato / subcarpeta).exists():
            return candidato
    return None


def resolver_raiz_proyecto(ruta_modulo: Optional[Path] = None) -> Path:
    """Resuelve la raiz del proyecto (PyInstaller frozen o desarrollo).

    Criterio unico de deteccion compartido por main y da_config_manager
    (Regla 43 SRI: no duplicar la logica de rutas). En modo frozen la
    raiz es la carpeta del binario (o su padre si el binario esta en
    dist/ dentro del proyecto). Nunca se busca en rutas fijas del
    servidor: el ejecutable es portable y usa solo su propia config/.

    Args:
        ruta_modulo: __file__ del modulo llamante en modo desarrollo.
            Si es None se usa el cwd como punto de partida.

    Retorna:
        Path a la raiz del proyecto.
    """
    if getattr(sys, 'frozen', False):
        dir_exe = Path(sys.executable).parent.resolve()
        candidatos = (dir_exe, dir_exe.parent)

        raiz_frozen = _buscar_primera_ruta_valida(candidatos, 'config')
        return raiz_frozen if raiz_frozen else dir_exe

    ruta_base = Path(ruta_modulo).parent.parent if ruta_modulo is not None else Path.cwd()

    if (ruta_base / 'config').exists() or (ruta_base / 'app').exists():
        return ruta_base

    candidatos_sistema = (_RUTA_LINUX, *_RUTAS_WINDOWS)
    raiz_sistema = _buscar_primera_ruta_valida(candidatos_sistema, '')

    return raiz_sistema if raiz_sistema else ruta_base


def expandir_variables_entorno(texto: str) -> str:
    """Expandir variables tipo $VAR o ${VAR} usando os.environ.

    Utilidad compartida para evitar duplicar la lógica de expansión entre
    da_parametros_oracle y da_config_manager (Regla 43 SRI: codigo comun).

    Args: texto: Cadena con posibles referencias a variables de entorno.

    Returns: Cadena con las variables reemplazadas por su valor en os.environ.
    """
    patron = r'\$([A-Za-z_]\w*)|\$\{([A-Za-z_]\w*)\}'

    def reemplazar(coincidencia):
        """Sustituye una coincidencia $VAR/${VAR} por su valor en os.environ."""
        nombre = coincidencia.group(1) or coincidencia.group(2)
        return os.environ.get(nombre, coincidencia.group(0))

    return re.sub(patron, reemplazar, texto, flags=re.ASCII)


def resolver_referencia_password(referencia: str, logger: logging.Logger) -> str:
    """Resuelve una referencia de clave sin acceso a red.

    Utilidad compartida (Regla 43 SRI). Formatos admitidos (todos locales,
    sin VAULT ni servicios externos):
      $NOMBRE_VAR   -> lee la variable de entorno local del SO
      ${NOMBRE_VAR} -> idem, sintaxis con llaves
      texto_plano   -> retorna tal cual

    Args: referencia: Texto plano o referencia $VAR desde el TOML.
        logger: Logger compartido para advertir si la variable no existe.

    Returns:
        Contraseña resuelta o cadena vacía si la variable no existe.
    """
    if not referencia:
        return ''

    if referencia.startswith('$'):
        nombre = referencia.lstrip('$').strip('{}')
        valor = os.environ.get(nombre, '')
        if not valor:
            logger.warning(
                'Variable de entorno %s no definida. '
                'Definirla con: export %s=valor (Linux) o setx %s valor (Windows)',
                nombre, nombre, nombre
            )
        return valor

    return referencia


def cargar_clave_privada(key_file: str, password: Optional[str] = None) -> Any:
    """Carga una clave privada SSH detectando su tipo automaticamente.

    Utilidad compartida (Regla 43 SRI) para exportador, validador y
    transferencia. La clave de produccion sri_datos_abiertos_key es
    ed25519; paramiko.RSAKey.from_private_key_file lanza SSHException
    con claves que no son RSA, por lo que se prueban los tipos en orden:
    Ed25519 -> RSA -> ECDSA.

    Args: key_file: Ruta al archivo de clave privada (formato OpenSSH/PEM).
        password: Passphrase de la clave, o None si no tiene.

    Returns: Instancia de paramiko.PKey lista para Transport.connect(pkey=...).

    Raises: ValueError: Si paramiko no esta instalado o ningun tipo de clave
                    pudo cargar el archivo.
    """
    if not PARAMIKO_DISPONIBLE:
        raise ValueError('paramiko no esta instalado: pip install paramiko')

    ultimo_error: Optional[Exception] = None
    for clase in paramiko.Ed25519Key, paramiko.RSAKey, paramiko.ECDSAKey:
        try:
            return clase.from_private_key_file(key_file, password=password or None)
        except paramiko.PasswordRequiredException:
            raise
        except paramiko.SSHException as exc:
            ultimo_error = exc

    raise ValueError(
        f'No se pudo cargar la clave privada {key_file} '
        f'(tipos probados: Ed25519, RSA, ECDSA): {ultimo_error}'
    )
