# -*- coding: utf-8 -*-
"""Gestor centralizado de configuracion desde archivos TOML.

app-da_config_manager.py

Detecta automaticamente la plataforma y carga el TOML apropiado:
  - Linux   -> configlnx.toml
  - Windows -> configwin.toml
  - Fallback -> config.toml

Toda la configuracion de rutas, credenciales y servidores reside
en el TOML. Ningun valor quemado en el codigo (Regla 2 SRI).

NOTA PYINSTALLER: Cuando corre como ejecutable frozen, usa
sys.executable para determinar la ruta base (no __file__ que
apuntaria al temp /tmp/_MEIxxxxxx).

Historial:
+--------------------+---------+------------------------------------------+
| Autor              | Version | Cambios                                  |
+--------------------+---------+------------------------------------------+
| Jim A. Gonzalez    | 1.0.0   | Soporte basico TOML y Windows            |
| Jim A. Gonzalez    | 2.0.0   | Soporte Linux RHEL 10, wallet, variables |
| Jim A. Gonzalez    | 2.1.0   | Deteccion dinamica configlnx.toml        |
| Jim A. Gonzalez    | 3.0.0   | Servidores descarga, verificacion remota |
| Jim A. Gonzalez    | 3.1.0   | Deteccion PyInstaller frozen (sys.executable)|
| Jim A. Gonzalez    | 3.2.0   | network_admin en spark, config de prueba |
|                    |         | de consultas [prueba_consultas]          |
| Jim A. Gonzalez    | 3.3.0   | Rutas relativas del TOML se resuelven    |
|                    |         | contra la raiz (ejecutable portable)     |
+--------------------+---------+------------------------------------------+
"""

import logging
from pathlib import Path
import platform
from typing import Any, Dict, List, Optional

try:
    import tomllib
except ImportError:
    import tomli as tomllib

try:
    from pyspark.sql import SparkSession
    HAS_PYSPARK = True
except ImportError:
    SparkSession = None
    HAS_PYSPARK = False

from app.da_comunes import (
    expandir_variables_entorno,
    resolver_raiz_proyecto,
    resolver_referencia_password,
)
from app.da_parametros_oracle import ParametrosOracle


def _log_modulo(level: int, msg: str, *args: object) -> None:
    """Registra eventos de carga del modulo (antes de instanciar clases)."""
    logging.getLogger(__name__).log(level, msg, *args)


if not HAS_PYSPARK:
    _log_modulo(
        logging.WARNING,
        'pyspark no disponible, no se puede leer desde Oracle. Usando solo el TOML.'
    )


class ConfigManager:
    """Gestor centralizado de configuracion TOML.

    Auto-detecta plataforma (Windows/Linux) y carga el archivo TOML
    apropiado. Compatible con el instalador v4.4 de Linux.

    NOTA: En modo PyInstaller frozen, la ruta base se detecta via
    sys.executable (directorio del binario), no via __file__.
    """

    def __init__(self, ruta_toml: Optional[str], logger: logging.Logger):
        """Inicializa el gestor detectando la ruta base y el TOML activo.

        Args:
            ruta_toml: Ruta explicita al TOML (sobreescribe la deteccion).
            logger: Logger compartido inyectado desde el punto de entrada.
        """
        self._logger = logger
        self.ruta_base = self._detectar_ruta_base()
        self.ruta_toml = Path(ruta_toml) if ruta_toml else self._detectar_archivo_config()
        self._config: Dict[str, Any] = {}
        self._cargar_toml()

    def _log(self, level: int, msg: str, *args: object, exc_info: bool = False) -> None:
        """Registra un mensaje con formato lazy % para compatibilidad con Pylint."""
        self._logger.log(level, msg, *args, exc_info=exc_info)

    # -- Deteccion de rutas ------------------------------------------

    @staticmethod
    def _detectar_ruta_base() -> Path:
        """Detecta la ruta base del proyecto en orden de prioridad.

        Delega en da_comunes.resolver_raiz_proyecto para no duplicar la
        logica de deteccion de rutas (Regla 43 SRI). Pasa __file__ para
        que en desarrollo la raiz se calcule subiendo desde app/.

        Returns:
            Path a la raiz del proyecto.
        """
        return resolver_raiz_proyecto(Path(__file__))

    def _detectar_archivo_config(self) -> Path:
        """Selecciona el archivo TOML segun la plataforma detectada.

        Returns:
            Path al archivo de configuracion activo.
        """
        directorio = self.ruta_base / 'config'
        sistema = platform.system()
        nombres_por_sistema = {
            'Linux': 'configlnx.toml',
            'Windows': 'configwin.toml',
        }

        seleccionado: Optional[Path] = None
        nombre_plataforma = nombres_por_sistema.get(sistema)
        if nombre_plataforma:
            candidato = directorio / nombre_plataforma
            if candidato.exists():
                self._log(logging.INFO, '%s — usando: %s', sistema, candidato)
                seleccionado = candidato
            else:
                self._log(logging.INFO, '%s — %s no encontrado, intentando config.toml', sistema, nombre_plataforma)

        if seleccionado is None:
            config_default = directorio / 'config.toml'
            if config_default.exists():
                self._log(logging.INFO, 'Usando config.toml generico: %s', config_default)
            else:
                self._log(
                    logging.WARNING,
                    'No se encontro ningun archivo de configuracion en %s '
                    '(configlnx.toml / configwin.toml / config.toml)',
                    directorio
                )
            seleccionado = config_default

        return seleccionado

    # -- Carga y procesamiento ---------------------------------------

    def _cargar_toml(self) -> None:
        """Carga la configuracion activa segun fuente_config del TOML.

        Flujo:
          1. Siempre se lee el TOML (base obligatoria).
          2. Si fuente_config = "oracle" o "ambos" (y forzar_toml = false),
             se complementa con parametros de la tabla ADM.ADM_PARAMETRO_AMBIENTE.
             Las secciones spark, rutas y destino_default siempre vienen del TOML.
          3. Si fuente_config = "toml" o forzar_toml = true -> solo el TOML.
        """
        if not self.ruta_toml.exists():
            raise FileNotFoundError(f'Archivo de configuracion no encontrado: {self.ruta_toml}')

        try:
            with open(self.ruta_toml, 'rb') as archivo:
                config_crudo = tomllib.load(archivo)

            self._config = self._procesar_config(config_crudo)

            fuente = self._config.get('general', {}).get('fuente_config', 'toml')
            forzado = self._config.get('general', {}).get('forzar_toml', False)
            self._log(logging.INFO, 'Configuracion cargada: %s', self.ruta_toml)
            self._log(logging.INFO, 'Fuente: %s', 'TOML (forzado)' if forzado else fuente)

            if not forzado and fuente in {'oracle', 'ambos'}:
                self._cargar_desde_oracle()

        except (OSError, ValueError) as ex:
            self._log(logging.ERROR, 'Error cargando configuracion %s', ex, exc_info=True)
            raise

    def _cargar_desde_oracle(self) -> None:
        """Complementa la configuracion con parametros de la tabla Oracle ADM.

        Requiere en el TOML: [oracle] jdbc_url, codigo_aplicacion, ambiente.
        Requiere: [spark] url y wallet_path para conectar.

        Secciones que Oracle puede proveer: email, verificacion,
        servidor_descarga_1, servidor_descarga_2.
        Secciones que SIEMPRE vienen del TOML: spark, rutas, destino_default.
        """
        if not HAS_PYSPARK:
            return

        oracle_cfg = self._config.get('oracle', {})
        spark_cfg = self._config.get('spark', {})

        jdbc_url = oracle_cfg.get('jdbc_url') or spark_cfg.get('jdbc_url', '')
        wallet_path = spark_cfg.get('wallet_path', '')
        spark_url = spark_cfg.get('url', '')
        codigo_app = oracle_cfg.get('codigo_aplicacion', 'DAT')
        ambiente = oracle_cfg.get('ambiente', 'PRO')

        if not jdbc_url or not spark_url:
            self._log(
                logging.WARNING,
                'No se puede consultar Oracle: '
                'falta spark.url o oracle.jdbc_url en el TOML.'
            )
            return

        try:
            self._log(logging.INFO, 'Conectando Spark para leer parametros Oracle...')
            spark = SparkSession.builder \
                .appName("sri_datos_abiertos") \
                .remote(spark_url) \
                .getOrCreate()

            lector = ParametrosOracle(spark, jdbc_url, wallet_path, self._logger)
            params_oracle = lector.obtener_todos_parametros(codigo_app, ambiente)

            secciones_oracle = {'email', 'verificacion', 'servidor_descarga_1', 'servidor_descarga_2'}
            for seccion, valor in params_oracle.items():
                if seccion in secciones_oracle and isinstance(valor, dict):
                    self._config[seccion] = valor
                    self._log(logging.INFO, 'Parametro %s obtenido desde Oracle', seccion)

            spark.stop()
            self._log(logging.INFO, 'Configuracion complementada desde Oracle (%s/%s)', codigo_app, ambiente)

        except (RuntimeError, OSError, ValueError, AttributeError, KeyError) as exc:
            self._log(logging.WARNING, 'Error leyendo parametros Oracle: %s. Se continua con la configuracion del TOML.', exc)

    def _procesar_config(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Expandir variables de entorno recursivamente en toda la configuracion.

        Args:
            config: Diccionario crudo del TOML.

        Returns:
            Diccionario con variables de entorno expandidas.
        """
        resultado: Dict[str, Any] = {}
        for clave, valor in config.items():
            if isinstance(valor, dict):
                resultado[clave] = self._procesar_config(valor)
            elif isinstance(valor, list):
                resultado[clave] = [
                    self._procesar_config(item) if isinstance(item, dict)
                    else self._expandir_variables(item)
                    for item in valor
                ]
            else:
                resultado[clave] = self._expandir_variables(valor)
        return resultado

    @staticmethod
    def _expandir_variables(texto: Any) -> Any:
        """Reemplaza $VAR o ${VAR} con valores de os.environ.

        Delega en da_comunes.expandir_variables_entorno para el caso str;
        los valores no-str se retornan sin cambios (Regla 43 SRI: codigo comun).

        Args:
            texto: Valor a procesar (solo se procesa si es str).

        Returns:
            Texto con variables expandidas o el valor original.
        """
        if not isinstance(texto, str):
            return texto
        return expandir_variables_entorno(texto)

    def _resolver_password(self, referencia: str) -> str:
        """Resuelve una referencia de contrasena sin acceso a red.

        Delega en da_comunes.resolver_referencia_password para evitar
        duplicar la logica (Regla 43 SRI).

        Args:
            referencia: Texto plano o referencia $VAR desde el TOML.

        Returns:
            Contrasena resuelta o cadena vacia si la variable no existe.
        """
        return resolver_referencia_password(referencia, self._logger)

    # -- Getters publicos --------------------------------------------

    def get(self, seccion: str, default: Any = None) -> Any:
        """Retorna una seccion completa del TOML."""
        return self._config.get(seccion, default)

    def get_spark_config(self) -> Dict[str, Any]:
        """Retorna la configuracion de Spark directamente desde el TOML."""
        spark = self._config.get('spark', {})
        wallet = self._config.get('wallet', {})
        ruta_wallet = wallet.get('wallet_path') or spark.get('wallet_path', '')

        if not ruta_wallet:
            self._log(logging.WARNING, 'spark.wallet_path no definido en %s. Declararlo en el TOML es obligatorio.', self.ruta_toml)

        return {
            'spark_url':          spark.get('url', ''),
            'wallet_path':        ruta_wallet,
            'network_admin':      wallet.get('network_admin') or ruta_wallet,
            'oracle_home':        spark.get('oracle_home', ''),
            'jdbc_url':           spark.get('jdbc_url', ''),
            'partitions_default': spark.get('partitions_default', 16),
            'fetch_size':         spark.get('fetch_size', 500000),
            'driver_memory':      spark.get('driver_memory', '8g'),
            'executor_memory':    spark.get('executor_memory', '8g'),
        }

    def get_email_config(self) -> Dict[str, Any]:
        """Retorna la configuracion de correo. Las claves se resuelven desde el TOML."""
        email = self._config.get('email', {})
        return {
            'smtp_server':  email.get('smtp_server', ''),
            'smtp_port':    email.get('smtp_port', 25),
            'timeout':      email.get('timeout', 15),
            'username':     email.get('username', ''),
            'password':     self._resolver_password(email.get('password', '')),
            'from_address': email.get('from_address', 'datosabiertos@localhost'),
            'to_addresses': email.get('to_addresses', ['admin@localhost']),
            'use_tls':      email.get('use_tls', False),
        }

    def _ruta_absoluta(self, valor: str) -> Path:
        """Expande variables y resuelve una ruta relativa contra la raiz del proyecto."""
        ruta = Path(self._expandir_variables(valor))
        return ruta if ruta.is_absolute() else self.ruta_base / ruta

    def get_rutas(self) -> Dict[str, Any]:
        """Retorna rutas como objetos Path con creacion automatica de directorios."""
        rutas = self._config.get('rutas', {})
        base = self.ruta_base

        consultas = self._ruta_absoluta(rutas.get('consultas', 'data/input/consultas'))
        temp = self._ruta_absoluta(rutas.get('temp_local', 'temp'))
        logs = self._ruta_absoluta(rutas.get('log_dir', 'logs'))
        destino_local = self._ruta_absoluta(rutas.get('destino_local', 'data/output'))
        mails = base / 'mails_enviados'

        for directorio in [temp, logs, destino_local, mails]:
            directorio.mkdir(parents=True, exist_ok=True)

        return {
            'consultas':     consultas,
            'temp':          temp,
            'logs':          logs,
            'destino_local': destino_local,
            'mails':         mails,
            'base':          base,
        }

    def get_destino_default(self) -> Dict[str, Any]:
        """Retorna la configuracion del destino local (paso 1 del flujo)."""
        destino = self._config.get('destino_default', {})
        tipo = destino.get('tipo', 'local')

        config: Dict[str, Any] = {
            'tipo': tipo,
            'directorio_remoto': destino.get(
                'directorio_remoto',
                str(self.ruta_base / 'destino_local')
            ),
        }

        if tipo == 'smb' and 'smb' in destino:
            smb = destino['smb']
            config.update({
                'host':     smb.get('host'),
                'puerto':   smb.get('puerto', 445),
                'share':    smb.get('share'),
                'usuario':  smb.get('usuario'),
                'password': self._resolver_password(smb.get('password', '')),
                'dominio':  smb.get('dominio', ''),
            })
        elif tipo == 'sftp' and 'sftp' in destino:
            sftp = destino['sftp']
            config.update({
                'host':     sftp.get('host'),
                'puerto':   sftp.get('puerto', 22),
                'usuario':  sftp.get('usuario'),
                'password': self._resolver_password(sftp.get('password', '')),
                'key_file': sftp.get('key_file'),
            })

        return config

    def get_servidores_descarga(self) -> List[Dict[str, Any]]:
        """Retorna la lista de servidores de descarga configurados.

        Lee secciones [servidor_descarga_1], [servidor_descarga_2]... dinamicamente.

        Returns:
            Lista de diccionarios con ip, ruta_remota, usuario, credenciales.
        """
        servidores: List[Dict[str, Any]] = []
        numero = 1

        while True:
            clave = f'servidor_descarga_{numero}'
            seccion = self._config.get(clave)
            if not seccion:
                break
            servidores.append({
                'nombre':      seccion.get('nombre', f'Servidor {numero}'),
                'ip':          seccion.get('ip', ''),
                'ruta_remota': seccion.get('ruta_remota', ''),
                'usuario':     seccion.get('usuario', ''),
                'password':    self._resolver_password(seccion.get('password', '')),
                'key_file':    seccion.get('key_file', ''),
                'puerto':      seccion.get('puerto', 22),
            })
            numero += 1

        if not servidores:
            self._log(logging.WARNING, 'No se encontraron secciones [servidor_descarga_N] en el TOML')

        return servidores

    def get_verificacion_config(self) -> Dict[str, Any]:
        """Retorna la configuracion para el subcomando verificar."""
        ver = self._config.get('verificacion', {})
        return {
            'patrones_archivos':    ver.get('patrones_archivos', []),
            'tamanio_minimo_bytes': ver.get('tamanio_minimo_bytes', 1024),
        }

    def get_prueba_consultas_config(self) -> Dict[str, Any]:
        """Retorna la configuracion de la prueba previa de consultas.

        modo: 'una_fila' ejecuta la consulta limitada a 1 fila;
              'estructura' solo valida objetos, permisos y columnas
              (WHERE 1 = 0, sin leer datos).
        """
        prueba = self._config.get('prueba_consultas', {})
        return {
            'modo':             prueba.get('modo', 'una_fila'),
            'timeout_segundos': int(prueba.get('timeout_segundos', 600)),
        }

    def get_oracle_config(self) -> Dict[str, Any]:
        """Retorna parametros Oracle (tabla ADM). Solo si fuente_config != 'toml'."""
        return self._config.get('oracle', {})

    def debe_usar_oracle(self) -> bool:
        """Indica si se debe consultar Oracle para parametros."""
        if self._config.get('general', {}).get('forzar_toml', False):
            return False
        fuente = self._config.get('general', {}).get('fuente_config', 'toml')
        return fuente in {'oracle', 'ambos'}

    def get_raw_config(self) -> Dict[str, Any]:
        """Retorna la configuracion cruda completa (util para diagnostico)."""
        return self._config.copy()


def get_config_manager(ruta_toml: Optional[str], logger: logging.Logger) -> ConfigManager:
    """Retorna la instancia singleton del ConfigManager.

    El singleton se reusa entre llamadas, pero si se solicita una ruta
    TOML distinta a la cacheada (por ejemplo con --config), la instancia
    se recrea para respetar la ruta explicita. Sin este reemplazo, el flag
    --config quedaba ignorado tras la primera carga (bug v3.0.1).

    La instancia se cachea como atributo de la propia funcion
    (get_config_manager.instancia), evitando una variable global de modulo
    y los disables de Pylint asociados.

    Args:
        ruta_toml: Ruta explicita al TOML. Si difiere de la cargada,
                   fuerza la recreacion de la instancia.
        logger: Logger compartido inyectado desde el punto de entrada.

    Returns:
        Instancia de ConfigManager para la ruta solicitada.
    """
    instancia = getattr(get_config_manager, 'instancia', None)

    if instancia is None:
        instancia = ConfigManager(ruta_toml, logger)
    elif ruta_toml is not None:
        ruta_pedida = Path(ruta_toml).resolve()
        if ruta_pedida != instancia.ruta_toml.resolve():
            logger.info(
                'Ruta TOML distinta solicitada (%s != %s). Recargando configuracion.',
                ruta_pedida, instancia.ruta_toml
            )
            instancia = ConfigManager(ruta_toml, logger)

    get_config_manager.instancia = instancia
    return instancia


def reiniciar_config_manager() -> None:
    """Limpia el singleton. Util en pruebas unitarias para aislar casos."""
    get_config_manager.instancia = None
