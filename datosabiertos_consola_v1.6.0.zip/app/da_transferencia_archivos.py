# -*- coding: utf-8 -*-
"""Transferencia de archivos multi-protocolo: Local, SMB y SFTP.

app-da_transferencia_archivos.py

Toda la configuración de credenciales llega por parámetro, ningún
valor quemado en el código (Regla 2 del estándar SRI).

Historial de versiones:
  * 1.0.0 (Jim A. González): SMB básico y copia local.
  * 2.0.0 (Jim A. González): smbprotocol puro, soporte SFTP.
  * 3.0.0 (Jim A. González): Config unificada, resolución VAULT.
  * 4.0.0 (Jim A. González): Soporte multiplataforma, chunked upload.
"""

from datetime import datetime
import logging
import os
from pathlib import Path
import shutil
from typing import Any, Dict, Optional
import uuid

from app.da_comunes import cargar_clave_privada

try:
    from smbprotocol.connection import Connection
    from smbprotocol.session import Session
    from smbprotocol.tree import TreeConnect
    from smbprotocol.open import (
        Open, FilePipePrinterAccessMask,
        CreateDisposition, FileAttributes,
        ImpersonationLevel, ShareAccess, CreateOptions
    )
    SMB_DISPONIBLE = True
except ImportError:
    SMB_DISPONIBLE = False

try:
    import paramiko
    SFTP_DISPONIBLE = True
except ImportError:
    SFTP_DISPONIBLE = False

_BYTES_EN_MB = 1024 * 1024


class TransferenciaArchivos:
    """Transfiere archivos a destinos remotos (SMB, SFTP o local)."""

    def __init__(self, credenciales: Dict[str, Any], logger: logging.Logger):
        """
        Inicializa el transferidor con el mapa de credenciales.

        Args:
            credenciales: Diccionario con secciones 'smb' y/o 'sftp'.
            logger: Logger compartido inyectado desde el punto de entrada.
        """
        self._credenciales = credenciales
        self._logger = logger
        self.ultimo_resultado: Dict[str, Any] = {}

    def _log(self, level: int, msg: str, *args: object, exc_info: bool = False) -> None:
        """Registra un mensaje con formato lazy % para compatibilidad con Pylint."""
        self._logger.log(level, msg, *args, exc_info=exc_info)

    def transferir(self, archivo_local: str, destino: Dict[str, Any], nombre_destino: Optional[str] = None) -> Dict[str, Any]:
        """
        Transfiere un archivo según la configuración de destino.

        Args:
            archivo_local: Ruta completa al archivo origen (CSV o ZIP).
            destino: Configuración con tipo, host, puerto, directorio, etc.
            nombre_destino: Nombre alternativo en el destino.

        Returns:
            Diccionario con exito, tipo, tamanio_mb, mensaje, timestamp.
        """
        tipo = destino.get('tipo', 'local').lower()
        ruta_archivo = Path(archivo_local)

        if not ruta_archivo.exists():
            raise FileNotFoundError(f'Archivo no encontrado: {archivo_local}')

        nombre = nombre_destino or ruta_archivo.name
        tamanio = ruta_archivo.stat().st_size

        resultado: Dict[str, Any] = {
            'exito': False,
            'tipo': tipo,
            'archivo_origen': str(archivo_local),
            'archivo_destino': nombre,
            'tamanio_bytes': tamanio,
            'tamanio_mb': round(tamanio / _BYTES_EN_MB, 2),
            'mensaje': '',
            'timestamp': datetime.now().isoformat(),
        }

        try:
            if tipo == 'local':
                resultado = self._copia_local(ruta_archivo, destino, nombre, resultado)
            elif tipo == 'smb':
                if not SMB_DISPONIBLE:
                    raise ImportError('Instale: pip install smbprotocol')
                resultado = self._copia_smb(ruta_archivo, destino, nombre, resultado)
            elif tipo == 'sftp':
                if not SFTP_DISPONIBLE:
                    raise ImportError('Instale: pip install paramiko')
                resultado = self._copia_sftp(ruta_archivo, destino, nombre, resultado)
            else:
                raise ValueError(f'Tipo de transferencia no soportado: {tipo}')

        except (OSError, ValueError, ImportError) as exc:
            resultado['mensaje'] = f'ERROR: {exc}'
            self._log(logging.ERROR, 'Error en transferencia %s: %s', tipo, exc, exc_info=True)

        self.ultimo_resultado = resultado
        return resultado

    def _copia_local(self, archivo: Path, destino: Dict[str, Any], nombre: str, resultado: Dict[str, Any]) -> Dict[str, Any]:
        """
        Copia el archivo a un directorio local o de red mapeado.

        Args:
            archivo: Ruta al archivo origen.
            destino: Configuración de destino.
            nombre: Nombre del archivo en destino.
            resultado: Diccionario base de resultado.

        Returns:
            Diccionario de resultado actualizado.
        """
        directorio = Path(destino['directorio_remoto'])
        directorio.mkdir(parents=True, exist_ok=True)

        ruta_final = directorio / nombre
        shutil.copy2(archivo, ruta_final)

        resultado['exito'] = True
        resultado['ruta_destino'] = str(ruta_final)
        resultado['mensaje'] = f'Copia local exitosa: {ruta_final}'
        self._log(logging.INFO, 'Transferencia local exitosa: %s', ruta_final)
        return resultado

    def _copia_smb(self, archivo: Path, destino: Dict[str, Any], nombre: str, resultado: Dict[str, Any]) -> Dict[str, Any]:
        """
        Copia el archivo usando protocolo SMB (Windows shares).

        Args:
            archivo: Ruta al archivo origen.
            destino: Configuración de destino con host, share, usuario.
            nombre: Nombre del archivo en destino.
            resultado: Diccionario base de resultado.

        Returns:
            Diccionario de resultado actualizado.
        """
        host = destino['host']
        puerto = destino.get('puerto', 445)
        share = destino.get('share', 'compartido')
        directorio = destino['directorio_remoto'].replace('/', '\\')

        creds = self._credenciales.get('smb', {}).get(
            destino.get('credencial_key', 'default'), {}
        )
        usuario = creds.get('usuario', '')
        password = creds.get('password', '')
        dominio = creds.get('dominio', '')

        conn = Connection(uuid.uuid4().hex, host, puerto)
        conn.connect()

        try:
            sesion = Session(conn, usuario, password, dominio)
            sesion.connect()

            arbol = TreeConnect(sesion, f'\\\\{host}\\{share}')
            arbol.connect()

            ruta_remota = f'{directorio}\\{nombre}'
            archivo_smb = Open(arbol, ruta_remota)
            archivo_smb.create(
                impersonation_level=ImpersonationLevel.Impersonation,
                desired_access=FilePipePrinterAccessMask.GENERIC_WRITE,
                file_attributes=FileAttributes.FILE_ATTRIBUTE_NORMAL,
                share_access=ShareAccess.FILE_SHARE_WRITE,
                create_disposition=CreateDisposition.FILE_OVERWRITE_IF,
                create_options=CreateOptions.FILE_NON_DIRECTORY_FILE,
            )

            with open(archivo, 'rb') as flujo:
                contenido = flujo.read()
                archivo_smb.write(contenido, 0)

            archivo_smb.close()
            arbol.disconnect()
            sesion.disconnect()

            resultado['exito'] = True
            resultado['ruta_destino'] = f'\\\\{host}\\{share}{directorio}\\{nombre}'
            resultado['mensaje'] = f'Transferencia SMB exitosa a {host}'
            self._log(logging.INFO, 'Transferencia SMB exitosa: %s', host)

        finally:
            conn.disconnect()

        return resultado

    def _copia_sftp(self, archivo: Path, destino: Dict[str, Any], nombre: str, resultado: Dict[str, Any]) -> Dict[str, Any]:
        """
        Copia el archivo usando SFTP (SSH).

        Args:
            archivo: Ruta al archivo origen.
            destino: Configuración de destino con host, puerto, usuario.
            nombre: Nombre del archivo en destino.
            resultado: Diccionario base de resultado.

        Returns:
            Diccionario de resultado actualizado.
        """
        host = destino['host']
        puerto = destino.get('puerto', 22)
        directorio_remoto = destino['directorio_remoto']

        creds = self._credenciales.get('sftp', {}).get(
            destino.get('credencial_key', 'default'), {}
        )
        usuario = creds.get('usuario')
        password = creds.get('password')
        key_file = creds.get('key_file')

        transporte = paramiko.Transport((host, puerto))
        transporte.banner_timeout = 15
        transporte.auth_timeout = 15

        if key_file and os.path.exists(key_file):
            clave_privada = cargar_clave_privada(key_file, password)
            transporte.connect(username=usuario, pkey=clave_privada)
        else:
            transporte.connect(username=usuario, password=password)

        sftp = paramiko.SFTPClient.from_transport(transporte)

        try:
            try:
                sftp.chdir(directorio_remoto)
            except IOError:
                sftp.mkdir(directorio_remoto)
                sftp.chdir(directorio_remoto)

            ruta_final = f'{directorio_remoto}/{nombre}'
            sftp.put(str(archivo), ruta_final)

            resultado['exito'] = True
            resultado['ruta_destino'] = f'sftp://{host}:{puerto}{ruta_final}'
            resultado['mensaje'] = f'Transferencia SFTP exitosa a {host}'
            self._log(logging.INFO, 'Transferencia SFTP exitosa: %s', host)

        finally:
            sftp.close()
            transporte.close()

        return resultado
