# -*- coding: utf-8 -*-

"""Conexion a la base de datos.

# app/da_conexion_bdd.py

╠═════════════════════════════════════════════════════════════════════════════════════════════╣
║  CONFIGURACIÓN WALLET REQUERIDA:                                                            ║
║  • tnsnames.ora: Definición de aliases de conexión                                          ║
║  • cwallet.sso: Almacén seguro de credenciales (auto-login)                                 ║
║  • sqlnet.ora: Configuración de autenticación (WALLET_ROOT, etc.)                           ║
╚═════════════════════════════════════════════════════════════════════════════════════════════╝


HISTORIAL DE CAMBIOS:
+----------------------+---------+------------------------------------------------------------+

| Autor                | Versión | Cambios                                                    |
+----------------------+---------+------------------------------------------------------------+

| Jim A. González      | 1.0.0   | Versión Grafica   REACT + FASTAPI                          |
| Jim A. González      | 1.0.1   | Version DOS - procesamiento, zip,copia remota + envio mail |
| Jim A. González      | 1.0.2   | Sesion Spark comun; SQL con SQLAlchemy Core y agregacion   |
|                      |         | Spark (sin SQL armado por texto)                           |
|                      |         |                                                            |
+----------------------+---------+------------------------------------------------------------+
"""

import ast
from concurrent.futures import ThreadPoolExecutor
import json
import logging
import os
from pathlib import Path
import platform
import time
from typing import Any, Dict, Optional, Tuple

import oracledb
import pandas as pd
from pydantic import BaseModel, ConfigDict, Field
from pyspark.sql import functions as fn
from pyspark.sql import SparkSession
from sqlalchemy import and_, column, create_engine, literal_column, select, table
from sqlalchemy.exc import SQLAlchemyError

from app.da_comunes import ConexionParams
from app.da_excepciones import TrazabilidadExcepciones
from app.da_sesion_spark import crear_sesion_spark, opciones_jdbc


class TrazabilidadConexionBDD(BaseModel):
    """Conexión Oracle nativa con pool de sesiones y wallet."""

    model_config = ConfigDict(arbitrary_types_allowed=True)
    conexion_params: ConexionParams
    _pool: Optional[oracledb.SessionPool] = None
    _executor: Optional[ThreadPoolExecutor] = None
    logger: logging.Logger = Field(default=None, exclude=True)

    # Configuración de wallet
    WALLET_PATH: Optional[str] = Field(default=None, exclude=True)
    ORACLE_HOME: Optional[str] = Field(default=None, exclude=True)
    DSN: str = Field(default="STAR_BI_DWH", exclude=True)

    def __init__(self, logger_in: logging.Logger, **data):
        """Inicializa la conexión Oracle nativa con pool y executor."""
        super().__init__(**data)
        self.logger = logger_in
        self._configuracion_oracle_client()
        self._executor = ThreadPoolExecutor(max_workers=min(4, self.conexion_params.max_workers))

    def _log(self, level: int, msg: str, *args: object, exc_info: bool = False) -> None:
        """Registra un mensaje con formato lazy % para compatibilidad con Pylint."""
        self.logger.log(level, msg, *args, exc_info=exc_info)

    def _configuracion_oracle_client(self):
        """Configura variables de entorno Oracle según plataforma."""
        sistema = platform.system()

        if sistema == "Windows":
            wallet_path = self.WALLET_PATH or os.environ.get('TNS_ADMIN', r"D:/oracle/waldec25")
            oracle_home = self.ORACLE_HOME or os.environ.get('ORACLE_HOME', r"D:/softapps/ora21cli/oraclient")

            os.environ['TNS_ADMIN'] = wallet_path
            os.environ['ORACLE_HOME'] = oracle_home

            self._log(logging.INFO, " Windows - TNS_ADMIN: %s", os.environ['TNS_ADMIN'])
            self._log(logging.INFO, " Windows - ORACLE_HOME: %s", os.environ['ORACLE_HOME'])

            return

        tns_admin = os.environ.get('TNS_ADMIN')
        oracle_home = os.environ.get('ORACLE_HOME')

        if not tns_admin:
            installer_wallet = Path('/opt/oracle/wallets')
            if installer_wallet.exists():
                tns_admin = str(installer_wallet)
                os.environ['TNS_ADMIN'] = tns_admin

        if tns_admin:
            self._log(logging.INFO, "🐧 Linux - Usando TNS_ADMIN: %s", tns_admin)
        else:
            self._log(logging.WARNING, "🐧 Linux - TNS_ADMIN no configurado")

        if oracle_home:
            self._log(logging.INFO, "🐧 Linux - Usando ORACLE_HOME: %s", oracle_home)
        else:
            self._log(logging.WARNING, "🐧 Linux - ORACLE_HOME no configurado")

        try:
            oracledb.init_oracle_client()
            self._log(logging.INFO, "✅ Cliente Oracle inicializado")
        except (oracledb.DatabaseError, oracledb.InterfaceError) as exc:
            self._log(logging.WARNING, "⚠️ Cliente Oracle ya inicializado o error: %s", exc)

    @property
    def pool(self):
        """Lazy loading del pool de conexiones."""
        if self._pool is None:
            try:
                pool_params = {
                    "dsn": self.DSN,
                    "min": self.conexion_params.min_,
                    "max": self.conexion_params.max_,
                    "increment": self.conexion_params.increment,
                    "getmode": oracledb.POOL_GETMODE_WAIT,
                    "wait_timeout": self.conexion_params.wait_timeout,
                    "timeout": self.conexion_params.timeout,
                    "max_lifetime_session": self.conexion_params.max_lifetime_session,
                    "ping_interval": 60,
                    "externalauth": True,
                    "homogeneous": False
                }
                self._pool = oracledb.SessionPool(**pool_params)
                self._log(logging.INFO, "✅ Pool creado: %s-%s conexiones", self.conexion_params.min_, self.conexion_params.max_)
            except oracledb.Error as exc:
                self._log(logging.CRITICAL, "❌ Error al crear pool: %s", exc)
                raise
        return self._pool

    def adquiere_conexion(self, max_retries: int = 3, retry_delay: float = 2.0):
        """Adquiere conexión del pool con reintentos."""
        last_error = None
        for attempt in range(1, max_retries + 1):
            try:
                conn = self.pool.acquire()
                if conn.ping() is None:
                    return conn
                self.pool.release(conn)
                raise oracledb.DatabaseError("Conexión inactiva")
            except (oracledb.DatabaseError, AttributeError) as exc:
                last_error = exc
                self._log(logging.WARNING, "⚠️ Intento %s fallido: %s", attempt, exc)
                time.sleep(min(retry_delay * (2 ** (attempt - 1)), 10))

                if attempt == 1 and self.pool.opened < self.conexion_params.max_:
                    try:
                        self._increase_pool_size()
                    except TrazabilidadExcepciones.ALL_NON_CRITICAL as pool_err:
                        self._log(logging.WARNING, "No se pudo aumentar pool: %s", pool_err)

        raise RuntimeError(f"No se pudo adquirir conexión después de {max_retries} intentos: {last_error}")

    def _increase_pool_size(self):
        """Aumenta dinámicamente el tamaño del pool."""
        new_size = min(self.pool.opened + self.conexion_params.increment, self.conexion_params.max_)
        if new_size > self.pool.opened:
            self._log(logging.INFO, "📈 Aumentando pool de %s a %s", self.pool.opened, new_size)
            self.pool.reconfigure(
                min=new_size,
                max=self.conexion_params.max_,
                increment=self.conexion_params.increment
            )

    def test_conexion(self) -> bool:
        """Test básico de conectividad."""
        conn = None
        try:
            conn = self.adquiere_conexion()
            conn.ping()
            return True
        except TrazabilidadExcepciones.DB_ERRORS as exc:
            self._log(logging.CRITICAL, "❌ Error de conexión: %s", exc)
            return False
        finally:
            if conn:
                try:
                    self.pool.release(conn)
                except TrazabilidadExcepciones.ALL_NON_CRITICAL:
                    pass

    def get_motor(self, conexion):
        """Crea engine SQLAlchemy desde conexión oracledb."""
        return create_engine("oracle+oracledb://", creator=lambda: conexion)

    def consulta_parametro(self, tabla: str, campo_valor: str, filtros: Dict[str, Any], schema: str = "ADM") -> Optional[Dict[str, Any]]:
        """Consulta genérica usando SQL directo."""
        conexion = self.adquiere_conexion()
        resultado: Optional[Dict[str, Any]] = None
        try:
            engine = self.get_motor(conexion)
            origen = table(tabla, *(column(nombre) for nombre in [campo_valor, *filtros]), schema=schema)
            sentencia = (
                select(origen.c[campo_valor])
                .where(and_(*(origen.c[nombre] == valor for nombre, valor in filtros.items())))
                .where(literal_column('ROWNUM') == 1)
            )

            with engine.connect() as connection:
                row = connection.execute(sentencia).fetchone()

                if row:
                    resultado = self._interpretar_valor(campo_valor, row[0])

        except SQLAlchemyError as exc:
            self._log(logging.ERROR, "❌ Error SQL en consulta_parametro %s", exc, exc_info=True)
            resultado = None
        finally:
            self.pool.release(conexion)

        return resultado

    @staticmethod
    def _interpretar_valor(campo_valor: str, valor: Any) -> Any:
        """Convierte el valor crudo de la BD: JSON si es texto, o el valor tal cual."""
        if isinstance(valor, str):
            try:
                return json.loads(valor)
            except json.JSONDecodeError:
                return {campo_valor: valor}
        return valor

    def _parsear_resultado(self, row, campo_valor) -> Optional[Dict]:
        """Parsea el valor retornado (JSON o string)."""
        if not row:
            return None

        valor = row[0]
        if isinstance(valor, dict):
            return valor

        return self._parsear_cadena(valor, campo_valor) if isinstance(valor, str) \
            else {campo_valor: valor}

    @staticmethod
    def _parsear_cadena(valor: str, campo_valor: str) -> Dict:
        """Intenta interpretar una cadena como JSON o literal Python."""
        try:
            return json.loads(valor)
        except json.JSONDecodeError:
            pass

        try:
            return ast.literal_eval(valor)
        except (ValueError, SyntaxError):
            return {campo_valor: valor}

    def consulta_sql_directo(self, sql: str, params: list = None) -> Tuple[pd.DataFrame, bool]:
        """Ejecuta SQL directo y retorna DataFrame."""
        conexion = self.adquiere_conexion()
        try:
            engine = self.get_motor(conexion)
            with engine.connect() as connection:
                if params and isinstance(params, list):
                    params = tuple(params)
                df = pd.read_sql(sql, connection, params=params)
                return df, not df.empty
        except SQLAlchemyError as exc:
            self._log(logging.ERROR, "❌ Error SQL: %s", exc, exc_info=True)
            raise
        finally:
            self.pool.release(conexion)

    def close(self):
        """Cierra pool y executor."""
        try:
            if self._pool:
                self._pool.close()
        except TrazabilidadExcepciones.ALL_NON_CRITICAL as exc:
            self._log(logging.ERROR, "Error cerrando pool: %s", exc, exc_info=True)

        try:
            if self._executor:
                self._executor.shutdown(wait=True)
        except TrazabilidadExcepciones.ALL_NON_CRITICAL as exc:
            self._log(logging.ERROR, "Error cerrando executor: %s", exc, exc_info=True)


class ConexionBDD:
    """Gestiona conexiones Oracle usando Wallet y Spark Connect (Instalador v4.4)."""

    def __init__(self, config: Dict[str, Any], logger: logging.Logger):
        """
        Inicializa la conexión con la configuración y el logger compartido.

        Args:
            config: Configuración con wallet_path, spark_url, oracle_home.
            logger: Logger compartido inyectado desde el punto de entrada.
        """
        self.config = config
        self._logger = logger
        self.spark: Optional[SparkSession] = None
        self._setup_env()

    def _log(self, level: int, msg: str, *args: object, exc_info: bool = False) -> None:
        """Registra un mensaje con formato lazy % para compatibilidad con Pylint."""
        self._logger.log(level, msg, *args, exc_info=exc_info)

    def _setup_env(self):
        """Configura variables de entorno Oracle y Spark."""
        sistema = platform.system()

        if sistema == "Windows":
            os.environ['TNS_ADMIN'] = self.config['wallet_path']
            if self.config.get('oracle_home'):
                os.environ['ORACLE_HOME'] = self.config['oracle_home']
        else:
            wallet_path = self.config.get('wallet_path')
            if wallet_path:
                os.environ['TNS_ADMIN'] = wallet_path

            base_dir = Path('/home/python/sri_datos_abiertos_facturacion')
            spark_jars_dir = base_dir / 'spark'
            if spark_jars_dir.exists():
                jars = list(spark_jars_dir.glob('*.jar'))
                if jars:
                    classpath = ':'.join(str(j) for j in jars)
                    current_cp = os.environ.get('SPARK_CLASSPATH', '')
                    os.environ['SPARK_CLASSPATH'] = f"{classpath}:{current_cp}" if current_cp else classpath
                    self._log(logging.INFO, "🐧 JARs Oracle agregados: %s archivos", len(jars))

    def conectar_spark(self) -> SparkSession:
        """Establece conexión Spark Connect."""
        try:
            self.spark = crear_sesion_spark(self.config['spark_url'])

            self._log(logging.INFO, "✅ Spark Connect: %s", self.config['spark_url'])
            return self.spark
        except Exception as exc:
            self._log(logging.ERROR, "Error Spark: %s", exc, exc_info=True)
            raise

    def leer_oracle(self, query: str, partition_col: Optional[str] = None, num_partitions: int = 4, fetch_size: int = 500000) -> Any:
        """Lee datos desde Oracle usando particionamiento."""
        if not self.spark:
            self.conectar_spark()

        jdbc_url = self.config.get('jdbc_url', "jdbc:oracle:thin:/@DETALLES")
        wallet_path = self.config['wallet_path']

        reader = self.spark.read.format('jdbc').options(**opciones_jdbc(jdbc_url, wallet_path, wallet_path, fetch_size))
        clave_origen = 'query' if query.strip().lower().startswith('select') else 'dbtable'
        reader = reader.option(clave_origen, query)

        if partition_col:
            limites = (
                self.spark.read.format('jdbc').options(**opciones_jdbc(jdbc_url, wallet_path, wallet_path, fetch_size))
                .option('pushDownAggregate', 'true')
                .option(clave_origen, query).load()
                .agg(fn.min(partition_col).alias('min_val'), fn.max(partition_col).alias('max_val'))
                .collect()[0]
            )
            reader = (
                reader
                .option('partitionColumn', partition_col)
                .option('lowerBound', str(limites['min_val']))
                .option('upperBound', str(limites['max_val']))
                .option('numPartitions', str(num_partitions))
            )

        return reader.load()

    def stop(self):
        """Cierra sesión de Spark."""
        if self.spark:
            self.spark.stop()
            self._log(logging.INFO, "Spark session cerrada")
