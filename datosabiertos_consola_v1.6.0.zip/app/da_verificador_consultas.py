"""Prueba previa de las consultas JSON antes de exportar.

app/da_verificador_consultas.py

Dos verificaciones por consulta:
  1. Credencial: la "conexion" del JSON debe ser un alias de tnsnames.ora.
     Cada alias es el nombre de la credencial guardada en el wallet; si
     no existe, la consulta no se ejecuta.
  2. Ejecucion: modo "una_fila" lee una fila con limit(1), que Spark baja
     a Oracle; modo "estructura" solo resuelve columnas y permisos (Spark
     ejecuta la consulta con WHERE 1 = 0, sin leer datos).

El resultado indica que consultas funcionaran y cuales no, para la
consola, el log y el correo.

Historial:
+--------------------+---------+------------------------------------------+
| Autor              | Version | Cambios                                  |
+--------------------+---------+------------------------------------------+
| Jim A. Gonzalez    | 1.0.0   | Credencial vs tnsnames + prueba 1 fila   |
+--------------------+---------+------------------------------------------+
"""

from dataclasses import dataclass
from datetime import datetime
import logging
from pathlib import Path
import re
from typing import Any, Callable, Dict, List, Optional

from py4j.protocol import Py4JJavaError
from pyspark.errors import PySparkException

from app.da_modelos import ConsultaDefinicion
from app.da_sesion_spark import crear_sesion_spark, opciones_jdbc
from app.da_validador import leer_alias_tnsnames

ESTADO_OK = 'OK'
ESTADO_SIN_CREDENCIAL = 'SIN CREDENCIAL'
ESTADO_ERROR_CONSULTA = 'ERROR CONSULTA'
ESTADO_SIN_SPARK = 'SIN SPARK'
MODO_UNA_FILA = 'una_fila'
MODO_ESTRUCTURA = 'estructura'
_MODOS_VALIDOS = (MODO_UNA_FILA, MODO_ESTRUCTURA)
_ERRORES_EJECUCION = (PySparkException, Py4JJavaError, RuntimeError, OSError, ValueError)
_PATRON_ORA = re.compile(r'(ORA-\d{5}[^\n\r]*)')
_LARGO_DETALLE = 220


@dataclass
class ResultadoPrueba:
    """Resultado de la prueba de una consulta. Entidad pasiva (Regla 44 SRI)."""

    consulta_id: str
    nombre: str
    alias: str
    estado: str
    detalle: str
    segundos: float = 0.0


def resumir_error(exc: BaseException) -> str:
    """
    Reduce una excepcion de Spark/JDBC a una linea legible.

    Prioriza el primer codigo ORA-XXXXX; si no hay, usa la primera linea
    del mensaje.

    Args:
        exc: Excepcion capturada.

    Returns:
        Texto de una linea de hasta _LARGO_DETALLE caracteres.
    """
    texto = str(exc)
    coincidencia = _PATRON_ORA.search(texto)
    linea = coincidencia.group(1) if coincidencia else (texto.strip().splitlines() or [type(exc).__name__])[0]
    return linea.strip()[:_LARGO_DETALLE]


class VerificadorConsultas:
    """Verifica credencial y ejecucion de las consultas antes de exportar."""

    def __init__(self, config_spark: Dict[str, Any], config_prueba: Dict[str, Any], logger: logging.Logger):
        """
        Inicializa el verificador.

        Args:
            config_spark: Seccion spark del TOML (spark_url, wallet_path,
                          network_admin, fetch_size).
            config_prueba: Seccion prueba_consultas (modo, timeout_segundos).
            logger: Logger compartido inyectado desde el punto de entrada.

        Raises:
            ValueError: Si el modo de prueba del TOML no es valido.
        """
        self._spark_cfg = config_spark
        self._modo = config_prueba.get('modo', MODO_UNA_FILA)
        if self._modo not in _MODOS_VALIDOS:
            raise ValueError(f'prueba_consultas.modo="{self._modo}" no valido. Use: {", ".join(_MODOS_VALIDOS)}')
        self._timeout = int(config_prueba.get('timeout_segundos', 600))
        self._logger = logger
        self._tns_admin = config_spark.get('network_admin') or config_spark.get('wallet_path', '')
        self.ruta_tnsnames = Path(self._tns_admin) / 'tnsnames.ora'

    def _log(self, level: int, msg: str, *args: object) -> None:
        """Registra un mensaje con formato lazy % para compatibilidad con Pylint."""
        self._logger.log(level, msg, *args)

    def alias_disponibles(self) -> List[str]:
        """
        Lee los alias de tnsnames.ora (credenciales validas del wallet).

        Returns:
            Lista de alias en mayusculas; vacia si el archivo no se puede leer.
        """
        try:
            alias = leer_alias_tnsnames(self.ruta_tnsnames)
        except OSError as exc:
            self._log(logging.ERROR, 'No se pudo leer %s: %s', self.ruta_tnsnames, exc)
            return []
        self._log(logging.INFO, 'Credenciales validas en %s: %s', self.ruta_tnsnames, ', '.join(alias))
        return alias

    def verificar_credencial(self, consulta: ConsultaDefinicion, disponibles: List[str]) -> Optional[ResultadoPrueba]:
        """
        Verifica que la conexion del JSON exista en tnsnames.ora.

        Args:
            consulta: Consulta a verificar.
            disponibles: Alias leidos de tnsnames.ora.

        Returns:
            ResultadoPrueba con el problema, o None si la credencial existe.
        """
        alias = (consulta.wallet or '').upper()
        if alias and alias in disponibles:
            return None
        detalle = (
            f'Usa la credencial "{alias}", que no existe en el wallet. '
            f'Disponibles: {", ".join(disponibles) or "ninguna"}'
            if alias else 'El JSON no declara "conexion"'
        )
        return ResultadoPrueba(consulta.id_, consulta.nombre, alias or '-', ESTADO_SIN_CREDENCIAL, detalle)

    def probar(self, consultas: List[ConsultaDefinicion], resolver_sql: Callable[[ConsultaDefinicion], str]) -> List[ResultadoPrueba]:
        """
        Ejecuta las dos verificaciones sobre cada consulta.

        Args:
            consultas: Consultas a verificar.
            resolver_sql: Funcion que devuelve el SQL con el periodo resuelto.

        Returns:
            Un ResultadoPrueba por consulta, en el mismo orden recibido.
        """
        disponibles = self.alias_disponibles()
        resultados: Dict[str, ResultadoPrueba] = {}
        pendientes: List[ConsultaDefinicion] = []
        for consulta in consultas:
            problema = self.verificar_credencial(consulta, disponibles)
            if problema:
                resultados[consulta.id_] = problema
                self._log(logging.WARNING, 'Consulta %s no se ejecutara: %s', consulta.id_, problema.detalle)
            else:
                pendientes.append(consulta)

        for resultado in self._probar_ejecucion(pendientes, resolver_sql):
            resultados[resultado.consulta_id] = resultado
        return [resultados[consulta.id_] for consulta in consultas]

    def _probar_ejecucion(self, consultas: List[ConsultaDefinicion], resolver_sql: Callable[[ConsultaDefinicion], str]) -> List[ResultadoPrueba]:
        """Ejecuta la prueba de una fila con una sesion Spark por URL."""
        if not consultas:
            return []
        resultados: List[ResultadoPrueba] = []
        sesiones: Dict[str, Any] = {}
        try:
            for consulta in consultas:
                spark_url = consulta.spark_url or self._spark_cfg.get('spark_url', '')
                try:
                    if spark_url not in sesiones:
                        sesiones[spark_url] = crear_sesion_spark(spark_url)
                except _ERRORES_EJECUCION as exc:
                    resultados.append(ResultadoPrueba(
                        consulta.id_, consulta.nombre, consulta.wallet or '-', ESTADO_SIN_SPARK,
                        f'Spark {spark_url}: {resumir_error(exc)}'
                    ))
                    continue
                resultados.append(self._probar_una(sesiones[spark_url], consulta, resolver_sql))
        finally:
            for sesion in sesiones.values():
                sesion.stop()
        return resultados

    def _probar_una(self, spark: Any, consulta: ConsultaDefinicion, resolver_sql: Callable[[ConsultaDefinicion], str]) -> ResultadoPrueba:
        """
        Ejecuta la consulta de prueba de una sola consulta.

        Args:
            spark: Sesion Spark activa.
            consulta: Consulta con credencial valida.
            resolver_sql: Funcion que devuelve el SQL con el periodo resuelto.

        Returns:
            ResultadoPrueba con estado OK o ERROR CONSULTA.
        """
        inicio = datetime.now()
        alias = consulta.wallet or '-'
        self._log(logging.INFO, 'Probando %s en %s (modo %s)...', consulta.id_, alias, self._modo)
        try:
            opts = opciones_jdbc(consulta.jdbc_url, self._spark_cfg['wallet_path'], self._tns_admin, 1000)
            df = (
                spark.read.format('jdbc').options(**opts)
                .option('queryTimeout', str(self._timeout))
                .option('pushDownLimit', 'true')
                .option('query', resolver_sql(consulta))
                .load()
            )
            filas = len(df.limit(1).collect()) if self._modo == MODO_UNA_FILA else 0
        except _ERRORES_EJECUCION as exc:
            segundos = (datetime.now() - inicio).total_seconds()
            self._log(logging.ERROR, 'Consulta %s fallo en la prueba: %s', consulta.id_, resumir_error(exc))
            return ResultadoPrueba(consulta.id_, consulta.nombre, alias, ESTADO_ERROR_CONSULTA, resumir_error(exc), segundos)

        segundos = (datetime.now() - inicio).total_seconds()
        detalle = f'{len(df.columns)} columnas, {filas} fila(s) de prueba'
        if self._modo == MODO_UNA_FILA and filas == 0:
            detalle += ' (sin datos para el periodo)'
        self._log(logging.INFO, 'Consulta %s OK: %s en %.1fs', consulta.id_, detalle, segundos)
        return ResultadoPrueba(consulta.id_, consulta.nombre, alias, ESTADO_OK, detalle, segundos)


def tabla_texto(resultados: List[ResultadoPrueba]) -> str:
    """
    Formatea los resultados como tabla de texto para consola, log y archivo.

    Args:
        resultados: Resultados de la prueba.

    Returns:
        Tabla de texto con una linea por consulta y un resumen final.
    """
    lineas = [f'{"CONSULTA":<28} {"CONEXION":<20} {"ESTADO":<15} {"SEG":>6}  DETALLE', '-' * 110]
    for res in resultados:
        lineas.append(f'{res.consulta_id:<28} {res.alias:<20} {res.estado:<15} {res.segundos:>6.1f}  {res.detalle}')
    funcionan = sum(1 for res in resultados if res.estado == ESTADO_OK)
    lineas.append('-' * 110)
    lineas.append(f'Funcionaran: {funcionan} de {len(resultados)}')
    return '\n'.join(lineas)
