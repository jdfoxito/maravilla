# -*- coding: utf-8 -*-
"""Interfaz de linea de comandos (CLI) del exportador.

app-main.py

Contiene el punto de entrada Click, utilidades de pantalla,
menu interactivo y subcomando verificar.

NOTA PYINSTALLER: Cuando se ejecuta como ejecutable --onefile,
PyInstaller descomprime en /tmp/_MEIxxxxxx. El codigo detecta
sys.frozen y usa el directorio del ejecutable real (sys.executable)
como directorio de trabajo para leer/escribir archivos.

Historial:
+--------------------+---------+------------------------------------------+
| Autor              | Version | Cambios                                  |
+--------------------+---------+------------------------------------------+
| Jim A. Gonzalez    | 1.0.0   | Extraido de exportador.py (Regla 43 SRI) |
| Jim A. Gonzalez    | 1.1.1   | Refactor main: complejidad 36 -> <20     |
| Jim A. Gonzalez    | 1.2.0   | Fix estado correo en verificacion remota   |
| Jim A. Gonzalez    | 1.3.0   | Deteccion PyInstaller frozen + rutas reales|
| Jim A. Gonzalez    | 1.4.0   | Prueba previa de consultas: credencial   |
|                    |         | vs tnsnames.ora + 1 fila. Subcomando     |
|                    |         | probar; -d y menu prueban antes. Fix:    |
|                    |         | 'verificar' se tomaba como CONSULTA_ID   |
|                    |         | Resumen de acceso a correo y servidores  |
| Jim A. Gonzalez    | 1.6.0   | receptores del JSON para probar y        |
|                    |         | verificar; probar_sufijo                 |
| Jim A. Gonzalez    | 1.5.0   | Ejecutable portable: siembra config/ y   |
|                    |         | consultas; log en logs/ (Regla 94)       |
+--------------------+---------+------------------------------------------+
"""

from datetime import datetime
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
import platform
import sys
from typing import Any, Dict, List, Optional, Tuple

import click

from app.da_comunes import resolver_raiz_proyecto
from app.da_conectividad import lineas_resumen, probar_correo
from app.da_config_manager import get_config_manager
from app.da_excepciones import TrazabilidadExcepciones
from app.da_exportador import ExportadorDatosAbiertos
from app.da_notificacion import NotificadorEmail
from app.da_modelos import ConsultaDefinicion
from app.da_validador import VerificadorRemoto
from app.da_verificador_consultas import ESTADO_OK, ResultadoPrueba, tabla_texto, VerificadorConsultas


def _detectar_ruta_base() -> Path:
    """Detecta la ruta base del proyecto, considerando PyInstaller frozen.

    Delega en da_comunes.resolver_raiz_proyecto para no duplicar la
    logica de deteccion de rutas (Regla 43 SRI). Pasa __file__ para que
    en modo desarrollo la raiz se calcule subiendo desde app/.

    Returns:
        Path a la raiz del proyecto o directorio del ejecutable.
    """
    return resolver_raiz_proyecto(Path(__file__))


_ARCHIVOS_EMPAQUETADOS = (('config', '*.toml'), ('data/input/consultas', '*.json'))
_NOMBRE_LOG = 'sri_datos_abiertos.log'


def _sembrar_consultas_empaquetadas(logger: logging.Logger) -> None:
    """Copia el TOML y las consultas empaquetadas en el binario hacia disco.

    PyInstaller --onefile descomprime los --add-data en sys._MEIPASS
    (/tmp/_MEIxxxxxx), que se destruye al terminar el proceso. Si junto
    al binario no existen config/*.toml o data/input/consultas/*.json,
    se siembran desde el ejecutable. Asi el binario funciona en
    cualquier carpeta: "solo copiar el binario" (Regla 57).
    Los archivos ya presentes en disco NUNCA se sobreescriben.
    """
    if not getattr(sys, 'frozen', False):
        return
    raiz_paquete = Path(getattr(sys, '_MEIPASS', ''))
    raiz_disco = _detectar_ruta_base()
    for carpeta, patron in _ARCHIVOS_EMPAQUETADOS:
        destino = raiz_disco / carpeta
        try:
            destino.mkdir(parents=True, exist_ok=True)
            sembrados = 0
            for origen in (raiz_paquete / carpeta).glob(patron):
                if not (destino / origen.name).exists():
                    (destino / origen.name).write_bytes(origen.read_bytes())
                    sembrados += 1
        except OSError as exc:
            _log(logger, logging.WARNING, 'No se pudo sembrar %s: %s', destino, exc)
            continue
        if sembrados:
            _log(logger, logging.INFO, 'Sembrados desde el ejecutable: %s archivo(s) en %s', sembrados, destino)


def _agregar_log_archivo(logger: logging.Logger, ruta_config: Optional[str]) -> None:
    """Agrega el archivo de log logs/sri_datos_abiertos.log (Regla 94).

    Rotacion de 10 MB con 5 respaldos. No duplica el handler si ya existe.
    """
    if any(isinstance(handler, RotatingFileHandler) for handler in logger.handlers):
        return
    ruta_log = get_config_manager(ruta_config, logger).get_rutas()['logs'] / _NOMBRE_LOG
    handler = RotatingFileHandler(ruta_log, maxBytes=10 * 1024 * 1024, backupCount=5, encoding='utf-8')
    handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(name)s: %(message)s', datefmt='%Y-%m-%d %H:%M:%S'))
    logger.addHandler(handler)
    _log(logger, logging.INFO, 'Log del proceso: %s', ruta_log)


def _iniciar(ruta_config: Optional[str]) -> logging.Logger:
    """Crea el logger, siembra los archivos empaquetados y abre el log en archivo."""
    logger = _crear_logger()
    _sembrar_consultas_empaquetadas(logger)
    _agregar_log_archivo(logger, ruta_config)
    return logger


def _crear_logger() -> logging.Logger:
    """Crea y configura el logger raiz compartido por toda la aplicacion."""
    logger_raiz = logging.getLogger('app')
    if not logger_raiz.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter(
            '%(asctime)s [%(levelname)s] %(name)s: %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        ))
        logger_raiz.addHandler(handler)
        logger_raiz.setLevel(logging.INFO)
        logger_raiz.propagate = False
    return logger_raiz


def _log(logger: logging.Logger, level: int, msg: str, *args: object, exc_info: bool = False) -> None:
    """Registra un mensaje con formato lazy % para compatibilidad con Pylint."""
    logger.log(level, msg, *args, exc_info=exc_info)


_CMD_PYTHON_MODULO = "python -m app.main"
_SUFIJO_VERIFICAR = "%s verificar"
_SUFIJO_HISTORIA1 = "%s -d facturacion_sql_historia1"
_SUFIJO_PROBAR = '%s probar'
_ENCABEZADOS_PRUEBA = ('Consulta', 'Nombre', 'Conexion', 'Estado', 'Segundos', 'Detalle')
VERSION = '1.6.0'


def _detectar_comando_base() -> str:
    """Detecta el modo de ejecucion examinando argv[0] via pathlib.

    Funciona identico en Windows y Linux, incluyendo PyInstaller frozen.
    """
    argv0 = Path(sys.argv[0]).resolve()
    ejecutable = argv0.name

    if ejecutable.startswith(("sri_datos_abiertos", "datos_abiertos1_0")):
        return f"./{ejecutable}"

    ruta_str = str(argv0)
    if "__pypackages__" in ruta_str or ".venv" in ruta_str or "venv" in ruta_str:
        return "pdm run start"

    return _CMD_PYTHON_MODULO


def _banner() -> None:
    """Muestra la pantalla de bienvenida con estado del ETL de Facturacion."""
    sistema = platform.system()
    cmd = _detectar_comando_base()
    formato = "%Y-%m-%d  %H:%M:%S"
    color = 'yellow'
    click.echo()
    click.echo(click.style("╔══════════════════════════════════════════════════════╗", fg="cyan"))
    click.echo(click.style("║   SRI — Exportador de Datos Abiertos Facturacion     ║", fg="cyan", bold=True, ))
    click.echo(click.style("╚══════════════════════════════════════════════════════╝", fg="cyan"))
    click.echo(f"  Sistema   : {sistema}")
    click.echo(f"  Version   : {VERSION}")
    click.echo(f"  Fecha     : {datetime.now().strftime(formato)}")
    click.echo(f"  Comando   : {click.style(cmd, fg=color)}")
    click.echo()


def _pantalla_ayuda(cmd: str) -> None:
    """Muestra la ayuda completa organizada por los tres modos de ejecucion."""
    comando_exportador = "pdm run exportador"
    if cmd.startswith("./") or cmd in ("sri_datos_abiertos", "datos_abiertos1_0"):
        cmd_pdm = comando_exportador
        cmd_py = _CMD_PYTHON_MODULO
    elif cmd.startswith("pdm "):
        cmd_pdm = cmd
        cmd_py = _CMD_PYTHON_MODULO
    else:
        cmd_pdm = comando_exportador
        cmd_py = cmd

    cmd_exe = "./sri_datos_abiertos.1.0.0"

    click.echo()
    click.echo(click.style("╔══════════════════════════════════════════════════════════════╗", fg="yellow"))
    click.echo(click.style("║              AYUDA — MODOS DE USO                            ║", fg="yellow", bold=True))
    click.echo(click.style("╚══════════════════════════════════════════════════════════════╝", fg="yellow"))
    click.echo()
    click.echo(click.style("  1. EJECUTABLE COMPILADO  (produccion y pruebas)", fg="green", bold=True))
    click.echo("     Solo copiar el binario. Sin instalar nada.")
    click.echo()
    for cmd_ej, descripcion in [
        (cmd_exe, "[Menu interactivo]"),
        (f"{cmd_exe} --listar", "Lista de consultas disponibles"),
        (_SUFIJO_HISTORIA1 % cmd_exe, "Ejecutar Historia 1 sin menu"),
        (f"{cmd_exe} facturacion_sql_historia1", "Ejecutar Historia 1 sin menu (sin -d)"),
        (_SUFIJO_PROBAR % cmd_exe, 'Probar credencial y 1 fila de cada consulta'),
        (_SUFIJO_VERIFICAR % cmd_exe, "Verificar archivos en los servidores"),
        (f"{cmd_exe} verificar --anio 2024", "Verificar archivos del anio 2024"),
    ]:
        cmd_estilizado = click.style(cmd_ej, fg="cyan")
        click.echo(f"     {cmd_estilizado:<58} {descripcion}")
    click.echo()
    click.echo(click.style("  2. CON PDM  (desarrollo con entorno virtual)", fg="green", bold=True))
    click.echo("     Requiere: pdm install")
    click.echo("     Scripts en pyproject.toml -> [tool.pdm.scripts]")
    click.echo()
    for cmd_ej, descripcion in [
        (cmd_pdm, "Menu interactivo"),
        ("pdm run exportador", "Menu interactivo (alias)"),
        ("pdm run listar", "Lista consultas disponibles"),
        ("pdm run historia1", "Ejecutar Historia 1"),
        ("pdm run historia2", "Ejecutar Historia 2"),
        ("pdm run historia3", "Ejecutar Historia 3"),
        ('pdm run historia5', 'Ejecutar Historia 5 (Vehiculos nuevos)'),
        ("pdm run verificar", "Verificar archivos en servidores"),
        ("pdm run verificar-anio -- --anio 2024", "Verificar anio especifico"),
    ]:
        cmd_estilizado = click.style(cmd_ej, fg="cyan")
        click.echo(f"     {cmd_estilizado:<55} {descripcion}")
    click.echo()
    click.echo(click.style("  3. CON PYTHON -m  (venv activo, sin PDM)", fg="green", bold=True))
    click.echo("     Linux:   source venv/bin/activate")
    click.echo("     Windows: venv\\Scripts\\activate")
    click.echo()
    for cmd_ej, descripcion in [
        (cmd_py, "Menu interactivo"),
        (f"{cmd_py} --listar", "Lista consultas disponibles"),
        (_SUFIJO_HISTORIA1 % cmd_py, "Ejecutar Historia 1 sin menu"),
        (f"{cmd_py} facturacion_sql_historia1", "Ejecutar Historia 1 sin menu (sin -d)"),
        (_SUFIJO_PROBAR % cmd_py, 'Probar credencial y 1 fila de cada consulta'),
        (f'{cmd_py} probar facturacion_sql_historia5', 'Probar una sola consulta'),
        (_SUFIJO_VERIFICAR % cmd_py, "Verificar archivos en servidores"),
        (f"{cmd_py} -c /ruta/config.toml", "Usar TOML alternativo"),
    ]:
        cmd_estilizado = click.style(cmd_ej, fg="cyan")
        click.echo(f"     {cmd_estilizado:<65} {descripcion}")
    click.echo()
    click.echo(click.style("  CRON  (ejecucion automatica mensual)", fg="green", bold=True))
    cmd_cron = "/home/python/sri_datos_abiertos_facturacion/venv/bin/python -m app.main"
    for cron_ej, descripcion in [
        (_SUFIJO_HISTORIA1 % cmd_cron, "1 de cada mes 01:00"),
        (f"{cmd_cron} -d facturacion_sql_historia2", "1 de cada mes 02:00"),
        (_SUFIJO_PROBAR % cmd_cron, 'Ultimo dia de cada mes 20:00 (aviso previo)'),
        (f"{cmd_cron} -d facturacion_sql_historia3", "1 de cada mes 03:00"),
        (f'{cmd_cron} -d facturacion_sql_historia5', '1 de cada mes 04:00'),
        (_SUFIJO_VERIFICAR % cmd_cron, '1 de cada mes 05:00'),
    ]:
        click.echo(f"     {click.style(cron_ej, fg='yellow')}")
        click.echo(f"       -> {descripcion}")
    click.echo()
    linea_division = "─" * 64
    click.echo(f"  {linea_division}")
    click.echo("  Consultas JSON : data/input/consultas/*.json")
    click.echo("  Config Linux   : config/configlnx.toml")
    click.echo("  Config Windows : config/configwin.toml")
    click.echo("  Scripts PDM    : pyproject.toml -> [tool.pdm.scripts]")
    click.echo(f"  {linea_division}")
    click.echo()


def _mostrar_lista(consultas: List[Tuple[str, str]]) -> None:
    """Lista simple de consultas disponibles (para --listar)."""
    click.echo("\nConsultas disponibles:")
    click.echo("─" * 65)
    for cid, nombre in consultas:
        cid_estilizado = click.style(cid, fg="cyan", bold=True)
        click.echo(f"  {cid_estilizado:<40} {nombre}")
    click.echo()


def _mostrar_menu_interactivo(consultas: List[Tuple[str, str]], sin_credencial: Dict[str, str]) -> None:
    """Menu numerado con opciones 0=salir y ?=ayuda.

    Marca en rojo las consultas cuya conexion no existe en tnsnames.ora.
    """
    click.echo(click.style("  Consultas disponibles:", fg="white", bold=True))
    linea_corta = "─" * 62
    click.echo(f"  {linea_corta}")
    for num, (cid, nombre) in enumerate(consultas, 1):
        num_estilizado = click.style(str(num), fg="yellow", bold=True)
        cid_estilizado = click.style(cid, fg="cyan")
        marca = click.style(f'  [sin credencial {sin_credencial[cid]}]', fg='red') if cid in sin_credencial else ''
        click.echo(f"  {num_estilizado}.  {cid_estilizado:<38} {nombre}{marca}")
    click.echo(f"  {linea_corta}")
    salir_estilizado = click.style("0", fg="red", bold=True)
    ayuda_estilizada = click.style("?", fg="yellow", bold=True)
    click.echo(f"  {salir_estilizado}.  Salir       {ayuda_estilizada} Ayuda / mas opciones")
    click.echo()


def _construir_resumen_verificacion(resultados: List[Dict[str, Any]], anio: int) -> str:
    """Construye el texto del resumen de verificacion por servidor."""
    lineas = [f"Verificacion de archivos — Anio {anio}", "=" * 55]
    for res in resultados:
        estado_srv = "OK" if res["exito"] else "ERROR"
        lineas.append(f"\n{estado_srv} {res['servidor']} ({res['ip']})")
        for err in res["errores"]:
            lineas.append(f"   ERROR: {err}")
        for arch in res["archivos"]:
            estado_arch = "OK" if arch["ok"] else "ADVERTENCIA"
            lineas.append(
                f"   {estado_arch} {arch['nombre']} "
                f"({arch['tamanio_kb']} KB) — {arch['fecha_mod']}"
            )
        if not res["archivos"] and not res["errores"]:
            lineas.append("   Sin archivos encontrados para este anio")
    return "\n".join(lineas)


def _enviar_correo_verificacion(cfg_email: Dict[str, Any], anio: int, exito: bool, resumen: str, logger: logging.Logger) -> None:
    """Envia el correo de verificacion si hay servidor SMTP configurado y accesible."""
    if not cfg_email.get("smtp_server"):
        return
    if not probar_correo(cfg_email).disponible:
        _log(logger, logging.WARNING, 'Sin acceso al correo: la verificacion queda en log, consola y mails_enviados/')
        return
    try:
        correo_ok = NotificadorEmail(cfg_email, logger).enviar_notificacion(
            asunto=f"VERIFICACION {'OK' if exito else 'CON PROBLEMAS'} — {anio}",
            consulta_id=f"verificar_{anio}",
            resultado_transferencia={
                "exito": exito,
                "tipo": "verificacion",
                "archivo_destino": f"Verificacion {anio}",
                "tamanio_bytes": 0,
                "tamanio_mb": 0,
                "mensaje": resumen,
            },
            error=None if exito else f"Problemas detectados en servidores ({VERSION})",
        )
        if correo_ok:
            _log(logger, logging.INFO, "Correo de verificacion enviado")
        else:
            _log(logger, logging.WARNING, "Correo de verificacion no enviado (fallo SMTP)")
    except TrazabilidadExcepciones.ALL_NON_CRITICAL as exc:
        _log(logger, logging.WARNING, "Correo de verificacion no enviado: %s", exc)


def _notificar_verificacion(
    resultados: List[Dict[str, Any]],
    anio: int,
    cfg_email: Dict[str, Any],
    cfg_rutas: Dict[str, Any],
    logger: logging.Logger
) -> None:
    """Envia correo y guarda copia local con el resumen de verificacion."""
    exito = all(res["exito"] and res["archivos"] for res in resultados)
    resumen = _construir_resumen_verificacion(resultados, anio)
    _enviar_correo_verificacion(cfg_email, anio, exito, resumen, logger)
    dir_mails = cfg_rutas["mails"]
    dir_mails.mkdir(parents=True, exist_ok=True)
    marca = datetime.now().strftime("%Y%m%d_%H%M%S")
    estado = "OK" if exito else "ERROR"
    ruta = dir_mails / f"{marca}_verificacion_{anio}_{estado}.txt"
    ruta.write_text(resumen, encoding="utf-8")
    _log(logger, logging.INFO, "Reporte de verificacion guardado: %s", ruta)


def _mostrar_conectividad(exportador: ExportadorDatosAbiertos, ruta_config: Optional[str]) -> None:
    """Muestra en consola el acceso a correo y servidores, y su efecto."""
    destino_local = str(get_config_manager(ruta_config, logging.getLogger('app')).get_rutas()['destino_local'])
    click.echo(click.style('  Conectividad:', fg='white', bold=True))
    for linea in lineas_resumen(exportador.diagnosticar_conectividad(), destino_local):
        sin_acceso = 'SIN ACCESO' in linea or linea.startswith('->')
        click.echo(click.style(f'  {linea}', fg='yellow' if sin_acceso else None))
    click.echo()


def _crear_verificador(logger: logging.Logger, ruta_config: Optional[str]) -> VerificadorConsultas:
    """Crea el verificador de consultas con la configuracion del TOML."""
    gestor = get_config_manager(ruta_config, logger)
    return VerificadorConsultas(gestor.get_spark_config(), gestor.get_prueba_consultas_config(), logger)


def _email_con_receptores(cfg_email: Dict[str, Any], consultas: List[ConsultaDefinicion]) -> Dict[str, Any]:
    """Usa los receptores declarados en los JSON (union, sin repetir).

    Si ninguna consulta declara receptores se usan los del TOML. Asi las
    notificaciones se cambian editando los JSON, sin recompilar.
    """
    receptores: List[str] = []
    for consulta in consultas:
        for correo in (consulta.config_email or {}).get('to_addresses', []):
            if correo not in receptores:
                receptores.append(correo)
    return {**cfg_email, 'to_addresses': receptores} if receptores else cfg_email


def _notificar_prueba(
    resultados: List[ResultadoPrueba], consultas: List[ConsultaDefinicion], ruta_config: Optional[str], logger: logging.Logger
) -> None:
    """Envia el correo a los receptores de las consultas y guarda la copia local."""
    gestor = get_config_manager(ruta_config, logger)
    funcionan = sum(1 for res in resultados if res.estado == ESTADO_OK)
    hay_error = funcionan < len(resultados)
    resumen = f'{funcionan} de {len(resultados)} consultas funcionaran'
    filas = [(res.consulta_id, res.nombre, res.alias, res.estado, f'{res.segundos:.1f}', res.detalle) for res in resultados]
    cfg_email = _email_con_receptores(gestor.get_email_config(), consultas)
    if not probar_correo(cfg_email).disponible:
        _log(logger, logging.WARNING, 'Sin acceso al correo: el resultado de la prueba queda en log, consola y mails_enviados/')
    elif cfg_email.get('smtp_server'):
        enviado = NotificadorEmail(cfg_email, logger).enviar_tabla(
            asunto=f'PRUEBA DE CONSULTAS {"CON PROBLEMAS" if hay_error else "OK"} - {resumen}',
            titulo=f'Prueba de consultas: {resumen}',
            encabezados=_ENCABEZADOS_PRUEBA,
            filas=filas,
            hay_error=hay_error,
        )
        _log(logger, logging.INFO if enviado else logging.WARNING, 'Correo de prueba de consultas %s', 'enviado' if enviado else 'no enviado')
    dir_mails = gestor.get_rutas()['mails']
    marca = datetime.now().strftime('%Y%m%d_%H%M%S')
    ruta = dir_mails / f'{marca}_prueba_consultas_{"ERROR" if hay_error else "OK"}.txt'
    ruta.write_text(f'Prueba de consultas v{VERSION}\n{tabla_texto(resultados)}\n', encoding='utf-8')
    _log(logger, logging.INFO, 'Reporte de prueba guardado: %s', ruta)


def _probar_consultas(
    exportador: ExportadorDatosAbiertos,
    consultas: List[ConsultaDefinicion],
    ruta_config: Optional[str],
    logger: logging.Logger
) -> bool:
    """Prueba credencial y una fila de cada consulta; informa en consola, log y correo.

    Returns:
        True si todas las consultas funcionaran.
    """
    _mostrar_conectividad(exportador, ruta_config)
    resultados = _crear_verificador(logger, ruta_config).probar(consultas, exportador.sql_para_ejecucion)
    tabla = tabla_texto(resultados)
    click.echo()
    for linea in tabla.splitlines():
        es_problema = any(estado in linea for estado in ('SIN CREDENCIAL', 'ERROR CONSULTA', 'SIN SPARK'))
        click.echo(click.style(f'  {linea}', fg='red' if es_problema else None))
    click.echo()
    _log(logger, logging.INFO, 'Resultado de la prueba de consultas:\n%s', tabla)
    _notificar_prueba(resultados, consultas, ruta_config, logger)
    return all(res.estado == ESTADO_OK for res in resultados)


def _modo_listar(exportador: ExportadorDatosAbiertos) -> None:
    """Modo --listar: Muestra consultas y sale."""
    consultas = exportador.listar_consultas()
    if not consultas:
        click.echo("No se encontraron consultas configuradas")
        sys.exit(1)
    _mostrar_lista(consultas)


def _modo_directo(exportador: ExportadorDatosAbiertos, consulta_id: Optional[str], cmd: str, ruta_config: Optional[str]) -> None:
    """Modo --directo: prueba la consulta con una fila, la ejecuta y sale.

    Si la prueba falla no se ejecuta la exportacion completa.
    """
    if not consulta_id:
        click.echo(click.style("ERROR: ", fg="red", bold=True) + "Se requiere CONSULTA_ID con --directo")
        click.echo(f"  Uso: {click.style(f'{cmd} -d <ID>', fg='yellow')}")
        sys.exit(1)
    consulta = exportador.encontrar_consulta(consulta_id)
    if not consulta:
        click.echo(f'Consulta "{consulta_id}" no encontrada')
        sys.exit(1)
    logger = logging.getLogger('app')
    if not _probar_consultas(exportador, [consulta], ruta_config, logger):
        click.echo(click.style('La prueba previa fallo: no se ejecuta la exportacion.', fg='red', bold=True))
        sys.exit(1)
    click.echo(f"\nEjecutando: {click.style(consulta.nombre, fg='green', bold=True)}")
    sys.exit(0 if exportador.procesar_consulta(consulta) else 1)


def _despedida(exito: bool = True) -> None:
    """Muestra mensaje de salida con timestamp."""
    despedida = click.style("Hasta luego.", fg="cyan")
    hora = datetime.now().strftime("%H:%M:%S")
    click.echo(f"\n  {despedida}  {hora}\n")
    sys.exit(0 if exito else 1)


def _resolver_seleccion(consultas: List[Tuple[str, str]], seleccion: str, ) -> Optional[str]:
    """Convierte la entrada del usuario en un consulta_id valido."""
    if seleccion.isdigit():
        idx = int(seleccion) - 1
        if 0 <= idx < len(consultas):
            return consultas[idx][0]
        click.echo(click.style(
            f"  Numero invalido. Entre 1 y {len(consultas)}, "
            "0 para salir o ? para ayuda.\n",
            fg="red",
        ))
        return None
    return seleccion


def _ejecutar_consulta_interactiva(exportador: ExportadorDatosAbiertos, consulta: Any, ruta_config: Optional[str]) -> bool:
    """Prueba la consulta con una fila, la ejecuta y muestra el resultado."""
    if not _probar_consultas(exportador, [consulta], ruta_config, logging.getLogger('app')):
        click.echo(click.style('\n  La prueba previa fallo: no se ejecuta la exportacion.\n', fg='red', bold=True))
        return False
    click.echo()
    click.echo(f"  Ejecutando: {click.style(consulta.nombre, fg='green', bold=True)}")
    click.echo(f"  ID  : {consulta.id_}")
    click.echo(f"  SQL : {consulta.sql[:75]}...")
    click.echo()
    exito = exportador.procesar_consulta(consulta)
    if exito:
        click.echo(click.style("\n  Proceso completado con exito.\n", fg="green", bold=True))
    else:
        click.echo(click.style("\n  El proceso termino con errores. Revise el log.\n", fg="red", bold=True,))
    return exito


def _consultas_sin_credencial(exportador: ExportadorDatosAbiertos, ruta_config: Optional[str]) -> Dict[str, str]:
    """Retorna {consulta_id: alias} de las consultas cuya conexion no esta en tnsnames.ora."""
    verificador = _crear_verificador(logging.getLogger('app'), ruta_config)
    disponibles = verificador.alias_disponibles()
    return {
        consulta.id_: problema.alias
        for consulta in exportador.cargar_consultas()
        if (problema := verificador.verificar_credencial(consulta, disponibles)) is not None
    }


def _modo_interactivo(exportador: ExportadorDatosAbiertos, cmd: str, ruta_config: Optional[str]) -> None:
    """Modo interactivo: Menu en loop hasta que el usuario salga."""
    _banner()
    consultas = exportador.listar_consultas()
    if not consultas:
        click.echo(click.style("  Sin consultas configuradas.", fg="yellow"))
        sys.exit(1)
    sin_credencial = _consultas_sin_credencial(exportador, ruta_config)
    _mostrar_conectividad(exportador, ruta_config)
    while True:
        _mostrar_menu_interactivo(consultas, sin_credencial)
        try:
            seleccion = input(click.style("  Seleccione -> ", fg="white", bold=True)).strip()
        except (EOFError, KeyboardInterrupt):
            click.echo()
            click.echo("\n  Cancelado.\n")
            sys.exit(0)
        if seleccion in ("0", "salir", "exit", "q"):
            _despedida()
            return
        if seleccion in ("?", "h", "ayuda", "help"):
            _pantalla_ayuda(cmd)
            continue
        consulta_id = _resolver_seleccion(consultas, seleccion)
        if consulta_id is None:
            continue
        consulta = exportador.encontrar_consulta(consulta_id)
        if not consulta:
            click.echo(click.style(f'  Consulta "{consulta_id}" no encontrada.\n', fg="red"))
            continue
        exito = _ejecutar_consulta_interactiva(exportador, consulta, ruta_config)
        if not click.confirm(click.style("  Ejecutar otra consulta?", fg="cyan"), default=False, ):
            _despedida(exito)
            return


_CMD_EJECUTAR = 'ejecutar'


class GrupoExportador(click.Group):
    """Grupo Click que acepta un subcomando o un CONSULTA_ID como primer argumento.

    Con un argumento posicional en el grupo, Click tomaba 'verificar' como
    CONSULTA_ID y el subcomando nunca se ejecutaba. Aqui, si el primer
    argumento no es un subcomando registrado, se enruta al comando oculto
    'ejecutar' con ese CONSULTA_ID.
    """

    def resolve_command(self, ctx: click.Context, args: List[str]) -> Tuple[Optional[str], Optional[click.Command], List[str]]:
        """Enruta un CONSULTA_ID al comando oculto 'ejecutar'."""
        if args and args[0] not in self.commands and not args[0].startswith('-'):
            args = [_CMD_EJECUTAR, *args]
        return super().resolve_command(ctx, args)


@click.group(cls=GrupoExportador, invoke_without_command=True)
@click.option('--listar', '-l', is_flag=True, help='Lista todas las consultas disponibles')
@click.option('--directo', '-d', is_flag=True, help='Ejecuta sin menu (ideal para cron.d)')
@click.option('--config', '-c', 'ruta_config', help='Ruta alternativa al archivo TOML')
@click.pass_context
def main(ctx, listar, directo, ruta_config):
    """Punto de entrada del exportador de Datos Abiertos SRI (Oracle a servidores).

    Uso: main [-d] CONSULTA_ID | main probar | main verificar | main --listar
    """
    if ctx.invoked_subcommand is not None:
        return
    logger = _iniciar(ruta_config)
    exportador = ExportadorDatosAbiertos(ruta_config, logger)
    cmd = _detectar_comando_base()
    if listar:
        _modo_listar(exportador)
        return
    if directo:
        _modo_directo(exportador, None, cmd, ruta_config)
        return
    _modo_interactivo(exportador, cmd, ruta_config)


@main.command(_CMD_EJECUTAR, hidden=True)
@click.argument('consulta_id')
@click.option('--config', '-c', 'ruta_config', default=None, help='Ruta alternativa al TOML')
@click.pass_context
def cmd_ejecutar(ctx: click.Context, consulta_id: str, ruta_config: Optional[str]):
    """Prueba y ejecuta una consulta sin menu (main [-d] CONSULTA_ID)."""
    ruta_efectiva = ruta_config or ctx.parent.params.get('ruta_config')
    logger = _iniciar(ruta_efectiva)
    exportador = ExportadorDatosAbiertos(ruta_efectiva, logger)
    _modo_directo(exportador, consulta_id, _detectar_comando_base(), ruta_efectiva)


@main.command('probar')
@click.argument('consulta_id', required=False)
@click.option('--config', '-c', 'ruta_config', default=None, help='Ruta alternativa al TOML')
def cmd_probar(consulta_id: Optional[str], ruta_config: Optional[str]):
    """Prueba que las consultas funcionaran, sin exportar.

    Verifica que la conexion de cada JSON exista en tnsnames.ora (credencial
    del wallet) y ejecuta la consulta limitada a una fila. Informa en
    consola, log y correo.

    Ejemplos:
      exportador probar
      exportador probar facturacion_sql_historia5
    """
    logger = _iniciar(ruta_config)
    exportador = ExportadorDatosAbiertos(ruta_config, logger)
    consultas = exportador.cargar_consultas()
    if consulta_id:
        consultas = [consulta for consulta in consultas if consulta.id_ == consulta_id]
    if not consultas:
        click.echo(click.style(f'Sin consultas para probar ({consulta_id or "todas"})', fg='red'))
        sys.exit(1)
    sys.exit(0 if _probar_consultas(exportador, consultas, ruta_config, logger) else 1)


@main.command("verificar")
@click.option("--anio", "-a", type=int, default=None, help="Anio a verificar (por defecto: anio actual)", )
@click.option("--config", "-c", "ruta_config", default=None, help="Ruta alternativa al TOML")
def cmd_verificar(anio: Optional[int], ruta_config: Optional[str]):
    """Verifica que los archivos esten en los servidores de descarga.

    Comprueba existencia, tamano y fecha en Quito y Guayaquil.
    Envia correo con el resultado.

    Ejemplos:
      exportador verificar
      exportador verificar --anio 2024
    """
    logger = _iniciar(ruta_config)
    gestor = get_config_manager(ruta_config, logger)
    servidores = gestor.get_servidores_descarga()
    cfg_ver = gestor.get_verificacion_config()
    cfg_email = _email_con_receptores(gestor.get_email_config(), ExportadorDatosAbiertos(ruta_config, logger).cargar_consultas())
    cfg_rutas = gestor.get_rutas()
    anio_ver = anio or datetime.now().year
    anio_estilizado = click.style(str(anio_ver), fg="cyan", bold=True)
    click.echo(
        f"\nVerificando archivos anio {anio_estilizado} "
        f"en {len(servidores)} servidor(es)...\n"
    )
    verificador = VerificadorRemoto(servidores, cfg_ver, logger)
    resultados = verificador.verificar_todos(anio_ver)
    total_archivos = sum(len(res["archivos"]) for res in resultados)
    con_errores = sum(1 for res in resultados if res["errores"])
    click.echo(f"\n{'─' * 55}")
    click.echo(f"  Servidores verificados : {len(resultados)}")
    click.echo(f"  Archivos encontrados   : {total_archivos}")
    click.echo(f"  Servidores con errores : {con_errores}")
    click.echo(f"{'─' * 55}")
    _notificar_verificacion(resultados, anio_ver, cfg_email, cfg_rutas, logger)
    todo_ok = all(res["exito"] and res["archivos"] for res in resultados)
    sys.exit(0 if todo_ok else 1)


if __name__ == "__main__":
    main.main()
