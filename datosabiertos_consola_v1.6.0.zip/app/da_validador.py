# -*- coding: utf-8 -*-
"""Validadores de conectividad y verificación remota.

app-da_validador.py

Contiene:
  - ValidadorConectividad: valida wallet Oracle, Spark Connect y destino local.
  - VerificadorRemoto: verifica por SFTP que los archivos estén en los servidores.

Historial:
+--------------------+---------+------------------------------------------+
| Autor              | Versión | Cambios                                  |
+--------------------+---------+------------------------------------------+
| Jim A. González    | 1.0.0   | Extraído de exportador.py (Regla 43 SRI) |
| Jim A. González    | 1.1.0   | leer_alias_tnsnames publica: alias con   |
|                    |         | punto/guion y varios por linea; sesion   |
|                    |         | Spark comun (da_sesion_spark)            |
| Jim A. González    | 1.2.0   | abrir_transporte_sftp publica (reuso en  |
|                    |         | da_conectividad)                         |
+--------------------+---------+------------------------------------------+
"""

from datetime import datetime
import logging
from pathlib import Path
import re
from typing import Any, Dict, List, Optional, Tuple

import click
import paramiko

from app.da_comunes import cargar_clave_privada
from app.da_excepciones import TrazabilidadExcepciones
from app.da_sesion_spark import crear_sesion_spark


# -- Nombres de archivo/claves de configuracion (evita literales duplicados)
_ARCHIVO_TNSNAMES = 'tnsnames.ora'
_ARCHIVO_SQLNET = 'sqlnet.ora'
_CLAVE_WALLET_PATH = 'wallet_path'
_PATRON_ALIAS = r'[A-Za-z][\w.\-]*'
_PATRON_LINEA_TNS = re.compile(rf'^({_PATRON_ALIAS}(?:\s*,\s*{_PATRON_ALIAS})*)\s*=', re.ASCII)


def leer_alias_tnsnames(ruta_tnsnames: Path) -> List[str]:
    """
    Lista los alias declarados en un tnsnames.ora, en mayusculas.

    Cada alias es tambien el nombre de la credencial en el wallet.
    Reconoce STAR_BI_DWH, DETALLES.WORLD, SRI-MVEH y lineas con varios
    alias ("A, B = (...)"). Ignora comentarios y lineas de continuacion.

    Args:
        ruta_tnsnames: Ruta al archivo tnsnames.ora.

    Returns:
        Lista de alias sin duplicados, en orden de aparicion.

    Raises:
        OSError: Si el archivo no se puede leer.
    """
    alias_encontrados: List[str] = []
    for linea in ruta_tnsnames.read_text(encoding='utf-8', errors='ignore').splitlines():
        coincidencia = _PATRON_LINEA_TNS.match(linea.split('#', 1)[0].strip())
        if not coincidencia:
            continue
        for alias in coincidencia.group(1).split(','):
            nombre = alias.strip().upper()
            if nombre and nombre not in alias_encontrados:
                alias_encontrados.append(nombre)
    return alias_encontrados


class ValidadorConectividad:
    """Valida wallet Oracle, Spark Connect y destino local antes de ejecutar."""

    def __init__(self, config: Dict[str, Any], logger: logging.Logger):
        """
        Inicializa el validador con la configuración base.

        Args:
            config: Configuración base del sistema (spark, rutas, destino).
            logger: Logger compartido inyectado desde el punto de entrada.
        """
        self._config = config
        self._logger = logger
        self.ruta_wallet: Optional[Path] = None
        self.ruta_tnsnames: Optional[Path] = None
        self.tns_disponibles: List[str] = []

    def _log(self, level: int, msg: str, *args: object, exc_info: bool = False) -> None:
        """Registra un mensaje con formato lazy % para compatibilidad con Pylint."""
        self._logger.log(level, msg, *args, exc_info=exc_info)

    @staticmethod
    def _es_nombre_tns(valor: str) -> bool:
        """Retorna True si el valor parece ser un nombre TNS (no una ruta)."""
        if not valor or '/' in valor or '\\' in valor or ':' in valor:
            return False
        return bool(re.fullmatch(_PATRON_ALIAS, valor, re.ASCII))

    def _cargar_tnsnames(self) -> None:
        """Carga y parsea el archivo tnsnames.ora del wallet o network_admin."""
        if not self.ruta_wallet:
            return

        wallet_cfg = self._config.get('wallet', {})
        network_admin_str = wallet_cfg.get('network_admin')
        if network_admin_str:
            self.ruta_tnsnames = Path(network_admin_str) / _ARCHIVO_TNSNAMES
        else:
            self.ruta_tnsnames = self.ruta_wallet / _ARCHIVO_TNSNAMES

        self.tns_disponibles = []

        if not self.ruta_tnsnames.exists():
            self._log(logging.WARNING, 'No se encontro tnsnames.ora en %s', self.ruta_tnsnames.parent)
            return

        try:
            self.tns_disponibles = leer_alias_tnsnames(self.ruta_tnsnames)
            self._log(logging.INFO, 'TNS disponibles: %s', ', '.join(sorted(self.tns_disponibles)))

        except TrazabilidadExcepciones.ERRORES_SISTEMA as exc:
            self._log(logging.WARNING, 'Error leyendo tnsnames.ora: %s', exc)

    @staticmethod
    def _extraer_tns_de_jdbc(jdbc_url: str) -> Optional[str]:
        """
        Extrae el nombre TNS de una URL JDBC de Oracle.

        Args:
            jdbc_url: URL JDBC completa.

        Returns:
            Nombre TNS o None si no se encontró.
        """
        if not jdbc_url:
            return None
        coincidencia = re.search(
            rf'jdbc:oracle:thin:/?/?@({_PATRON_ALIAS})', jdbc_url, re.ASCII
        )
        return coincidencia.group(1) if coincidencia else None

    def _resolver_ruta_y_tns(self, wallet_override: Optional[str], jdbc_url: Optional[str]) -> Tuple[Optional[str], Optional[str]]:
        """
        Resuelve la ruta del wallet y el TNS requerido a partir de los overrides.

        Args:
            wallet_override: Ruta o nombre TNS del wallet (opcional).
            jdbc_url: URL JDBC para extraer el TNS requerido.

        Returns:
            Tupla (ruta_str, tns_requerido); cualquiera puede ser None.
        """
        ruta_str: Optional[str] = None
        tns_requerido: Optional[str] = None

        if wallet_override:
            if self._es_nombre_tns(wallet_override):
                ruta_str = self._config['spark'].get(_CLAVE_WALLET_PATH)
                tns_requerido = wallet_override
            else:
                ruta_str = wallet_override
        else:
            ruta_str = self._config['spark'].get(_CLAVE_WALLET_PATH)

        if jdbc_url and not tns_requerido:
            tns_requerido = self._extraer_tns_de_jdbc(jdbc_url)

        return ruta_str, tns_requerido

    def _resolver_rutas_wallet(self) -> Tuple[Optional[Path], Optional[Path], str]:
        """
        Obtiene las rutas wallet_path y network_admin desde el TOML.

        Las rutas se leen de la seccion [wallet], con fallback a [spark]
        para wallet_path. Si network_admin no esta definido, se usa
        wallet_path como fallback.

        Returns:
            Tupla (wallet_path, network_admin, wallet_path_str); los Path
            pueden ser None si la cadena de origen esta vacia.
        """
        wallet_cfg = self._config.get('wallet', {})
        wallet_path_str = (
            wallet_cfg.get(_CLAVE_WALLET_PATH)
            or self._config['spark'].get(_CLAVE_WALLET_PATH, '')
        )
        network_admin_str = wallet_cfg.get('network_admin') or wallet_path_str

        wallet_path = Path(wallet_path_str) if wallet_path_str else None
        network_admin = Path(network_admin_str) if network_admin_str else None
        return wallet_path, network_admin, wallet_path_str

    @staticmethod
    def _comprobar_archivos_wallet(
        wallet_path: Path,
        network_admin: Optional[Path],
        cwallet: Path,
        ewallet: Path,
        sqlnet: Optional[Path],
        tnsnames: Optional[Path],
    ) -> Tuple[bool, str]:
        """
        Evalua en orden las comprobaciones de archivos requeridos.

        Returns:
            Tupla (exito, mensaje); mensaje con la primera falla hallada,
            vacio si todo es correcto.
        """
        comprobaciones = (
            (
                not cwallet.exists() and not ewallet.exists(),
                f'Wallet sin cwallet.sso ni ewallet.p12 en {wallet_path}',
            ),
            (
                not sqlnet or not sqlnet.exists(),
                f'sqlnet.ora no encontrado en {network_admin} (ni en wallet_path)',
            ),
            (
                not tnsnames or not tnsnames.exists(),
                f'tnsnames.ora no encontrado en {network_admin} (ni en wallet_path)',
            ),
        )
        for falla, texto in comprobaciones:
            if falla:
                return False, texto
        return True, ''

    def _log_fecha_archivo(
        self, nombre: str, ruta: Optional[Path], con_directorio: bool = False
    ) -> None:
        """Registra la fecha de modificacion de un archivo del wallet."""
        if not ruta or not ruta.exists():
            return
        fecha = datetime.fromtimestamp(
            ruta.stat().st_mtime
        ).strftime('%Y-%m-%d %H:%M:%S')
        if con_directorio:
            self._log(logging.INFO, '   Wallet/%s -> %s (%s)', nombre, fecha, ruta.parent)
        else:
            self._log(logging.INFO, '   Wallet/%s -> %s', nombre, fecha)

    def _log_fechas_wallet(
        self, wallet_path: Path, sqlnet: Optional[Path], tnsnames: Optional[Path]
    ) -> None:
        """Registra las fechas de modificacion de los archivos del wallet."""
        for nombre in ['cwallet.sso', 'ewallet.p12']:
            self._log_fecha_archivo(nombre, wallet_path / nombre)
        self._log_fecha_archivo(_ARCHIVO_SQLNET, sqlnet, con_directorio=True)
        self._log_fecha_archivo(_ARCHIVO_TNSNAMES, tnsnames, con_directorio=True)

    def _validar_estructura_wallet(self) -> Tuple[bool, str]:
        """
        Comprueba que el wallet tenga los archivos requeridos.

        Busca credenciales (cwallet.sso, ewallet.p12) en wallet.wallet_path
        y configuracion de red (sqlnet.ora, tnsnames.ora) en wallet.network_admin.
        Si network_admin no esta definido, usa wallet_path como fallback.

        Returns:
            Tupla (exito, mensaje). Mensaje vacio si todo es correcto.
        """
        wallet_path, network_admin, wallet_path_str = self._resolver_rutas_wallet()

        if not wallet_path or not wallet_path.exists():
            return False, f'Wallet path no existe: {wallet_path_str}'

        cwallet = wallet_path / 'cwallet.sso'
        ewallet = wallet_path / 'ewallet.p12'

        sqlnet = (network_admin / _ARCHIVO_SQLNET) if network_admin else None
        tnsnames = (network_admin / _ARCHIVO_TNSNAMES) if network_admin else None

        if tnsnames and tnsnames.exists():
            self.ruta_tnsnames = tnsnames

        exito, mensaje = self._comprobar_archivos_wallet(
            wallet_path, network_admin, cwallet, ewallet, sqlnet, tnsnames
        )
        if exito:
            self._log_fechas_wallet(wallet_path, sqlnet, tnsnames)

        return exito, mensaje

    def _validar_tns_requerido(self, tns_requerido: Optional[str]) -> Tuple[bool, str]:
        """
        Valida que el TNS requerido este presente en el wallet (si se indico).

        Args:
            tns_requerido: Nombre TNS a verificar, o None.

        Returns:
            Tupla (exito, mensaje) describiendo el resultado.
        """
        if tns_requerido:
            no_disponible = (self.tns_disponibles and tns_requerido.upper() not in self.tns_disponibles)
            if no_disponible:
                return (
                    False,
                    f"TNS '{tns_requerido}' no en wallet. "
                    f"Disponibles: {', '.join(sorted(self.tns_disponibles))}"
                )
            return True, f"Wallet OK | TNS '{tns_requerido}' válido"

        return True, f'Wallet OK | {len(self.tns_disponibles)} TNS disponibles'

    def validar_wallet(self, wallet_override: Optional[str] = None, jdbc_url: Optional[str] = None) -> Tuple[bool, str]:
        """
        Valida el wallet Oracle y muestra fechas de modificación de sus archivos.

        Args:
            wallet_override: Ruta o nombre TNS del wallet (opcional).
            jdbc_url: URL JDBC para extraer el TNS requerido.

        Returns:
            Tupla (exito, mensaje).
        """
        ruta_str, tns_requerido = self._resolver_ruta_y_tns(wallet_override, jdbc_url)

        if not ruta_str:
            return False, 'Wallet no configurado en TOML ni en consulta'

        self.ruta_wallet = Path(ruta_str)
        if not self.ruta_wallet.exists():
            return False, f'Directorio wallet no existe: {self.ruta_wallet}'

        self._cargar_tnsnames()

        ok_estructura, msg_estructura = self._validar_estructura_wallet()
        if not ok_estructura:
            resultado = (False, msg_estructura)
        else:
            resultado = self._validar_tns_requerido(tns_requerido)
        return resultado

    def validar_spark(self, spark_url_override: Optional[str] = None) -> Tuple[bool, str]:
        """
        Verifica la conectividad a Spark Connect.

        Args:
            spark_url_override: URL alternativa de Spark Connect.

        Returns:
            Tupla (exito, mensaje).
        """
        spark_url = spark_url_override or self._config['spark'].get('spark_url')
        if not spark_url:
            return False, 'URL de Spark no configurada'

        try:
            spark = crear_sesion_spark(spark_url)
            version = spark.version
            spark.stop()
            return True, f"Spark Connect OK: {spark_url} ({version})"
        except (RuntimeError, OSError, ValueError, AttributeError) as exc:
            return False, f'Spark Connect falló: {exc}'

    @staticmethod
    def validar_destino(config_destino: Dict[str, Any]) -> Tuple[bool, str, bool]:
        """
        Verifica la accesibilidad del destino configurado.

        Args:
            config_destino: Configuración del destino.

        Returns:
            Tupla (accesible, mensaje, es_critico).
        """
        tipo = config_destino.get('tipo', 'local').lower()
        directorio = config_destino.get('directorio_remoto', './destino_local')
        resultado: Tuple[bool, str, bool]

        if tipo == 'local':
            try:
                ruta = Path(directorio)
                ruta.mkdir(parents=True, exist_ok=True)
                prueba = ruta / '.prueba_escritura'
                prueba.write_text('ok')
                prueba.unlink()
                resultado = (True, f'Destino local accesible: {ruta}', False)
            except OSError as exc:
                resultado = (False, f'Destino local no accesible: {exc}', True)
        elif tipo in ('smb', 'sftp'):
            resultado = (
                True, f'Destino {tipo} configurado (se validará al transferir)', False
            )
        else:
            resultado = (False, f'Tipo de destino desconocido: {tipo}', True)

        return resultado

    def validar_todo(
        self,
        consulta: Any,
        destino: Optional[Dict[str, Any]] = None
    ) -> Tuple[bool, List[str], List[str]]:
        """
        Ejecuta todas las validaciones para una consulta.

        Args:
            consulta: ConsultaDefinicion con la configuración de la consulta.
            destino: Destino YA FUSIONADO (JSON > TOML) con ruta absoluta.
                     Si es None, se usa consulta.destino (compatibilidad).
                     Antes se validaba consulta.destino crudo ("./destino_local"
                     relativo al CWD) mientras la copia real iba a
                     rutas.destino_local: se validaba un directorio distinto
                     al usado y se creaban carpetas huérfanas según el CWD.

        Returns:
            Tupla (puede_proceder, errores_criticos, advertencias).
        """
        errores: List[str] = []
        advertencias: List[str] = []

        exito, mensaje = self.validar_wallet(consulta.wallet, consulta.jdbc_url)
        if exito:
            self._log(logging.INFO, 'Validado correcto %s', mensaje)
        else:
            self._log(logging.ERROR, 'ERROR en wallet %s', mensaje)
            errores.append(f'Wallet: {mensaje}')

        exito, mensaje = self.validar_spark(consulta.spark_url)
        if exito:
            self._log(logging.INFO, 'Spark Bien %s', mensaje)
        else:
            self._log(logging.ERROR, 'ERROR Spark validación %s', mensaje)
            errores.append(f'Spark: {mensaje}')

        destino_efectivo = destino if destino is not None else consulta.destino
        exito, mensaje, es_critico = self.validar_destino(destino_efectivo)
        if exito:
            self._log(logging.INFO, 'Validar Destino %s', mensaje)
        elif es_critico:
            self._log(logging.ERROR, 'ERROR Destino %s', mensaje)
            errores.append(f'Destino: {mensaje}')
        else:
            self._log(logging.WARNING, 'ADVERTENCIA %s', mensaje)
            advertencias.append(f'Destino: {mensaje}')

        return len(errores) == 0, errores, advertencias


def abrir_transporte_sftp(servidor: Dict[str, Any], timeout: int = 10) -> paramiko.Transport:
    """
    Abre y autentica un transporte SFTP segun las credenciales del servidor.

    Args:
        servidor: Configuración con ip, puerto, usuario y credenciales.
        timeout: Segundos de espera para banner y autenticacion.

    Returns:
        Transporte paramiko ya conectado.

    Raises:
        ValueError: Si no hay credenciales (ni key_file ni password).
        paramiko.SSHException / OSError: Si la conexion o auth fallan.
    """
    ip = servidor['ip']
    puerto = servidor.get('puerto', 22)
    usuario = servidor['usuario']
    password = servidor.get('password', '')
    key_file = servidor.get('key_file', '')

    transporte = paramiko.Transport((ip, puerto))
    transporte.banner_timeout = timeout
    transporte.auth_timeout = timeout

    if key_file and Path(key_file).exists():
        clave = cargar_clave_privada(key_file, password)
        transporte.connect(username=usuario, pkey=clave)
    elif password:
        transporte.connect(username=usuario, password=password)
    else:
        transporte.close()
        raise ValueError('Sin credenciales (configura key_file o password en el TOML)')

    return transporte


class VerificadorRemoto:
    """
    Verifica por SFTP que los archivos esperados estén en los servidores.

    Toda la configuración viene del TOML. Sin valores quemados en código.
    """

    def __init__(
        self,
        servidores: List[Dict[str, Any]],
        config_verificacion: Dict[str, Any],
        logger: logging.Logger
    ):
        """
        Inicializa el verificador remoto.

        Args:
            servidores: Lista de configuraciones de servidores.
            config_verificacion: Configuración con patrones y tamaño mínimo.
            logger: Logger compartido inyectado desde el punto de entrada.
        """
        self._servidores = servidores
        self._patrones = config_verificacion.get('patrones_archivos', [])
        self._tamanio_minimo = config_verificacion.get('tamanio_minimo_bytes', 1024)
        self._logger = logger

    def _log(self, level: int, msg: str, *args: object, exc_info: bool = False) -> None:
        """Registra un mensaje con formato lazy % para compatibilidad con Pylint."""
        self._logger.log(level, msg, *args, exc_info=exc_info)

    def verificar_todos(self, anio: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Verifica cada servidor configurado.

        Args:
            anio: Año para filtrar archivos (por defecto el año actual).

        Returns:
            Lista de resultados por servidor.
        """
        anio_ver = anio or datetime.now().year
        resultados: List[Dict[str, Any]] = []

        for servidor in self._servidores:
            resultado = self._verificar_servidor(servidor, anio_ver)
            resultados.append(resultado)
            self._mostrar_resultado(resultado)

        return resultados

    def _construir_entrada_archivo(self, entrada: Any) -> Dict[str, Any]:
        """
        Construye el diccionario descriptor de un archivo remoto.

        Args:
            entrada: Entrada de directorio (SFTPAttributes).

        Returns:
            Diccionario con nombre, tamaño, fecha y estado de validacion.
        """
        tamanio = entrada.st_size or 0
        fecha = (
            datetime.fromtimestamp(entrada.st_mtime).strftime('%Y-%m-%d %H:%M:%S')
            if entrada.st_mtime else 'desconocida'
        )
        bajo_minimo = tamanio < self._tamanio_minimo
        return {
            'nombre': entrada.filename,
            'tamanio_kb': round(tamanio / 1024, 2),
            'fecha_mod': fecha,
            'ok': not bajo_minimo,
            'advertencia': (
                f'Tamaño {tamanio} B < mínimo {self._tamanio_minimo} B'
                if bajo_minimo else ''
            ),
        }

    def _verificar_servidor(
        self,
        servidor: Dict[str, Any],
        anio: int
    ) -> Dict[str, Any]:
        """
        Conecta por SFTP y lista el directorio remoto del servidor.

        Args:
            servidor: Configuración del servidor (ip, ruta, usuario, etc.).
            anio: Año para filtrar archivos.

        Returns:
            Diccionario con archivos encontrados y posibles errores.
        """
        ip = servidor['ip']
        nombre = servidor['nombre']
        ruta = servidor['ruta_remota']
        puerto = servidor.get('puerto', 22)

        resultado: Dict[str, Any] = {
            'servidor': nombre, 'ip': ip, 'ruta': ruta,
            'archivos': [], 'errores': [], 'exito': False,
        }

        transporte = None
        try:
            transporte = abrir_transporte_sftp(servidor)
            sftp = paramiko.SFTPClient.from_transport(transporte)
            entradas = sftp.listdir_attr(ruta)
            for entrada in entradas:
                if self._coincide_patron(entrada.filename, anio):
                    resultado['archivos'].append(self._construir_entrada_archivo(entrada))
            sftp.close()
            resultado['exito'] = True

        except ValueError as exc:
            resultado['errores'].append(str(exc))
        except paramiko.AuthenticationException:
            resultado['errores'].append(f'Autenticación SSH fallida en {nombre} ({ip})')
        except paramiko.SSHException as exc:
            resultado['errores'].append(f'Error SSH en {nombre}: {exc}')
        except OSError as exc:
            resultado['errores'].append(
                f'No se pudo conectar/listar {ip}:{puerto} ({ruta}) — {exc}'
            )
        finally:
            if transporte is not None:
                transporte.close()

        return resultado

    def _coincide_patron(self, nombre_archivo: str, anio: int) -> bool:
        """
        Verifica si el archivo coincide con los patrones configurados y el año.

        Args:
            nombre_archivo: Nombre del archivo en el servidor.
            anio: Año esperado en el nombre del archivo.

        Returns:
            True si el archivo debe incluirse en el resultado.
        """
        nombre_lower = nombre_archivo.lower()
        anio_str = str(anio)

        if self._patrones:
            return any(
                patron.lower() in nombre_lower and anio_str in nombre_lower
                for patron in self._patrones
            )
        return anio_str in nombre_lower

    def _mostrar_resultado(self, resultado: Dict[str, Any]) -> None:
        """
        Imprime el resultado de verificación en consola y log.

        Args:
            resultado: Diccionario con el resultado de la verificación.
        """
        icono = 'OK' if resultado['exito'] else 'ERROR'
        click.echo(f'\n{icono} {resultado["servidor"]} ({resultado["ip"]})')
        click.echo(f'   Ruta: {resultado["ruta"]}')

        if resultado['errores']:
            for err in resultado['errores']:
                click.echo(click.style(f'   ERROR: {err}', fg='red'))
        elif not resultado['archivos']:
            click.echo(click.style(
                '   Sin archivos encontrados para el año indicado', fg='yellow'
            ))
        else:
            for arch in resultado['archivos']:
                estado = 'OK' if arch['ok'] else 'ADVERTENCIA'
                linea = (
                    f'   {estado} {arch["nombre"]}  '
                    f'({arch["tamanio_kb"]} KB)  {arch["fecha_mod"]}'
                )
                if arch['advertencia']:
                    linea += f'  {arch["advertencia"]}'
                click.echo(linea)
                self._log(
                    logging.INFO,
                    'Remoto %s: %s %s KB %s',
                    resultado['servidor'], arch['nombre'],
                    arch['tamanio_kb'], arch['fecha_mod']
                )
