# -*- coding: utf-8 -*-
"""Lector de parámetros desde la tabla ADM.ADM_PARAMETRO_AMBIENTE de Oracle.

app_da_parametros_oracle.py

Se usa cuando fuente_config = "oracle" o "ambos" en el TOML.
En modo "toml" (forzar_toml = true) este módulo no se invoca.

Historial de versiones:
  * 1.0.0 (Jim A. González): Versión inicial.
  * 2.0.0 (Jim A. González): Expansión de variables de entorno.
  * 2.0.1 (Jim A. González): Filtro con predicados Spark (sin SQL
    armado por texto) y opciones JDBC comunes.
"""

import json
import logging
from typing import Any, Dict, Optional

from app.da_comunes import expandir_variables_entorno, resolver_referencia_password
from app.da_sesion_spark import opciones_jdbc

try:
    from pyspark.sql import functions as fn
    from pyspark.sql import SparkSession
except ImportError:
    fn = None
    SparkSession = None

_TABLA_PARAMETROS = 'ADM.ADM_PARAMETRO_AMBIENTE'


class ParametrosOracle:
    """Lee parámetros desde ADM.ADM_PARAMETRO_AMBIENTE siguiendo el estándar SRI."""

    def __init__(self, spark: SparkSession, jdbc_url: str, ruta_wallet: str, logger: logging.Logger):
        """
        Inicializa el lector de parámetros.

        Args:
            spark: Sesión Spark Connect activa.
            jdbc_url: URL JDBC de la base de datos Oracle.
            ruta_wallet: Ruta al directorio del wallet Oracle.
            logger: Logger compartido inyectado desde el punto de entrada.
        """
        self._spark = spark
        self._jdbc_url = jdbc_url
        self._ruta_wallet = ruta_wallet
        self._logger = logger

    def _log(self, level: int, msg: str, *args: object, exc_info: bool = False) -> None:
        """Registra un mensaje con formato lazy % para compatibilidad con Pylint."""
        self._logger.log(level, msg, *args, exc_info=exc_info)

    def obtener_parametro(
        self,
        codigo_aplicacion: str,
        nombre_parametro: str,
        ambiente: str = 'PRO'
    ) -> Optional[Dict[str, Any]]:
        """
        Obtiene un parámetro específico y parsea el JSON de VALOR_TEXTO.

        Args:
            codigo_aplicacion: Código del aplicativo (ej: 'DAT').
            nombre_parametro: Nombre del parámetro a buscar.
            ambiente: Ambiente de ejecución (PRO, DEV, QA).

        Returns:
            Diccionario con el valor del parámetro o None si no existe.
        """
        filtro = (
            (fn.col('CODIGO_APLICACION') == codigo_aplicacion)
            & (fn.col('NOMBRE_PARAMETRO') == nombre_parametro)
            & (fn.col('AMBIENTE') == ambiente)
            & (fn.col('ESTADO') == 'ACT')
            & (fn.col('ELIMINADO') == 'N')
        )

        try:
            df = (
                self._spark.read.format('jdbc')
                .options(**opciones_jdbc(self._jdbc_url, self._ruta_wallet, self._ruta_wallet))
                .option('dbtable', _TABLA_PARAMETROS)
                .load()
                .filter(filtro)
                .select('VALOR_TEXTO')
            )

            if df.count() == 0:
                self._log(
                    logging.WARNING,
                    'Parámetro no encontrado: %s.%s',
                    codigo_aplicacion, nombre_parametro
                )
                return None

            valor_texto = df.collect()[0]['VALOR_TEXTO']
            valor_expandido = expandir_variables_entorno(valor_texto)
            return json.loads(valor_expandido)

        except ValueError:
            self._log(logging.ERROR, 'Error parseando parámetro %s', nombre_parametro, exc_info=True)
            raise
        except (RuntimeError, OSError, AttributeError, KeyError, IndexError):
            self._log(logging.ERROR, 'Error leyendo parámetro %s', nombre_parametro, exc_info=True)
            raise

    def obtener_todos_parametros(
        self,
        codigo_app: str = 'DAT',
        ambiente: str = 'PRO'
    ) -> Dict[str, Any]:
        """
        Carga todos los parámetros necesarios para el proceso de exportación.

        Args:
            codigo_app: Código del aplicativo.
            ambiente: Ambiente de ejecución.

        Returns:
            Diccionario con todas las secciones de configuración.

        Raises:
            ValueError: Si faltan parámetros obligatorios.
        """
        self._log(logging.INFO, 'Cargando parámetros desde Oracle (%s/%s)...', codigo_app, ambiente)

        config = {
            'spark':  self.obtener_parametro(codigo_app, 'DATOS_ABIERTOS_SPARK_CONFIG', ambiente),
            'email':  self.obtener_parametro(codigo_app, 'DATOS_ABIERTOS_EMAIL_SERVER', ambiente),
            'smb':    self.obtener_parametro(codigo_app, 'DATOS_ABIERTOS_SMB_SERVER', ambiente),
            'sftp':   self.obtener_parametro(codigo_app, 'DATOS_ABIERTOS_SFTP_SERVER', ambiente),
            'queries': self.obtener_parametro(codigo_app, 'DATOS_ABIERTOS_QUERIES', ambiente),
            'paths':  self.obtener_parametro(codigo_app, 'DATOS_ABIERTOS_PATHS', ambiente),
        }

        if not config['spark']:
            raise ValueError('No se encontró configuración SPARK en Oracle')
        if not config['queries']:
            raise ValueError('No se encontraron QUERIES configuradas en Oracle')

        self._log(logging.INFO, 'Parámetros cargados correctamente desde Oracle')
        return config

    def resolver_password(self, referencia: str) -> str:
        """
        Resuelve una referencia de clave sin acceso a red.

        Delega en la utilidad compartida da_comunes.resolver_referencia_password
        para evitar duplicar la lógica (Regla 43 SRI).

        Args:
            referencia: Texto plano o referencia $VAR desde el TOML.

        Returns:
            Contraseña resuelta o cadena vacía si la variable no existe.
        """
        return resolver_referencia_password(referencia, self._logger)
