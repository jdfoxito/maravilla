# -*- coding: utf-8 -*-
"""
Notificador de correo con plantilla HTML para resultados de exportacion.

app/da_notificacion.py

Envia alertas de exito o error con metricas de Spark embebidas.
Fallback a archivo local si el servidor SMTP no esta disponible.
Soporta modo INTRANET: sin TLS, sin auth, puerto 25. Timeout configurable.

Historial:
+--------------------+---------+------------------------------------------+
| Autor              | Version | Cambios                                  |
+--------------------+---------+------------------------------------------+
| Jim A. González    | 1.0.0   | Version inicial texto plano              |
| Jim A. González    | 2.0.0   | Plantilla HTML, metricas Spark           |
| Jim A. González    | 3.0.0   | Config centralizada TOML, fallback TLS   |
| Jim A. González    | 3.1.0   | Modo intranet sin auth/TLS, logs debug   |
| Jim A. González    | 3.2.0   | Timeout SMTP configurable desde TOML     |
| Jim A. González    | 3.3.0   | enviar_tabla: reporte tabular (prueba de |
|                    |         | consultas)                               |
+--------------------+---------+------------------------------------------+
"""

from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from html import escape
import logging
import smtplib
from typing import Any, Dict, List, Optional, Sequence


class NotificadorEmail:
    """Envia notificaciones HTML de exito o error del proceso de exportacion."""

    def __init__(self, config: Dict[str, Any], logger: logging.Logger):
        """
        Inicializa el notificador con la configuracion de correo.

        Args:
            config: Diccionario con smtp_server, smtp_port, username, password,
                    from_address, to_addresses, use_tls, timeout.
            logger: Logger compartido inyectado desde el punto de entrada.
        """
        self._logger = logger
        self._smtp_server = config.get('smtp_server', 'localhost')
        self._smtp_port = int(config.get('smtp_port', 25))
        self._timeout = int(config.get('timeout', 15))
        self._usuario = config.get('username', '')
        self._password = config.get('password', '')
        self._remitente = config.get('from_address', 'python@sri.ad')
        self._destinatarios = config.get('to_addresses', ['python@sri.ad'])
        self._usar_tls = bool(config.get('use_tls', False))

        self._modo_intranet = (
            not self._usar_tls
            and not self._password
            and self._smtp_port == 25
        )

        if self._modo_intranet:
            self._log(
                logging.INFO,
                "[INTRANET] Servidor SMTP sin autenticacion. Host=%s:%s (timeout=%ss)",
                self._smtp_server, self._smtp_port, self._timeout
            )
        else:
            self._log(
                logging.INFO,
                "[EXTERNO] Host=%s:%s TLS=%s User=%s timeout=%ss",
                self._smtp_server, self._smtp_port, self._usar_tls, self._usuario or 'N/A',
                self._timeout
            )

    def _log(self, level: int, msg: str, *args: object, exc_info: bool = False) -> None:
        """Registra un mensaje con formato lazy % para compatibilidad con Pylint."""
        self._logger.log(level, msg, *args, exc_info=exc_info)

    def _conectar_y_enviar(self, msg: MIMEMultipart) -> None:
        """
        Abre la conexion SMTP, aplica TLS/auth segun config y envia el mensaje.

        Args:
            msg: Mensaje MIME ya construido.

        Raises:
            smtplib.SMTPException / OSError: si la conexion o el envio fallan.
        """
        self._log(
            logging.INFO,
            "SMTP >> Conectando a %s:%s (timeout=%ss)...",
            self._smtp_server, self._smtp_port, self._timeout
        )
        with smtplib.SMTP(self._smtp_server, self._smtp_port, timeout=self._timeout) as servidor:
            self._log(logging.DEBUG, "SMTP >> Conexion establecida. Intranet=%s", self._modo_intranet)

            if self._usar_tls:
                self._log(logging.DEBUG, "SMTP >> Iniciando STARTTLS ...")
                servidor.starttls()
                self._log(logging.INFO, "SMTP >> STARTTLS completado")

            if self._usuario and self._password:
                self._log(logging.DEBUG, "SMTP >> Autenticando como '%s' ...", self._usuario)
                servidor.login(self._usuario, self._password)
                self._log(logging.INFO, "SMTP >> Autenticacion exitosa")
            else:
                self._log(logging.INFO, "SMTP >> Sin autenticacion (modo intranet o credenciales vacias)")

            servidor.sendmail(self._remitente, self._destinatarios, msg.as_string())
            self._log(logging.INFO, "SMTP >> Correo enviado correctamente")

    def enviar_notificacion(
        self,
        asunto: str,
        consulta_id: str,
        resultado_transferencia: Dict[str, Any],
        detalles_spark: Optional[Dict[str, Any]] = None,
        error: Optional[str] = None
    ) -> bool:
        """
        Envia correo con el resultado de la operacion.

        Args:
            asunto: Asunto del correo (COMPLETADO o ERROR).
            consulta_id: Identificador de la consulta ejecutada.
            resultado_transferencia: Diccionario con datos de la transferencia.
            detalles_spark: Metricas de Spark.
            error: Mensaje de error si el proceso fallo.

        Returns:
            True si el correo fue enviado correctamente.
        """
        if not self._smtp_server:
            self._log(logging.WARNING, "SMTP no configurado (smtp_server vacio). Omitiendo envio.")
            return False

        msg = MIMEMultipart('alternative')
        msg['Subject'] = f'[Datos Abiertos] {asunto} - {consulta_id}'
        msg['From'] = self._remitente
        msg['To'] = ', '.join(self._destinatarios)
        msg.attach(MIMEText(
            self._generar_html(consulta_id, resultado_transferencia, detalles_spark, error),
            'html', 'utf-8'
        ))

        enviado = False
        try:
            self._conectar_y_enviar(msg)
            enviado = True
        except (smtplib.SMTPException, OSError):
            self._log(
                logging.ERROR,
                "SMTP >> Fallo al enviar a %s:%s", self._smtp_server, self._smtp_port,
                exc_info=True
            )

        return enviado

    def enviar_tabla(self, asunto: str, titulo: str, encabezados: Sequence[str], filas: List[Sequence[Any]], hay_error: bool) -> bool:
        """
        Envia un reporte con una tabla HTML (por ejemplo, prueba de consultas).

        Args:
            asunto: Asunto del correo, sin el prefijo [Datos Abiertos].
            titulo: Titulo del encabezado del correo.
            encabezados: Nombres de las columnas.
            filas: Filas de la tabla; los valores se escapan para HTML.
            hay_error: True pinta el encabezado en rojo.

        Returns:
            True si el correo fue enviado correctamente.
        """
        if not self._smtp_server:
            self._log(logging.WARNING, 'SMTP no configurado (smtp_server vacio). Omitiendo envio.')
            return False

        msg = MIMEMultipart('alternative')
        msg['Subject'] = f'[Datos Abiertos] {asunto}'
        msg['From'] = self._remitente
        msg['To'] = ', '.join(self._destinatarios)
        msg.attach(MIMEText(self._generar_html_tabla(titulo, encabezados, filas, hay_error), 'html', 'utf-8'))

        enviado = False
        try:
            self._conectar_y_enviar(msg)
            enviado = True
        except (smtplib.SMTPException, OSError):
            self._log(logging.ERROR, 'SMTP >> Fallo al enviar a %s:%s', self._smtp_server, self._smtp_port, exc_info=True)
        return enviado

    @staticmethod
    def _generar_html_tabla(titulo: str, encabezados: Sequence[str], filas: List[Sequence[Any]], hay_error: bool) -> str:
        """Genera el cuerpo HTML de un reporte tabular."""
        color = '#d32f2f' if hay_error else '#388e3c'
        celda = 'style="border:1px solid #ddd;padding:6px;text-align:left;vertical-align:top"'
        cabecera = ''.join(f'<th {celda}>{escape(str(valor))}</th>' for valor in encabezados)
        cuerpo = ''.join(
            '<tr>' + ''.join(f'<td {celda}>{escape(str(valor))}</td>' for valor in fila) + '</tr>'
            for fila in filas
        )
        fecha_actual = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        return (
            '<html><body style="font-family:Arial,sans-serif;background-color:#f5f5f5">'
            '<div style="background:#fff;padding:20px;border-radius:8px;margin:20px">'
            f'<div style="background-color:{color};color:#fff;padding:15px;border-radius:5px">'
            f'<h2>{escape(titulo)}</h2><p>Fecha: {fecha_actual}</p></div>'
            f'<table style="border-collapse:collapse;margin-top:12px;font-size:13px"><tr>{cabecera}</tr>{cuerpo}</table>'
            '</div><p style="text-align:center;color:#666;font-size:12px">Sistema Automatico de Datos Abiertos — SRI</p>'
            '</body></html>'
        )

    @staticmethod
    def _generar_html(consulta_id: str, transferencia: Dict[str, Any], detalles_spark: Optional[Dict[str, Any]], error: Optional[str]) -> str:
        """
        Genera el cuerpo HTML del correo.

        Args:
            consulta_id: ID de la consulta.
            transferencia: Datos de la transferencia.
            detalles_spark: Metricas de procesamiento Spark.
            error: Mensaje de error si aplica.

        Returns:
            Cadena HTML lista para enviar.
        """
        hay_error = bool(error or not transferencia.get('exito'))
        estado = 'ERROR' if hay_error else 'EXITO'
        color_principal = '#d32f2f' if hay_error else '#388e3c'
        fecha_actual = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        html = (
            '<html><head>'
            '<style>'
            'body{font-family:Arial,sans-serif;background-color:#f5f5f5}'
            '.contenedor{background:#fff;padding:20px;border-radius:8px;margin:20px}'
            f'.encabezado{{background-color:{color_principal};color:#fff;'
            'padding:15px;border-radius:5px}'
            f'.detalle{{margin:10px 0;padding:10px;background:#f9f9f9;'
            f'border-left:4px solid {color_principal}}}'
            '.exito{color:#388e3c;font-weight:bold}'
            '.error{color:#d32f2f;font-weight:bold}'
            '</style></head><body>'
            '<div class="contenedor">'
            '<div class="encabezado">'
            f'<h2>{estado} - Exportacion Datos Abiertos</h2>'
            f'<p>Proceso: {consulta_id} | Fecha: {fecha_actual}</p>'
            '</div>'
        )

        if error:
            html += (
                '<div class="detalle">'
                '<h3 class="error">Error en procesamiento:</h3>'
                f'<p>{error}</p>'
                '</div>'
            )
        else:
            estado_texto = 'Si' if transferencia.get('exito') else 'No'
            clase_estado = 'exito' if transferencia.get('exito') else 'error'
            tipo_tx = transferencia.get('tipo', 'N/A').upper()
            archivo_tx = transferencia.get('archivo_destino', 'N/A')
            tamanio_mb = transferencia.get('tamanio_mb', 0)
            tamanio_bytes = transferencia.get('tamanio_bytes', 0)
            ruta_tx = transferencia.get('ruta_destino', 'N/A')
            mensaje_tx = transferencia.get('mensaje', 'N/A')
            html += (
                '<div class="detalle"><h3>Resumen de transferencia:</h3><ul>'
                f'<li><strong>Estado:</strong> '
                f'<span class="{clase_estado}">{estado_texto}</span></li>'
                f'<li><strong>Tipo:</strong> {tipo_tx}</li>'
                f'<li><strong>Archivo:</strong> {archivo_tx}</li>'
                f'<li><strong>Tamano:</strong> {tamanio_mb} MB '
                f'({tamanio_bytes:,} bytes)</li>'
                f'<li><strong>Ruta destino:</strong> {ruta_tx}</li>'
                f'<li><strong>Mensaje:</strong> {mensaje_tx}</li>'
                '</ul></div>'
            )

            if detalles_spark:
                total_reg = detalles_spark.get('total_registros', 0)
                t_lectura = detalles_spark.get('tiempo_lectura', 'N/A')
                t_total = detalles_spark.get('tiempo_total', 'N/A')
                velocidad = detalles_spark.get('velocidad', 0)
                html += (
                    '<div class="detalle"><h3>Detalles Spark:</h3><ul>'
                    f'<li>Registros procesados: {total_reg:,}</li>'
                    f'<li>Tiempo lectura: {t_lectura}s</li>'
                    f'<li>Tiempo total: {t_total}s</li>'
                    f'<li>Velocidad: {velocidad:,.0f} reg/s</li>'
                    '</ul></div>'
                )

        html += (
            '</div>'
            '<p style="text-align:center;color:#666;font-size:12px">'
            'Sistema Automatico de Datos Abiertos — SRI'
            '</p></body></html>'
        )
        return html
