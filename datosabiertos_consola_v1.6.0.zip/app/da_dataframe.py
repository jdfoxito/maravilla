# -*- coding: utf-8 -*-
"""Procesamiento de DataFrames Spark despues de la extraccion Oracle.

app-da_dataframe.py

Punto UNICO de extension para las transformaciones de negocio sobre el
DataFrame leido desde Oracle, ANTES de escribir el CSV. Cuando aparezca
una historia nueva con reglas de negocio, solo se toca este modulo:
se registra un proceso nuevo y se declara en el JSON de la consulta.
El resto de clases (exportador, validador, notificacion) no cambia.

Como se declara en el JSON de la consulta (todo opcional):

  {
    "proceso":  "proceso_caso2",                  <- pipeline de negocio
    "columnas": {"col_origen": "COLUMNA_FINAL"},  <- renombra, reordena
                                                     y descarta lo no listado
    "orden":    [{"columna": "CATEGORIA", "ascendente": false}],
    "catalogos": {"canton_sql": "SELECT ..."}     <- SQL auxiliares
  }

Si el JSON no declara nada de lo anterior, el DataFrame pasa SIN
CAMBIOS (comportamiento historico de las historias 1 a 3).

Orden del pipeline en ProcesadorDataFrame.aplicar():
  1. proceso  (reglas de negocio, sobre los nombres ORIGINALES del SQL)
  2. columnas (renombre/seleccion final, declarativo desde el JSON)
  3. orden    (ordenamiento final, declarativo desde el JSON)

NOTA REDONDEO: la proteccion x1.5 usa round() de Spark (HALF_UP), NO el
round() de Python (banker's rounding). Con 676163 x 1.5 = 1014244.5 el
SDC espera 1014245; el round de Python devolveria 1014244.

Historial:
+--------------------+---------+------------------------------------------+
| Autor              | Version | Cambios                                  |
+--------------------+---------+------------------------------------------+
| Jim A. Gonzalez    | 1.0.0   | Dispatcher + proceso_caso1 +             |
|                    |         | proceso_caso2 (Catastro Vehicular SDC)   |
| Jim A. Gonzalez    | 1.1.0   | normalizar_decimales: NUMBER de Oracle   |
|                    |         | sin ceros decimales en el CSV            |
+--------------------+---------+------------------------------------------+
"""

from dataclasses import dataclass
from functools import reduce
import logging
from typing import Any, Callable, Dict, List, Optional

from pyspark.sql import DataFrame
from pyspark.sql import functions as fn
from pyspark.sql import SparkSession
from pyspark.sql.types import DecimalType

from app.da_modelos import ConsultaDefinicion


# -- Constantes de negocio (SDC Catastro Vehicular, 29/10/2025) ---------

_FACTOR_PROTECCION = 1.5
_COLUMNAS_PROTEGIDAS = ('codigo_vehiculo', 'codigo_sub_categoria')
_COL_CANTON = 'codigo_canton'
_COL_PERSONA = 'tipo_identificac_potenc_prop'
_MAPA_PERSONA = {'C': 'NATURAL', 'P': 'NATURAL', 'R': 'JURÍDICA'}


@dataclass
class ContextoProceso:
    """Datos de apoyo que un proceso de negocio puede necesitar.

    Atributos:
        spark: Sesion Spark Connect activa (la misma de la extraccion).
        jdbc_opts: Opciones JDBC en uso (url, wallet, driver) para leer
                   catalogos auxiliares desde la MISMA base.
        consulta: ConsultaDefinicion con las declaraciones del JSON.
        logger: Logger compartido del proceso.
        lector_catalogos: Inyeccion opcional para pruebas unitarias;
                   funcion (sql) -> DataFrame. Si es None, se lee via
                   JDBC con jdbc_opts.
    """

    spark: Any
    jdbc_opts: Dict[str, str]
    consulta: ConsultaDefinicion
    logger: logging.Logger
    lector_catalogos: Optional[Callable[[str], DataFrame]] = None


def _leer_catalogo(ctx: ContextoProceso, sql: str) -> DataFrame:
    """Lee un catalogo auxiliar (ADM) con la misma conexion de la consulta.

    Args:
        ctx: Contexto del proceso.
        sql: Consulta SQL del catalogo (declarada en el JSON).

    Returns:
        DataFrame Spark con el catalogo.
    """
    if ctx.lector_catalogos is not None:
        return ctx.lector_catalogos(sql)
    return (
        ctx.spark.read.format('jdbc').options(**ctx.jdbc_opts)
        .option('query', sql).load()
    )


def normalizar_decimales(df: DataFrame, logger: logging.Logger) -> DataFrame:
    """Escribe los NUMBER de Oracle sin ceros decimales sobrantes.

    Oracle NUMBER sin precision (COUNT, SUM, EXTRACT, ROUND) llega a
    Spark como Decimal(38,10) y el CSV mostraba 2026.0000000000. Se
    convierte a texto sin ceros: 2026, 1084868, 12.5. Las columnas que
    ya son texto (TO_CHAR del avaluo) no se tocan.

    Args:
        df: DataFrame leido desde Oracle.
        logger: Logger compartido.

    Returns:
        DataFrame con las columnas decimales normalizadas.
    """
    columnas = [
        campo.name for campo in df.schema.fields
        if isinstance(campo.dataType, DecimalType) and campo.dataType.scale > 0
    ]
    for nombre in columnas:
        texto = fn.col(f'`{nombre}`').cast('string')
        sin_ceros = fn.regexp_replace(texto, r'(\.\d*?[1-9])0+$', '$1')
        df = df.withColumn(nombre, fn.regexp_replace(sin_ceros, r'\.0+$', ''))
    if columnas:
        logger.info('Decimales normalizados: %s', ', '.join(columnas))
    return df


# -- Procesos de negocio registrados ------------------------------------


def proceso_caso1(df: DataFrame, ctx: ContextoProceso) -> DataFrame:
    """Caso 1 - Facturacion (historias 1 a 3): sin transformaciones.

    Se registra para dejar explicito que el caso existe y que no
    requiere logica de negocio: retorna el DataFrame tal cual.

    Args:
        df: DataFrame leido desde Oracle.
        ctx: Contexto del proceso.

    Returns:
        El mismo DataFrame, sin cambios.
    """
    ctx.logger.info('proceso_caso1: sin transformaciones de negocio')
    return df


def proceso_caso2(df: DataFrame, ctx: ContextoProceso) -> DataFrame:
    """Caso 2 - Catastro Vehicular (historia 5, SDC 29/10/2025).

    Reglas aplicadas sobre los nombres ORIGINALES del SQL:
      1. Proteccion de datos: codigo_vehiculo y codigo_sub_categoria
         se multiplican por 1.5 con redondeo HALF_UP a unidad
         (round de Spark, no el de Python).
      2. Tipo de persona: C/P -> NATURAL, R -> JURIDICA.
      3. Canton: codigo_canton se reemplaza por la descripcion del
         catalogo ADM (catalogos.canton_sql en el JSON). Si no hay
         catalogo configurado, se conserva el codigo y se registra
         una advertencia.

    El renombre de columnas y el ordenamiento NO van aqui: se declaran
    en el JSON ("columnas" y "orden") y los aplica el dispatcher despues.

    Args:
        df: DataFrame leido desde Oracle.
        ctx: Contexto del proceso.

    Returns:
        DataFrame con las reglas de negocio aplicadas.
    """
    ctx.logger.info('proceso_caso2: aplicando reglas Catastro Vehicular')
    return _aplicar_catalogo_canton(
        _aplicar_mapa_persona(
            _aplicar_proteccion(df, ctx),
            ctx
        ),
        ctx
    )


def _aplicar_proteccion(df: DataFrame, ctx: ContextoProceso) -> DataFrame:
    """Multiplica por 1.5 y redondea a unidad las columnas protegidas.

    Usa fn.round (HALF_UP) y castea a long para que el CSV no muestre
    decimales. Los nulos se conservan.

    Args:
        df: DataFrame de entrada.
        ctx: Contexto del proceso.

    Returns:
        DataFrame con las columnas protegidas transformadas.
    """
    for columna in _COLUMNAS_PROTEGIDAS:
        if columna in df.columns:
            df = df.withColumn(
                columna,
                fn.round(
                    fn.col(columna).cast('double') * fn.lit(_FACTOR_PROTECCION), 0
                ).cast('long')
            )
            ctx.logger.info(
                'proceso_caso2: %s protegido (x%.1f, redondeo unidad)',
                columna, _FACTOR_PROTECCION
            )
        else:
            ctx.logger.warning(
                'proceso_caso2: columna protegida %s no existe en el resultado',
                columna
            )
    return df


def _aplicar_mapa_persona(df: DataFrame, ctx: ContextoProceso) -> DataFrame:
    """Mapea el tipo de persona: C/P -> NATURAL, R -> JURIDICA.

    Los valores no contemplados se conservan tal cual (no se pierde
    informacion) y se deja traza en el log.

    Args:
        df: DataFrame de entrada.
        ctx: Contexto del proceso.

    Returns:
        DataFrame con la columna de persona mapeada.
    """
    if _COL_PERSONA not in df.columns:
        ctx.logger.warning(
            'proceso_caso2: columna %s no existe, se omite mapeo persona',
            _COL_PERSONA
        )
        return df

    normalizada = fn.upper(fn.trim(fn.col(_COL_PERSONA)))
    expresion = fn.col(_COL_PERSONA)
    for codigo, descripcion in _MAPA_PERSONA.items():
        expresion = fn.when(normalizada == codigo, fn.lit(descripcion)).otherwise(expresion)

    ctx.logger.info(
        'proceso_caso2: %s mapeado (%s)',
        _COL_PERSONA, ', '.join(f'{k}->{v}' for k, v in _MAPA_PERSONA.items())
    )
    return df.withColumn(_COL_PERSONA, expresion)


def _aplicar_catalogo_canton(df: DataFrame, ctx: ContextoProceso) -> DataFrame:
    """Reemplaza codigo_canton por su descripcion del catalogo ADM.

    El SQL del catalogo se declara en el JSON (catalogos.canton_sql) y
    debe devolver (codigo, descripcion) en ese orden. El join es LEFT con
    broadcast: si un codigo no tiene descripcion, se conserva el codigo
    original (no se pierde el dato).

    Args:
        df: DataFrame de entrada.
        ctx: Contexto del proceso.

    Returns:
        DataFrame con codigo_canton reemplazado por la descripcion.
    """
    if _COL_CANTON not in df.columns:
        return df

    catalogos = ctx.consulta.catalogos or {}
    sql_catalogo = catalogos.get('canton_sql', '')
    if not sql_catalogo:
        ctx.logger.warning(
            'proceso_caso2: sin catalogos.canton_sql en el JSON; '
            '%s se conserva como codigo',
            _COL_CANTON
        )
        return df

    catalogo = _leer_catalogo(ctx, sql_catalogo)
    cols_catalogo = catalogo.columns
    if len(cols_catalogo) < 2:
        raise ValueError(
            f'Catalogo de cantones invalido: se esperaban >= 2 columnas '
            f'(codigo, descripcion), llegaron: {cols_catalogo}'
        )

    cat = catalogo.select(
        fn.col(cols_catalogo[0]).cast('string').alias('_cat_codigo'),
        fn.col(cols_catalogo[1]).cast('string').alias('_cat_desc'),
    )
    unidos = df.join(
        fn.broadcast(cat),
        df[_COL_CANTON].cast('string') == cat['_cat_codigo'],
        'left'
    )
    ctx.logger.info(
        'proceso_caso2: %s mapeado con catalogo ADM (%s filas)',
        _COL_CANTON, sql_catalogo[:60]
    )
    return unidos.withColumn(
        _COL_CANTON,
        fn.coalesce(unidos['_cat_desc'], unidos[_COL_CANTON])
    ).drop('_cat_codigo', '_cat_desc')


# -- Dispatcher ----------------------------------------------------------


class ProcesadorDataFrame:
    """Aplica el pipeline de transformaciones declarado en el JSON.

    Registro de procesos de negocio disponibles. Para una historia
    nueva: se escribe la funcion proceso_casoN y se agrega aqui; el
    JSON la referencia por nombre con la clave "proceso".
    """

    PROCESOS: Dict[str, Callable[[DataFrame, ContextoProceso], DataFrame]] = {}

    def __init__(self, logger: logging.Logger):
        """Inicializa el procesador.

        Args:
            logger: Logger compartido inyectado desde el punto de entrada.
        """
        self._logger = logger

    def _log(self, level: int, msg: str, *args: object, exc_info: bool = False) -> None:
        """Registra un mensaje con formato lazy % para compatibilidad con Pylint."""
        self._logger.log(level, msg, *args, exc_info=exc_info)

    def aplicar(self, df: DataFrame, ctx: ContextoProceso) -> DataFrame:
        """Ejecuta el pipeline: proceso -> columnas -> orden.

        Args:
            df: DataFrame leido desde Oracle.
            ctx: Contexto con la consulta y sus declaraciones JSON.

        Returns:
            DataFrame transformado.

        Raises:
            ValueError: Si el proceso declarado no esta registrado o
                        falta alguna columna requerida.
        """
        return reduce(
            lambda actual, paso: paso(actual), self._pipeline(ctx), df
        )

    def _pipeline(
        self, ctx: ContextoProceso
    ) -> List[Callable[[DataFrame], DataFrame]]:
        """Construye los pasos del pipeline segun lo declarado en el JSON.

        Solo se incluyen los pasos declarados; si el JSON no declara
        nada, la lista queda vacia y el DataFrame pasa sin cambios.
        """
        pasos: List[Callable[[DataFrame], DataFrame]] = []

        nombre = (ctx.consulta.proceso or '').strip()
        if nombre:
            pasos.append(
                lambda actual: self._aplicar_proceso(actual, ctx, nombre)
            )

        if ctx.consulta.columnas:
            pasos.append(
                lambda actual: self._aplicar_columnas(actual, ctx.consulta.columnas)
            )

        if ctx.consulta.orden:
            pasos.append(
                lambda actual: self._aplicar_orden(actual, ctx.consulta.orden)
            )

        return pasos

    def _aplicar_proceso(
        self, df: DataFrame, ctx: ContextoProceso, nombre: str
    ) -> DataFrame:
        """Resuelve y ejecuta el proceso de negocio por nombre.

        Args:
            df: DataFrame de entrada.
            ctx: Contexto del proceso.
            nombre: Nombre declarado en el JSON.

        Returns:
            DataFrame con las reglas de negocio aplicadas.

        Raises:
            ValueError: Si el nombre no esta registrado.
        """
        funcion = self.PROCESOS.get(nombre)
        if funcion is None:
            raise ValueError(
                f'Proceso "{nombre}" no registrado. '
                f'Disponibles: {sorted(self.PROCESOS)}'
            )
        self._log(logging.INFO, 'Aplicando proceso de negocio: %s', nombre)
        return funcion(df, ctx)

    def _aplicar_columnas(
        self, df: DataFrame, columnas: Dict[str, str]
    ) -> DataFrame:
        """Renombra, reordena y selecciona columnas segun el JSON.

        Solo quedan las columnas listadas, en el orden del mapeo y con
        su nombre final. Si falta alguna columna origen se aborta con
        error (fail-fast: el correo de alerta se dispara aguas arriba).

        Args:
            df: DataFrame de entrada.
            columnas: Mapeo {nombre_origen: NOMBRE_FINAL}.

        Returns:
            DataFrame con las columnas finales.

        Raises:
            ValueError: Si alguna columna origen no existe.
        """
        faltantes = [c for c in columnas if c not in df.columns]
        if faltantes:
            raise ValueError(
                f'Columnas no encontradas para renombrar: {faltantes}. '
                f'Disponibles: {df.columns}'
            )
        self._log(
            logging.INFO,
            'Columnas finales: %s renombradas/seleccionadas',
            len(columnas)
        )
        return df.select(
            [fn.col(origen).alias(destino) for origen, destino in columnas.items()]
        )

    def _aplicar_orden(
        self, df: DataFrame, orden: List[Dict[str, Any]]
    ) -> DataFrame:
        """Ordena el DataFrame segun la declaracion del JSON.

        Args:
            df: DataFrame de entrada.
            orden: Lista de {"columna": nombre, "ascendente": bool}.

        Returns:
            DataFrame ordenado.

        Raises:
            ValueError: Si alguna columna de ordenamiento no existe.
        """
        criterios = []
        for item in orden:
            columna = item.get('columna', '')
            if columna not in df.columns:
                raise ValueError(
                    f'Columna de ordenamiento no existe: "{columna}". '
                    f'Disponibles: {df.columns}'
                )
            ascendente = bool(item.get('ascendente', True))
            criterios.append(
                fn.col(columna).asc() if ascendente else fn.col(columna).desc()
            )
        self._log(logging.INFO, 'Ordenamiento aplicado: %s', orden)
        return df.orderBy(criterios)


ProcesadorDataFrame.PROCESOS.update({
    'proceso_caso1': proceso_caso1,
    'proceso_caso2': proceso_caso2,
})


# -- Prueba local (sin Oracle): python -m app.da_dataframe --------------


def _datos_muestra() -> List[Dict[str, Any]]:
    """Registros de muestra tomados de la SDC Catastro Vehicular.

    Returns:
        Filas con los valores esperados del documento (mas una fila
        extra para validar ordenamiento y mapeo JURIDICA).
    """
    fila_base = {
        'tipo_transaccion': 'COMPRA LOCAL',
        'fecha_proceso': '2026-06-09 11:22:48',
        'codigo_vehiculo': 7222346,
        'codigo_tipo_servicio': 'PAR',
        'capacidad_pasajeros': 2,
        'cilindraje': 150,
        'codigo_tipo_combustible': 'GASOLINA',
        'codigo_sub_categoria': 676163,
        'fecha_compra_registro': '2026-06-08',
        'codigo_canton': '11201',
        'numero_camv_cpn': 'M00163609',
        'tipo_identificac_potenc_prop': 'C',
        'codigo_color_crea1': 'NEG',
        'codigo_color_crea2': 'NEG',
        'marca': 'RANGER',
        'modelo': '150GY',
        'pais': 'CHINA POPULAR',
        'anio_modelo': 2026,
        'clase': 'MOTOCICLETA',
        'nombre_sub_clase': 'PASEO',
        'tipo_sub_clase': 'LIVIANO',
        'anio_fiscal_desde': 2026,
        'anio_fiscal_hasta': 2026,
        'valor_avaluo': 998.34,
        'codigo_estado_activo_inactivo': 'ACT',
        'FECHA_CARGA': '2026-07-17 11:38:32',
    }
    fila_juridica = dict(
        fila_base,
        codigo_vehiculo=100,
        codigo_sub_categoria=900000,
        tipo_identificac_potenc_prop='R',
        codigo_canton='99999',
        numero_camv_cpn='M99999999',
    )
    return [fila_base, fila_juridica]


def _consulta_prueba(con_catalogo: bool = True) -> ConsultaDefinicion:
    """Construye la ConsultaDefinicion de prueba (misma estructura del JSON).

    Args:
        con_catalogo: True para incluir catalogos.canton_sql.

    Returns:
        ConsultaDefinicion equivalente a facturacion_sql_historia5.json.
    """
    return ConsultaDefinicion.desde_dict({
        'id': 'facturacion_sql_historia5',
        'proceso': 'proceso_caso2',
        'catalogos': (
            {'canton_sql': 'SELECT CODIGO_CANTON, DESCRIPCION FROM ADM.ADM_CANTON'}
            if con_catalogo else {}
        ),
        'columnas': {
            'codigo_sub_categoria': 'CATEGORIA',
            'codigo_vehiculo': 'CODIGO_VEHICULO',
            'tipo_transaccion': 'TIPO_TRANSACCION',
            'marca': 'MARCA',
            'modelo': 'MODELO',
            'pais': 'PAIS',
            'anio_modelo': 'ANO_MODELO',
            'clase': 'CLASE',
            'nombre_sub_clase': 'SUB_CLASE',
            'tipo_sub_clase': 'TIPO',
            'valor_avaluo': 'AVALUO',
            'fecha_proceso': 'FECHA_PROCESO',
            'codigo_tipo_servicio': 'TIPO_SERVICIO',
            'cilindraje': 'CILINDRAJE',
            'codigo_tipo_combustible': 'TIPO_COMBUSTIBLE',
            'fecha_compra_registro': 'FECHA_COMPRA_REGISTRO',
            'codigo_canton': 'CANTON',
            'codigo_color_crea1': 'COLOR1',
            'codigo_color_crea2': 'COLOR2',
            'tipo_identificac_potenc_prop': 'PERSONA_NATURAL_JURIDICA',
            'capacidad_pasajeros': 'CAPACIDAD_PASAJEROS',
            'numero_camv_cpn': 'NUMERO_CAMV_CPN',
        },
        'orden': [{'columna': 'CATEGORIA', 'ascendente': False}],
    })


def _verificar(condicion: bool, detalle: Any) -> None:
    """Sustituto de assert que sobrevive a la optimizacion -O."""
    if not condicion:
        raise AssertionError(detalle)


def _prueba_local() -> None:
    """Valida proceso_caso2 con datos de muestra, sin Oracle ni Spark Connect.

    Crea una sesion Spark local e inyecta un catalogo de cantones falso
    via ContextoProceso.lector_catalogos. Verifica:
      - 7222346 x 1.5  -> 10833519
      - 676163  x 1.5  -> 1014245  (HALF_UP, no banker's rounding)
      - C -> NATURAL, R -> JURIDICA
      - canton mapeado por catalogo / conservado sin catalogo
      - 22 columnas finales en el orden del SDC
      - orden por CATEGORIA descendente
    """
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s [%(levelname)s] %(name)s: %(message)s'
    )
    logger = logging.getLogger('prueba_da_dataframe')
    spark = (
        SparkSession.builder.master('local[2]')
        .appName('prueba_da_dataframe')
        .getOrCreate()
    )
    spark.sparkContext.setLogLevel('ERROR')

    try:
        catalogo_falso = spark.createDataFrame(
            [('11201', 'GUAYAQUIL'), ('10901', 'QUITO')],
            ['CODIGO_CANTON', 'DESCRIPCION']
        )
        procesador = ProcesadorDataFrame(logger)

        consulta = _consulta_prueba(con_catalogo=True)
        ctx = ContextoProceso(
            spark=spark, jdbc_opts={}, consulta=consulta, logger=logger,
            lector_catalogos=lambda _sql: catalogo_falso,
        )
        df = procesador.aplicar(
            spark.createDataFrame(_datos_muestra()), ctx
        ).cache()
        filas = df.collect()

        _verificar(df.columns == list(consulta.columnas.values()), df.columns)
        _verificar(len(filas) == 2, filas)

        primera, segunda = filas
        _verificar(primera['CATEGORIA'] == 1350000, primera['CATEGORIA'])
        _verificar(segunda['CATEGORIA'] == 1014245, segunda['CATEGORIA'])
        _verificar(segunda['CODIGO_VEHICULO'] == 10833519, segunda['CODIGO_VEHICULO'])
        _verificar(primera['CODIGO_VEHICULO'] == 150, primera['CODIGO_VEHICULO'])
        _verificar(segunda['PERSONA_NATURAL_JURIDICA'] == 'NATURAL',
                   segunda['PERSONA_NATURAL_JURIDICA'])
        _verificar(primera['PERSONA_NATURAL_JURIDICA'] == 'JURÍDICA',
                   primera['PERSONA_NATURAL_JURIDICA'])
        _verificar(segunda['CANTON'] == 'GUAYAQUIL', segunda['CANTON'])
        _verificar(primera['CANTON'] == '99999', primera['CANTON'])
        logger.info('CASO A OK: pipeline completo con catalogo')

        consulta_sin = _consulta_prueba(con_catalogo=False)
        ctx_sin = ContextoProceso(
            spark=spark, jdbc_opts={}, consulta=consulta_sin, logger=logger,
        )
        df_sin = procesador.aplicar(spark.createDataFrame(_datos_muestra()), ctx_sin)
        cantones = {f['CANTON'] for f in df_sin.collect()}
        _verificar(cantones == {'11201', '99999'}, cantones)
        logger.info('CASO B OK: sin catalogo, codigo_canton se conserva')

        consulta_vacia = ConsultaDefinicion.desde_dict({'id': 'historia1'})
        ctx_vacio = ContextoProceso(spark=spark, jdbc_opts={}, consulta=consulta_vacia, logger=logger, )
        df_origen = spark.createDataFrame(_datos_muestra()).cache()
        df_pasado = procesador.aplicar(df_origen, ctx_vacio).cache()
        _verificar(df_pasado.columns == df_origen.columns, 'columnas difieren tras paso intacto')
        _verificar(df_pasado.count() == df_origen.count(), 'conteo difiere tras paso intacto')
        logger.info('CASO C OK: sin declaraciones, el DataFrame pasa sin cambios')
        logger.info('TODAS LAS PRUEBAS PASARON')
    finally:
        spark.stop()


if __name__ == '__main__':
    _prueba_local()
