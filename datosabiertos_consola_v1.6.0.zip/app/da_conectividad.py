"""Diagnostico de acceso al correo y a los servidores de descarga.

app/da_conectividad.py

Se ejecuta antes de exportar o probar consultas. Define como se
comporta el proceso cuando falta un servicio:
  - Sin correo: la notificacion queda en el log, la consola y
    mails_enviados/ (no se espera el timeout SMTP en cada consulta).
  - Sin servidor de descarga: no se publica en ese servidor; el archivo
    queda en destino_local (data/output).

Historial:
+--------------------+---------+------------------------------------------+
| Autor              | Version | Cambios                                  |
+--------------------+---------+------------------------------------------+
| Jim A. Gonzalez    | 1.0.0   | Diagnostico SMTP y SFTP previo           |
+--------------------+---------+------------------------------------------+
"""

from dataclasses import dataclass, field
import logging
import smtplib
import socket
from typing import Any, Dict, List

import paramiko

from app.da_validador import abrir_transporte_sftp

TIMEOUT_SEGUNDOS = 8


@dataclass
class EstadoServicio:
    """Disponibilidad de un servicio externo. Entidad pasiva (Regla 44 SRI)."""

    nombre: str
    destino: str
    disponible: bool
    detalle: str


@dataclass
class EstadoConectividad:
    """Resultado del diagnostico. Entidad pasiva (Regla 44 SRI)."""

    correo: EstadoServicio
    servidores: List[EstadoServicio] = field(default_factory=list)


def probar_puerto(host: str, puerto: int, timeout: int = TIMEOUT_SEGUNDOS) -> str:
    """
    Intenta abrir una conexion TCP.

    Args:
        host: Nombre o IP.
        puerto: Puerto TCP.
        timeout: Segundos de espera.

    Returns:
        Cadena vacia si el puerto responde; el motivo del fallo si no.
    """
    try:
        with socket.create_connection((host, puerto), timeout=timeout):
            return ''
    except OSError as exc:
        return f'puerto {puerto} sin respuesta ({exc})'


def probar_correo(cfg_email: Dict[str, Any], timeout: int = TIMEOUT_SEGUNDOS) -> EstadoServicio:
    """
    Verifica que el servidor SMTP acepte conexiones.

    Args:
        cfg_email: Seccion email del TOML (smtp_server, smtp_port).
        timeout: Segundos de espera.

    Returns:
        EstadoServicio del correo.
    """
    host = cfg_email.get('smtp_server', '')
    puerto = int(cfg_email.get('smtp_port', 25))
    destino = f'{host}:{puerto}'
    if not host:
        return EstadoServicio('Correo', '-', False, 'smtp_server vacio en el TOML')
    motivo = probar_puerto(host, puerto, timeout)
    if motivo:
        return EstadoServicio('Correo', destino, False, motivo)
    try:
        with smtplib.SMTP(host, puerto, timeout=timeout) as servidor:
            servidor.noop()
    except (smtplib.SMTPException, OSError) as exc:
        return EstadoServicio('Correo', destino, False, f'SMTP no responde ({exc})')
    return EstadoServicio('Correo', destino, True, 'SMTP responde')


def probar_servidor_descarga(servidor: Dict[str, Any], timeout: int = TIMEOUT_SEGUNDOS) -> EstadoServicio:
    """
    Verifica puerto SSH, autenticacion y ruta remota de un servidor de descarga.

    Args:
        servidor: Seccion servidor_descarga_N del TOML.
        timeout: Segundos de espera.

    Returns:
        EstadoServicio del servidor.
    """
    nombre = servidor.get('nombre', servidor.get('ip', ''))
    puerto = int(servidor.get('puerto', 22))
    destino = f'{servidor.get("ip", "")}:{puerto}'
    motivo = probar_puerto(servidor.get('ip', ''), puerto, timeout)
    if motivo:
        return EstadoServicio(nombre, destino, False, motivo)

    transporte = None
    try:
        transporte = abrir_transporte_sftp(servidor, timeout)
        cliente = paramiko.SFTPClient.from_transport(transporte)
        cliente.stat(servidor['ruta_remota'])
        cliente.close()
    except paramiko.AuthenticationException:
        return EstadoServicio(nombre, destino, False, 'autenticacion SSH rechazada (revisar clave)')
    except (paramiko.SSHException, OSError, ValueError) as exc:
        return EstadoServicio(nombre, destino, False, str(exc) or type(exc).__name__)
    finally:
        if transporte is not None:
            transporte.close()
    return EstadoServicio(nombre, destino, True, 'SSH y ruta remota accesibles')


class DiagnosticoConectividad:
    """Diagnostica correo y servidores, e informa al usuario que pasara."""

    def __init__(self, cfg_email: Dict[str, Any], servidores: List[Dict[str, Any]], destino_local: str, logger: logging.Logger):
        """
        Inicializa el diagnostico.

        Args:
            cfg_email: Seccion email del TOML.
            servidores: Servidores de descarga del TOML.
            destino_local: Carpeta donde queda el archivo si no se publica.
            logger: Logger compartido inyectado desde el punto de entrada.
        """
        self._cfg_email = cfg_email
        self._servidores = servidores
        self._destino_local = destino_local
        self._logger = logger

    def _log(self, level: int, msg: str, *args: object) -> None:
        """Registra un mensaje con formato lazy % para compatibilidad con Pylint."""
        self._logger.log(level, msg, *args)

    def ejecutar(self, incluir_servidores: bool = True) -> EstadoConectividad:
        """
        Ejecuta el diagnostico y registra el efecto de cada servicio caido.

        Args:
            incluir_servidores: False omite los servidores (skip_sftp).

        Returns:
            EstadoConectividad con correo y servidores.
        """
        correo = probar_correo(self._cfg_email)
        if correo.disponible:
            self._log(logging.INFO, 'Correo disponible: %s', correo.destino)
        else:
            self._log(
                logging.WARNING, 'No hay acceso al correo (%s): %s. La notificacion quedara en el log y la consola.',
                correo.destino, correo.detalle
            )

        servidores = [probar_servidor_descarga(srv) for srv in self._servidores] if incluir_servidores else []
        for estado in servidores:
            if estado.disponible:
                self._log(logging.INFO, 'Servidor de descarga %s disponible: %s', estado.nombre, estado.destino)
            else:
                self._log(
                    logging.WARNING, 'No hay acceso al servidor %s (%s): %s. No se publicara ahi; el archivo queda en %s',
                    estado.nombre, estado.destino, estado.detalle, self._destino_local
                )
        return EstadoConectividad(correo=correo, servidores=servidores)


def lineas_resumen(estado: EstadoConectividad, destino_local: str) -> List[str]:
    """
    Arma el resumen para consola y archivo de notificacion.

    Args:
        estado: Resultado del diagnostico.
        destino_local: Carpeta donde queda el archivo si no se publica.

    Returns:
        Lineas de texto listas para imprimir.
    """
    lineas = [f'{"SERVICIO":<12} {"DESTINO":<22} ESTADO']
    for servicio in [estado.correo, *estado.servidores]:
        marca = 'OK' if servicio.disponible else f'SIN ACCESO - {servicio.detalle}'
        lineas.append(f'{servicio.nombre:<12} {servicio.destino:<22} {marca}')
    if not estado.correo.disponible:
        lineas.append('-> Sin correo: la notificacion queda en el log, la consola y mails_enviados/.')
    if estado.servidores and not any(srv.disponible for srv in estado.servidores):
        lineas.append(f'-> Sin servidores de descarga: no se publicara remotamente; el archivo queda en {destino_local}')
    return lineas
