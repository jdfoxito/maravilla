"""Sesion Spark y opciones JDBC Oracle compartidas por todo el sistema.

app/da_sesion_spark.py

Punto unico para crear la sesion Spark (Connect o clasica) y para armar
las opciones JDBC con autenticacion por Oracle Wallet (Regla 28 SRI).
Antes la misma logica estaba repetida en exportador, validador,
config_manager y conexion_bdd (Regla 79 SRI).

Historial:
+--------------------+---------+------------------------------------------+
| Autor              | Version | Cambios                                  |
+--------------------+---------+------------------------------------------+
| Jim A. Gonzalez    | 1.0.0   | Extraido de exportador/validador         |
+--------------------+---------+------------------------------------------+
"""

from typing import Any, Dict

try:
    from pyspark.sql import SparkSession
except ImportError:
    SparkSession = None

NOMBRE_APP = 'sri_datos_abiertos'
PREFIJO_JDBC = 'jdbc:oracle:thin:/@'
DRIVER_ORACLE = 'oracle.jdbc.OracleDriver'
PREFIJO_SPARK_CONNECT = 'sc://'


def crear_sesion_spark(spark_url: str, nombre_app: str = NOMBRE_APP) -> Any:
    """
    Crea o reutiliza la sesion Spark segun el tipo de URL.

    Args:
        spark_url: sc://host:puerto para Spark Connect, o master clasico
                   (local[*], spark://host:puerto).
        nombre_app: Nombre de la aplicacion en Spark.

    Returns:
        Sesion Spark activa.

    Raises:
        RuntimeError: Si pyspark no esta instalado.
    """
    if SparkSession is None:
        raise RuntimeError('pyspark no esta instalado: no se puede crear la sesion Spark')
    constructor = SparkSession.builder.appName(nombre_app)
    if spark_url.startswith(PREFIJO_SPARK_CONNECT):
        return constructor.remote(spark_url).getOrCreate()
    return constructor.master(spark_url).getOrCreate()


def jdbc_desde_alias(alias: str) -> str:
    """Retorna la URL JDBC thin para un alias TNS autenticado por wallet."""
    return f'{PREFIJO_JDBC}{alias}'


def opciones_jdbc(jdbc_url: str, ruta_wallet: str, tns_admin: str, fetch_size: int = 500000) -> Dict[str, str]:
    """
    Arma las opciones JDBC de Oracle con autenticacion por wallet.

    No se envian usuario ni clave: el auto-login del wallet resuelve la
    credencial que tiene el mismo nombre que el alias TNS.

    Args:
        jdbc_url: URL JDBC (jdbc:oracle:thin:/@ALIAS).
        ruta_wallet: Directorio con cwallet.sso.
        tns_admin: Directorio con tnsnames.ora y sqlnet.ora.
        fetch_size: Filas por viaje de red.

    Returns:
        Diccionario listo para DataFrameReader.options().
    """
    return {
        'url': jdbc_url,
        'driver': DRIVER_ORACLE,
        'oracle.net.wallet_location': ruta_wallet,
        'oracle.net.tns_admin': tns_admin,
        'fetchsize': str(fetch_size),
    }
