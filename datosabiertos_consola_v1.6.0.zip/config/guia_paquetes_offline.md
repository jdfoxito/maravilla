# Instalación sin acceso a PyPI

Úsela cuando el instalador diga **"No hay acceso a PyPI ni paquetes locales en /opt/librerias"**.

En `sritrazadesa` el `ping` a pypi.org responde, pero HTTPS se corta con *Connection reset by peer*. Eso indica que un firewall o proxy bloquea el puerto 443 y no es un problema del instalador. Hay dos salidas.

## Opción A: pedir salida HTTPS o usar el proxy

Pida a infraestructura salida HTTPS (443) hacia `pypi.org` y `files.pythonhosted.org`. Si existe un proxy institucional, páselo de forma explícita, porque `sudo` descarta las variables de proxy del usuario:

```bash
curl -v https://pypi.org/simple/pip/ -o /dev/null      # debe responder 200
sudo https_proxy=http://PROXY:PUERTO ./datos_abiertos.bash
```

## Opción B: descargar los paquetes en otro equipo

1. **En un equipo con internet** (sirve Windows), dentro de la carpeta del proyecto:

   ```powershell
   pip download -r requirements.txt pip setuptools wheel pyinstaller -d wheelhouse `
     --python-version 3.13 --platform manylinux2014_x86_64 --platform manylinux_2_28_x86_64 `
     --only-binary=:all:
   ```

   Si un paquete existe solo como código fuente (`pyspark` suele publicarse como `.tar.gz`), descárguelo aparte:

   ```powershell
   pip download pyspark==<version del requirements.txt> --no-deps --no-binary=:all: -d wheelhouse
   ```

2. **Copie** el contenido de `wheelhouse\` a `/opt/librerias/` del servidor. Los JAR de Oracle van en esa misma carpeta.

3. **Ejecute** `sudo ./datos_abiertos.bash`. El instalador detecta los paquetes y muestra *"Se instalara SIN conexion desde los paquetes de /opt/librerias"*.

## El entorno virtual ya no se pierde

Antes de instalar, el instalador mueve el venv actual a `venv.respaldo_<fecha>`:

- Si algo falla, lo devuelve a `venv/` de forma automática.
- Si todo sale bien, borra el respaldo.
- Si quedaron dependencias fallidas, conserva el respaldo y muestra el comando para volver a él.

## PDM

`pdm update` también necesita PyPI, así que falla por la misma causa. Para que PDM use Python 3.13 y no 3.15:

```bash
pdm use /usr/local/python3.13/bin/python3.13
pdm export -f requirements --without-hashes -o requirements.txt
```
