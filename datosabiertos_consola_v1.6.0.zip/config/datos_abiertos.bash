#!/bin/bash
#==============================================================================
# INSTALADOR SRI DATOS ABIERTOS FACTURACION
# Version: 5.0.0 — Noviembre 2026
#==============================================================================
# Ejecutar desde /home/python/sri_datos_abiertos_facturacion/
#   sed -i 's/\r$//' datos_abiertos.bash
#   chmod +x datos_abiertos.bash
#   sudo ./datos_abiertos.bash
#
# OBJETIVO v5.0.0:
#   - Verifica el ambiente (Python, Java, Oracle/wallet/TNS, JARs, Spark,
#     SSH, correo) y GENERA EL EJECUTABLE PORTABLE del programa.
#   - NO instala librerias: usa el .venv de PDM del proyecto. Si faltan
#     paquetes, se instalan aparte (config/guia_paquetes_offline.md).
#   - Versiones: se exige la de requirements.txt o una MAS NUEVA (por
#     vulnerabilidades); una version mas vieja se reporta. Las versiones
#     exactas empaquetadas quedan en config/requirements_ejecutable.txt.
#   - Modo --solo-ejecutable (sin root): solo valida el .venv y genera el
#     ejecutable. Es lo que usa "pdm run ejecutable".
#   - Arma dist/sri_datos_abiertos_<version>/ con el binario, config/,
#     data/input/consultas/ y carpetas de trabajo, mas un .tar.gz. Esa
#     carpeta se copia a cualquier ruta y se ejecuta sin instalar nada.
#
# NOTA: Linux (RHEL 10). PyInstaller --onefile descomprime en /tmp, pero
#       el programa lee y escribe en la carpeta del ejecutable.
#==============================================================================

set -eEo pipefail

#============================================================================
# PARSEAR ARGUMENTOS
#============================================================================

SOLO_EJECUTABLE=false
for arg in "$@"; do
    case "${arg}" in
        --solo-ejecutable) SOLO_EJECUTABLE=true ;;
    esac
done

if [[ "${SOLO_EJECUTABLE}" == false && ${EUID} -ne 0 ]]; then
    echo "[ERROR] Este instalador debe ejecutarse con privilegios de root."
    echo "  Uso correcto: sudo ./datos_abiertos.bash"
    exit 1
fi

#==============================================================================
# VARIABLES CONFIGURABLES
#==============================================================================
NOMBRE_PROYECTO="sri_datos_abiertos_facturacion"
DIRECTORIO_BASE="/home/python/${NOMBRE_PROYECTO}"
PYTHON_CMD="/usr/local/python3.13/bin/python3.13"
JAVA_HOME_DEFAULT="/usr/lib/jvm/java-21-openjdk"
SPARK_HOME="/opt/spark/spark403"
VERSION_SPARK="4.0.3"
SPARK_TGZ="spark-${VERSION_SPARK}-bin-hadoop3.tgz"
DIRECTORIO_SPARK_OFFLINE="/opt/spark"
SPARK_LIBS="/opt/librerias"

SERVIDORES_REMOTOS=("10.1.15.11" "10.11.0.15")
USUARIO_REMOTO="datos_abiertos"
CLAVE_SSH="/home/python/.ssh/sri_datos_abiertos_key"
RUTA_REMOTA="/opt/rh/jbcs-httpd24/root/var/www/html/descargas/download/datosAbiertos"

ARCHIVO_LIBRERIAS="requirements.txt"
ARCHIVO_CONFIG="configlnx.toml"
NOMBRE_SERVICIO="sri-datos-abiertos-spark"
PROPIETARIO_PROYECTO="python:python"
RUTA_WALLET_ORACLE="/opt/oracle/wallets"
ORACLE_HOME_DEFAULT="/opt/oracle/client_home"
ESPACIO_MINIMO_GB=5

# WALLETS_TNS se llena dinamicamente desde los jdbc_url de los JSON de
# consultas (ver detectar_wallets_de_consultas). Antes estaba hardcodeado
# con "SRI_DW_FACTURACION_SRI"/"SRI_DW_BI_DWH", aliases que ninguna consulta
# usa: el chequeo fallaba siempre por probar wallets equivocados. Los
# aliases reales viven en facturacion_sql_historia*.json.
WALLETS_TNS=()
WALLETS_FALLIDOS=()
RUTA_VENV="${DIRECTORIO_BASE}/.venv"
SPARK_OMITIDO=false
DEPENDENCIAS_FALLIDAS=()

JARS_REQUERIDOS=("ojdbc11.jar" "oraclepki.jar" "osdt_cert-19.3.0.0.jar" "osdt_core-19.3.0.0.jar")
JARS_FALTANTES=()

mkdir -p "${DIRECTORIO_BASE}/logs"
ARCHIVO_LOG="${DIRECTORIO_BASE}/logs/instalador_$(date +%Y%m%d_%H%M%S).log"
touch "${ARCHIVO_LOG}"
chmod 640 "${ARCHIVO_LOG}"

ROJO='\033[0;31m'; VERDE='\033[0;32m'; AMARILLO='\033[1;33m'
AZUL='\033[0;34m'; CIAN='\033[0;36m'; NC='\033[0m'

log()       { echo -e "${AZUL}[$(date '+%Y-%m-%d %H:%M:%S')]${NC} $*" | tee -a "${ARCHIVO_LOG}"; }
error_log() { echo -e "${ROJO}[ERROR]${NC} $*" | tee -a "${ARCHIVO_LOG}"; }
aviso()     { echo -e "${AMARILLO}[ADVERTENCIA]${NC} $*" | tee -a "${ARCHIVO_LOG}"; }
exito()     { echo -e "${VERDE}[ÉXITO]${NC} $*" | tee -a "${ARCHIVO_LOG}"; }
info()      { echo -e "${CIAN}[INFO]${NC} $*" | tee -a "${ARCHIVO_LOG}"; }

existe_cmd() { command -v "$1" &>/dev/null; }

trampa_error() {
    local codigo_salida=$?
    local linea=${BASH_LINENO[0]}
    local comando="${BASH_COMMAND}"
    local funcion="${FUNCNAME[1]:-main}"
    echo "" | tee -a "${ARCHIVO_LOG}"
    echo "===============================================================================" | tee -a "${ARCHIVO_LOG}"
    echo -e "${ROJO}[FALLO FATAL] El instalador se detuvo inesperadamente${NC}" | tee -a "${ARCHIVO_LOG}"
    echo "  Funcion : ${funcion}" | tee -a "${ARCHIVO_LOG}"
    echo "  Linea   : ${linea}" | tee -a "${ARCHIVO_LOG}"
    echo "  Comando : ${comando}" | tee -a "${ARCHIVO_LOG}"
    echo "  Codigo  : ${codigo_salida}" | tee -a "${ARCHIVO_LOG}"
    echo "===============================================================================" | tee -a "${ARCHIVO_LOG}"
    echo "" | tee -a "${ARCHIVO_LOG}"
    echo -e "${AMARILLO}▶  Revise el log completo:${NC}" | tee -a "${ARCHIVO_LOG}"
    echo "   ${ARCHIVO_LOG}" | tee -a "${ARCHIVO_LOG}"
    echo "" | tee -a "${ARCHIVO_LOG}"
    echo "Ultimas 30 lineas del log:" | tee -a "${ARCHIVO_LOG}"
    tail -30 "${ARCHIVO_LOG}"
    exit "${codigo_salida}"
}

verificar_correo() {
    log "Verificando acceso al servidor de correo"
    local toml="${DIRECTORIO_BASE}/config/${ARCHIVO_CONFIG}"
    local host puerto
    host=$(awk -F'"' '/^\[email\]/{s=1;next} /^\[/{s=0} s && /^smtp_server/{print $2}' "${toml}" 2>/dev/null || true)
    puerto=$(awk -F'=' '/^\[email\]/{s=1;next} /^\[/{s=0} s && /^smtp_port/{gsub(/[^0-9]/,"",$2); print $2}' "${toml}" 2>/dev/null || true)
    puerto="${puerto:-25}"
    if [[ -z "${host}" ]]; then
        aviso "smtp_server vacio en ${ARCHIVO_CONFIG}: las notificaciones quedaran en el log y la consola."
        return 0
    fi
    if timeout 5 bash -c "exec 3<>/dev/tcp/${host}/${puerto}" 2>/dev/null; then
        exito "Correo accesible en ${host}:${puerto}"
    else
        aviso "No hay acceso al correo ${host}:${puerto}."
        aviso "   La aplicacion funcionara igual: las notificaciones quedaran en el log, la consola y mails_enviados/."
    fi
}

trap trampa_error ERR

leer_version() {
    local version=""
    local archivo="${DIRECTORIO_BASE}/app/main.py"
    if [[ -f "${archivo}" ]]; then
        version=$("${PYTHON_CMD}" -c "
import re
try:
    txt = open('${archivo}', encoding='utf-8').read()
    m = re.search(r"^VERSION\s*=\s*['\"]([0-9]+\.[0-9]+\.[0-9]+)['\"]", txt, re.M)
    print(m.group(1) if m else '')
except Exception:
    print('')
" 2>/dev/null || true)
        version="${version//[$'\t\r\n ']/}"
        if [[ -z "${version}" ]]; then
            version=$(grep -oP "^VERSION\s*=\s*['\"]?\K[0-9]+\.[0-9]+\.[0-9]+" \
                      "${archivo}" 2>/dev/null | head -1 || true)
        fi
    fi
    if [[ -z "${version}" ]]; then
        aviso "No se encontro VERSION en app/main.py. Usando 0.0.0."
        version="0.0.0"
    fi
    echo "${version}"
}

verificar_espacio() {
    log "Verificando espacio en disco disponible..."
    local espacio_disponible
    espacio_disponible=$(df -BG "${DIRECTORIO_BASE}" 2>/dev/null | \
                         awk 'NR==2 {gsub(/G/,"",$4); print $4}')
    if [[ -z "${espacio_disponible}" ]]; then
        aviso "No se pudo determinar el espacio disponible en ${DIRECTORIO_BASE}"
        return
    fi
    if (( espacio_disponible < ESPACIO_MINIMO_GB )); then
        error_log "Espacio insuficiente: ${espacio_disponible}G disponibles, se requieren ${ESPACIO_MINIMO_GB}G minimos."
        exit 1
    fi
    exito "Espacio disponible: ${espacio_disponible}G (minimo requerido: ${ESPACIO_MINIMO_GB}G)"
}

verificar_python() {
    log "Verificando Python 3.13 en ${PYTHON_CMD}"
    if [[ ! -x "${PYTHON_CMD}" ]]; then
        error_log "Python no encontrado en ${PYTHON_CMD}."
        error_log "Consulte 'Manual de instalacion de Python 3.13.5.docx'."
        exit 1
    fi
    local version
    version=$("${PYTHON_CMD}" --version 2>&1 | awk '{print $2}')
    if [[ ! "${version}" =~ ^3\.13\. ]]; then
        error_log "Version de Python detectada: ${version}. Se requiere 3.13.x."
        error_log "Consulte 'Manual de instalacion de Python 3.13.5.docx'."
        exit 1
    fi
    exito "Python ${version} encontrado"
    log "   Verificando modulo SSL..."
    if ! "${PYTHON_CMD}" -c "import ssl" 2>>"${ARCHIVO_LOG}"; then
        error_log "Modulo SSL no funcional. Consulte el manual de Python."
        exit 1
    fi
    log "   Verificando modulo _ctypes..."
    if ! "${PYTHON_CMD}" -c "import _ctypes" 2>>"${ARCHIVO_LOG}"; then
        error_log "Modulo _ctypes no funcional (requiere libffi). Consulte el manual."
        exit 1
    fi
    log "   Verificando biblioteca compartida (Py_ENABLE_SHARED)..."
    local shared
    shared=$("${PYTHON_CMD}" -c "import sysconfig; print(sysconfig.get_config_var('Py_ENABLE_SHARED'))")
    if [[ "${shared}" != "1" ]]; then
        error_log "Python no se compilo como biblioteca compartida. Consulte el manual."
        exit 1
    fi
    exito "Python ${version} verificado correctamente (SSL ok  ctypes ok  shared ok)"
}

verificar_java() {
    log "Verificando Java 21"
    if [[ -d "${JAVA_HOME_DEFAULT}" && -x "${JAVA_HOME_DEFAULT}/bin/java" ]]; then
        export JAVA_HOME="${JAVA_HOME_DEFAULT}"
        export PATH="${JAVA_HOME}/bin:${PATH}"
    else
        local ruta_java
        ruta_java=$(update-alternatives --list java 2>/dev/null \
                    | grep -E "java-21" | head -1 || true)
        if [[ -n "${ruta_java}" ]]; then
            export JAVA_HOME
            JAVA_HOME=$(dirname "$(dirname "${ruta_java}")")
            export PATH="${JAVA_HOME}/bin:${PATH}"
        else
            aviso "Java 21 no encontrado. Intentando instalar (requiere internet/repos)..."
            if dnf install -y java-21-openjdk java-21-openjdk-devel 2>>"${ARCHIVO_LOG}"; then
                exito "Java 21 instalado via dnf"
                if [[ -d "${JAVA_HOME_DEFAULT}" && -x "${JAVA_HOME_DEFAULT}/bin/java" ]]; then
                    export JAVA_HOME="${JAVA_HOME_DEFAULT}"
                    export PATH="${JAVA_HOME}/bin:${PATH}"
                else
                    ruta_java=$(update-alternatives --list java 2>/dev/null \
                                | grep -E "java-21" | head -1 || true)
                    JAVA_HOME=$(dirname "$(dirname "${ruta_java}")")
                    export JAVA_HOME
                    export PATH="${JAVA_HOME}/bin:${PATH}"
                fi
            else
                error_log "No se pudo instalar Java 21 (sin internet o sin repos)."
                error_log "Instalelo manualmente. Consulte 'Manual_infraestructura_Configuracion_Redhat.docx'."
                exit 1
            fi
        fi
    fi
    local java_bin="${JAVA_HOME}/bin/java"
    [[ -x "${java_bin}" ]] || java_bin="java"
    local version
    version=$("${java_bin}" -version 2>&1 | head -1 | grep -oP 'version "\K[^"]*' || true)
    if [[ ! "${version}" =~ ^21 ]]; then
        error_log "Version de Java detectada: ${version:-desconocida}. Se requiere Java 21."
        error_log "Consulte 'Manual_infraestructura_Configuracion_Redhat.docx'."
        exit 1
    fi
    exito "Java ${version} | JAVA_HOME=${JAVA_HOME}"
}

detectar_wallets_de_consultas() {
    # Extrae los alias TNS reales de los jdbc_url en los JSON de consultas
    # (jdbc:oracle:thin:/@ALIAS). Evita probar wallets que ninguna consulta
    # usa. Busca en config/consultas (paquete) y en data/input/consultas.
    local dirs=(
        "${DIRECTORIO_BASE}/config/consultas"
        "${DIRECTORIO_BASE}/data/input/consultas"
    )
    local encontrados=()
    local d
    for d in "${dirs[@]}"; do
        if [[ -d "${d}" ]] && compgen -G "${d}/*.json" > /dev/null; then
            while IFS= read -r alias; do
                [[ -n "${alias}" ]] && encontrados+=("${alias}")
            done < <( { grep -rhoE 'jdbc:oracle:thin:/?@[A-Za-z_][A-Za-z0-9_.-]*' "${d}"/*.json \
                          | grep -oE '@[A-Za-z_][A-Za-z0-9_.-]*' | tr -d '@'
                        grep -rhoE '"conexion"[[:space:]]*:[[:space:]]*"[^"]+"' "${d}"/*.json \
                          | sed -E 's/.*"([^"]+)"$/\1/'
                      } | sort -u || true)
        fi
    done
    # Deduplicar preservando orden
    WALLETS_TNS=()
    local a existe w
    for a in "${encontrados[@]}"; do
        existe=false
        for w in "${WALLETS_TNS[@]}"; do
            [[ "${w}" == "${a}" ]] && existe=true && break
        done
        [[ "${existe}" == false ]] && WALLETS_TNS+=("${a}")
    done
    if (( ${#WALLETS_TNS[@]} == 0 )); then
        aviso "No se detectaron alias TNS en los JSON; usando STAR_BI_DWH por defecto."
        WALLETS_TNS=("STAR_BI_DWH")
    else
        info "   Alias TNS detectados en consultas: ${WALLETS_TNS[*]}"
    fi
}

asegurar_tnsnames_en_wallet() {
    # Si el wallet no tiene tnsnames.ora/sqlnet.ora pero si estan en
    # ORACLE_HOME/network/admin, se enlazan. sqlplus /@ALIAS funciona con
    # TNS_ADMIN de ORACLE_HOME, pero la app y Spark buscan en el wallet:
    # sin este symlink daban 'sqlnet.ora no encontrado' aunque sqlplus si
    # conectara (el sintoma exacto del log de instalacion).
    local origen="${ORACLE_HOME}/network/admin"
    local archivo ruta_wallet ruta_origen
    for archivo in tnsnames.ora sqlnet.ora; do
        ruta_wallet="${RUTA_WALLET_ORACLE}/${archivo}"
        ruta_origen="${origen}/${archivo}"
        if [[ ! -f "${ruta_wallet}" && -f "${ruta_origen}" ]]; then
            if ln -sf "${ruta_origen}" "${ruta_wallet}" 2>/dev/null; then
                info "   Enlazado ${archivo}: ${ruta_origen} -> ${ruta_wallet}"
            else
                aviso "   No se pudo enlazar ${archivo} al wallet (permisos)."
            fi
        fi
    done
}

TNS_DISPONIBLES=()   # todos los alias declarados en tnsnames.ora
TNS_CONECTAN=()      # alias con credencial en el wallet que si conectan

resolver_tns_admin() {
    # Una sola fuente de verdad: [wallet].network_admin del TOML.
    # Si no existe ese tnsnames.ora, se usa el wallet como antes.
    local toml="${DIRECTORIO_BASE}/config/${ARCHIVO_CONFIG}"
    local na=""
    if [[ -f "${toml}" ]]; then
        na=$(awk -F'"' '/^\[wallet\]/{s=1;next} /^\[/{s=0} s && /^network_admin/{print $2}' "${toml}")
    fi
    if [[ -n "${na}" && -f "${na}/tnsnames.ora" ]]; then
        export TNS_ADMIN="${na}"
    else
        export TNS_ADMIN="${TNS_ADMIN:-${RUTA_WALLET_ORACLE}}"
    fi
    info "   TNS_ADMIN = ${TNS_ADMIN}"
    if [[ -f "${TNS_ADMIN}/sqlnet.ora" ]]; then
        local wl
        wl=$(grep -iE 'DIRECTORY|WALLET_LOCATION' "${TNS_ADMIN}/sqlnet.ora" | tr -s ' ' | head -3)
        info "   sqlnet.ora -> ${wl:-sin WALLET_LOCATION declarado}"
    fi
}

listar_tns_disponibles() {
    local tns="${TNS_ADMIN}/tnsnames.ora"
    TNS_DISPONIBLES=()
    TNS_CONECTAN=()
    if [[ ! -f "${tns}" ]]; then
        error_log "No existe ${tns}: no hay alias que probar."
        return 1
    fi

    # Alias al inicio de linea, admite puntos/guiones (ALIAS.WORLD) y
    # varios alias separados por coma ("A, B = (...)"). Ignora comentarios.
    mapfile -t TNS_DISPONIBLES < <(
        sed -e 's/#.*//' "${tns}" \
        | grep -oE '^[A-Za-z][A-Za-z0-9_.-]*([[:space:]]*,[[:space:]]*[A-Za-z][A-Za-z0-9_.-]*)*[[:space:]]*=' \
        | tr -d '=' | tr ',' '\n' | sed 's/[[:space:]]//g' | grep -v '^$' \
        | tr '[:lower:]' '[:upper:]' | sort -u
    )
    if grep -qiE '^[[:space:]]*IFILE' "${tns}"; then
        aviso "   tnsnames.ora usa IFILE: los alias de archivos incluidos no se listan aqui."
    fi

    info "   Alias en tnsnames.ora: ${#TNS_DISPONIBLES[@]}"
    printf '     %-38s %s\n' 'ALIAS (= credencial wallet)' 'CONEXION' | tee -a "${ARCHIVO_LOG}"
    local alias
    for alias in "${TNS_DISPONIBLES[@]}"; do
        if echo "exit" | timeout 25 sqlplus -s -L "/@${alias}" >/dev/null 2>>"${ARCHIVO_LOG}"; then
            TNS_CONECTAN+=("${alias}")
            printf '     %-38s %s\n' "${alias}" 'OK' | tee -a "${ARCHIVO_LOG}"
        else
            printf '     %-38s %s\n' "${alias}" 'sin credencial o no conecta' | tee -a "${ARCHIVO_LOG}"
        fi
    done
}

contiene() {
    local buscado="$1"; shift
    local x
    for x in "$@"; do [[ "${x}" == "${buscado}" ]] && return 0; done
    return 1
}

validar_tns_vs_consultas() {
    resolver_tns_admin
    listar_tns_disponibles || true
    detectar_wallets_de_consultas      # llena WALLETS_TNS desde los JSON

    WALLETS_FALLIDOS=()
    local alias
    for alias in "${WALLETS_TNS[@]}"; do
        local a_up="${alias^^}"
        if contiene "${a_up}" "${TNS_CONECTAN[@]}"; then
            exito "   Consulta usa ${alias}: OK (esta en tnsnames y el wallet conecta)"
        elif contiene "${a_up}" "${TNS_DISPONIBLES[@]}"; then
            aviso "   Consulta usa ${alias}: esta en tnsnames pero el wallet NO tiene credencial con ese nombre"
            WALLETS_FALLIDOS+=("${alias}")
        else
            aviso "   Consulta usa ${alias}: NO existe en tnsnames.ora"
            WALLETS_FALLIDOS+=("${alias}")
        fi
    done

    if (( ${#WALLETS_FALLIDOS[@]} > 0 )); then
        aviso "Alias de JSON con problemas: ${WALLETS_FALLIDOS[*]}"
        aviso "Alias que SI conectan (usar uno de estos en jdbc_url): ${TNS_CONECTAN[*]:-ninguno}"
    else
        exito "Todos los alias usados por las consultas conectan por wallet"
    fi
}

verificar_oracle() {
    log "Verificando cliente Oracle y wallet"
    if [[ -z "${ORACLE_HOME:-}" ]]; then
        export ORACLE_HOME="${ORACLE_HOME_DEFAULT}"
    fi
    if [[ ! -d "${ORACLE_HOME}" ]]; then
        error_log "Cliente Oracle no encontrado en ${ORACLE_HOME}."
        error_log "Consulte 'Manual_infraestructura_Configuracion_Redhat.docx'."
        exit 1
    fi
    if [[ -d "${ORACLE_HOME}/bin" ]]; then
        export PATH="${ORACLE_HOME}/bin:${PATH}"
        export LD_LIBRARY_PATH="${ORACLE_HOME}/lib:${LD_LIBRARY_PATH:-}"
    fi
    if ! existe_cmd sqlplus; then
        error_log "Comando 'sqlplus' no disponible. Verifique ORACLE_HOME/bin en PATH."
        exit 1
    fi
    if [[ ! -d "${RUTA_WALLET_ORACLE}" || ! -f "${RUTA_WALLET_ORACLE}/ewallet.p12" ]]; then
        error_log "Wallet no encontrado en ${RUTA_WALLET_ORACLE}."
        error_log "Consulte 'Manual_configuracion_wallet.docx'."
        exit 1
    fi
    if [[ -z "${TNS_ADMIN:-}" ]]; then
        export TNS_ADMIN="${RUTA_WALLET_ORACLE}"
    fi
    if [[ ! -f "${TNS_ADMIN}/tnsnames.ora" ]]; then
        aviso "No se encontro tnsnames.ora en ${TNS_ADMIN}. Intentando enlazar desde ORACLE_HOME..."
        asegurar_tnsnames_en_wallet
        # Reintentar tras el enlace
        if [[ ! -f "${TNS_ADMIN}/tnsnames.ora" ]]; then
            aviso "Sigue sin haber tnsnames.ora en ${TNS_ADMIN}. Las conexiones podrian fallar."
        fi
    fi
    if [[ -f "${TNS_ADMIN}/tnsnames.ora" ]]; then
        info "   Archivos del wallet:"
        for archivo in cwallet.sso ewallet.p12 sqlnet.ora tnsnames.ora; do
            local ruta_arch="${RUTA_WALLET_ORACLE}/${archivo}"
            if [[ -f "${ruta_arch}" ]]; then
                local fecha_mod
                fecha_mod=$(stat -c '%y' "${ruta_arch}" 2>/dev/null | cut -d'.' -f1)
                info "     ${archivo}: ${fecha_mod}"
            fi
        done
    fi
    validar_tns_vs_consultas
    if (( ${#WALLETS_FALLIDOS[@]} > 0 )); then
        aviso "El ejecutable se generara igual, pero NO podra conectarse con: ${WALLETS_FALLIDOS[*]}"
        aviso "Consulte 'Manual_configuracion_wallet.docx'."
    fi
}

verificar_jars() {
    log "Verificando JARs de Oracle en /opt/librerias"
    if [[ ! -d "${SPARK_LIBS}" ]]; then
        aviso "${SPARK_LIBS} no existe. Creando directorio..."
        mkdir -p "${SPARK_LIBS}"
        chown "${PROPIETARIO_PROYECTO}" "${SPARK_LIBS}"
        chmod 755 "${SPARK_LIBS}"
    fi
    # Los JARs vienen en el paquete dentro de config/. Se copian a
    # /opt/librerias si faltan. Antes el instalador asumia que ya estaban
    # en /opt/librerias y, al no copiarlos, Spark quedaba sin driver Oracle
    # (el sintoma del log: '/opt/librerias vacio, JARs faltantes').
    local dir_jars_paquete="${DIRECTORIO_BASE}/config"
    local copiados_pkg=0
    local jar
    for jar in "${JARS_REQUERIDOS[@]}"; do
        if [[ ! -f "${SPARK_LIBS}/${jar}" ]]; then
            # coincidencia exacta o por patron (osdt_*-19.3.0.0.jar)
            local origen="${dir_jars_paquete}/${jar}"
            if [[ ! -f "${origen}" ]]; then
                origen=$(compgen -G "${dir_jars_paquete}/${jar%.jar}*.jar" 2>/dev/null | head -1 || true)
            fi
            if [[ -n "${origen}" && -f "${origen}" ]]; then
                cp "${origen}" "${SPARK_LIBS}/${jar}" \
                    && { info "   ${jar} copiado desde config/ a ${SPARK_LIBS}"; copiados_pkg=$((copiados_pkg+1)); }
            fi
        fi
    done
    if (( copiados_pkg > 0 )); then
        chown "${PROPIETARIO_PROYECTO}" "${SPARK_LIBS}"/*.jar 2>/dev/null || true
        exito "Se copiaron ${copiados_pkg} JAR(s) de Oracle desde config/ a ${SPARK_LIBS}"
    fi
    JARS_FALTANTES=()
    for jar in "${JARS_REQUERIDOS[@]}"; do
        if [[ ! -f "${SPARK_LIBS}/${jar}" ]]; then
            JARS_FALTANTES+=("${jar}")
        fi
    done
    if (( ${#JARS_FALTANTES[@]} > 0 )); then
        aviso "JARs faltantes en ${SPARK_LIBS}:"
        for jar in "${JARS_FALTANTES[@]}"; do
            aviso "   - ${jar}"
        done
        aviso "Copie los JARs desde el portal de Oracle o desde el Oracle Client."
        aviso "Spark no podra conectar a Oracle sin estos JARs."
        aviso "Ruta esperada: ${SPARK_LIBS}/"
    else
        exito "Todos los JARs requeridos presentes en ${SPARK_LIBS}"
    fi
    info "   JARs disponibles:"
    if compgen -G "${SPARK_LIBS}/*.jar" > /dev/null; then
        while read -r line; do
            info "     ${line}"
        done < <(ls -la "${SPARK_LIBS}"/*.jar)
    else
        info "     (ninguno)"
    fi
    if [[ -d "${SPARK_HOME}/jars" ]]; then
        local copiados=0
        for jar in "${JARS_REQUERIDOS[@]}"; do
            if [[ -f "${SPARK_LIBS}/${jar}" && ! -f "${SPARK_HOME}/jars/${jar}" ]]; then
                cp "${SPARK_LIBS}/${jar}" "${SPARK_HOME}/jars/" \
                    && { info "   ${jar} copiado a ${SPARK_HOME}/jars"; copiados=$((copiados+1)); }
            fi
        done
        if (( copiados > 0 )); then
            aviso "Se copiaron ${copiados} JAR(s) nuevos a Spark. Reinicie el servicio:"
            aviso "   sudo systemctl restart ${NOMBRE_SERVICIO}"
        fi
    fi
}

corregir_libffi() {
    if [[ ! -f /usr/lib64/libffi.so.6 ]]; then
        log "Buscando libffi compatible (necesario para _ctypes)..."
        local libffi
        libffi=$(find /usr/lib64 -name "libffi.so.*" | sort | head -1)
        if [[ -n "${libffi}" ]]; then
            ln -sf "${libffi}" /usr/lib64/libffi.so.6
            ldconfig
            exito "Enlace simbolico libffi.so.6 -> ${libffi} creado"
        else
            aviso "libffi no encontrado. Si hay errores con _ctypes, instale 'libffi-devel'."
        fi
    fi
}

instalar_spark() {
    log "Instalando Apache Spark ${VERSION_SPARK} en ${SPARK_HOME}"
    local fuente_tgz=""
    if [[ -f "${DIRECTORIO_SPARK_OFFLINE}/${SPARK_TGZ}" ]]; then
        fuente_tgz="${DIRECTORIO_SPARK_OFFLINE}/${SPARK_TGZ}"
        exito "Archivo Spark encontrado en modo offline: ${fuente_tgz}"
    else
        aviso "No se encontro ${DIRECTORIO_SPARK_OFFLINE}/${SPARK_TGZ}."
        aviso "Spark NO se instalara. El ejecutable se generara, pero Spark no funcionara en este ambiente."
        aviso "Copie ${SPARK_TGZ} en ${DIRECTORIO_SPARK_OFFLINE} y vuelva a ejecutar para habilitar Spark."
        SPARK_OMITIDO=true
        return 0
    fi
    mkdir -p "$(dirname "${SPARK_HOME}")"
    tar -xzf "${fuente_tgz}" -C "$(dirname "${SPARK_HOME}")" 2>>"${ARCHIVO_LOG}"
    if [[ ! -d "${SPARK_HOME}" ]]; then
        mv "$(dirname "${SPARK_HOME}")/spark-${VERSION_SPARK}-bin-hadoop3" \
           "${SPARK_HOME}"
    fi
    chown -R "${PROPIETARIO_PROYECTO}" "${SPARK_HOME}" 2>/dev/null || \
        aviso "Algunos archivos de Spark no se pudieron recronar. Se continua."
    exito "Spark extraido en ${SPARK_HOME}"
    if [[ -d "${SPARK_LIBS}" ]]; then
        local copiados=0
        for jar_origen in "${SPARK_LIBS}"/*.jar; do
            if [[ -f "${jar_origen}" ]]; then
                cp "${jar_origen}" "${SPARK_HOME}/jars/" \
                    && { log "   $(basename "${jar_origen}") copiado a Spark/jars"; copiados=$((copiados+1)); }
            fi
        done
        if (( copiados == 0 )); then
            aviso "No se encontraron JARs en ${SPARK_LIBS} — Spark no podra leer Oracle."
        elif [[ ! -f "${SPARK_HOME}/jars/ojdbc11.jar" ]]; then
            aviso "Falta ojdbc11.jar en ${SPARK_LIBS} — Spark no podra conectar a Oracle."
        fi
    else
        aviso "${SPARK_LIBS} no existe — copie ojdbc11.jar, oraclepki.jar, osdt_*.jar."
    fi
    cat > /etc/profile.d/spark.sh << EOF
export SPARK_HOME=${SPARK_HOME}
export PATH=\$SPARK_HOME/bin:\$SPARK_HOME/sbin:\$PATH
export PYSPARK_PYTHON=${PYTHON_CMD}
EOF
    source /etc/profile.d/spark.sh
    exito "Variables de entorno Spark configuradas"
    cat > /etc/systemd/system/${NOMBRE_SERVICIO}.service << EOF
[Unit]
Description=SRI Datos Abiertos Facturacion - Spark Connect Server
After=network.target

[Service]
Type=simple
User=python
Group=python
Environment="JAVA_HOME=${JAVA_HOME}"
Environment="SPARK_HOME=${SPARK_HOME}"
Environment="ORACLE_HOME=${ORACLE_HOME}"
Environment="TNS_ADMIN=${RUTA_WALLET_ORACLE}"
Environment="LD_LIBRARY_PATH=${ORACLE_HOME}/lib"
Environment="PYSPARK_PYTHON=${RUTA_VENV}/bin/python"
WorkingDirectory=${SPARK_HOME}
ExecStart=${SPARK_HOME}/bin/spark-submit \
  --jars ${SPARK_HOME}/jars/ojdbc11.jar \
  --conf spark.connect.grpc.binding.port=15002 \
  --conf spark.connect.grpc.binding.address=0.0.0.0 \
  --conf spark.driver.memory=10g \
  --conf spark.executor.memory=10g \
  --conf spark.driver.extraJavaOptions="-Doracle.net.tns_admin=${RUTA_WALLET_ORACLE} -Doracle.net.wallet_location=${RUTA_WALLET_ORACLE}" \
  --conf spark.executor.extraJavaOptions="-Doracle.net.tns_admin=${RUTA_WALLET_ORACLE} -Doracle.net.wallet_location=${RUTA_WALLET_ORACLE}" \
  --class org.apache.spark.sql.connect.service.SparkConnectServer \
  internal
StandardOutput=journal
StandardError=journal
Restart=on-failure
RestartSec=10
TimeoutStartSec=120

[Install]
WantedBy=multi-user.target
EOF
    systemctl daemon-reload
    systemctl enable "${NOMBRE_SERVICIO}"
    systemctl start "${NOMBRE_SERVICIO}" 2>>"${ARCHIVO_LOG}" || {
        aviso "El servicio ${NOMBRE_SERVICIO} no arranco de inmediato."
        aviso "Revise con: journalctl -u ${NOMBRE_SERVICIO} -n 50"
    }
    exito "Servicio ${NOMBRE_SERVICIO} registrado e iniciado"
    sleep 5
    if timeout 3 bash -c "echo >/dev/tcp/localhost/15002" 2>/dev/null; then
        exito "Spark Connect respondiendo en puerto 15002"
    else
        aviso "Spark Connect aun no responde en puerto 15002."
        aviso "Verifique con: systemctl status ${NOMBRE_SERVICIO}"
    fi
}

verificar_spark() {
    SPARK_OMITIDO=false
    if systemctl is-active --quiet "${NOMBRE_SERVICIO}" 2>/dev/null; then
        exito "Servicio ${NOMBRE_SERVICIO} esta activo"
    elif [[ -d "${SPARK_HOME}" && -x "${SPARK_HOME}/bin/spark-submit" ]]; then
        aviso "Spark instalado pero el servicio ${NOMBRE_SERVICIO} no esta activo — (re)instalando servicio..."
        instalar_spark
    else
        aviso "Spark no esta instalado — intentando instalar..."
        instalar_spark
    fi
    if [[ "${SPARK_OMITIDO}" == true ]]; then
        aviso "Spark quedo pendiente: la app se compilara, pero Spark no funcionara en este ambiente."
        return 0
    fi
    if timeout 3 bash -c "echo >/dev/tcp/localhost/15002" 2>/dev/null; then
        exito "Spark Connect responde en puerto 15002"
    else
        aviso "Spark Connect no responde en localhost:15002 (puede estar iniciando)."
        aviso "Verifique con: systemctl status ${NOMBRE_SERVICIO}"
    fi
}

verificar_ssh() {
    log "Verificando conectividad SSH a servidores de descarga"
    local todo_bien=true
    if [[ ! -f "${CLAVE_SSH}" ]]; then
        aviso "No existe la clave SSH ${CLAVE_SSH}."
        aviso "Consulte 'Manual_configuracion_usuarios.docx' (Seccion II/III)."
        aviso "Se omite la verificacion de servidores de descarga."
        aviso "Sin clave no se publicara remotamente: los archivos quedaran en ${DIRECTORIO_BASE}/data/output"
        return 0
    fi
    local ssh_base=(sudo -u python ssh -i "${CLAVE_SSH}" -o ConnectTimeout=5 -o BatchMode=yes)
    for ip in "${SERVIDORES_REMOTOS[@]}"; do
        info "   Probando SSH ${USUARIO_REMOTO}@${ip}..."
        if "${ssh_base[@]}" "${USUARIO_REMOTO}@${ip}" "echo OK" 2>/dev/null | grep -q "OK"; then
            exito "Conexion SSH exitosa a ${ip}"
            local marca_prueba="probe_instalador_$(date +%s)_$$.txt"
            local archivo_prueba="/tmp/${marca_prueba}"
            echo "prueba instalador ${NOMBRE_PROYECTO} $(date)" > "${archivo_prueba}"
            chown python:python "${archivo_prueba}" 2>/dev/null || true
            if sudo -u python scp -i "${CLAVE_SSH}" -o ConnectTimeout=5 -o BatchMode=yes \
                   "${archivo_prueba}" \
                   "${USUARIO_REMOTO}@${ip}:${RUTA_REMOTA}/" >/dev/null 2>>"${ARCHIVO_LOG}" \
               && "${ssh_base[@]}" "${USUARIO_REMOTO}@${ip}" \
                   "test -f ${RUTA_REMOTA}/${marca_prueba} && rm -f ${RUTA_REMOTA}/${marca_prueba}" \
                   >/dev/null 2>>"${ARCHIVO_LOG}"; then
                exito "   Copia real verificada en ${ip}:${RUTA_REMOTA}"
            else
                aviso "   Fallo la copia de prueba a ${ip}:${RUTA_REMOTA}"
                aviso "   Verifique permisos (chown datos_abiertos, chmod 775) y que la ruta exista."
                aviso "   Consulte 'Manual_configuracion_usuarios.docx' (Seccion I, 1.3)."
                todo_bien=false
            fi
            rm -f "${archivo_prueba}"
        else
            aviso "No se pudo conectar por SSH a ${ip}."
            aviso "Consulte 'Manual_configuracion_usuarios.docx'."
            todo_bien=false
        fi
    done
    if [[ "${todo_bien}" == false ]]; then
        aviso "Existen problemas de conectividad SSH: en los servidores sin acceso no se publicara."
        aviso "Los archivos quedaran en ${DIRECTORIO_BASE}/data/output"
    fi
}

crear_estructura() {
    log "Creando estructura de directorios en ${DIRECTORIO_BASE} (Regla 57)"
    mkdir -p "${DIRECTORIO_BASE}/app"
    mkdir -p "${DIRECTORIO_BASE}/config"
    mkdir -p "${DIRECTORIO_BASE}/config/consultas"
    mkdir -p "${DIRECTORIO_BASE}/data/input/consultas"
    mkdir -p "${DIRECTORIO_BASE}/data/input/valoraciones"
    mkdir -p "${DIRECTORIO_BASE}/data/output"
    mkdir -p "${DIRECTORIO_BASE}/dist"
    mkdir -p "${DIRECTORIO_BASE}/logs"
    mkdir -p "${DIRECTORIO_BASE}/tests"
    mkdir -p "${DIRECTORIO_BASE}/mails_enviados"
    mkdir -p "${DIRECTORIO_BASE}/temp"
    mkdir -p "${DIRECTORIO_BASE}/destino_local"
    chown -R "${PROPIETARIO_PROYECTO}" "${DIRECTORIO_BASE}" 2>/dev/null || \
        aviso "Algunos archivos no se pudieron recronar (ya pertenecen a python). Se continua."
    exito "Estructura de directorios creada (Regla 57 SRI)"
}

copiar_consultas() {
    log "Copiando archivos de consultas JSON a data/input/consultas/"
    local dir_consultas="${DIRECTORIO_BASE}/data/input/consultas"
    local dir_config="${DIRECTORIO_BASE}/config/consultas"
    if [[ -d "${dir_config}" && -n "$(ls -A "${dir_config}"/*.json 2>/dev/null)" ]]; then
        cp "${dir_config}"/*.json "${dir_consultas}/" 2>/dev/null || true
        exito "Consultas JSON copiadas desde config/consultas/ -> data/input/consultas/"
    fi
    local dir_script
    dir_script="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    if [[ -d "${dir_script}/consultas" ]]; then
        cp "${dir_script}/consultas"/*.json "${dir_consultas}/" 2>/dev/null || true
        exito "Consultas JSON copiadas desde el paquete del instalador"
    fi
    local consultas_esperadas=("facturacion_sql_historia1.json" "facturacion_sql_historia2.json" "facturacion_sql_historia3.json" "facturacion_sql_historia4.json" "facturacion_sql_historia5.json")
    local faltantes=()
    for c in "${consultas_esperadas[@]}"; do
        if [[ ! -f "${dir_consultas}/${c}" ]]; then
            faltantes+=("${c}")
        fi
    done
    if (( ${#faltantes[@]} > 0 )); then
        aviso "Consultas faltantes en data/input/consultas/:"
        for c in "${faltantes[@]}"; do
            aviso "   - ${c}"
        done
        aviso "El ejecutable se generara, pero algunas historias no estaran disponibles."
    else
        exito "Todas las consultas esperadas presentes en data/input/consultas/"
    fi

    # Validación estricta: las 3 consultas principales DEBEN existir
    local consultas_obligatorias=("facturacion_sql_historia1.json" "facturacion_sql_historia2.json" "facturacion_sql_historia3.json")
    local faltantes_obligatorias=()
    for c in "${consultas_obligatorias[@]}"; do
        if [[ ! -f "${dir_consultas}/${c}" ]]; then
            faltantes_obligatorias+=("${c}")
        fi
    done
    if (( ${#faltantes_obligatorias[@]} > 0 )); then
        error_log "CONSULTAS OBLIGATORIAS FALTANTES:"
        for c in "${faltantes_obligatorias[@]}"; do
            error_log "   - ${c}"
        done
        error_log ""
        error_log "Debe copiar las consultas JSON a: ${dir_consultas}/"
        error_log "Las consultas deben estar disponibles antes de ejecutar el instalador."
        exit 1
    fi
    exito "Las 3 consultas obligatorias estan presentes (H1, H2, H3)"
}

verificar_config() {
    log "Verificando archivos de configuracion"
    if [[ ! -f "${DIRECTORIO_BASE}/config/${ARCHIVO_CONFIG}" ]]; then
        error_log "No se encuentra ${DIRECTORIO_BASE}/config/${ARCHIVO_CONFIG}."
        error_log "Debe existir antes de ejecutar el instalador."
        exit 1
    fi
    exito "Archivo de configuracion ${ARCHIVO_CONFIG} encontrado"
    if [[ ! -f "${DIRECTORIO_BASE}/${ARCHIVO_LIBRERIAS}" ]]; then
        error_log "No se encuentra ${DIRECTORIO_BASE}/${ARCHIVO_LIBRERIAS}."
        error_log "Debe contener la lista de dependencias Python (requirements.txt)."
        exit 1
    fi
    exito "Archivo ${ARCHIVO_LIBRERIAS} encontrado"
}

verificar_venv_pdm() {
    log "Verificando el entorno virtual de PDM en ${RUTA_VENV}"
    local python_venv="${RUTA_VENV}/bin/python"
    if [[ ! -x "${python_venv}" ]]; then
        error_log "No existe ${python_venv}."
        error_log "Cree el entorno con PDM e instale las dependencias (procedimiento aparte):"
        error_log "   cd ${DIRECTORIO_BASE} && pdm use ${PYTHON_CMD} && pdm install"
        error_log "   Sin acceso a PyPI: ver config/guia_paquetes_offline.md"
        exit 1
    fi
    local version_venv
    version_venv=$("${python_venv}" -c 'import sys; print("%d.%d" % sys.version_info[:2])')
    if [[ "${version_venv}" != "3.13" ]]; then
        error_log "El .venv usa Python ${version_venv}; el proyecto requiere 3.13."
        error_log "   pdm use ${PYTHON_CMD} && pdm install"
        exit 1
    fi
    exito "Entorno PDM: Python $("${python_venv}" --version 2>&1 | cut -d' ' -f2)"

    local archivo_req="${DIRECTORIO_BASE}/${ARCHIVO_LIBRERIAS}"
    local reporte
    reporte=$("${python_venv}" - "${archivo_req}" "${DIRECTORIO_BASE}/config/requirements_ejecutable.txt" <<'PYCHK'
import sys
from importlib import metadata
try:
    from packaging.requirements import Requirement
    from packaging.version import Version
except ImportError:
    from pip._vendor.packaging.requirements import Requirement
    from pip._vendor.packaging.version import Version
for linea in open(sys.argv[1], encoding='utf-8'):
    linea = linea.split('#', 1)[0].strip()
    if not linea:
        continue
    req = Requirement(linea)
    if req.marker is not None and not req.marker.evaluate():
        continue
    try:
        instalada = metadata.version(req.name)
    except metadata.PackageNotFoundError:
        print(f'FALTA {req.name} {req.specifier}')
        continue
    minimas = [spec.version for spec in req.specifier if spec.operator in ('==', '>=', '~=')]
    if minimas and Version(instalada) < max(Version(v) for v in minimas):
        print(f'ANTIGUA {req.name} instalada {instalada}, requiere {req.specifier} o mas nueva')
    elif minimas and Version(instalada) > max(Version(v) for v in minimas):
        print(f'NUEVA {req.name} {instalada}')
paquetes = sorted((d.metadata['Name'], d.version) for d in metadata.distributions() if d.metadata['Name'])
with open(sys.argv[2], 'w', encoding='utf-8') as salida:
    salida.write('# Versiones exactas empaquetadas en el ejecutable (generado por el instalador)\n')
    salida.writelines(f'{nombre}=={version}\n' for nombre, version in paquetes)
PYCHK
) || { error_log "No se pudo leer ${archivo_req} con el .venv."; exit 1; }

    DEPENDENCIAS_FALLIDAS=()
    local linea nuevas=0 antiguas=0
    while IFS= read -r linea; do
        case "${linea}" in
            FALTA*)   DEPENDENCIAS_FALLIDAS+=("${linea#FALTA }") ;;
            ANTIGUA*) aviso "   Version vieja (posible vulnerabilidad): ${linea#ANTIGUA }"; antiguas=$((antiguas+1)) ;;
            NUEVA*)   nuevas=$((nuevas+1)) ;;
        esac
    done <<< "${reporte}"
    if (( ${#DEPENDENCIAS_FALLIDAS[@]} > 0 )); then
        error_log "Faltan ${#DEPENDENCIAS_FALLIDAS[@]} paquete(s) en el .venv:"
        for linea in "${DEPENDENCIAS_FALLIDAS[@]}"; do error_log "   - ${linea}"; done
        error_log "Instalelos aparte (config/guia_paquetes_offline.md) y vuelva a ejecutar."
        exit 1
    fi
    if (( antiguas > 0 )); then
        aviso "${antiguas} paquete(s) con version anterior a la exigida: actualicelos en el .venv."
    fi
    (( nuevas > 0 )) && info "   ${nuevas} paquete(s) con version mas nueva que ${ARCHIVO_LIBRERIAS} (correcto)."
    info "   Versiones empaquetadas: ${DIRECTORIO_BASE}/config/requirements_ejecutable.txt"
    exito "Todas las dependencias de ${ARCHIVO_LIBRERIAS} estan en el .venv"

    if ! "${python_venv}" -m PyInstaller --version >/dev/null 2>&1; then
        error_log "PyInstaller no esta en el .venv: no se puede generar el ejecutable."
        error_log "   pdm add -dG build pyinstaller   (o instalarlo offline en el .venv)"
        exit 1
    fi
    exito "PyInstaller $("${python_venv}" -m PyInstaller --version 2>/dev/null) disponible"
}

#==============================================================================
# CORRECCION v4.0.1: instalar_dependencias ahora es tolerante a fallos
#==============================================================================
#==============================================================================
# CREACION DE SCRIPTS DE PRUEBA
#==============================================================================
crear_pruebas() {
    log "Creando scripts de prueba en ${DIRECTORIO_BASE}/tests"
    cat > "${DIRECTORIO_BASE}/tests/prueba_wallet.py" << 'EOF'
#!/usr/bin/env python3
"""Prueba de Oracle Wallet (autologin sin contrasena)."""
import oracledb
import sys
import os
try:
    import tomllib
except ImportError:
    import tomli as tomllib

cfg_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'configlnx.toml')
with open(cfg_path, 'rb') as f:
    cfg = tomllib.load(f)

jdbc_url    = cfg['spark']['jdbc_url']
wallet_path = cfg['spark']['wallet_path']
tns         = jdbc_url.split('@')[-1]

print(f"TNS: {tns} | Wallet: {wallet_path}")
try:
    oracledb.init_oracle_client(config_dir=wallet_path)
    conn = oracledb.connect(dsn=tns)
    cursor = conn.cursor()
    cursor.execute("SELECT SYSDATE FROM DUAL")
    fecha = cursor.fetchone()[0]
    print(f"Conectado — SYSDATE: {fecha}")
    conn.close()
    sys.exit(0)
except Exception as exc:
    print(f"Error: {exc}")
    sys.exit(1)
EOF
    cat > "${DIRECTORIO_BASE}/tests/prueba_spark.py" << 'EOF'
#!/usr/bin/env python3
"""Prueba Spark Connect + Oracle Wallet."""
from pyspark.sql import SparkSession
import sys
import os
try:
    import tomllib
except ImportError:
    import tomli as tomllib

cfg_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'configlnx.toml')
with open(cfg_path, 'rb') as f:
    cfg = tomllib.load(f)

spark_url   = cfg['spark']['url']
jdbc_url    = cfg['spark']['jdbc_url']
wallet_path = cfg['spark']['wallet_path']

print(f"Spark: {spark_url} | JDBC: {jdbc_url}")
try:
    spark = SparkSession.builder.remote(spark_url).getOrCreate()
    df = (spark.read.format("jdbc")
          .option("url", jdbc_url)
          .option("driver", "oracle.jdbc.OracleDriver")
          .option("oracle.net.wallet_location", wallet_path)
          .option("oracle.net.tns_admin", wallet_path)
          .option("user", "").option("password", "")
          .option("query", "SELECT SYSDATE AS FECHA FROM DUAL")
          .load())
    df.show()
    spark.stop()
    print("Prueba Spark + Oracle exitosa")
    sys.exit(0)
except Exception as exc:
    print(f"Error: {exc}")
    sys.exit(1)
EOF
    cat > "${DIRECTORIO_BASE}/tests/prueba_email.py" << 'EOF'
#!/usr/bin/env python3
"""Prueba de envio de correo (notificaciones SMTP)."""
import smtplib
import sys
import os
from email.mime.text import MIMEText
try:
    import tomllib
except ImportError:
    import tomli as tomllib

cfg_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'configlnx.toml')
with open(cfg_path, 'rb') as f:
    cfg = tomllib.load(f)

email_cfg = cfg.get('email', {})
host        = email_cfg.get('smtp_server', 'localhost')
port        = email_cfg.get('smtp_port', 25)
remitente   = email_cfg.get('from_address', 'datosabiertos@sri.gob.ec')
destinatario = email_cfg.get('to_addresses', ['dnracautorizaciondetransacciones@sri.ad'])[0]

print(f"SMTP: {host}:{port} | De: {remitente} | Para: {destinatario}")

msg = MIMEText("Prueba de notificacion - instalador sri_datos_abiertos_facturacion.")
msg['Subject'] = "[Datos Abiertos] Prueba SMTP"
msg['From'] = remitente
msg['To'] = destinatario

try:
    with smtplib.SMTP(host, port, timeout=10) as server:
        server.sendmail(remitente, [destinatario], msg.as_string())
    print("Correo de prueba enviado correctamente.")
    sys.exit(0)
except Exception as exc:
    print(f"Error: {exc}")
    sys.exit(1)
EOF
    chmod +x "${DIRECTORIO_BASE}/tests/prueba_wallet.py" \
             "${DIRECTORIO_BASE}/tests/prueba_spark.py" \
             "${DIRECTORIO_BASE}/tests/prueba_email.py" 2>/dev/null || true
    chown -R "${PROPIETARIO_PROYECTO}" "${DIRECTORIO_BASE}/tests" 2>/dev/null || true
    exito "Scripts de prueba creados en ${DIRECTORIO_BASE}/tests"
}

#==============================================================================
# GENERACION DE EJECUTABLE CON PYINSTALLER
#==============================================================================
generar_ejecutable() {
    log "Buscando codigo fuente en ${DIRECTORIO_BASE}/app"
    if [[ ! -d "${DIRECTORIO_BASE}/app" ]] || \
       [[ -z "$(ls -A "${DIRECTORIO_BASE}/app"/*.py 2>/dev/null)" ]]; then
        aviso "No se encontraron archivos .py en app/ — se omite la generacion del ejecutable."
        return
    fi
    cd "${DIRECTORIO_BASE}"
    local version
    version=$(leer_version)
    local nombre_ejecutable="sri_datos_abiertos.${version}"
    log "   Version detectada: ${version}"
    log "   Ejecutable a generar: ${nombre_ejecutable}"
    local archivo_principal="app/main.py"
    if [[ ! -f "${DIRECTORIO_BASE}/${archivo_principal}" ]]; then
        aviso "app/main.py no encontrado. No se puede generar el ejecutable."
        return
    fi
    log "   Punto de entrada: ${archivo_principal}"
    local log_pyinstaller="${DIRECTORIO_BASE}/logs/pyinstaller_$(date +%Y%m%d_%H%M%S).log"
    log "   Ejecutando PyInstaller (log en ${log_pyinstaller})..."
    local codigo_pyinstaller=0
    # NOTA: --collect-all incluye TODO el paquete (no solo el módulo raíz).
    # Esto es necesario para click, pydantic, pandas, pyspark, etc.
    "${RUTA_VENV}/bin/python" -m PyInstaller \
        --onefile \
        --clean \
        --name "${nombre_ejecutable}" \
        --add-data "app:app" \
        --add-data "config/${ARCHIVO_CONFIG}:config" \
        --add-data "data/input/consultas:data/input/consultas" \
        --collect-all pyspark \
        --collect-all click \
        --collect-all pydantic \
        --collect-all pydantic_core \
        --collect-all pandas \
        --collect-all numpy \
        --collect-all oracledb \
        --collect-all paramiko \
        --collect-all cryptography \
        --collect-all grpcio \
        --collect-all protobuf \
        --collect-all pyarrow \
        --collect-all tomli \
        --collect-all tomllib \
        --collect-all typing_extensions \
        --collect-all typing_inspection \
        --collect-all annotated_types \
        --collect-all pynacl \
        --collect-all bcrypt \
        --collect-all cffi \
        --collect-all pycparser \
        --collect-all greenlet \
        --collect-all sqlalchemy \
        --collect-all zstandard \
        --collect-all lxml \
        --collect-all smbprotocol \
        --collect-all pyspnego \
        --collect-all invoke \
        --collect-all googleapis_common_protos \
        --collect-all grpcio_status \
        --collect-all pandera \
        --collect-all py4j \
        --collect-all colorama \
        --collect-all sspilib \
        --hidden-import=smtplib \
        --hidden-import=email.mime.text \
        --hidden-import=email.mime.multipart \
        --hidden-import=ctypes \
        --exclude-module pkg_resources \
        --paths "/usr/local/python3.13/lib/python3.13" \
        --paths ".venv/lib/python3.13/site-packages" \
        "${archivo_principal}" \
        > "${log_pyinstaller}" 2>&1 || codigo_pyinstaller=$?
    if [[ ${codigo_pyinstaller} -ne 0 ]]; then
        aviso "PyInstaller fallo (codigo ${codigo_pyinstaller})."
        aviso "Ultimas 40 lineas del log de PyInstaller:"
        tail -40 "${log_pyinstaller}" | tee -a "${ARCHIVO_LOG}"
        aviso "Log completo: ${log_pyinstaller}"
        aviso "Generando lanzador con el .venv como alternativa (no portable)..."
        cat > "${DIRECTORIO_BASE}/sri_datos_abiertos" << 'EOF'
#!/bin/bash
cd "$(dirname "$(readlink -f "$0")")" && exec .venv/bin/python -m app.main "$@"
EOF
        chmod +x "${DIRECTORIO_BASE}/sri_datos_abiertos"
        chown "${PROPIETARIO_PROYECTO}" "${DIRECTORIO_BASE}/sri_datos_abiertos" 2>/dev/null || true
        exito "Lanzador creado: ${DIRECTORIO_BASE}/sri_datos_abiertos"
        return
    fi
    cat "${log_pyinstaller}" >> "${ARCHIVO_LOG}"
    local ruta_ejecutable="${DIRECTORIO_BASE}/dist/${nombre_ejecutable}"
    if [[ -f "${ruta_ejecutable}" ]]; then
        local enlace="${DIRECTORIO_BASE}/sri_datos_abiertos"
        ln -sf "${ruta_ejecutable}" "${enlace}"
        chmod +x "${ruta_ejecutable}"
        chown -R "${PROPIETARIO_PROYECTO}" \
                 "${DIRECTORIO_BASE}/dist" \
                 "${enlace}" 2>/dev/null || true
        exito "Ejecutable: ${ruta_ejecutable}"
        exito "Enlace:     ${enlace} -> ${nombre_ejecutable}"
        armar_paquete_portable "${ruta_ejecutable}" "${version}"
    else
        aviso "PyInstaller termino pero no genero ${nombre_ejecutable}."
        aviso "Revise: ${log_pyinstaller}"
    fi
}

#==============================================================================
# RESUMEN FINAL
#==============================================================================
armar_paquete_portable() {
    # Carpeta autocontenida: binario + config/ + consultas + carpetas de
    # trabajo. Se copia a cualquier ruta y se ejecuta sin instalar nada.
    local ruta_ejecutable="$1" version="$2"
    local nombre_paquete="sri_datos_abiertos_${version}"
    local paquete="${DIRECTORIO_BASE}/dist/${nombre_paquete}"
    log "Armando paquete portable en ${paquete}"
    rm -rf "${paquete}"
    mkdir -p "${paquete}/config" "${paquete}/data/input/consultas" "${paquete}/data/output" \
             "${paquete}/logs" "${paquete}/temp" "${paquete}/mails_enviados"
    cp "${ruta_ejecutable}" "${paquete}/"
    ln -sf "$(basename "${ruta_ejecutable}")" "${paquete}/sri_datos_abiertos"
    cp "${DIRECTORIO_BASE}/config/${ARCHIVO_CONFIG}" "${paquete}/config/"
    cp "${DIRECTORIO_BASE}/config/guia_paquetes_offline.md" "${paquete}/config/" 2>/dev/null || true
    cp "${DIRECTORIO_BASE}/config/requirements_ejecutable.txt" "${paquete}/config/" 2>/dev/null || true
    cp "${DIRECTORIO_BASE}/data/input/consultas/"*.json "${paquete}/data/input/consultas/"
    tar -czf "${DIRECTORIO_BASE}/dist/${nombre_paquete}.tar.gz" -C "${DIRECTORIO_BASE}/dist" "${nombre_paquete}"
    chown -R "${PROPIETARIO_PROYECTO}" "${paquete}" "${DIRECTORIO_BASE}/dist/${nombre_paquete}.tar.gz" 2>/dev/null || true
    exito "Paquete portable: ${paquete}"
    exito "Para llevarlo a otro servidor: ${DIRECTORIO_BASE}/dist/${nombre_paquete}.tar.gz"
    info "   Uso: tar -xzf ${nombre_paquete}.tar.gz && cd ${nombre_paquete} && ./sri_datos_abiertos probar"
}

resumen_final() {
    local version_python
    version_python=$("${PYTHON_CMD}" --version 2>&1)
    local version_java
    version_java=$(java -version 2>&1 | head -1)
    local version_app
    version_app=$(leer_version)
    local cmd_exe="${DIRECTORIO_BASE}/sri_datos_abiertos"
    local cmd_venv="${RUTA_VENV}/bin/python -m app.main"
    echo "" | tee -a "${ARCHIVO_LOG}"
    echo "==============================================================================" | tee -a "${ARCHIVO_LOG}"
    echo "                    INSTALACION COMPLETADA" | tee -a "${ARCHIVO_LOG}"
    echo "==============================================================================" | tee -a "${ARCHIVO_LOG}"
    echo "Proyecto       : ${NOMBRE_PROYECTO}" | tee -a "${ARCHIVO_LOG}"
    echo "Version app    : ${version_app}" | tee -a "${ARCHIVO_LOG}"
    echo "Directorio     : ${DIRECTORIO_BASE}" | tee -a "${ARCHIVO_LOG}"
    echo "Python         : ${version_python}" | tee -a "${ARCHIVO_LOG}"
    echo "Java           : ${version_java}" | tee -a "${ARCHIVO_LOG}"
    echo "Spark          : ${SPARK_HOME} (servicio: ${NOMBRE_SERVICIO})" | tee -a "${ARCHIVO_LOG}"
    echo "Oracle Home    : ${ORACLE_HOME}" | tee -a "${ARCHIVO_LOG}"
    echo "Wallet         : ${RUTA_WALLET_ORACLE}" | tee -a "${ARCHIVO_LOG}"
    if (( ${#WALLETS_FALLIDOS[@]} > 0 )); then
        echo "  Wallets SIN conexion : ${WALLETS_FALLIDOS[*]}" | tee -a "${ARCHIVO_LOG}"
        echo "  (el ejecutable se genero, pero no podra conectarse a esas bases)" | tee -a "${ARCHIVO_LOG}"
    else
        echo "  Wallets              : todas las conexiones OK" | tee -a "${ARCHIVO_LOG}"
    fi
    if (( ${#JARS_FALTANTES[@]} > 0 )); then
        echo "  JARs faltantes       : ${JARS_FALTANTES[*]}" | tee -a "${ARCHIVO_LOG}"
        echo "  (copie a ${SPARK_LIBS})" | tee -a "${ARCHIVO_LOG}"
    fi
    if (( ${#DEPENDENCIAS_FALLIDAS[@]} > 0 )); then
        echo "  Dependencias faltantes: ${DEPENDENCIAS_FALLIDAS[*]}" | tee -a "${ARCHIVO_LOG}"
        echo "  (instalelas aparte en el .venv: config/guia_paquetes_offline.md)" | tee -a "${ARCHIVO_LOG}"
    fi
    if [[ "${SPARK_OMITIDO}" == true ]]; then
        echo "  Spark                : NO instalado (falto ${SPARK_TGZ})" | tee -a "${ARCHIVO_LOG}"
    fi
    echo "Log instalador : ${ARCHIVO_LOG}" | tee -a "${ARCHIVO_LOG}"
    echo "" | tee -a "${ARCHIVO_LOG}"
    echo "------------------------------------------------------------------------------" | tee -a "${ARCHIVO_LOG}"
    echo "  ESTRUCTURA DE DIRECTORIOS (Regla 57 SRI)" | tee -a "${ARCHIVO_LOG}"
    echo "------------------------------------------------------------------------------" | tee -a "${ARCHIVO_LOG}"
    echo "  ${DIRECTORIO_BASE}/" | tee -a "${ARCHIVO_LOG}"
    echo "  ├── app/                  -> Codigo fuente Python" | tee -a "${ARCHIVO_LOG}"
    echo "  ├── config/               -> configlnx.toml, configwin.toml" | tee -a "${ARCHIVO_LOG}"
    echo "  ├── data/" | tee -a "${ARCHIVO_LOG}"
    echo "  │   ├── input/" | tee -a "${ARCHIVO_LOG}"
    echo "  │   │   ├── consultas/    -> facturacion_sql_historia*.json" | tee -a "${ARCHIVO_LOG}"
    echo "  │   │   └── valoraciones/ -> Tests (dev/QA)" | tee -a "${ARCHIVO_LOG}"
    echo "  │   └── output/           -> ZIP/CSV generados (quedan aqui si no hay servidores)" | tee -a "${ARCHIVO_LOG}"
    echo "  ├── tests/                -> Pruebas pytest (NO en el ejecutable)" | tee -a "${ARCHIVO_LOG}"
    echo "  ├── dist/                 -> Ejecutable PyInstaller" | tee -a "${ARCHIVO_LOG}"
    echo "  ├── logs/                 -> Logs de ejecucion" | tee -a "${ARCHIVO_LOG}"
    echo "  ├── .venv/                -> Entorno virtual de PDM (desarrollo)" | tee -a "${ARCHIVO_LOG}"
    echo "  ├── temp/                 -> Temporales" | tee -a "${ARCHIVO_LOG}"
    echo "  ├── requirements.txt      -> Dependencias" | tee -a "${ARCHIVO_LOG}"
    echo "  └── README.md             -> Documentacion" | tee -a "${ARCHIVO_LOG}"
    echo "" | tee -a "${ARCHIVO_LOG}"
    echo "------------------------------------------------------------------------------" | tee -a "${ARCHIVO_LOG}"
    echo "  COMO EJECUTAR LA APLICACION" | tee -a "${ARCHIVO_LOG}"
    echo "------------------------------------------------------------------------------" | tee -a "${ARCHIVO_LOG}"
    echo "" | tee -a "${ARCHIVO_LOG}"
    if [[ -f "${cmd_exe}" ]]; then
        echo "  1. Ejecutable compilado (produccion — sin activar venv):" | tee -a "${ARCHIVO_LOG}"
        echo "" | tee -a "${ARCHIVO_LOG}"
        echo "    ${cmd_exe}                           Menu interactivo" | tee -a "${ARCHIVO_LOG}"
        echo "    ${cmd_exe} --listar                  Lista consultas disponibles" | tee -a "${ARCHIVO_LOG}"
        echo "    ${cmd_exe} -d facturacion_sql_historia1   Sin menu (para cron)" | tee -a "${ARCHIVO_LOG}"
        echo "    ${cmd_exe} -d facturacion_sql_historia2   Sin menu" | tee -a "${ARCHIVO_LOG}"
        echo "    ${cmd_exe} -d facturacion_sql_historia3   Sin menu" | tee -a "${ARCHIVO_LOG}"
        echo "    ${cmd_exe} verificar                 Verifica archivos en servidores" | tee -a "${ARCHIVO_LOG}"
        echo "    ${cmd_exe} verificar --anio 2024     Verifica archivos del anio 2024" | tee -a "${ARCHIVO_LOG}"
        echo "" | tee -a "${ARCHIVO_LOG}"
    fi
    echo "  2. Con Python + venv (desarrollo o si no hay ejecutable):" | tee -a "${ARCHIVO_LOG}"
    echo "" | tee -a "${ARCHIVO_LOG}"
    echo "    source ${RUTA_VENV}/bin/activate" | tee -a "${ARCHIVO_LOG}"
    echo "    ${cmd_venv}                      Menu interactivo" | tee -a "${ARCHIVO_LOG}"
    echo "    ${cmd_venv} --listar             Lista consultas" | tee -a "${ARCHIVO_LOG}"
    echo "    ${cmd_venv} -d <ID>              Sin menu" | tee -a "${ARCHIVO_LOG}"
    echo "    ${cmd_venv} verificar            Verifica servidores" | tee -a "${ARCHIVO_LOG}"
    echo "" | tee -a "${ARCHIVO_LOG}"
    echo "------------------------------------------------------------------------------" | tee -a "${ARCHIVO_LOG}"
    echo "  CRON.D — Ejecucion automatica mensual" | tee -a "${ARCHIVO_LOG}"
    echo "  Archivo sugerido: /etc/cron.d/sri_datos_abiertos" | tee -a "${ARCHIVO_LOG}"
    echo "------------------------------------------------------------------------------" | tee -a "${ARCHIVO_LOG}"
    echo "" | tee -a "${ARCHIVO_LOG}"
    local cmd_cron=""
    local prefijo_cron=""
    if [[ -f "${cmd_exe}" ]]; then
        # Binario PyInstaller: se ejecuta DIRECTO. Anteponer 'python' da
        # 'source code cannot contain null bytes' (intenta leer un ELF como
        # script .py). Este era el error del log de instalacion.
        cmd_cron="${cmd_exe}"
        prefijo_cron=""
    else
        # Sin binario: usar el python del venv contra el modulo app.main.
        cmd_cron="${RUTA_VENV}/bin/python -m app.main"
        prefijo_cron=""
    fi
    echo "  # Historia 1 - Facturacion Fisica (primer dia del mes, 04:00) [HU1]" | tee -a "${ARCHIVO_LOG}"
    echo "  0 4 1 * *  ${prefijo_cron}${cmd_cron} -d facturacion_sql_historia1" | tee -a "${ARCHIVO_LOG}"
    echo "" | tee -a "${ARCHIVO_LOG}"
    echo "  # Historia 2 - Comprobantes CEL (PRIMER MARTES del mes, 04:30) [HU2]" | tee -a "${ARCHIVO_LOG}"
    echo "  # El SDC exige primer martes: cron dispara todos los martes y el" | tee -a "${ARCHIVO_LOG}"
    echo "  # test [ \$(date +\\%d) -le 07 ] limita al primero del mes." | tee -a "${ARCHIVO_LOG}"
    echo "  30 4 * * 2  [ \"\$(date +\\%d)\" -le 07 ] && ${prefijo_cron}${cmd_cron} -d facturacion_sql_historia2" | tee -a "${ARCHIVO_LOG}"
    echo "" | tee -a "${ARCHIVO_LOG}"
    echo "  # Historia 3 - Emisores CEL (primer dia del mes, 05:00) [HU3]" | tee -a "${ARCHIVO_LOG}"
    echo "  0 5 1 * *  ${prefijo_cron}${cmd_cron} -d facturacion_sql_historia3" | tee -a "${ARCHIVO_LOG}"
    echo "" | tee -a "${ARCHIVO_LOG}"
    echo "  # Historia 5 - Vehiculos nuevos (primer dia del mes, 05:30)" | tee -a "${ARCHIVO_LOG}"
    echo "  30 5 1 * *  ${prefijo_cron}${cmd_cron} -d facturacion_sql_historia5" | tee -a "${ARCHIVO_LOG}"
    echo "" | tee -a "${ARCHIVO_LOG}"
    echo "  # Prueba previa: credencial + 1 fila de cada consulta (ultimo dia, 20:00)" | tee -a "${ARCHIVO_LOG}"
    echo "  0 20 28-31 * *  [ \"\$(date -d tomorrow +\\%d)\" = 01 ] && ${prefijo_cron}${cmd_cron} probar" | tee -a "${ARCHIVO_LOG}"
    echo "" | tee -a "${ARCHIVO_LOG}"
    echo "  # Verificar archivos en servidores (primer dia del mes, 06:00)" | tee -a "${ARCHIVO_LOG}"
    echo "  0 6 1 * *  ${prefijo_cron}${cmd_cron} verificar" | tee -a "${ARCHIVO_LOG}"
    echo "" | tee -a "${ARCHIVO_LOG}"
    echo "------------------------------------------------------------------------------" | tee -a "${ARCHIVO_LOG}"
    echo "  VERIFICACION POST-INSTALACION" | tee -a "${ARCHIVO_LOG}"
    echo "------------------------------------------------------------------------------" | tee -a "${ARCHIVO_LOG}"
    echo "" | tee -a "${ARCHIVO_LOG}"
    echo "  1. Estado del servicio Spark:" | tee -a "${ARCHIVO_LOG}"
    echo "       sudo systemctl status ${NOMBRE_SERVICIO}" | tee -a "${ARCHIVO_LOG}"
    echo "" | tee -a "${ARCHIVO_LOG}"
    echo "  2. Probar wallet Oracle:" | tee -a "${ARCHIVO_LOG}"
    echo "       source ${RUTA_VENV}/bin/activate" | tee -a "${ARCHIVO_LOG}"
    echo "       python ${DIRECTORIO_BASE}/tests/prueba_wallet.py" | tee -a "${ARCHIVO_LOG}"
    echo "" | tee -a "${ARCHIVO_LOG}"
    echo "  3. Probar Spark + Oracle:" | tee -a "${ARCHIVO_LOG}"
    echo "       python ${DIRECTORIO_BASE}/tests/prueba_spark.py" | tee -a "${ARCHIVO_LOG}"
    echo "" | tee -a "${ARCHIVO_LOG}"
    echo "  4. Probar envio de correo (notificaciones):" | tee -a "${ARCHIVO_LOG}"
    echo "       python ${DIRECTORIO_BASE}/tests/prueba_email.py" | tee -a "${ARCHIVO_LOG}"
    echo "" | tee -a "${ARCHIVO_LOG}"
    echo "  5. Verificar JARs en /opt/librerias:" | tee -a "${ARCHIVO_LOG}"
    echo "       ls -la ${SPARK_LIBS}/*.jar" | tee -a "${ARCHIVO_LOG}"
    echo "" | tee -a "${ARCHIVO_LOG}"
    echo "==============================================================================" | tee -a "${ARCHIVO_LOG}"
    exito "Instalador finalizado. Log completo en: ${ARCHIVO_LOG}"
}

#==============================================================================
# FUNCION PRINCIPAL
#==============================================================================
principal() {
    if [[ "${SOLO_EJECUTABLE}" == true ]]; then
        log "=== GENERACION DE EJECUTABLE (--solo-ejecutable) $(date) ==="
        verificar_config
        verificar_venv_pdm
        generar_ejecutable
        log "=== FIN $(date) ==="
        return 0
    fi
    clear
    echo "=============================================================================="
    echo "    INSTALADOR SRI DATOS ABIERTOS FACTURACION  v${version_app:-?}"
    echo "=============================================================================="
    echo "Proyecto : ${NOMBRE_PROYECTO}"
    echo "Log      : ${ARCHIVO_LOG}"
    echo ""
    read -r -p "Presione ENTER para continuar o Ctrl+C para cancelar..."
    log "=== INICIO DE INSTALACION $(date) ==="
    verificar_espacio
    verificar_python
    verificar_java
    verificar_oracle
    verificar_jars
    corregir_libffi
    verificar_spark
    verificar_ssh
    verificar_correo
    crear_estructura
    copiar_consultas
    verificar_config
    verificar_venv_pdm
    crear_pruebas
    generar_ejecutable
    resumen_final
    log "=== FIN DE INSTALACION $(date) ==="
}

version_app=$(leer_version 2>/dev/null || echo "?")
principal "$@"
