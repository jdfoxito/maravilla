"""Control de calidad del archivo antes de reemplazar la version vigente.

app/da_control_publicacion.py

Reproduce los controles del proceso manual de publicacion: el archivo
nuevo de un dataset acumulado (enero..mes anterior) debe tener mas filas
que el vigente. El 03/11/2026 se publico por error el archivo del mes
anterior y solo el conteo de filas lo detecto.

Historial:
+--------------------+---------+------------------------------------------+
| Autor              | Version | Cambios                                  |
+--------------------+---------+------------------------------------------+
| Jim A. Gonzalez    | 1.0.0   | Conteo, comparacion e historico          |
+--------------------+---------+------------------------------------------+
"""

from datetime import datetime
import logging
from pathlib import Path
import shutil
from typing import BinaryIO
import zipfile

DIR_HISTORICO = 'historico'
VERSIONES_HISTORICO = 12
TOLERANCIA_MISMO_MES = 0.99
_TAMANIO_BLOQUE = 1024 * 1024


def _contar_lineas(flujo: BinaryIO) -> int:
    """Cuenta filas de datos de un flujo CSV, sin la cabecera."""
    lineas = 0
    for bloque in iter(lambda: flujo.read(_TAMANIO_BLOQUE), b''):
        lineas += bloque.count(b'\n')
    return max(lineas - 1, 0)


def contar_filas_archivo(ruta: Path) -> int:
    """
    Cuenta las filas de datos de un CSV o del primer CSV de un ZIP.

    Args:
        ruta: Archivo .csv o .zip.

    Returns:
        Numero de filas sin la cabecera.

    Raises:
        FileNotFoundError: Si el ZIP no contiene ningun CSV.
    """
    if ruta.suffix.lower() != '.zip':
        with open(ruta, 'rb') as flujo:
            return _contar_lineas(flujo)

    with zipfile.ZipFile(ruta) as archivo_zip:
        nombres_csv = [nombre for nombre in archivo_zip.namelist() if nombre.lower().endswith('.csv')]
        if not nombres_csv:
            raise FileNotFoundError(f'El ZIP {ruta.name} no contiene archivos CSV')
        with archivo_zip.open(nombres_csv[0]) as flujo:
            return _contar_lineas(flujo)


class ControlPublicacion:
    """Compara el archivo nuevo con el vigente y archiva la version anterior."""

    def __init__(self, logger: logging.Logger):
        """
        Inicializa el control.

        Args:
            logger: Logger compartido inyectado desde el punto de entrada.
        """
        self._logger = logger

    def _log(self, level: int, msg: str, *args: object) -> None:
        """Registra un mensaje con formato lazy % para compatibilidad con Pylint."""
        self._logger.log(level, msg, *args)

    def validar_contra_vigente(self, ruta_vigente: Path, total_nuevo: int, consulta_id: str) -> None:
        """
        Valida que el conteo nuevo sea coherente con la version vigente.

        Reglas del dataset acumulado:
          - Vigente de un mes anterior: el nuevo debe tener mas filas.
          - Vigente de este mismo mes (re-ejecucion): se acepta hasta 1%
            menos.
          - Sin vigente (primer mes del anio): no se compara.

        Args:
            ruta_vigente: Archivo publicado actualmente en destino_local.
            total_nuevo: Filas del archivo recien generado.
            consulta_id: Identificador de la consulta para el log.

        Raises:
            ValueError: Si el conteo no es coherente. No se publica nada.
        """
        if not ruta_vigente.exists():
            self._log(logging.INFO, 'Sin version vigente de %s: no se compara', ruta_vigente.name)
            return

        total_vigente = contar_filas_archivo(ruta_vigente)
        fecha_vigente = datetime.fromtimestamp(ruta_vigente.stat().st_mtime)
        ahora = datetime.now()
        mismo_mes = (fecha_vigente.year, fecha_vigente.month) == (ahora.year, ahora.month)
        self._log(
            logging.INFO, 'Control %s: vigente=%s filas (%s) | nuevo=%s filas',
            consulta_id, f'{total_vigente:,}', fecha_vigente.strftime('%Y-%m-%d'), f'{total_nuevo:,}'
        )

        if mismo_mes and total_nuevo < int(total_vigente * TOLERANCIA_MISMO_MES):
            raise ValueError(
                f'Re-ejecucion del mes con {total_nuevo:,} filas, menos del 99% '
                f'de la version vigente ({total_vigente:,}). No se publica.'
            )
        if not mismo_mes and total_nuevo <= total_vigente:
            raise ValueError(
                f'El archivo nuevo tiene {total_nuevo:,} filas y el vigente {total_vigente:,}. '
                'En un acumulado mensual deberia crecer. Revisar periodo o fuente. No se publica.'
            )

    def archivar_vigente(self, ruta_vigente: Path) -> None:
        """
        Mueve la version vigente a destino_local/historico/.

        Conserva las ultimas VERSIONES_HISTORICO copias de cada archivo.

        Args:
            ruta_vigente: Archivo publicado actualmente en destino_local.
        """
        if not ruta_vigente.exists():
            return
        dir_historico = ruta_vigente.parent / DIR_HISTORICO
        dir_historico.mkdir(parents=True, exist_ok=True)
        marca = datetime.fromtimestamp(ruta_vigente.stat().st_mtime).strftime('%Y%m%d_%H%M%S')
        destino = dir_historico / f'{marca}_{ruta_vigente.name}'
        shutil.move(str(ruta_vigente), destino)
        self._log(logging.INFO, 'Version anterior archivada: %s', destino)

        versiones = sorted(dir_historico.glob(f'*_{ruta_vigente.name}'))
        for version_vieja in versiones[:-VERSIONES_HISTORICO]:
            version_vieja.unlink(missing_ok=True)
