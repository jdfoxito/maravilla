
# -*- coding: utf-8 -*-
"""Modelos de datos del sistema de exportación.

app-da_modelos.py

Contiene la dataclass ConsultaDefinicion que representa
una consulta cargada desde un archivo JSON.

Regla 44 SRI: Las clases de entidad son estructuras pasivas,
sin lógica de negocio ni procesamiento.

Historial:
+--------------------+---------+------------------------------------------+
| Autor              | Versión | Cambios                                  |
+--------------------+---------+------------------------------------------+
| Jim A. González    | 1.0.0   | Extraído de exportador.py (Regla 43 SRI) |
| Jim A. González    | 1.1.0   | conexion = alias TNS del wallet;         |
|                    |         | SalidaArchivo (nombre CSV, ZIP, publicar)|
+--------------------+---------+------------------------------------------+
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from app.da_sesion_spark import jdbc_desde_alias


@dataclass
class SalidaArchivo:
    """
    Forma del archivo publicado. Clase de entidad pasiva (Regla 44 SRI).

    nombre_csv: nombre (sin anio ni extension) del CSV; None usa el
                nombre_archivo de la consulta.
    comprimir: False publica el CSV plano (caso vehiculos).
    publicar: False genera en destino_local sin subir (pruebas).
    """

    nombre_csv: Optional[str] = None
    comprimir: bool = True
    publicar: bool = True


@dataclass
class ConsultaDefinicion:
    """
    Estructura tipada de una definición de consulta leída desde JSON.

    Clase de entidad pasiva (Regla 44 SRI): solo contiene atributos
    y el método de construcción desde diccionario.
    Transformaciones de negocio post-extraccion (da_dataframe.py).
    proceso: nombre del pipeline registrado (proceso_caso1, caso2...)
    columnas: {col_origen: COLUMNA_FINAL} renombra/reordena/descarta
    orden: [{"columna": X, "ascendente": bool}]
    catalogos: SQL auxiliares del proceso (ej: canton_sql)
    wallet: alias TNS, que es tambien el nombre de la credencial en el
            wallet. En el JSON se declara como "conexion".
    salida: forma del archivo publicado (SalidaArchivo).
    """

    id_: str
    nombre: str
    sql: str
    nombre_archivo: str
    columna_particion: Optional[str] = None
    num_particiones: int = 1
    delimitador: str = '|'
    destino: Dict[str, Any] = field(default_factory=dict)
    wallet: Optional[str] = None
    spark_url: Optional[str] = None
    jdbc_url: Optional[str] = None
    config_email: Optional[Dict[str, Any]] = None
    anio: Optional[int] = None
    mes_ini: Optional[int] = None
    mes_fin: Optional[int] = None
    proceso: Optional[str] = None
    columnas: Dict[str, str] = field(default_factory=dict)
    orden: List[Dict[str, Any]] = field(default_factory=list)
    catalogos: Dict[str, Any] = field(default_factory=dict)
    salida: SalidaArchivo = field(default_factory=SalidaArchivo)

    @classmethod
    def desde_dict(cls, datos: Dict[str, Any]) -> 'ConsultaDefinicion':
        """
        Crea instancia desde diccionario JSON.

        Acepta nombres en español o inglés para compatibilidad
        con los JSONs existentes (partition_column, num_partitions).

        Args:
            datos: Diccionario con los campos de la consulta.

        Returns:
            Instancia de ConsultaDefinicion.
        """
        destino = datos.get('destino', {})
        if isinstance(destino, str):
            destino = {'tipo': 'local', 'directorio_remoto': destino}
        alias = datos.get('conexion') or datos.get('wallet')
        jdbc_url = datos.get('jdbc_url') or (jdbc_desde_alias(alias) if alias else None)

        return cls(
            id_=datos.get('id', 'desconocido'),
            nombre=datos.get('nombre', datos.get('id', 'desconocido')),
            sql=datos.get('sql', ''),
            nombre_archivo=datos.get('nombre_archivo', datos.get('id', 'exportacion')),
            columna_particion=datos.get(
                'columna_particion', datos.get('partition_column')
            ),
            num_particiones=datos.get(
                'num_particiones', datos.get('num_partitions', 1)
            ),
            delimitador=datos.get('delimitador', '|'),
            destino=destino,
            wallet=alias,
            spark_url=datos.get('spark'),
            jdbc_url=jdbc_url,
            config_email=datos.get('email'),
            anio=datos.get('anio'),
            mes_ini=datos.get('mes_ini'),
            mes_fin=datos.get('mes_fin'),
            proceso=datos.get('proceso'),
            columnas=datos.get('columnas', {}),
            orden=datos.get('orden', []),
            catalogos=datos.get('catalogos', {}),
            salida=SalidaArchivo(
                nombre_csv=datos.get('nombre_csv'),
                comprimir=bool(datos.get('comprimir', True)),
                publicar=bool(datos.get('publicar', True)),
            ),
        )
