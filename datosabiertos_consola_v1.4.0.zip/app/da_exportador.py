# -*- coding: utf-8 -*-
"""
Motor de exportacion masiva Oracle -> CSV -> ZIP -> Servidores publicos.

app-daexportador.py

Flujo completo:
  Oracle (Wallet) -> Spark Connect -> CSV -> ZIP
  -> destino_local/ -> SFTP Quito + Guayaquil -> Correo

Modos CLI:
  exportador                  Menu interactivo
  exportador <ID>             Confirmacion antes de ejecutar
  exportador -d <ID>          Directo sin menu (cron)
  exportador --listar         Lista de consultas disponibles
  exportador verificar        Verifica archivos en servidores remotos
  exportador verificar -a ANIO Verifica archivos de un año especifico

Historial:
+--------------------+---------+------------------------------------------+
| Autor              | Version | Cambios                                  |
+--------------------+---------+------------------------------------------+
| Jim A. González    | 1.0.0   | Version grafica REACT + FastAPI          |
| Jim A. González    | 1.0.1   | Version consola Spark + Oracle Wallet    |
| Jim A. González    | 1.1.0   | Verificar remoto, modo directo, periodos |
|                    |         | SFTP, config sin valores duros           |
| Jim A. González    | 1.2.0   | Fix estado correo, skip_sftp dev,        |
|                    |         | timeout SMTP configurable                |
| Jim A. González    | 1.3.0   | Paridad con proceso manual: CSV sin ZIP, |
|                    |         | nombre CSV interno, decimales, sin       |
|                    |         | recorte, una lectura Oracle, control vs  |
|                    |         | vigente, historico, sesion Spark comun   |
+--------------------+---------+------------------------------------------+
"""

from datetime import datetime
import json
import logging
from pathlib import Path
import re
import shutil
from typing import Any, Dict, List, Optional, Tuple
import zipfile

import paramiko
from pyspark.sql import functions as fn
from pyspark.sql import SparkSession

from app.da_comunes import cargar_clave_privada
from app.da_config_manager import get_config_manager
from app.da_control_publicacion import ControlPublicacion, contar_filas_archivo
from app.da_dataframe import ContextoProceso, normalizar_decimales, ProcesadorDataFrame
from app.da_excepciones import TrazabilidadExcepciones
from app.da_modelos import ConsultaDefinicion
from app.da_notificacion import NotificadorEmail
from app.da_sesion_spark import crear_sesion_spark, opciones_jdbc
from app.da_validador import ValidadorConectividad

VERSION = '1.4.0'
_BYTES_EN_MB = 1024 * 1024
_MSG_ERROR_SFTP = 'ERROR SFTP: %s'

# NOTA: no usar logging.basicConfig() aqui. El logger raiz 'app' se
# configura una sola vez en main._crear_logger(); un basicConfig a nivel
# de modulo agregaba un segundo handler y duplicaba cada linea en consola.


class ExportadorDatosAbiertos:
    """
    Exportador principal. Toda la configuracion viene del TOML.

    Sin rutas ni valores quemados en el codigo Python (Regla 2 SRI).
    """

    def __init__(self, ruta_config: Optional[str], logger: logging.Logger):
        """
        Inicializa el exportador cargando la configuracion del TOML.

        Args:
            ruta_config: Ruta explicita al TOML. Si es None, se detecta
                         automaticamente (configlnx.toml en Linux,
                         configwin.toml en Windows).
            logger: Logger compartido inyectado desde el punto de entrada.
        """
        self._logger = logger
        self._gestor_config = get_config_manager(ruta_config, logger)
        self._config_base = {
            'spark':           self._gestor_config.get_spark_config(),
            'email':           self._gestor_config.get_email_config(),
            'rutas':           self._gestor_config.get_rutas(),
            'destino_default': self._gestor_config.get_destino_default(),
        }
        self._spark: Optional[SparkSession] = None
        self._validador = ValidadorConectividad(self._config_base, logger)
        self._control = ControlPublicacion(logger)

    def _log(self, level: int, msg: str, *args: object, exc_info: bool = False) -> None:
        """Registra un mensaje con formato lazy % para compatibilidad con Pylint."""
        self._logger.log(level, msg, *args, exc_info=exc_info)

    # -- Helpers ---------------------------------------------------------

    @staticmethod
    def _es_ruta_valida(valor: str) -> bool:
        """Retorna True si el valor parece una ruta de archivo."""
        return bool(valor) and ('/' in valor or '\\' in valor or ':' in valor)

    def _resolver_ruta_wallet(self, referencia: str) -> Optional[Path]:
        """
        Valida que la ruta de wallet declarada en el TOML exista en disco.

        La ruta SIEMPRE debe estar declarada completa en spark.wallet_path
        del TOML. No se busca en variables de entorno ni en rutas por defecto
        del sistema operativo (Regla 2 SRI — sin valores quemados en codigo).

        Args:
            referencia: Ruta completa al directorio del wallet (del TOML).

        Returns:
            Path si existe, None si no existe (se logueara el error).
        """
        if not referencia:
            return None
        ruta = Path(referencia)
        if ruta.exists():
            return ruta
        self._log(
            logging.ERROR,
            'Wallet no encontrado en la ruta declarada en el TOML: %s. '
            'Verificar spark.wallet_path en %s',
            referencia, 'configlnx.toml / configwin.toml'
        )
        return None

    # -- Carga de consultas ----------------------------------------------

    def cargar_consultas(self) -> List[ConsultaDefinicion]:
        """
        Carga todas las consultas desde archivos JSON del directorio configurado.

        Returns:
            Lista de ConsultaDefinicion cargadas.
        """
        directorio = self._config_base['rutas']['consultas']
        self._log(logging.INFO, 'Cargando consultas desde: %s', directorio)

        if not directorio.exists():
            self._log(logging.ERROR, 'No existe carpeta de consultas: %s', directorio)
            return []

        consultas: List[ConsultaDefinicion] = []
        for archivo_json in sorted(directorio.glob('*.json')):
            try:
                with open(archivo_json, 'r', encoding='utf-8') as archivo:
                    datos = json.load(archivo)
                if isinstance(datos, list):
                    for item in datos:
                        consultas.append(ConsultaDefinicion.desde_dict(item))
                else:
                    consultas.append(ConsultaDefinicion.desde_dict(datos))
            except (ValueError, KeyError, OSError):
                self._log(logging.ERROR, 'Error cargando %s', archivo_json.name, exc_info=True)

        return consultas

    def encontrar_consulta(self, consulta_id: str) -> Optional[ConsultaDefinicion]:
        """
        Busca una consulta por ID exacto.

        Args:
            consulta_id: Identificador de la consulta.

        Returns:
            ConsultaDefinicion o None si no se encontro.
        """
        for consulta in self.cargar_consultas():
            if consulta.id_ == consulta_id:
                return consulta
        return None

    def listar_consultas(self) -> List[Tuple[str, str]]:
        """Retorna lista de (id, nombre) de consultas disponibles."""
        return [(consulta.id_, consulta.nombre) for consulta in self.cargar_consultas()]

    # -- Fusion de configuracion -----------------------------------------

    def fusionar_config(self, consulta: ConsultaDefinicion) -> Dict[str, Any]:
        """
        Fusiona la configuracion base con sobreescrituras de la consulta.

        Precedencia: JSON consulta > config.toml > valores por defecto.

        Args:
            consulta: Consulta con posibles sobreescrituras de configuracion.

        Returns:
            Configuracion completa fusionada.
        """
        config = {
            'spark':   self._config_base['spark'].copy(),
            'email':   self._config_base['email'].copy(),
            'rutas':   self._config_base['rutas'].copy(),
            'destino': self._config_base['destino_default'].copy(),
        }

        if consulta.spark_url:
            config['spark']['spark_url'] = consulta.spark_url

        if consulta.wallet and self._es_ruta_valida(consulta.wallet):
            ruta = self._resolver_ruta_wallet(consulta.wallet)
            if ruta:
                config['spark']['wallet_path'] = str(ruta)

        if consulta.jdbc_url:
            config['spark']['jdbc_url'] = consulta.jdbc_url

        if consulta.config_email:
            config['email'].update(consulta.config_email)

        if consulta.destino:
            config['destino'].update(consulta.destino)

        if config['destino'].get('tipo', 'local').lower() == 'local':
            config['destino']['directorio_remoto'] = str(config['rutas']['destino_local'])

        return config

    # -- Resolucion de parametros de periodo -----------------------------

    @staticmethod
    def _resolver_periodo(consulta: ConsultaDefinicion) -> Tuple[int, int, int]:
        """
        Resuelve el periodo (anio, mes_ini, mes_fin) de una consulta.

        Punto UNICO de verdad para el periodo: lo usan tanto el SQL como
        el nombre del ZIP. Antes procesar_consulta calculaba el anio por
        su cuenta sin la correccion de enero, y una corrida del 1 de enero
        generaba SQL del anio anterior pero un ZIP nombrado con el anio
        nuevo (y 'verificar' buscaba el anio equivocado).

        Por defecto: anio actual, acumulado enero..mes anterior (SDC SRI).
        En enero (sin overrides) el periodo es enero..diciembre del anio
        anterior.

        Args:
            consulta: Consulta con posibles overrides anio/mes_ini/mes_fin.

        Returns:
            Tupla (anio, mes_ini, mes_fin).
        """
        ahora = datetime.now()
        anio = consulta.anio or ahora.year
        mes_fin = consulta.mes_fin or (ahora.month - 1 if ahora.month > 1 else 12)
        mes_ini = consulta.mes_ini or 1

        if consulta.anio is None and consulta.mes_fin is None and ahora.month == 1:
            anio = ahora.year - 1

        return anio, mes_ini, mes_fin

    def _resolver_sql_con_periodo(self, sql: str, consulta: ConsultaDefinicion) -> str:
        """
        Inyecta :ANIO, :MES_INI, :MES_FIN en el SQL con valores reales.

        Args:
            sql: Consulta SQL con marcadores de posicion.
            consulta: Consulta con posibles valores de periodo.

        Returns:
            SQL con los marcadores reemplazados.
        """
        anio, mes_ini, mes_fin = self._resolver_periodo(consulta)

        reemplazos = (
            (':MES_INI', str(mes_ini)),
            (':MES_FIN', str(mes_fin)),
            (':ANIO', str(anio)),
        )

        sql_resuelto = sql.strip().rstrip(';')
        for marcador, valor in reemplazos:
            sql_resuelto = re.sub(
                re.escape(marcador) + r'\b', valor, sql_resuelto, flags=re.IGNORECASE
            )

        self._log(logging.INFO, 'Periodo SQL: anio=%s mes_ini=%s mes_fin=%s', anio, mes_ini, mes_fin)
        return sql_resuelto

    def sql_para_ejecucion(self, consulta: ConsultaDefinicion) -> str:
        """Retorna el SQL de la consulta con el periodo resuelto, listo para Oracle."""
        return self._resolver_sql_con_periodo(consulta.sql, consulta)

    def _ejecutar_transferencia_sftp(self, ruta_final: Path, nombre_remoto: str) -> Tuple[bool, List[Dict[str, Any]]]:
        """
        Ejecuta la subida SFTP a los servidores, salvo en modo desarrollo.

        Args:
            ruta_final: Ruta del archivo final (ZIP o CSV) en destino_local.
            nombre_remoto: Nombre del archivo remoto.

        Returns:
            Tupla (exito_global, resultados_por_servidor).
        """
        skip_sftp = self._gestor_config.get('general', {}).get('skip_sftp', False)
        if skip_sftp:
            self._log(logging.INFO, 'Modo desarrollo: omitiendo transferencia SFTP (skip_sftp=true)')
            return True, []

        servidores = self._gestor_config.get_servidores_descarga()
        resultados = [
            self._copiar_a_servidor(ruta_final, srv, nombre_remoto)
            for srv in servidores
        ]
        exito = all(res['exito'] for res in resultados)
        return exito, resultados

    def _generar_archivo_final(self, consulta: ConsultaDefinicion, rutas: Dict[str, Path], nombres: Dict[str, str]) -> None:
        """
        Controla el conteo, archiva la version vigente y deja el archivo final.

        Args:
            consulta: Definicion de la consulta.
            rutas: Diccionario con csv_tmp, zip_tmp y final.
            nombres: Diccionario con 'publicado' y 'csv'.

        Raises:
            ValueError: Si el conteo no es coherente con la version vigente.
        """
        total = contar_filas_archivo(rutas['csv_tmp'])
        self._control.validar_contra_vigente(rutas['final'], total, consulta.id_)
        self._control.archivar_vigente(rutas['final'])
        if consulta.salida.comprimir:
            self._comprimir_csv(rutas['csv_tmp'], rutas['zip_tmp'], nombres['csv'])
            shutil.copy2(rutas['zip_tmp'], rutas['final'])
        else:
            shutil.copy2(rutas['csv_tmp'], rutas['final'])
        self._log(logging.INFO, 'Copiado a destino_local: %s', rutas['final'])

    def _ejecutar_flujo_exportacion(
        self, consulta: ConsultaDefinicion, config: Dict[str, Any], rutas: Dict[str, Path], nombres: Dict[str, str]
    ) -> bool:
        """
        Ejecuta exportacion Spark, control, empaquetado, SFTP y notificacion.

        Args:
            consulta: Definicion de la consulta.
            config: Configuracion fusionada.
            rutas: Diccionario con csv_tmp, zip_tmp y final.
            nombres: Diccionario con 'publicado' y 'csv'.

        Returns:
            True si el flujo fue exitoso.
        """
        sql_resuelto = self._resolver_sql_con_periodo(consulta.sql, consulta)
        inicio = datetime.now()
        try:
            total = self._exportar_con_spark(config=config, sql=sql_resuelto, ruta_salida=str(rutas['csv_tmp']), consulta=consulta)
            secs = (datetime.now() - inicio).total_seconds()
            self._generar_archivo_final(consulta, rutas, nombres)
        finally:
            rutas['csv_tmp'].unlink(missing_ok=True)
            rutas['zip_tmp'].unlink(missing_ok=True)

        if consulta.salida.publicar:
            exito, resultados_sftp = self._ejecutar_transferencia_sftp(rutas['final'], nombres['publicado'])
        else:
            self._log(logging.INFO, 'publicar=false: archivo generado solo en destino_local')
            exito, resultados_sftp = True, []

        tamanio = rutas['final'].stat().st_size
        self._notificar(
            consulta_id=consulta.id_,
            exito=exito,
            resultado={
                'exito':           exito,
                'tipo':            'sftp' if consulta.salida.publicar else 'local',
                'nombre_zip':      nombres['publicado'],
                'archivo_destino': nombres['publicado'],
                'ruta_destino':    str(rutas['final']),
                'tamanio_bytes':   tamanio,
                'tamanio_mb':      round(tamanio / _BYTES_EN_MB, 2),
                'mensaje':         'OK en todos los servidores' if exito else 'Fallo en algun servidor',
                'servidores':      resultados_sftp,
            },
            detalles_spark={
                'total_registros': total,
                'tiempo_lectura':  secs,
                'tiempo_total':    secs,
                'velocidad':       total / secs if secs > 0 else 0,
            },
            config=config,
        )

        if exito:
            self._log(logging.INFO, 'Consulta %s -> EXITO', consulta.id_)
        else:
            self._log(logging.ERROR, 'Consulta %s -> CON ERRORES (revisar SFTP o notificacion)', consulta.id_)
        return exito

    @staticmethod
    def nombres_salida(consulta: ConsultaDefinicion, anio: int) -> Dict[str, str]:
        """
        Calcula el nombre del archivo publicado y el del CSV.

        Ejemplos (anio 2026):
          FACTURACION_FISICA + nombre_csv SRI_autorizaciones_fisicas
            -> FACTURACION_FISICA_2026.zip con SRI_autorizaciones_fisicas_2026.csv
          SRI_Vehiculos_Nuevos + comprimir false
            -> SRI_Vehiculos_Nuevos_2026.csv

        Args:
            consulta: Definicion de la consulta.
            anio: Anio de los datos (mismo del periodo SQL).

        Returns:
            Diccionario con 'publicado' y 'csv'.
        """
        base = consulta.nombre_archivo.rstrip('_')
        nombre_csv = f'{(consulta.salida.nombre_csv or base).rstrip("_")}_{anio}.csv'
        publicado = f'{base}_{anio}.zip' if consulta.salida.comprimir else nombre_csv
        return {'publicado': publicado, 'csv': nombre_csv}

    def procesar_consulta(self, consulta: ConsultaDefinicion) -> bool:
        """
        Ejecuta el flujo completo: Oracle -> Spark -> ZIP -> SFTP -> correo.

        En modo desarrollo (skip_sftp=true en TOML) omite la subida a servidores
        y el proceso se considera exitoso si Spark + ZIP funcionan.

        Args:
            consulta: Definicion de la consulta a procesar.

        Returns:
            True si el flujo completo (o parcial en dev) fue exitoso.
        """
        self._log(logging.INFO, '\n%s', '=' * 65)
        self._log(logging.INFO, 'Procesando: %s  [%s]  %s', consulta.nombre, consulta.id_, VERSION)
        self._log(logging.INFO, '%s', '=' * 65)

        config = self.fusionar_config(consulta)
        puede_proceder, errores, advertencias = self._validador.validar_todo(
            consulta, destino=config['destino']
        )

        if not puede_proceder:
            for err in errores:
                self._log(logging.ERROR, '   ERROR: %s', err)
            return False

        for adv in advertencias:
            self._log(logging.WARNING, '   ADVERTENCIA: %s', adv)

        anio_datos, _, _ = self._resolver_periodo(consulta)
        nombres = self.nombres_salida(consulta, anio_datos)
        marca = datetime.now().strftime('%Y%m%d_%H%M%S')
        dir_temp = config['rutas']['temp']
        rutas = {
            'csv_tmp': dir_temp / f'{Path(nombres["csv"]).stem}_{marca}.csv',
            'zip_tmp': dir_temp / f'{Path(nombres["publicado"]).stem}_{marca}.zip',
            'final':   config['rutas']['destino_local'] / nombres['publicado'],
        }

        try:
            return self._ejecutar_flujo_exportacion(consulta, config, rutas, nombres)
        except TrazabilidadExcepciones.ALL_NON_CRITICAL as exc:
            self._log(logging.ERROR, 'Error en %s', consulta.id_, exc_info=True)
            self._notificar(consulta_id=consulta.id_, exito=False, error=str(exc), config=config,)
            return False

    def _exportar_con_spark(self, config: Dict[str, Any], sql: str, ruta_salida: str, consulta: ConsultaDefinicion) -> int:
        """
        Exporta datos Oracle a CSV usando Spark con una sola lectura.

        El conteo se toma del CSV escrito para no ejecutar la consulta dos
        veces en Oracle. Los NUMBER sin precision se escriben sin ceros
        decimales y no se recortan espacios (igual que la exportacion manual).

        Args:
            config: Configuracion completa del sistema.
            sql: Consulta SQL ya resuelta.
            ruta_salida: Ruta del CSV de salida.
            consulta: Definicion de la consulta.

        Returns:
            Numero de registros exportados.

        Raises:
            ValueError: Si la consulta no devuelve filas.
        """
        cfg = config['spark']
        tns_admin = cfg.get('network_admin') or cfg['wallet_path']
        self._log(logging.INFO, 'Spark: %s | Wallet: %s | TNS: %s', cfg['spark_url'], cfg['wallet_path'], tns_admin)
        self._spark = crear_sesion_spark(cfg['spark_url'])

        try:
            opts = opciones_jdbc(cfg['jdbc_url'], cfg['wallet_path'], tns_admin, cfg.get('fetch_size', 500000))
            lector = self._spark.read.format('jdbc').options(**opts)
            if consulta.columna_particion:
                lector = self._aplicar_particionamiento(lector, opts, sql, consulta.columna_particion, consulta.num_particiones)

            df = lector.option('query', sql).load()
            df = normalizar_decimales(self._aplicar_proceso_dataframe(df, consulta, opts), self._logger)
            dir_tmp = Path(ruta_salida).parent / f'spark_tmp_{datetime.now().strftime("%Y%m%d%H%M%S")}'
            (
                df.write
                .option('delimiter', consulta.delimitador)
                .option('header', 'true')
                .option('encoding', 'UTF-8')
                .option('quote', '"')
                .option('escape', '"')
                .option('nullValue', '')
                .option('lineSep', '\n')
                .option('ignoreLeadingWhiteSpace', 'false')
                .option('ignoreTrailingWhiteSpace', 'false')
                .mode('overwrite')
                .csv(str(dir_tmp))
            )
            self._combinar_particiones(dir_tmp, Path(ruta_salida), consulta.delimitador)
        finally:
            self._spark.stop()
            self._spark = None

        total = contar_filas_archivo(Path(ruta_salida))
        self._log(logging.INFO, 'Registros: %s', f'{total:,}')
        if total == 0:
            raise ValueError(
                'La consulta no devolvio filas para el periodo solicitado. '
                'No se publica archivo para no sobrescribir el dataset vigente.'
            )
        return total

    def _aplicar_proceso_dataframe(self, df: Any, consulta: Optional[ConsultaDefinicion], opts: Dict[str, str]) -> Any:
        """
        Aplica las transformaciones de negocio declaradas en el JSON.

        Unico punto de acoplamiento con da_dataframe: si la consulta no
        declara 'proceso', 'columnas' ni 'orden', retorna el DataFrame
        SIN CAMBIOS (comportamiento historico de las historias 1 a 3).

        Args:
            df: DataFrame Spark leido desde Oracle.
            consulta: Definicion de la consulta (puede ser None).
            opts: Opciones JDBC en uso (para leer catalogos auxiliares).

        Returns:
            DataFrame transformado o el original.
        """
        if consulta is None or not (consulta.proceso or consulta.columnas or consulta.orden):
            return df

        contexto = ContextoProceso(spark=self._spark, jdbc_opts=opts, consulta=consulta, logger=self._logger, )
        return ProcesadorDataFrame(self._logger).aplicar(df, contexto)

    def _aplicar_particionamiento(
        self,
        lector: Any,
        opts: Dict[str, str],
        sql: str,
        columna: str,
        num_particiones: int
    ) -> Any:
        """
        Configura el particionamiento por rango en el lector Spark.

        Args:
            lector: DataFrame reader de Spark.
            opts: Opciones JDBC base.
            sql: Consulta SQL original.
            columna: Columna para particionamiento.
            num_particiones: Numero de particiones.

        Returns:
            Lector Spark configurado con particionamiento.
        """
        self._log(logging.INFO, 'Calculando rangos para columna: %s', columna)
        fila = (
            self._spark.read.format('jdbc').options(**opts)
            .option('pushDownAggregate', 'true')
            .option('query', sql).load()
            .agg(fn.min(columna).alias('vmin'), fn.max(columna).alias('vmax'))
            .collect()[0]
        )
        self._log(logging.INFO, 'Rango: %s - %s (%s particiones)', fila['vmin'], fila['vmax'], num_particiones)

        return (
            lector
            .option('partitionColumn', columna)
            .option('lowerBound', str(fila['vmin']))
            .option('upperBound', str(fila['vmax']))
            .option('numPartitions', str(num_particiones))
        )

    @staticmethod
    def _combinar_particiones(dir_temp: Path, archivo_salida: Path, delimitador: str = '|') -> None:
        """Combina los part-*.csv de Spark en un unico CSV con una sola cabecera.

        Verifica que el delimitador sea el correcto (PIPE según SDC).
        Args:
            dir_temp: Directorio temporal con archivos part-*.csv.
            archivo_salida: Archivo CSV de salida consolidado.
            delimitador: Caracter separador esperado (default: '|' según SDC).
        """
        archivos = sorted(dir_temp.glob('part-*.csv'))
        if not archivos:
            raise FileNotFoundError(f'Sin archivos CSV en {dir_temp}')

        with open(archivos[0], 'r', encoding='utf-8') as verificacion:
            primera_linea = verificacion.readline().rstrip('\n')
        parece_multicolumna = (' ' in primera_linea.strip()) or (',' in primera_linea)
        if delimitador not in primera_linea and parece_multicolumna:
            raise ValueError(
                f'DELIMITADOR INCORRECTO: esperado "{delimitador}", '
                f'pero la cabecera es: {primera_linea[:100]}'
            )

        buffer = 1024 * 1024
        with open(archivo_salida, 'wb') as salida:
            with open(archivos[0], 'rb') as primer_archivo:
                shutil.copyfileobj(primer_archivo, salida, buffer)
            for archivo in archivos[1:]:
                with open(archivo, 'rb') as parte:
                    parte.readline()
                    shutil.copyfileobj(parte, salida, buffer)

        shutil.rmtree(dir_temp)

    # -- Compresion ------------------------------------------------------

    def _comprimir_csv(self, ruta_csv: Path, ruta_zip: Path, nombre_interno: Optional[str] = None) -> None:
        """
        Comprime un CSV a ZIP con compresion maxima.

        Args:
            ruta_csv: Ruta al archivo CSV de origen.
            ruta_zip: Ruta al ZIP de destino.
            nombre_interno: Nombre del archivo DENTRO del ZIP. El SDC exige
                            conservar el nombre de origen (sin el timestamp
                            interno del temporal), ej. 'Comprobantes_CEL_2026.csv'.
        """
        arcname = nombre_interno or ruta_csv.name
        self._log(logging.INFO, 'Comprimiendo %s -> %s...', ruta_csv.name, arcname)
        with zipfile.ZipFile(ruta_zip, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
            zf.write(ruta_csv, arcname)
        self._log(logging.INFO, 'ZIP: %.2f MB', ruta_zip.stat().st_size / _BYTES_EN_MB)

    # -- Copia SFTP a servidor -------------------------------------------

    def _copiar_a_servidor(self, archivo_local: Path, servidor: Dict[str, Any], nombre_remoto: str) -> Dict[str, Any]:
        """
        Sube un archivo al servidor de descarga via SFTP.

        Toda la configuracion viene del TOML (Regla 2 SRI).

        Args: archivo_local: Archivo ZIP local a subir.
            servidor: Configuracion del servidor destino.
            nombre_remoto: Nombre del archivo en el servidor.

        Returns: Diccionario con servidor, ip, exito y mensaje.
        """
        ip = servidor['ip']
        nombre = servidor['nombre']
        password = servidor.get('password', '')
        key_file = servidor.get('key_file', '')
        ruta_remota = servidor['ruta_remota']

        resultado: Dict[str, Any] = {'servidor': nombre, 'ip': ip, 'exito': False, 'mensaje': ''}

        transporte = None
        sftp = None
        try:
            transporte = paramiko.Transport((ip, servidor.get('puerto', 22)))
            transporte.banner_timeout = 15
            transporte.auth_timeout = 15
            if key_file and Path(key_file).exists():
                transporte.connect(username=servidor['usuario'], pkey=cargar_clave_privada(key_file, password))
            elif password:
                transporte.connect(username=servidor['usuario'], password=password)
            else:
                raise ValueError(f'Sin credenciales para {nombre} ({ip}): configura key_file o password en el TOML')

            sftp = paramiko.SFTPClient.from_transport(transporte)
            destino = f'{ruta_remota}/{nombre_remoto}'
            temporal = f'{destino}.subiendo'

            sftp.put(str(archivo_local), temporal)
            try:
                sftp.posix_rename(temporal, destino)
            except (IOError, OSError):
                try:
                    sftp.remove(destino)
                except IOError:
                    pass
                sftp.rename(temporal, destino)

            resultado['exito'] = True
            resultado['mensaje'] = f'Copiado a {nombre} ({ip}): {destino} ({round((sftp.stat(destino).st_size or 0) / 1024, 2)} KB)'
            self._log(logging.INFO, 'SFTP exitoso: %s', resultado['mensaje'])

        except paramiko.AuthenticationException:
            resultado['mensaje'] = f'Autenticacion SSH fallida en {nombre} ({ip})'
            self._log(logging.ERROR, _MSG_ERROR_SFTP, resultado['mensaje'])
        except OSError as exc:
            resultado['mensaje'] = f'Error red {nombre} ({ip}): {exc}'
            self._log(logging.ERROR, _MSG_ERROR_SFTP, resultado['mensaje'])
        except ValueError as exc:
            resultado['mensaje'] = str(exc)
            self._log(logging.ERROR, _MSG_ERROR_SFTP, resultado['mensaje'])
        finally:
            if sftp is not None:
                sftp.close()
            if transporte is not None:
                transporte.close()

        return resultado

    def _notificar(
        self,
        consulta_id: str,
        exito: bool,
        config: Dict[str, Any],
        resultado: Optional[Dict[str, Any]] = None,
        detalles_spark: Optional[Dict[str, Any]] = None,
        error: Optional[str] = None
    ) -> None:
        """
        Envia correo y guarda notificacion local.

        Args:
            consulta_id: ID de la consulta ejecutada.
            exito: True si el proceso fue exitoso.
            config: Configuracion completa del sistema.
            resultado: Resultado de la transferencia.
            detalles_spark: Metricas de Spark.
            error: Mensaje de error si aplica.
        """
        cfg_email = config.get('email', {})
        correo_ok = False

        if cfg_email.get('smtp_server'):
            try:
                correo_ok = NotificadorEmail(cfg_email, self._logger).enviar_notificacion(
                    asunto='COMPLETADO' if exito else 'ERROR',
                    consulta_id=consulta_id,
                    resultado_transferencia=resultado or {},
                    detalles_spark=detalles_spark,
                    error=error,
                )
                if correo_ok:
                    self._log(logging.INFO, 'Correo enviado')
                else:
                    self._log(logging.WARNING, 'Correo no enviado (fallo SMTP, revisar logs anteriores)')
            except TrazabilidadExcepciones.ALL_NON_CRITICAL as exc:
                self._log(logging.WARNING, 'Correo no enviado: %s', exc)

        self._guardar_notificacion_local(
            consulta_id=consulta_id,
            exito=exito,
            resultado=resultado,
            detalles_spark=detalles_spark,
            error=error,
            correo_enviado=correo_ok,
            config=config,
        )

    def _guardar_notificacion_local(
        self,
        consulta_id: str,
        exito: bool,
        config: Dict[str, Any],
        resultado: Optional[Dict[str, Any]] = None,
        detalles_spark: Optional[Dict[str, Any]] = None,
        error: Optional[str] = None,
        correo_enviado: bool = False
    ) -> None:
        """
        Guarda la notificacion como archivo de texto en disco.

        Args:
            consulta_id: ID de la consulta.
            exito: Estado del proceso.
            config: Configuracion completa.
            resultado: Resultado de la transferencia.
            detalles_spark: Metricas de Spark.
            error: Mensaje de error si aplica.
            correo_enviado: True si el correo fue enviado.
        """
        dir_mails = config['rutas']['mails']
        dir_mails.mkdir(parents=True, exist_ok=True)

        marca = datetime.now().strftime('%Y%m%d_%H%M%S')
        estado = 'OK' if exito else 'ERROR'
        ruta = dir_mails / (f'{marca}_{consulta_id}_{estado}.txt')

        fecha_actual = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        estado_correo = 'Enviado' if correo_enviado else 'No enviado (guardado localmente)'
        estado_exito = 'EXITO' if exito else 'ERROR'
        lineas = [
            'NOTIFICACION DE EXPORTACION',
            '=' * 55,
            f'Fecha    : {fecha_actual}',
            f'Consulta : {consulta_id}',
            f'Version  : {VERSION}',
            f'Estado   : {estado_exito}',
            f'Correo   : {estado_correo}',
            '',
        ]

        if error:
            lineas += ['ERROR:', error, '']

        if resultado:
            archivo_destino = resultado.get('archivo_destino', 'N/A')
            tamanio_mb = resultado.get('tamanio_mb', 0)
            mensaje_resultado = resultado.get('mensaje', 'N/A')
            lineas += [
                'TRANSFERENCIA:',
                f'  Archivo : {archivo_destino}',
                f'  Tamano : {tamanio_mb} MB',
                f'  Mensaje : {mensaje_resultado}',
                '',
            ]
            for srv in resultado.get('servidores', []):
                icono = 'OK' if srv.get('exito') else 'ERROR'
                srv_nombre = srv['servidor']
                srv_ip = srv['ip']
                srv_mensaje = srv['mensaje']
                lineas.append(f'  {icono} {srv_nombre} ({srv_ip}): {srv_mensaje}')
            if resultado.get('servidores'):
                lineas.append('')

        if detalles_spark:
            lineas += [
                'SPARK:',
                f'  Registros : {detalles_spark.get("total_registros", 0):,}',
                f'  Tiempo    : {detalles_spark.get("tiempo_total", 0):.2f}s',
                f'  Velocidad : {detalles_spark.get("velocidad", 0):,.0f} reg/s',
                '',
            ]

        lineas += ['=' * 55, f'Exportador SRI v{VERSION} — generado automaticamente']
        ruta.write_text('\n'.join(lineas), encoding='utf-8')
        self._log(logging.INFO, 'Notificacion guardada: %s', ruta)
