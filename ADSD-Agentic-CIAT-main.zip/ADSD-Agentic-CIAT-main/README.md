# ADSD (Anomaly Detection for Structured Data)

## Introduction

ADSD (Anomaly Detection for Structured Data) has been designed and built to leverage the latest AI/ML to provide automated detection of anomalies in government transaction data. The ADSD capabilities can be applied to any transaction data or equivalent document for B2B transactions, collected by a Government administration by using a predefined data schema.

ADSD builds on the expert knowledge of business representatives from Public Finance and Customs Agencies represented by the Interamerican Center of Customs Administrations - CIAT. ADSD is provided to customers and to partners as a Microsoft Industry Accelerator at no charge to accelerate their “time to value” on Azure.

These capabilities can be applicable to Industry Use Cases like:

- Reduce data processing complexity for analytics to detect anomalies quickly and solve problems faster.
- Measure transaction data quality with a rapid transaction data analysis that helps agencies identify policy gaps in collecting transaction data documents.
- Detect transaction data anomalies in the Customs agency's interest to identify issuing errors requiring  correction, detect unexpected issuing patterns, or detect issuing operations requiring further investigation for potential incorrect conduct.
- Provide an anomaly index and score to increase productivity and intelligence of the Customs agency investigation department.

ADSD provides these key capabilities:

- Standardized transaction data schemas. PII data not supported.
- Tooling to facilitate transformation of your domain data schema **to** standardized transaction data schema, and **back**
- Data Quality Index to assess the quality of ingested data
- Fully automated Unsupervised ML Pipeline designed for transaction data
- More than 50 features engineered from risk transaction patterns
- Ability to create or shipped with example dashboards to show how data can be interpreted
- Anomaly detection Index to facilitate prioritization of detected anomalies
- Interpretation of features that influence the anomaly index
- Embedded interactive tool to do a deep analysis of  data

## Responsible AI

The ADSD Accelerator and Microsoft are committed to the advancement of AI driven by ethical principles that put people first. Read our [Transparency Note](./docs/transparency.md)

Find out more with Microsoft's [Responsible AI resources](https://www.microsoft.com/en-us/ai/responsible-ai)

## Data Collection Notice

The software may collect information about you and your use of the software and send it to Microsoft. Microsoft may use this information to provide services and improve our products and services. You may turn off the telemetry as described in the repository. There are also some features in the software that may enable you and Microsoft to collect data from users of your applications. If you use these features, you must comply with applicable law, including providing appropriate notices to users of your applications together with a copy of Microsoft’s privacy statement. Our privacy statement is located at <https://go.microsoft.com/fwlink/?LinkID=824704>. You can learn more about data collection and use in the help documentation and our privacy statement. Your use of the software operates as your consent to these practices.

### About Data Collection

Data collection by the software in this repository is used by Microsoft solely to help justify the efforts of the teams who build and maintain this accelerator for our customers. It is your choice to leave this enabled, or to disable data collection.

Data collection is implemented by the presence of a tracking GUID in the environment variables at deployment time. The GUID is associated with each Azure resource deployed by the installation scripts. This GUID is used by Microsoft to track the Azure consumption this open source solution generates.


## High Level Architecture

![High level Architecture](/images/architecture.drawio.png)

## ADSD Workflow

![ADSD Workflow](/images/workflow.png)

ADSD is composed of Microsoft components and Open-Source Software (OSS) and is provided to customers and partners at no charge.  

The components of this accelerator include:

- Custom configuration code
- Deployment kit
- Cost calculator
- Documentation

This accelerator is designed to accelerate the “time to value” in using the Microsoft components. As an accelerator, is it not for sale, nor is it a supported product.  

A full set of features can be explored on our [Features](docs/features/features.md) page.

## Getting Started

### Pre-requisites

ADSD requires a variety of services across Azure. There are a few prerequisites required to deploy and configure ADSD. Please obtain these items first before continuing on to the deployment section of this guide.

>To get started with ADSD you will need the following:
>
>- An active Azure Subscription
>- Administrative rights on the Azure Subscription
>- Microsoft Fabric Workspace

You can sign up for an Azure subscription [here](https://azure.microsoft.com/en-us/free/).

Once you have your prerequisite items, please move on to the Cost Estimation step.



## Deployment Overview

There are a few steps to deploying ADSD. The following checklist will guide you through configuring ADSD in your environment. Please follow the steps in the order they are provided as values from one step may be used in subsequent steps.

>1. Configure Local Development Environment and Azure Resources
>       - [Deploying ADSD](docs/deployment/deployment.md)
>3. Run a functional test
>       - [Run Functional Test](test_data/readme.md)
>4. Configure Power BI
>       - [Deploy Power BI Report](powerbi/POWERBI.md)

Once all these steps are completed, ADSD is ready to be used. Please move on to the Using ADSD for the first time section.

## Using ADSD for the first time

Now that you have successfully deployed ADSD, you are ready to use the accelerator to process some data.

To run the ADSD Accelerator, you need to follow these steps:

> 1. Prepare your data and upload it to Azure.
>       - Generic government anomaly detection. Your data must be in a specified format to be valid for processing. See our [input data schema specification](/docs/inputdataschema.md).
>       - CUSTOMS anomaly detection. Your data must be in a specified format to be valid for processing. See our [input data schema specification](docs/inputdataschemacustoms.md).
>       - Upload your data into the input container using the [data upload specification](/docs/datauploadspec.md).
> 2. Once uploaded you can then run the Azure Synapse Pipeline to process your data.
>       - Next you need to [tune the hyperparameters](/docs/hyperparameters.md) for your data
>       - Finally, follow our [Running your first batch](/docs/runningfirstbatch.md) guide.

For more detailed information review the [Features](docs%2Ffeatures%2Ffeatures.md) section of ADSD.

## Navigating the Source Code

This project has the following structure:

Folder/File | Description
--- | ---
docs/ | General Documentation for the Accelerator
powerbi/ | The Power BI files used in the deployment
test_data/ | Functional and Performance tests and framework

## Documentation

The `docs/` folder contains detailed documentation that supports the deployment, configuration, and validation of the ADSD Accelerator. 

| Document | Description | Link |
|---------|-------------|------|
| deployment.md | Step-by-step guide to deploy the ADSD Accelerator in Microsoft Fabric, including GitHub integration and workspace setup | [deployment.md](docs/deployment.md) |
| costestimator.md | Cost estimation guidelines for running ADSD in Microsoft Fabric, including capacity sizing and licensing | [costestimator.md](docs/costestimator.md) |
| datauploadspec.md | Instructions and specifications for uploading test data into the Lakehouse structure | [datauploadspec.md](docs/datauploadspec.md) |
| hyperparameters.md | Description and configuration of hyperparameters used in the ADSD pipelines and models | [hyperparameters.md](docs/hyperparameters.md) |
| inputdataschema.md | Definition of the expected input data schema for standard ADSD processing | [inputdataschema.md](docs/inputdataschema.md) |
| inputdataschemacustoms.md | Definition of the input data schema specific to customs-related scenarios | [inputdataschemacustoms.md](docs/inputdataschemacustoms.md) |
| transparency.md | Documentation related to transparency, explainability, and interpretation of results | [transparency.md](docs/transparency.md) |


## Contributing

This project welcomes contributions and suggestions.  Most contributions require you to agree to a
Contributor License Agreement (CLA) declaring that you have the right to, and actually do, grant us
the rights to use your contribution. For details, visit <https://cla.opensource.microsoft.com>.

When you submit a pull request, a CLA bot will automatically determine whether you need to provide
a CLA and decorate the PR appropriately (e.g., status check, comment). Simply follow the instructions
provided by the bot. You will only need to do this once across all repos using our CLA.

This project has adopted the [Microsoft Open Source Code of Conduct](https://opensource.microsoft.com/codeofconduct/).
For more information see the [Code of Conduct FAQ](https://opensource.microsoft.com/codeofconduct/faq/) or
contact [opencode@microsoft.com](mailto:opencode@microsoft.com) with any additional questions or comments.
