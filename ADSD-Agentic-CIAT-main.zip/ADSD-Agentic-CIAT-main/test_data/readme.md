
# Functional Test Data – Setup Guide

## Overview

This folder contains the required test data files used to execute the functional validation of the data pipelines within the Microsoft Fabric Lakehouse environment.

These files simulate input data sources and must be manually copied into the appropriate directories inside the Lakehouse **Files** area before executing the pipelines.

---

## Prerequisites

Before running the functional tests, ensure:

- The target **Fabric Workspace** is deployed and synchronized with GitHub
- The **Lakehouse** is created and accessible
- You have permissions to upload files into the Lakehouse

---

## Initial Setup — Folder Structure

Before uploading the test files, you must create the required folder structure in the Lakehouse.

To do this, run the following notebook:

**`0_0_nb_folder_setup`**

### Purpose

This notebook automatically creates the required directory structure inside the Lakehouse **Files** area, ensuring that all pipelines can correctly locate the input data.

### Instructions

1. Open the notebook `0_0_nb_folder_setup.Notebook` in your Fabric workspace  
2. Attach the notebook to the target Lakehouse  
3. Run all cells  

### Expected Outcome

After execution, the following folder structure will be created:

Files/  
└── input/  
&nbsp;&nbsp;&nbsp;&nbsp;├── main_entity_profiles/  
&nbsp;&nbsp;&nbsp;&nbsp;├── transactional_data/  
&nbsp;&nbsp;&nbsp;&nbsp;└── exchange_rates/

## Target Lakehouse Structure

All files must be copied under the following base path:


Files/input/


Final expected structure:


Files/  
└── input/  
&nbsp;&nbsp;&nbsp;&nbsp;├── main_entity_profiles/  
&nbsp;&nbsp;&nbsp;&nbsp;├── transactional_data/  
&nbsp;&nbsp;&nbsp;&nbsp;└── exchange_rates/


---

## File Description and Placement

### 1. Main Entity Profiles

- **File Type:** CSV  
- **Purpose:** Contains master or reference data representing core business entities (e.g., customers, suppliers, or accounts)  
- **Usage:** Used as baseline data for transformations, enrichment, and joins  

**Files:**
- `entity_profile.csv`

**Target Path:**
```
Files/input/main_entity_profiles/
```



---

### 2. Transactional Data

- **File Type:** ZIP (compressed CSV files)  
- **Purpose:** Contains transactional records used for processing and anomaly detection  
- **Usage:** Represents high-volume operational data processed by the pipeline  

**Files:**
- `SYNT-EINV-00-2021-LOAD-1.zip`
- `SYNT-EINV-00-2021-LOAD-2.zip`
- `SYNT-EINV-00-2021-LOAD-3.zip`

**Target Path:**
```
Files/input/transactional_data/
```


> ⚠️ **Important:** Do not unzip the file unless explicitly required by the pipeline logic.

---

### 3. Exchange Rates

- **File Type:** CSV  
- **Purpose:** Provides currency exchange rates used for normalization and financial calculations  
- **Usage:** Applied during transformation stages for currency conversion  

**Files:**
- `exchange_rates.csv`

**Target Path:**
```
Files/input/exchange_rates/
```

### 4. Mapping Configuration Files

- **File Type:** JSON  
- **Purpose:** Defines mapping logic used during transformations  

**Files:**
- `adsd_to_adsd_specific_mapping.json`
- `adsd_to_customs_specific_mapping.json`
- `adsd_to_invoicing_specific_mapping.json`

**Target Path:**
```
Files/input/mappings/
```

---

## Upload Instructions

### Option 1 — Fabric UI

1. Navigate to your Lakehouse
2. Go to the **Files** section
3. Create the required folder structure:


Files/  
└── input/  
&nbsp;&nbsp;&nbsp;&nbsp;├── main_entity_profiles/  
&nbsp;&nbsp;&nbsp;&nbsp;├── transactional_data/  
&nbsp;&nbsp;&nbsp;&nbsp;└── exchange_rates/


4. Upload each file into its corresponding folder

---

### Option 2 — Notebook (PySpark)

### Option 2 — Notebook (PySpark)

You can upload files programmatically using a notebook:

```python
from notebookutils import mssparkutils

mssparkutils.fs.put(
    "Files/input/main_entity_profiles/sample.csv",
    open("sample.csv").read(),
    True
)
```

## Execution

Once all files are uploaded:

1. Run the pipeline **2_main_data_load** from Fabric with default parameters
2. Validate:
   - Data ingestion  
   - Transformations  
   - Output tables in the Lakehouse  

---

## Validation Checklist

- [ ] All files uploaded to correct directories  
- [ ] File names match expected pipeline inputs  
- [ ] No schema mismatches in CSV files  
- [ ] Pipeline execution completes successfully  
- [ ] Output data is generated correctly  

### Batch Validation (Important)

If the pipeline runs successfully:

- [ ] A new row is created in the `batch_status` table  
- [ ] The row contains a valid `batch_id`  

> ⚠️ Take note of the `batch_id`, as it is required for configuring Power BI parameters used in reporting and validation.

---

## Notes

- Ensure file encoding is UTF-8  
- Avoid modifying file structure unless required  
- These files are intended for **functional testing only**, not for production use  

---

## Troubleshooting

If issues occur during execution:

- Verify file paths and naming conventions  
- Check pipeline logs in Fabric  
- Confirm Lakehouse permissions and access  
- Ensure the pipeline is pointing to the correct Lakehouse and folder paths  
