# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse_name": "",
# META       "default_lakehouse_workspace_id": ""
# META     }
# META   }
# META }

# MARKDOWN ********************

# # Calculate uploaded data statistics
# Calculates statistics of the uploaded data
# 
# 
# - Total number of num_documentTypeC reported 
# 
# - Total number of num_documentTypeA reported 
#  
# - Total number of num_documentTypeB reported 
#  
# - Number of entity_target_ids in the entired period 
#  
# - Number of identified receiver_ids in the period 
#  
# - Number of ISICs (activity) reported in the period 

# CELL ********************

# MAGIC %%configure -f
# MAGIC {
# MAGIC     "defaultLakehouse": {
# MAGIC         "name": "ADSD"
# MAGIC     }
# MAGIC }

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

batch_id = ''
transaction_schema_applied_path = ''
statistics_path = ''
data_separator = ''
data_encoding = ''
database_name = ''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import pandas as pd
import datetime
import csv
import time
import pyodbc
from pyspark.sql.types import StructType,StructField, StringType, IntegerType,DoubleType
from pyspark.sql.functions import col, year, month, dayofmonth, isnan, when, count 

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

schema_uploaded_data_statistics = StructType([ 
    StructField("filename",StringType(),True), 
    StructField("month",StringType(),True), 
    StructField("num_documentTypeA",DoubleType(),True),
    StructField("num_documentTypeB",DoubleType(),True),
    StructField("num_documentTypeC",DoubleType(),True),
    StructField("num_entity_target_ids",DoubleType(),True),
    StructField("num_entity_subtarget_ids",DoubleType(),True),
    StructField("num_segments",DoubleType(),True),
    StructField("number_records",DoubleType(),True),
    StructField("num_documentTypeD",DoubleType(),True),
    StructField("num_documentTypeE",DoubleType(),True)
  ])

schema_total_documents = StructType([
    StructField('document_type', StringType(), True),
    StructField('total_documents', IntegerType(), True)
])

schema_total_unique = StructType([
    StructField('unique_entity_target_id', IntegerType(), True),
    StructField('unique_entity_subtarget_id', IntegerType(), True),
    StructField('unique_activity_id', IntegerType(), True)
])


unique_entity_target_id_dataset = pd.DataFrame()
unique_entity_subtarget_id_dataset = pd.DataFrame()
unique_activity_id_dataset = pd.DataFrame()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

emptyRDD = spark.sparkContext.emptyRDD()
df_uploaded_data_statistics = spark.createDataFrame(emptyRDD, schema=schema_uploaded_data_statistics)

emptyRDD = spark.sparkContext.emptyRDD()
df_statistics_uniques = spark.createDataFrame(emptyRDD, schema=schema_total_unique)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def deep_ls(path: str, max_depth=1):
    """
    List all files and folders in specified path and
    subfolders within maximum recursion depth.
    """

    # List all files in path
    li = mssparkutils.fs.ls(path)

    # Return all files
    for x in li:
        if x.size != 0:
            yield x

    # If the max_depth has not been reached, start
    # listing files and folders in subdirectories
    if max_depth > 1:
        for x in li:
            if x.size != 0:
                continue
            for y in deep_ls(x.path, max_depth - 1):
                yield y

    # If max_depth has been reached,
    # return the folders
    else:
        for x in li:
            if x.size == 0:
                yield x

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def getStatistics(df_uploaded_data_statistics, fileName, fullFilePath) :

    global unique_entity_target_id_dataset 
    global unique_entity_subtarget_id_dataset
    global unique_activity_id_dataset

    df = spark.read.csv(fullFilePath, sep=data_separator,inferSchema=True, header=True)


    df_counts = pd.DataFrame(df.groupBy('document_type').count().collect())

    df_total_document_by_type = spark.createDataFrame(df_counts, schema_total_documents)

    #transactions
    total_by_type = df_total_document_by_type.filter(df_total_document_by_type.document_type == 'A').collect()
    if len(total_by_type) > 0 :
        total_number_sale_transactions = total_by_type[0][1]
    else :
        total_number_sale_transactions = 0
    
    #debit notes
    total_by_type = df_total_document_by_type.filter(df_total_document_by_type.document_type == 'B').collect()
    if len(total_by_type) > 0 :
        total_number_document_typeB = total_by_type[0][1]
    else :
        total_number_document_typeB = 0

    #credit notes
    total_by_type = df_total_document_by_type.filter(df_total_document_by_type.document_type == 'C').collect()
    if len(total_by_type) > 0 :
        total_number_document_typeC = total_by_type[0][1]
    else :
        total_number_document_typeC = 0        

    #purchase
    total_by_type = df_total_document_by_type.filter(df_total_document_by_type.document_type == 'D').collect()
    if len(total_by_type) > 0 :
        total_number_document_typeD = total_by_type[0][1]
    else :
        total_number_document_typeD = 0  

    #export transaction
    total_by_type = df_total_document_by_type.filter(df_total_document_by_type.document_type == 'E').collect()
    if len(total_by_type) > 0 :
        total_number_document_typeE = total_by_type[0][1]
    else :
        total_number_document_typeE = 0          

    total_entity_target_ids = df.select('entity_target_id').distinct().count()
    total_entity_subtarget_ids = df.select('entity_subtarget_id').distinct().count()
    total_ISICs = df.select('segment_group').distinct().count()

    total_rows_in_dataset = df.count()


    file_name_splits = (fileName.split("-"))
    month_number = (file_name_splits[2])
    year_of_analysis = (file_name_splits[3])
    month_of_analysis = month_number + ' - ' + year_of_analysis

    new_row = [[fileName,month_of_analysis, total_number_sale_transactions, total_number_document_typeB, 
    total_number_document_typeC, total_entity_target_ids , total_entity_subtarget_ids, total_ISICs, 
    total_rows_in_dataset, total_number_document_typeD, total_number_document_typeE]]
    
    unknown_df = spark.createDataFrame(new_row)
    df_uploaded_data_statistics = df_uploaded_data_statistics.union(unknown_df)

    unique_entity_target_id_in_file = pd.DataFrame(df.select('entity_target_id').distinct().collect())
    unique_entity_subtarget_id_in_file = pd.DataFrame(df.select('entity_subtarget_id').distinct().collect())
    unique_activity_id_in_file = pd.DataFrame(df.select('segment_group').distinct().collect())
   
    unique_entity_target_id_dataset = pd.concat([unique_entity_target_id_dataset, unique_entity_target_id_in_file], ignore_index=True)
    unique_entity_subtarget_id_dataset = pd.concat([unique_entity_subtarget_id_dataset, unique_entity_subtarget_id_in_file], ignore_index=True)
    unique_activity_id_dataset = pd.concat([unique_activity_id_dataset, unique_activity_id_in_file], ignore_index=True)


    return df_uploaded_data_statistics    

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

file_names = mssparkutils.fs.ls(transaction_schema_applied_path)
for filename in file_names:
    print(f'Calculating data statistics for file: {filename.name}')  
    df_uploaded_data_statistics = getStatistics(df_uploaded_data_statistics, filename.name, filename.path)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

total_unique_entity_target_id_dataset = unique_entity_target_id_dataset[0].nunique()
total_unique_entity_subtarget_id_dataset = unique_entity_subtarget_id_dataset[0].nunique()
total_unique_activity_id_dataset = unique_activity_id_dataset[0].nunique()

new_row = [[total_unique_entity_target_id_dataset, total_unique_entity_subtarget_id_dataset, total_unique_activity_id_dataset]]
unknown_df_time = spark.createDataFrame(new_row)

df_statistics_uniques = df_statistics_uniques.union(unknown_df_time)



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # Write out the statistics
# if the notebook receives the "run_time_stamp" parameter from Synapse Ingest the parameter is used to create a folder to store the statistics, if no parameter is received we write the statistics to the default output folder

# CELL ********************

df_uploaded_data_statistics.write \
    .mode("overwrite") \
    .format("delta") \
    .saveAsTable(f"batch_{batch_id}_output_statistics_load_stats")

df_statistics_uniques.write \
    .mode("overwrite") \
    .format("delta") \
    .saveAsTable(f"batch_{batch_id}_output_statistics_load_stats_unique_receiver_issuer")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
