# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse_name": "",
# META       "default_lakehouse_workspace_id": ""
# META     }
# META   }
# META }

# CELL ********************

# MAGIC %%configure -f
# MAGIC {
# MAGIC     "defaultLakehouse": {
# MAGIC         "name": "ADSD"
# MAGIC     }
# MAGIC }

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import pyspark.sql.functions as F

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

batch_id = ''
iFor_data_prefix = ''
overhead_data_path = ''
overhead_results_prefix = ''
best_iforest_path = ''
id_feat = ''
time_slice_folder = ''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

if iFor_data_prefix != "":
    iFor_data_prefix = "/".join(iFor_data_prefix.split("/")[:-1]) + "/" + time_slice_folder + "/" + iFor_data_prefix.split("/")[-1]
    print(f'iFor_data_prefix = {iFor_data_prefix}')
if overhead_data_path != "":
    overhead_data_path = "/".join(overhead_data_path.split("/")[:-1]) + "/" + time_slice_folder + "/" + overhead_data_path.split("/")[-1]
    print(f'overhead_data_path = {overhead_data_path}')
if overhead_results_prefix != "":
    overhead_results_prefix = "/".join(overhead_results_prefix.split("/")[:-1]) + "/" + time_slice_folder + "/" + overhead_results_prefix.split("/")[-1]
    print(f'overhead_results_prefix = {overhead_results_prefix}')
if best_iforest_path != "":
    best_iforest_path = "/".join(best_iforest_path.split("/")[:-1]) + "/" + time_slice_folder + "/" + best_iforest_path.split("/")[-1]
    print(f'best_iforest_path = {best_iforest_path}')

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Casting parameters
id_feat = [i for i in id_feat.split(",")]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_predict = spark.read.parquet(overhead_results_prefix)
df_avg = df_predict.groupBy(id_feat).agg((F.sum('predict')/F.count('predict')).alias('avg'))
df_predict = df_predict.join(df_avg,on=id_feat)
df_predict = df_predict.withColumn("squared_residuals",F.pow(F.col('predict') - F.col("avg"),2))
df_model = df_predict.groupBy("tree_size","subsample_size","group_num").agg(F.sum("squared_residuals").alias("sum_of_squared_residuals"))
df_model = df_model.orderBy("sum_of_squared_residuals",ascending=True)
best_trees, best_subsample_size, best_group, _ = df_model.take(1)[0]
print("Best iForest: {}, {}, {}".format(best_trees, best_subsample_size, best_group))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_iFor = spark.read.parquet(iFor_data_prefix)
model_bytes = df_iFor.where((F.col('id')==best_group)&(F.col('tree_size')==best_trees)&(F.col('subsample_size')==best_subsample_size)).select('model').collect()[0]['model']

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.createDataFrame([('best_iforest',model_bytes)],schema=['id','model']).write.mode('overwrite').parquet(best_iforest_path)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
