# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse_name": "",
# META       "default_lakehouse_workspace_id": ""
# META     }
# META   }
# META }

# CELL ********************

# MAGIC %%configure -f
# MAGIC {
# MAGIC     "defaultLakehouse": {
# MAGIC         "name": "ADSD"
# MAGIC     }
# MAGIC }

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

batch_id = ''
transaction_schema_applied_path = ''
statistics_path = ''
data_separator = ''
data_encoding = ''
entity_profile_schema_applied_path = ''
data_quality_min_date = ''
data_quality_max_date = ''
database_name = ''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#Sample Quality Index Weights
SQi_below_range_weight = 3
SQi_above_range_weight = 3
SQi_in_range_weight = 2

#Completeness Index Weights. 
#Increasing the value for one column will increase its importance relative to the other columns being measured for completeness.
Ci_entity_target_id_weight = 3
Ci_transaction_date01_weight = 3
Ci_main_operation_type_weight = 2
Ci_document_type_weight = 2
Ci_currency01_weight = 2
Ci_exchange_rate_weight = 1
Ci_item_spec_volume_q06_weight = 1
Ci_item_spec_value_q01_weight = 1
Ci_item_spec_value_q02_weight = 1
Ci_item_spec_price_q01_weight = 2
Ci_item_spec_tax_q01_weight = 2
Ci_segment_group_weight = 2
Ci_document_id_weight = 3
Ci_entity_subtarget_id_weight = 2
Ci_item_spec_volume_q04_weight = 1

#Cross Reference Index weights
xRefi_entity_target_id_no_entity_profile_target_id_weight = 3

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import datetime
import csv
import pandas as pd
from datetime import date, datetime
from calendar import monthrange
import time
import pyodbc
import pyspark.sql.functions as F
from pyspark.sql.functions import col, year, month, dayofmonth, isnan, when, count
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType, FloatType, DateType

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# for every field it is needed to calculate the number of NULL records by month
all_files_data_quality_schema = StructType([ 
    StructField("filename",StringType(),True), 
    StructField("min_transaction_date01",DateType(),True),
    StructField("max_transaction_date01",DateType(),True),
    StructField("num_recs",DoubleType(),True),
    StructField("num_null_main_operation_type",DoubleType(),True),
    StructField("num_null_entity_target_id",DoubleType(),True),
    StructField("num_null_segment_group",DoubleType(),True), 
    StructField("num_null_entity_c_id",DoubleType(),True),
    StructField("num_null_entity_subtarget_id",DoubleType(),True), 
    StructField("num_null_document_type",DoubleType(),True),
    StructField("num_null_document_id",DoubleType(),True),  
    StructField("num_null_transaction_date01",DoubleType(),True),
    StructField("num_null_entity_c_name",DoubleType(),True),
    StructField("num_null_tax_rate01",DoubleType(),True),
    StructField("num_null_currency01",DoubleType(),True),
    StructField("num_null_exchange_exchange_rate_main",DoubleType(),True),
    StructField("num_null_payment_type01",DoubleType(),True),
    StructField("num_null_transaction_reference_a",DoubleType(),True),
    StructField("num_null_tax_type01",DoubleType(),True),
    StructField("num_null_transaction_origin",DoubleType(),True),
    StructField("num_null_item_code01",DoubleType(),True),
    StructField("num_null_item_description01",DoubleType(),True),
    StructField("num_null_item_spec_volume_q01",DoubleType(),True),
    StructField("num_null_item_spec_volume_q02",DoubleType(),True),
    StructField("num_null_item_spec_volume_q05",DoubleType(),True),
    StructField("num_null_item_spec_volume_q03",DoubleType(),True),
    StructField("num_null_item_spec_volume_q06",DoubleType(),True),
    StructField("num_null_item_spec_value_q01",DoubleType(),True),
    StructField("num_null_item_spec_value_q02",DoubleType(),True),
    StructField("num_null_item_spec_volume_q04",DoubleType(),True),
    StructField("num_null_item_spec_price_q01",DoubleType(),True),
    StructField("num_null_item_spec_tax_q01",DoubleType(),True),
    StructField("num_documentTypeA",DoubleType(),True),
    StructField("num_documentTypeB",DoubleType(),True),
    StructField("num_documentTypeC",DoubleType(),True),
    StructField("num_documentTypeD",DoubleType(),True),
    StructField("num_documentTypeE",DoubleType(),True),
    StructField("num_entity_target_ids",DoubleType(),True),
    StructField("num_entity_subtarget_ids",DoubleType(),True),
    StructField("num_segments",DoubleType(),True),
    StructField("num_entity_target_id_no_entity_profile_target_id",DoubleType(),True)
])

unique_issuer_schema = StructType([StructField("entity_target_id",StringType(),True)])
unique_receiver_schema = StructType([StructField("entity_subtarget_id",StringType(),True)])
unique_segment_group_schema = StructType([StructField("segment_group",StringType(),True)])

emptyRDD = spark.sparkContext.emptyRDD()
df_all_files_data_quality = spark.createDataFrame(emptyRDD, schema=all_files_data_quality_schema)
df_unique_entity_target_id_dataset = spark.createDataFrame(emptyRDD, schema=unique_issuer_schema)
df_unique_entity_subtarget_id_dataset = spark.createDataFrame(emptyRDD, schema=unique_receiver_schema)
df_unique_segment_group_dataset = spark.createDataFrame(emptyRDD, schema=unique_segment_group_schema)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_total_nulls(df, colname) :
    if [dtype for name, dtype in df.dtypes if name == colname][0] not in ("timestamp", "date"):
       total_rows = df.where(col(colname).contains('None') | col(colname).contains('NULL') | (col(colname) == '' ) | col(colname).isNull() | isnan(colname)).count()
    else:
        # isnan isn't supported on timestamp and date types
        total_rows = df.where(col(colname).contains('None') | col(colname).contains('NULL') | (col(colname) == '' ) | col(colname).isNull()).count()
    return total_rows

def qualify_totals(total_value):
    if len(total_value) > 0 :
        total_num = total_value[0][0]
    else :
        total_num = 0
    return total_num

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_data_quality_of_file(df, fileName, df_entity_profile) :
    global df_unique_entity_target_id_dataset
    global df_unique_entity_subtarget_id_dataset
    global df_unique_segment_group_dataset

    df_counts = df.groupBy('document_type').count()

    #transactions
    total_number_document_typeA = qualify_totals(df_counts.filter(df_counts.document_type == 'A').select('count').collect())
    #debit notes
    total_number_document_typeB = qualify_totals(df_counts.filter(df_counts.document_type == 'B').select('count').collect())
    #credit notes
    total_number_document_typeC = qualify_totals(df_counts.filter(df_counts.document_type == 'C').select('count').collect())
    #purchase
    total_number_document_typeD = qualify_totals(df_counts.filter(df_counts.document_type == 'D').select('count').collect())
    #export transaction
    total_number_document_typeE = qualify_totals(df_counts.filter(df_counts.document_type == 'E').select('count').collect())

    total_entity_target_ids = df.select('entity_target_id').distinct().count()
    total_entity_subtarget_ids = df.select('entity_subtarget_id').distinct().count()
    total_ISICs = df.select('segment_group').distinct().count()
    total_rows_in_dataset = df.count()

    total_rows_null_entity_target_id = get_total_nulls(df,"entity_target_id") 
    total_rows_null_transaction_date01 = get_total_nulls(df,"transaction_date01")
    total_rows_null_main_operation_type = get_total_nulls(df,"main_operation_type")
    total_rows_null_document_type = get_total_nulls(df,"document_type")
    total_rows_null_currency01 = get_total_nulls(df,"currency01")
    total_rows_null_item_spec_price_q01 = get_total_nulls(df,"item_spec_price_q01")
    total_rows_null_item_spec_tax_q01 = get_total_nulls(df,"item_spec_tax_q01")
    total_rows_null_segment_group = get_total_nulls(df,"segment_group")
    total_rows_null_document_id = get_total_nulls(df,"document_id")
    total_rows_null_entity_subtarget_id = get_total_nulls(df,"entity_subtarget_id")
    total_rows_null_item_spec_volume_q06 = get_total_nulls(df,"item_spec_volume_q06")
    total_rows_null_item_spec_value_q01 = get_total_nulls(df,"item_spec_value_q01")
    total_rows_null_item_spec_value_q02 = get_total_nulls(df,"item_spec_value_q02")
    total_rows_null_item_spec_volume_q04 = get_total_nulls(df,"item_spec_volume_q04")
    total_rows_null_entity_c_id = get_total_nulls(df,"entity_c_id")
    total_rows_null_entity_c_name = get_total_nulls(df,"entity_c_name")
    total_rows_null_tax_rate01s = get_total_nulls(df,"tax_rate01")
    total_rows_null_exchange_rate = get_total_nulls(df,"exchange_rate_main")
    total_rows_null_payment_type01 = get_total_nulls(df,"payment_type01")
    total_rows_null_transaction_reference_a = get_total_nulls(df,"transaction_reference_a")
    total_rows_null_tax_type01 = get_total_nulls(df,"tax_type01")
    total_rows_null_transaction_origin = get_total_nulls(df,"transaction_origin")
    total_rows_null_item_code01 = get_total_nulls(df,"item_code01")
    total_rows_null_item_description01 = get_total_nulls(df,"item_description01")
    total_rows_null_item_spec_volume_q01 = get_total_nulls(df,"item_spec_volume_q01")
    total_rows_null_item_spec_volume_q02 = get_total_nulls(df,"item_spec_volume_q02")
    total_rows_null_item_spec_volume_q05 = get_total_nulls(df,"item_spec_volume_q05")
    total_rows_null_item_spec_volume_q03 = get_total_nulls(df,"item_spec_volume_q03")

    transaction_date01_min = df.agg({"transaction_date01": "min"}).collect()[0][0]
    transaction_date01_max = df.agg({"transaction_date01": "max"}).collect()[0][0]
        
    df_unique_entity_target_id_in_file = df.select('entity_target_id').distinct()
    
    df_cross_reference = df_unique_entity_target_id_in_file.join(df_entity_profile, (df_unique_entity_target_id_in_file['entity_target_id'] == df_entity_profile['entity_profile_target_id']) , how='left') 
    num_entity_target_id_no_entity_profile_target_id = df_cross_reference.filter(col("entity_profile_target_id").isNull()).count()
    
    new_row = [[fileName, transaction_date01_min, transaction_date01_max, 
                total_rows_in_dataset, total_rows_null_main_operation_type, total_rows_null_entity_target_id, total_rows_null_segment_group,
                total_rows_null_entity_c_id, total_rows_null_entity_subtarget_id, total_rows_null_document_type,
                total_rows_null_document_id, total_rows_null_transaction_date01, total_rows_null_entity_c_name, total_rows_null_tax_rate01s,
                total_rows_null_currency01, total_rows_null_exchange_rate, total_rows_null_payment_type01, total_rows_null_transaction_reference_a,
                total_rows_null_tax_type01, total_rows_null_transaction_origin, total_rows_null_item_code01,
                total_rows_null_item_description01, total_rows_null_item_spec_volume_q01, total_rows_null_item_spec_volume_q02,
                total_rows_null_item_spec_volume_q05, total_rows_null_item_spec_volume_q03, total_rows_null_item_spec_volume_q06,
                total_rows_null_item_spec_value_q01, total_rows_null_item_spec_value_q02, total_rows_null_item_spec_volume_q04, 
                total_rows_null_item_spec_price_q01, total_rows_null_item_spec_tax_q01, 
                total_number_document_typeA, total_number_document_typeB, total_number_document_typeC,total_number_document_typeD , 
                total_number_document_typeE, total_entity_target_ids, total_entity_subtarget_ids, total_ISICs, num_entity_target_id_no_entity_profile_target_id
                ]]
    
    df_unique_entity_target_id_dataset = df_unique_entity_target_id_dataset.union(df_unique_entity_target_id_in_file)
    df_unique_entity_subtarget_id_dataset = df_unique_entity_subtarget_id_dataset.union(df.select('entity_subtarget_id').distinct())
    df_unique_segment_group_dataset = df_unique_segment_group_dataset.union(df.select('segment_group').distinct())

    return new_row

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ## Calculate the data quality of each file provided on a per-file basis

# CELL ********************

df_entity_profile = spark.read.csv(f'{entity_profile_schema_applied_path}/entity_profile/', sep=data_separator,inferSchema=True, header=True).select('entity_profile_target_id')

file_names = mssparkutils.fs.ls(transaction_schema_applied_path)

firstFile = True
for filename in file_names:
    print(f'Caclulating data quality for file: {filename.name}')
    
    df = spark.read.csv(filename.path, sep=data_separator,inferSchema=True, header=True)

    file_data_quality_row = get_data_quality_of_file(df, filename.name, df_entity_profile)
    df_all_files_data_quality = df_all_files_data_quality.union(spark.createDataFrame(file_data_quality_row))
    
    if firstFile == True:
        df_alldata = df
        firstFile = False
    else:
        df_alldata = df_alldata.union(df)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ## Calculate the aggregate data quality for the entire dataset across all files

# CELL ********************

max_date = datetime.strptime(data_quality_max_date, "%d-%m-%Y")
min_date = datetime.strptime(data_quality_min_date, "%d-%m-%Y")

total_records = df_all_files_data_quality.select(F.sum('num_recs')).take(1)[0][0]
total_records_in_period_of_analysis = df_alldata.filter(df_alldata.transaction_date01 >= min_date).filter(df_alldata.transaction_date01 <= max_date).count()
total_records_out_of_period_of_analysis = total_records - total_records_in_period_of_analysis

total_records_below_range = df_alldata.filter(df_alldata.transaction_date01 < min_date).count()
total_records_above_range = df_alldata.filter(df_alldata.transaction_date01 > max_date).count()
    

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_dataset_data_quality = df_all_files_data_quality.select(
                                        F.lit(min_date).alias('min_date'),
                                        F.lit(max_date).alias('max_date'),
                                        F.min('min_transaction_date01').alias('min_transaction_date01'),
                                        F.max('max_transaction_date01').alias('max_transaction_date01'),
                                        F.lit(total_records).alias('num_recs'),
                                        F.lit(total_records_in_period_of_analysis).alias('num_recs_in_period_of_analysis'),
                                        F.lit(total_records_out_of_period_of_analysis).alias('num_recs_out_period_of_analysis'),
                                        F.sum('num_null_main_operation_type').alias('num_null_main_operation_type'),
                                        F.sum('num_null_entity_target_id').alias('num_null_entity_target_id'),
                                        F.sum('num_null_segment_group').alias('num_null_segment_group'),
                                        F.sum('num_null_entity_c_id').alias('num_null_entity_c_id'),
                                        F.sum('num_null_entity_subtarget_id').alias('num_null_entity_subtarget_id'),
                                        F.sum('num_null_document_type').alias('num_null_document_type'),
                                        F.sum('num_null_document_id').alias('num_null_document_id'),
                                        F.sum('num_null_transaction_date01').alias('num_null_transaction_date01'),
                                        F.sum('num_null_entity_c_name').alias('num_null_entity_c_name'),
                                        F.sum('num_null_tax_rate01').alias('num_null_tax_rate01'),
                                        F.sum('num_null_currency01').alias('num_null_currency01'),
                                        F.sum('num_null_exchange_exchange_rate_main').alias('num_null_exchange_exchange_rate_main'),
                                        F.sum('num_null_payment_type01').alias('num_null_payment_type01'),
                                        F.sum('num_null_transaction_reference_a').alias('num_null_transaction_reference_a'),
                                        F.sum('num_null_tax_type01').alias('num_null_tax_type01'),
                                        F.sum('num_null_transaction_origin').alias('num_null_transaction_origin'),
                                        F.sum('num_null_item_code01').alias('num_null_item_code01'),
                                        F.sum('num_null_item_description01').alias('num_null_item_description01'),
                                        F.sum('num_null_item_spec_volume_q01').alias('num_null_item_spec_volume_q01'),
                                        F.sum('num_null_item_spec_volume_q02').alias('num_null_item_spec_volume_q02'),
                                        F.sum('num_null_item_spec_volume_q05').alias('num_null_item_spec_volume_q05'),
                                        F.sum('num_null_item_spec_volume_q03').alias('num_null_item_spec_volume_q03'),
                                        F.sum('num_null_item_spec_volume_q06').alias('num_null_item_spec_volume_q06'),
                                        F.sum('num_null_item_spec_value_q01').alias('num_null_item_spec_value_q01'),
                                        F.sum('num_null_item_spec_value_q02').alias('num_null_item_spec_value_q02'),
                                        F.sum('num_null_item_spec_volume_q04').alias('num_null_item_spec_volume_q04'),
                                        F.sum('num_null_item_spec_price_q01').alias('num_null_item_spec_price_q01'),
                                        F.sum('num_null_item_spec_tax_q01').alias('num_null_item_spec_tax_q01'),
                                        F.sum('num_documentTypeC').alias('num_documentTypeC'),
                                        F.sum('num_documentTypeB').alias('num_documentTypeB'),
                                        F.sum('num_documentTypeA').alias('num_documentTypeA'),
                                        F.sum('num_documentTypeD').alias('num_documentTypeD'),
                                        F.sum('num_documentTypeE').alias('num_documentTypeE'),
                                        ((F.lit(total_records_in_period_of_analysis)/F.lit(total_records))*100).alias('pct_in_range'),
                                        ((F.lit(total_records_below_range)/F.lit(total_records))*100).alias('pct_below_range'),
                                        ((F.lit(total_records_above_range)/F.lit(total_records))*100).alias('pct_above_range'),
                                        ((F.sum('num_entity_target_id_no_entity_profile_target_id')/F.lit(df_unique_entity_target_id_dataset.distinct().count()))*100).alias('pct_entity_target_id_no_entity_profile_target_id'),
                                        F.lit(df_unique_entity_target_id_dataset.distinct().count()).alias('num_unique_entity_target_id'),
                                        F.lit(df_unique_entity_subtarget_id_dataset.distinct().count()).alias('num_unique_entity_subtarget_id'),
                                        F.lit(df_unique_segment_group_dataset.distinct().count()).alias('num_unique_ISICS')
                                        )

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ## Calculate the weighted and scored Quality Indexes for the entire dataset

# CELL ********************

def get_scoring_by_percentage_range(percentage) :
    scoring_completeness = 1

    if percentage == 0:
        scoring_completeness = 1
    elif ((percentage > 0) and (percentage <= 0.01)):
        scoring_completeness = 0.9
    elif ((percentage > 0.01) and (percentage <= 0.02)):
        scoring_completeness = 0.5
    elif (percentage > 0.02):
        scoring_completeness = 0.25
    else:
        scoring_completeness = 0

    return scoring_completeness

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


ds_pct_below_range = df_dataset_data_quality.select("pct_below_range").take(1)[0][0] / 100

#Calculation of the scoring for ds_pct_below_range
if ds_pct_below_range <= 0.01:
    SQi_below_range_score = 1
elif ((ds_pct_below_range > 0.01) and (ds_pct_below_range < 0.02)):
    SQi_below_range_score = 0.9
elif ((ds_pct_below_range > 0.02) and (ds_pct_below_range < 0.05)):
    SQi_below_range_score = 0.5
elif ds_pct_below_range > 0.05:
    SQi_below_range_score = 0.25
else:
    SQi_below_range_score = 0

print(f'SQi_below_range_score: {SQi_below_range_score}')

#Calculation of the scoring for ds_pct_above_range
ds_pct_above_range = df_dataset_data_quality.select("pct_above_range").take(1)[0][0] / 100

if ds_pct_above_range <= 0.01:
    SQi_above_range_score = 1
elif ((ds_pct_above_range > 0.01) and (ds_pct_above_range < 0.02)):
    SQi_above_range_score = 0.9
elif ((ds_pct_above_range > 0.02) and (ds_pct_above_range < 0.05)):
    SQi_above_range_score = 0.5
elif ds_pct_above_range > 0.05:
    SQi_above_range_score = 0.25
else:
    SQi_above_range_score = 0
print(f'SQi_above_range_score: {SQi_above_range_score}')

#Calculation of the scoring for ds_pct_in_range
ds_pct_in_range = df_dataset_data_quality.select("pct_in_range").take(1)[0][0] / 100

if ds_pct_in_range >= 0.991:
    SQi_in_range_score = 1
elif ((ds_pct_in_range > 0.975) and (ds_pct_in_range < 0.991)):
    SQi_in_range_score = 0.9
elif ((ds_pct_in_range > 0.935) and (ds_pct_in_range < 0.975)):
    SQi_in_range_score = 0.5
elif ds_pct_in_range < 0.935:
    SQi_in_range_score = 0.25
else:
    SQi_in_range_score = 0

SQi_max_weight = SQi_below_range_weight + SQi_above_range_weight + SQi_in_range_weight
#SQi = Average (Sigma (Parameter wt * score) / Max possible score >> across all defined criteria
SQi = ((SQi_below_range_weight * SQi_below_range_score) +  (SQi_above_range_weight * SQi_above_range_score) + \
        (SQi_in_range_weight * SQi_in_range_score )) / SQi_max_weight

print(f'SQi: {SQi}')

# Calculation of Completeness index
total_rows_in_dataset = df_dataset_data_quality.select("num_recs").take(1)[0][0]

pct_null_entity_target_id = df_dataset_data_quality.select("num_null_entity_target_id").take(1)[0][0] / total_rows_in_dataset
pct_null_transaction_date01 = df_dataset_data_quality.select("num_null_transaction_date01").take(1)[0][0] / total_rows_in_dataset
pct_null_main_operation_type = df_dataset_data_quality.select("num_null_main_operation_type").take(1)[0][0] / total_rows_in_dataset
pct_null_document_type = df_dataset_data_quality.select("num_null_document_type").take(1)[0][0] / total_rows_in_dataset
pct_null_currency01 = df_dataset_data_quality.select("num_null_currency01").take(1)[0][0] / total_rows_in_dataset
pct_null_exchange_rate = df_dataset_data_quality.select("num_null_exchange_exchange_rate_main").take(1)[0][0] / total_rows_in_dataset
pct_null_item_spec_volume_q06 = df_dataset_data_quality.select("num_null_item_spec_volume_q06").take(1)[0][0] / total_rows_in_dataset
pct_null_item_spec_value_q01 = df_dataset_data_quality.select("num_null_item_spec_value_q01").take(1)[0][0] / total_rows_in_dataset
pct_null_item_spec_value_q02 = df_dataset_data_quality.select("num_null_item_spec_value_q02").take(1)[0][0] / total_rows_in_dataset
pct_null_item_spec_price_q01 = df_dataset_data_quality.select("num_null_item_spec_price_q01").take(1)[0][0] / total_rows_in_dataset
pct_null_item_spec_tax_q01 = df_dataset_data_quality.select("num_null_item_spec_tax_q01").take(1)[0][0] / total_rows_in_dataset
pct_null_segment_group = df_dataset_data_quality.select("num_null_segment_group").take(1)[0][0] / total_rows_in_dataset
pct_null_document_id = df_dataset_data_quality.select("num_null_document_id").take(1)[0][0] / total_rows_in_dataset
pct_null_entity_subtarget_id = df_dataset_data_quality.select("num_null_entity_subtarget_id").take(1)[0][0] / total_rows_in_dataset
pct_null_item_spec_volume_q04 = df_dataset_data_quality.select("num_null_item_spec_volume_q04").take(1)[0][0] / total_rows_in_dataset


computed_score_entity_target_id = get_scoring_by_percentage_range(pct_null_entity_target_id)
computed_score_transaction_date01 =  get_scoring_by_percentage_range(pct_null_transaction_date01)
computed_score_main_operation_type =  get_scoring_by_percentage_range(pct_null_main_operation_type)
computed_score_document_type =  get_scoring_by_percentage_range(pct_null_document_type)
computed_score_currency01 =  get_scoring_by_percentage_range(pct_null_currency01)
computed_score_exchange_rate =  get_scoring_by_percentage_range(pct_null_exchange_rate)
computed_score_item_spec_volume_q06 =  get_scoring_by_percentage_range(pct_null_item_spec_volume_q06)
computed_score_item_spec_value_q01 = get_scoring_by_percentage_range(pct_null_item_spec_value_q01)
computed_score_item_spec_value_q02 =  get_scoring_by_percentage_range(pct_null_item_spec_value_q02)
computed_score_item_spec_price_q01 =  get_scoring_by_percentage_range(pct_null_item_spec_price_q01)
computed_score_item_spec_tax_q01 =  get_scoring_by_percentage_range(pct_null_item_spec_tax_q01)
computed_score_segment_group =  get_scoring_by_percentage_range(pct_null_segment_group)
computed_score_document_id =  get_scoring_by_percentage_range(pct_null_document_id)
computed_score_entity_subtarget_id =  get_scoring_by_percentage_range(pct_null_entity_subtarget_id)
computed_score_item_spec_volume_q04 =  get_scoring_by_percentage_range(pct_null_item_spec_volume_q04)

weighted_score_entity_target_id = computed_score_entity_target_id * Ci_entity_target_id_weight
weighted_score_transaction_date01 =  computed_score_transaction_date01 * Ci_transaction_date01_weight
weighted_score_main_operation_type =  computed_score_main_operation_type * Ci_main_operation_type_weight
weighted_score_document_type =  computed_score_document_type * Ci_document_type_weight
weighted_score_currency01 =  computed_score_currency01 * Ci_currency01_weight
weighted_score_exchange_rate =  computed_score_exchange_rate * Ci_exchange_rate_weight
weighted_score_item_spec_volume_q06 =  computed_score_item_spec_volume_q06 * Ci_item_spec_volume_q06_weight
weighted_score_item_spec_value_q01 = computed_score_item_spec_value_q01 * Ci_item_spec_value_q01_weight
weighted_score_item_spec_value_q02 =  computed_score_item_spec_value_q02 * Ci_item_spec_value_q02_weight
weighted_score_item_spec_price_q01 =  computed_score_item_spec_price_q01 * Ci_item_spec_price_q01_weight
weighted_score_item_spec_tax_q01 =  computed_score_item_spec_tax_q01 * Ci_item_spec_tax_q01_weight
weighted_score_segment_group =  computed_score_segment_group * Ci_segment_group_weight
weighted_score_document_id =  computed_score_document_id * Ci_document_id_weight
weighted_score_entity_subtarget_id =  computed_score_entity_subtarget_id * Ci_entity_subtarget_id_weight
weighted_score_item_spec_volume_q04 =  computed_score_item_spec_volume_q04 * Ci_item_spec_volume_q04_weight

weighted_score_total = weighted_score_entity_target_id + weighted_score_transaction_date01 + weighted_score_main_operation_type + weighted_score_document_type + \
                    weighted_score_currency01 + weighted_score_exchange_rate + weighted_score_item_spec_volume_q06 + weighted_score_item_spec_value_q01 + \
                    weighted_score_item_spec_value_q02 + weighted_score_item_spec_price_q01 + weighted_score_item_spec_tax_q01 + weighted_score_segment_group + \
                    weighted_score_document_id + weighted_score_entity_subtarget_id + weighted_score_item_spec_volume_q04

Ci_max_weight = Ci_entity_target_id_weight + Ci_transaction_date01_weight + Ci_main_operation_type_weight + Ci_document_type_weight + \
                        Ci_currency01_weight + Ci_exchange_rate_weight + Ci_item_spec_volume_q06_weight + Ci_item_spec_value_q01_weight + \
                        Ci_item_spec_value_q02_weight + Ci_item_spec_price_q01_weight + Ci_item_spec_tax_q01_weight + Ci_segment_group_weight + \
                        Ci_document_id_weight + Ci_entity_subtarget_id_weight + Ci_item_spec_volume_q04_weight 

#Ci = Average (Sigma (Parameter wt * score) / Max possible score >> across all defined criteria parameters.
Ci = weighted_score_total / Ci_max_weight
print(f'Ci: {Ci}')

# Cross Reference index
ds_pct_entity_target_id_no_entity_profile_target_id = df_dataset_data_quality.select("pct_entity_target_id_no_entity_profile_target_id").take(1)[0][0] / 100

computed_score_entity_target_id_no_entity_profile_target_id = get_scoring_by_percentage_range(ds_pct_entity_target_id_no_entity_profile_target_id)
weighted_score_entity_target_id_no_entity_profile_target_id = xRefi_entity_target_id_no_entity_profile_target_id_weight * computed_score_entity_target_id_no_entity_profile_target_id

#xRefi = Average (Sigma (Parameter wt * score) / Max possible score >> across all defined cross reference data sources
xRefi = weighted_score_entity_target_id_no_entity_profile_target_id / xRefi_entity_target_id_no_entity_profile_target_id_weight
print(f'xRefi: {xRefi}')

#Overall Data Quality Index (DQi) is defined as the average of all the three scores : Average (SQi, Ci, xRefi)
DQi = (SQi + Ci + xRefi) / 3
print(f'DQi: {DQi}')

df_dataset_data_quality = df_dataset_data_quality.withColumn('SQi', F.lit(SQi)).withColumn('Ci', F.lit(Ci)).withColumn('xRefi', F.lit(xRefi)).withColumn('DQi', F.lit(DQi))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # Write out the statistics
# if the notebook receives the "run_time_stamp" parameter from Synapse Ingest the parameter is used to create a folder to store the statistics, if no parameter is received we write the statistics to the default output folder

# CELL ********************


#writeout statistics


df_all_files_data_quality.write \
    .mode("overwrite") \
    .format("delta") \
    .saveAsTable(f"batch_{batch_id}_output_statistics_file_data_quality")

df_dataset_data_quality.write \
    .mode("overwrite") \
    .format("delta") \
    .saveAsTable(f"batch_{batch_id}_output_statistics_dataset_data_quality")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
