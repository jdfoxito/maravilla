// Fabric notebook source

// METADATA ********************

// META {
// META   "kernel_info": {
// META     "name": "synapse_pyspark"
// META   },
// META   "dependencies": {
// META     "lakehouse": {
// META       "default_lakehouse_name": "",
// META       "default_lakehouse_workspace_id": ""
// META     }
// META   }
// META }

// MARKDOWN ********************

// ## This notebook calculates the pagerank score for each node

// MARKDOWN ********************

// ### Load packages

// CELL ********************

// MAGIC %%configure -f
// MAGIC {
// MAGIC     "defaultLakehouse": {
// MAGIC         "name": "ADSD"
// MAGIC     }
// MAGIC }

// METADATA ********************

// META {
// META   "language": "scala",
// META   "language_group": "synapse_pyspark"
// META }

// CELL ********************

import org.apache.spark._
import org.apache.spark.graphx._
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit

// METADATA ********************

// META {
// META   "language": "scala",
// META   "language_group": "synapse_pyspark"
// META }

// PARAMETERS CELL ********************

var edge_path = ""
var page_rank_path = ""
var batch_id = ""
var database_name = ""

// METADATA ********************

// META {
// META   "language": "scala",
// META   "language_group": "synapse_pyspark"
// META }

// MARKDOWN ********************

// ### Load data

// CELL ********************

// val df = spark.read.format("parquet").option("header","true").load(edge_path)

val tableName = s"${database_name}.batch_${batch_id}_output_edges"
val df = spark.table(tableName)

// METADATA ********************

// META {
// META   "language": "scala",
// META   "language_group": "synapse_pyspark"
// META }

// MARKDOWN ********************

// ### Convert edges to integers if not already done

// CELL ********************

val df1 = df.withColumn("entity_target_id_indexed",col("entity_target_id_indexed").cast("Integer")).withColumn("entity_subtarget_id_indexed",col("entity_subtarget_id_indexed").cast("Integer")).withColumn("edge_count",col("edge_count").cast("Integer"))

// METADATA ********************

// META {
// META   "language": "scala",
// META   "language_group": "synapse_pyspark"
// META }

// MARKDOWN ********************

// ### Create vertices

// CELL ********************

val vertices : RDD[(VertexId, Integer)] = df1
    .select(explode(array('entity_target_id_indexed, 'entity_subtarget_id_indexed))) // entity_target_id and entity_subtarget_id are the vertices
    .distinct // we remove duplicates
    .rdd.map(_.getAs[Integer](0)) // transform to RDD
    .zipWithIndex // associate a long index to each vertex
    .map(_.swap)

val vertexDf = vertices.toDF("id", "node")

// METADATA ********************

// META {
// META   "language": "scala",
// META   "language_group": "synapse_pyspark"
// META }

// MARKDOWN ********************

// ### Create edges

// CELL ********************

val edges : RDD[Edge[Integer]] = df1
    .join(vertexDf, df1("entity_target_id_indexed") === vertexDf("node")) // getting the IDs for "entity_target_id"
    .select('entity_target_id_indexed, 'entity_subtarget_id_indexed, 'edge_count, 'id as 'idS)
    .join(vertexDf, df1("entity_subtarget_id_indexed") === vertexDf("node")) // getting the IDs for "entity_subtarget_id"
    .rdd.map(row => // creating the edge using column "edge_count" as metadata 
    Edge(row.getAs[Long]("idS"), row.getAs[Long]("id"), row.getAs[Integer]("edge_count")))

// METADATA ********************

// META {
// META   "language": "scala",
// META   "language_group": "synapse_pyspark"
// META }

// MARKDOWN ********************

// ### Create graph

// CELL ********************

// And finally
val graph = Graph(vertices, edges)

// METADATA ********************

// META {
// META   "language": "scala",
// META   "language_group": "synapse_pyspark"
// META }

// MARKDOWN ********************

// ### Run pagerank

// CELL ********************

var pgrDf = vertexDf.withColumn("pagerank_score",lit(0))
try {
    val pgr = graph.pageRank(0.1)
    val pgrDF = pgr.vertices.toDF("node_id","pagerank_score")
    pgrDf = pgrDF.join(vertexDf, $"node_id"===$"id")
} catch {  
    case e: Exception => println("Exception occurred : " + e)
} 


// METADATA ********************

// META {
// META   "language": "scala",
// META   "language_group": "synapse_pyspark"
// META }

// MARKDOWN ********************

// ### Save dataframe

// CELL ********************

// pgrDf.select(pgrDf("node"),pgrDf("pagerank_score")).toDF("entity_target_id_indexed","pagerank_score").write.mode("overwrite").option("header", "true").format("parquet").save(page_rank_path)



val tableName = s"${database_name}.batch_${batch_id}_working_pagerank_scores"

pgrDf.select(pgrDf("node"), pgrDf("pagerank_score"))
  .toDF("entity_target_id_indexed", "pagerank_score")
  .write
  .mode("overwrite")
  .format("delta")
  .saveAsTable(tableName)

// METADATA ********************

// META {
// META   "language": "scala",
// META   "language_group": "synapse_pyspark"
// META }
