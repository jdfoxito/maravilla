# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse_name": "",
# META       "default_lakehouse_workspace_id": ""
# META     }
# META   }
# META }

# MARKDOWN ********************

# # Change source file to standard schema
# Reads the file with uploaded data and applies the standard naming schema to the columns. The output is dataset with new columns names without any change to the data values.


# CELL ********************

# MAGIC %%configure -f
# MAGIC {
# MAGIC     "defaultLakehouse": {
# MAGIC         "name": "ADSD"
# MAGIC     }
# MAGIC }

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

batch_id = ''
statistics_path = ''
data_encoding = ''
data_separator = ''
transaction_uncompressed_path = ''
transaction_schema_applied_path = ''
output_container_path = ''
database_name = ''
specific_domain_naming_path = ''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import datetime
import time
import csv
import pyodbc
from pyspark.sql.functions import col, year, month, dayofmonth, isnan, when, count, current_timestamp
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType, TimestampType, FloatType

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# Define the schema explicitly
schema = StructType([
    StructField("ADSDColumnName", StringType(), True),
    StructField("DomainColumnName", StringType(), True)
])

df_specific_domain_naming = spark.read.json(specific_domain_naming_path)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Create new row to append to DataFrame
row = [[f'{batch_id}', 'Starting Data Loading']]
columns = ['batch_id', 'status']
new_batch_status_df = spark.createDataFrame(row, columns)
new_batch_status_df = new_batch_status_df.withColumn("date_submitted", current_timestamp())
new_batch_status_df = new_batch_status_df.withColumn("update_time_stamp", current_timestamp())

# update the batch status table with new row to use in Power BI and webapp
# Opción 2: Guardar como tabla Delta registrada en el catálogo
new_batch_status_df.write \
    .mode("append") \
    .format("delta") \
    .saveAsTable("batch_status")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def generate_schema_string(dataframe):
    schema_string = ""
    for name in dataframe.schema.fieldNames():
        schema_string += "[" + name + "] "
        datatype = str(dataframe.schema[name].dataType.simpleString())
        if datatype == 'double': datatype = 'float'
        if datatype == 'string': datatype = 'nvarchar(MAX)'
        if datatype == 'timestamp': datatype = 'datetime2(7)'
        schema_string += datatype + ", "
    return schema_string[:-2]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def deep_ls(path: str, max_depth=1):
    """
    List all files and folders in specified path and
    subfolders within maximum recursion depth.
    """

    # List all files in path
    li = mssparkutils.fs.ls(path)

    # Return all files
    for x in li:
        if x.size != 0:
            yield x

    # If the max_depth has not been reached, start
    # listing files and folders in subdirectories
    if max_depth > 1:
        for x in li:
            if x.size != 0:
                continue
            for y in deep_ls(x.path, max_depth - 1):
                yield y

    # If max_depth has been reached,
    # return the folders
    else:
        for x in li:
            if x.size == 0:
                yield x

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def rename_from_domain_specific_to_adsd(df) :
    # Convertir el DataFrame de mapeo a un diccionario
    mapping_dict = df_specific_domain_naming.select("DomainColumnName", "ADSDColumnName").rdd.collectAsMap()
    
    # Renombrar las columnas del DataFrame original
    for old_name, new_name in mapping_dict.items():
        df = df.withColumnRenamed(old_name, new_name)
    
    return df

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

transaction_schema_applied_path

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def applySchema(fileName, fullFilePath) :
    df = spark.read.csv(fullFilePath, sep=data_separator,inferSchema=True, header=True)

    df = rename_from_domain_specific_to_adsd(df)

    col_names = ['main_operation_type', 'entity_target_id','segment_group','entity_c_id', 'entity_subtarget_id', 
    'document_type', 'document_id','transaction_date01','entity_c_name','tax_rate01',
    'currency01','exchange_rate_main','payment_type01','transaction_reference_a','tax_type01',
    'transaction_origin','item_code01','item_description01','item_spec_volume_q01','item_spec_volume_q02',
    'item_spec_volume_q05','item_spec_volume_q03','item_spec_volume_q06','item_spec_value_q01','item_spec_value_q02',
    'item_spec_volume_q04','item_spec_price_q01','item_spec_tax_q01']

    df = df.select(*col_names)

    # Change data types
    df = df.withColumn('main_operation_type' , df['main_operation_type'].cast(StringType()))
    df = df.withColumn('entity_target_id' , df['entity_target_id'].cast(StringType()))
    df = df.withColumn('segment_group' , df['segment_group'].cast(StringType()))
    df = df.withColumn('entity_c_id' , df['entity_c_id'].cast(StringType()))
    df = df.withColumn('entity_subtarget_id' , df['entity_subtarget_id'].cast(StringType()))
    df = df.withColumn('document_type' , df['document_type'].cast(StringType()))
    df = df.withColumn('document_id' , df['document_id'].cast(StringType()))
    df = df.withColumn('transaction_date01' , df['transaction_date01'].cast(TimestampType()))
    df = df.withColumn('entity_c_name' , df['entity_c_name'].cast(StringType()))
    df = df.withColumn('tax_rate01' , df['tax_rate01'].cast(IntegerType()))
    df = df.withColumn('currency01' , df['currency01'].cast(StringType()))
    df = df.withColumn('exchange_rate_main' , df['exchange_rate_main'].cast(FloatType()))
    df = df.withColumn('payment_type01' , df['payment_type01'].cast(StringType()))
    df = df.withColumn('transaction_reference_a' , df['transaction_reference_a'].cast(StringType()))
    df = df.withColumn('tax_type01' , df['tax_type01'].cast(StringType()))
    df = df.withColumn('transaction_origin' , df['transaction_origin'].cast(StringType()))
    df = df.withColumn('item_code01' , df['item_code01'].cast(StringType()))
    df = df.withColumn('item_description01' , df['item_description01'].cast(StringType()))
    df = df.withColumn('item_spec_volume_q01' , df['item_spec_volume_q01'].cast(FloatType()))
    df = df.withColumn('item_spec_volume_q02' , df['item_spec_volume_q02'].cast(FloatType()))
    df = df.withColumn('item_spec_volume_q05' , df['item_spec_volume_q05'].cast(FloatType()))
    df = df.withColumn('item_spec_volume_q03' , df['item_spec_volume_q03'].cast(FloatType()))
    df = df.withColumn('item_spec_volume_q06' , df['item_spec_volume_q06'].cast(FloatType()))
    df = df.withColumn('item_spec_value_q01' , df['item_spec_value_q01'].cast(FloatType()))
    df = df.withColumn('item_spec_value_q02' , df['item_spec_value_q02'].cast(FloatType()))
    df = df.withColumn('item_spec_volume_q04' , df['item_spec_volume_q04'].cast(FloatType()))
    df = df.withColumn('item_spec_price_q01' , df['item_spec_price_q01'].cast(FloatType()))
    df = df.withColumn('item_spec_tax_q01' , df['item_spec_tax_q01'].cast(FloatType()))
     
    df.write.mode("overwrite").csv(f'{transaction_schema_applied_path}/{fileName}', header=True, sep=data_separator)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

file_names = deep_ls(transaction_uncompressed_path,20)
for filename in file_names:  
    print(f'Processing file: {filename.name}')
    print(f'Processing file: {filename.path}')
    applySchema(filename.name.replace('.CSV',''), filename.path)
    

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
