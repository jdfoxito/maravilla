# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse_name": "",
# META       "default_lakehouse_workspace_id": ""
# META     }
# META   }
# META }

# CELL ********************

# MAGIC %%configure -f
# MAGIC {
# MAGIC     "defaultLakehouse": {
# MAGIC         "name": "ADSD"
# MAGIC     }
# MAGIC }

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

batch_id = ''
output_container_path = ''
database_name = ''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import pyodbc
from pyspark.sql.functions import col, year, month, dayofmonth, isnan, when, count, current_timestamp, to_date, lit
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType, TimestampType

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from delta.tables import DeltaTable
from pyspark.sql.functions import lit, current_timestamp


date_submitted_df = spark.sql(f"""
    SELECT date_submitted
    FROM {database_name}.batch_status
    WHERE batch_id = '{batch_id}'
    ORDER BY update_time_stamp DESC
    LIMIT 1
""")

date_submitted = date_submitted_df.first()["date_submitted"] if date_submitted_df.count() > 0 else None


new_batch_status_df = spark.createDataFrame(
    [[batch_id, 'Anomaly Detection Complete']],
    ['batch_id', 'status']
).withColumn("date_submitted", lit(date_submitted)) \
 .withColumn("update_time_stamp", current_timestamp())

print("Updating status record:")
new_batch_status_df.show(truncate=False)

# MERGE the table
table_name = f"{database_name}.batch_status"
deltaTable = DeltaTable.forName(spark, table_name)

deltaTable.alias("target").merge(
    new_batch_status_df.alias("source"),
    "target.batch_id = source.batch_id"
).whenMatchedUpdate(set = {
    "status": "source.status",
    "update_time_stamp": "source.update_time_stamp"
}).whenNotMatchedInsert(values = {
    "batch_id": "source.batch_id",
    "status": "source.status",
    "date_submitted": "source.date_submitted",
    "update_time_stamp": "source.update_time_stamp"
}).execute()

print(f"Status updated successfully in {table_name}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
