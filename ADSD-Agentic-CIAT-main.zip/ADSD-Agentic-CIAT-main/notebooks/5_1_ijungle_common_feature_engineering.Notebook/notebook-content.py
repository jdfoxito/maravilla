# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse_name": "",
# META       "default_lakehouse_workspace_id": ""
# META     }
# META   }
# META }

# CELL ********************

# MAGIC %%configure -f
# MAGIC {
# MAGIC     "defaultLakehouse": {
# MAGIC         "name": "ADSD"
# MAGIC     }
# MAGIC }

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.types import StructType, StructField, IntegerType, DateType, FloatType, StringType, BooleanType
import pyspark.sql.functions as F
from pyspark.ml.feature import VectorAssembler, StandardScaler, StringIndexer, StandardScalerModel, StringIndexerModel

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

batch_id = ''
transformed_data_path = ''
prepped_data_path = ''
features_path = ''
model_path = ''
id_feat = ''
date_feat = ''
first_year = ''
allowed_null_pct = ''
training = ''
time_slice_folder = ''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

if transformed_data_path != "":
    #transformed_data_path = transformed_data_path + "/" + time_slice_folder
    transformed_data_path = f"{database_name}.batch_{batch_id}_output_transformed_data_{time_slice_folder}"
    print(f'transformed_data_path = {transformed_data_path}')
if prepped_data_path != "":
    prepped_data_path = "/".join(prepped_data_path.split("/")[:-1]) + "/" + time_slice_folder + "/" + prepped_data_path.split("/")[-1]
    #prepped_data_path = prepped_data_path.replace("/prepped_data", f"/{time_slice_folder}/prepped_data")
    print(f'prepped_data_path = {prepped_data_path}')
if features_path != "":
    features_path = "/".join(features_path.split("/")[:-1]) + "/" + time_slice_folder + "/" + features_path.split("/")[-1]
    print(f'features_path = {features_path}')
if model_path != "":
    model_path = model_path + "/" + time_slice_folder
    print(f'model_path = {model_path}')

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Casting parameters
#id_feat = eval(id_feat)
id_feat = [i for i in id_feat.split(",")]
first_year = int(first_year)
allowed_null_pct = float(allowed_null_pct)
training = eval(training)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

schema = StructType([
    StructField('entity_target_id', StringType(), False),
    StructField('transaction_date01', DateType(), False),
    StructField('number_of_transactions', IntegerType(), False),
    StructField('total_entity_subtarget', IntegerType(), False),
    StructField('total_document_typeC',FloatType(), False),
    StructField('total_document_typeB',FloatType(), False),
    StructField('total_document_typeA',FloatType(), False),
    StructField('total_document_typeD',FloatType(), False),
    StructField('total_document_typeE',FloatType(), False),
    StructField('number_of_transactions_to_self',FloatType(), False),
    StructField('total_document_to_self',FloatType(), False),
    StructField('item_spec_volume_q01',FloatType(), False),
    StructField('item_spec_volume_q02',FloatType(), False),
    StructField('item_spec_volume_q05',FloatType(), False),
    StructField('item_spec_volume_q03',FloatType(), False),
    StructField('item_spec_volume_q06',FloatType(), False),
    StructField('item_spec_value_q01',FloatType(), False),
    StructField('item_spec_value_q02',FloatType(), False),
    StructField('item_spec_volume_q04',FloatType(), False),
    StructField('item_spec_price_q01',FloatType(), False),
    StructField('item_spec_tax_q01',FloatType(), False),
    StructField('number_of_entity_c_operations',IntegerType(), False),
    StructField('total_entity_c_entities',FloatType(), False),
    StructField('total_entity_c_value',FloatType(), False),
    StructField('pagerank_score',FloatType(), False),
    StructField('entity_target_type_c01',StringType(), False),
    StructField('entity_target_tax_spec_c03',StringType(), False),
    StructField('entity_target_tax_spec_c04',StringType(), False),
    StructField('entity_target_tax_spec_c05',StringType(), False),
    StructField('entity_target_tax_spec_c06',StringType(), False),
    StructField('entity_target_spec_q01',StringType(), False), #IntegerType()
    StructField('entity_target_date_01',StringType(), False),  #DateType()
    StructField('entity_target_date_02',StringType(), False), #DateType()
    StructField('entity_target_date_03',StringType(), False), #DateType()
    StructField('entity_target_spec_q03',StringType(), False), #FloatType()
    StructField('entity_target_spec_q02',StringType(), False), #BooleanType()
    StructField('entity_target_spec_q04',StringType(), False), #FloatType()
    StructField('entity_target_spec_q05',StringType(), False), #FloatType()
    StructField('entity_target_spec_q06',StringType(), False), #FloatType()
    StructField('entity_target_spec_q07',StringType(), False), #FloatType()
    StructField('entity_target_spec_q08',StringType(), False), #FloatType()
    StructField('entity_target_spec_q09',StringType(), False), #FloatType()
    StructField('entity_target_spec_q10',StringType(), False), #FloatType()
    StructField('entity_target_spec_q11',StringType(), False), #FloatType()
    StructField('entity_target_spec_g01',StringType(), False),
    StructField('entity_target_spec_g02',StringType(), False),
    StructField('entity_target_spec_g03',StringType(), False),
    StructField('ratio_item_spec_value_q02_entity_c_value',FloatType(), False),
    StructField('ratio_item_spec_tax_q01_item_spec_value_q02',FloatType(), False),
    StructField('ratio_item_spec_value_q02_entity_target_spec_q01',FloatType(), False),
    StructField('ratio_total_entity_subtarget_total_entity_c_entities',FloatType(), False),
    StructField('ratio_in_out',FloatType(), False),
    StructField('segment_01',FloatType(), False),
    StructField('item_spec_price_q01_segment_01',FloatType(), False),
    StructField('segment_02',FloatType(), False),
    StructField('item_spec_price_q01_segment_02',FloatType(), False),
    StructField('segment_03',FloatType(), False),
    StructField('item_spec_price_q01_segment_03',FloatType(), False),
    StructField('segment_04',FloatType(), False),
    StructField('item_spec_price_q01_segment_04',FloatType(), False),
    StructField('segment_05',FloatType(), False),
    StructField('item_spec_price_q01_segment_05',FloatType(), False),
    StructField('min_distance_from_entity_c',IntegerType(), False),
    StructField('min_distance_from_entity_subtarget',IntegerType(), False),
    StructField('min_depth_of_network',IntegerType(), False),
    StructField('min_place_in_network',FloatType(), False),
    StructField('max_distance_from_entity_c',IntegerType(), False),
    StructField('max_distance_from_subtarget_entity',IntegerType(), False),
    StructField('max_depth_of_network',IntegerType(), False),
    StructField('max_place_in_network',FloatType(), False),
    StructField('entity_target_id_indexed', IntegerType(), False)
])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#Removing schema for now, until upsteam schema is formalized.
#df = spark.read.schema(schema).parquet(
#Dropping entity_target_id because now index of entity_target_id is used for id_feat. 
#May be better to transform the column in here and drop entity_target_id_indexed from the transformed datasets.
print('Loading transformed data')

#df = spark.read.parquet(
#    transformed_data_path,
#    header=True
#).drop('entity_target_id')

df = spark.read.table(transformed_data_path ).drop('entity_target_id')

m = df.count()
print(f'Number of records: {m}')

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

for row in schema:
    #For now continue until schema is fully stable.
    continue
    column = row.name
    dataType = row.dataType
    #exclude dateType for now
    if dataType == DateType(): continue
    df = df.withColumn(column,F.col(column).cast(dataType))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Removing features with high percentaje of null values
allowed_null_feats = []
for feat in df.columns:
    null_pct = df.where(F.isnull(feat)).count()/m 
    if null_pct <= allowed_null_pct:
        allowed_null_feats.append(feat)
    else:
        print(f'Feature {feat} has {null_pct*100:.2f}% of null values')

df_allowed_null = df.select(allowed_null_feats)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Removing null values
df_notnull = df_allowed_null

for feat in df_notnull.schema.fieldNames():
    df_notnull = df_notnull.where(~F.isnull(feat))

print(f'Not null records: {df_notnull.count():,}')

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Removing records previous to first year parameter
df_recent = df_notnull.where(F.year(date_feat) >= first_year)
print(f'Number of records since {first_year}: {df_recent.count():,}')

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Date data augmentation
df_augmented = df_recent.withColumn('_dayofweek', F.dayofweek(date_feat))
df_augmented = df_augmented.withColumn('_dayofmonth', F.dayofmonth(date_feat))
df_augmented = df_augmented.withColumn('_dayofyear', F.dayofyear(date_feat))
df_augmented = df_augmented.withColumn('_weekofyear', F.weekofyear(date_feat))
df_augmented = df_augmented.withColumn('_month', F.month(date_feat))
df_augmented = df_augmented.withColumn('_quarter', F.quarter(date_feat))
df_augmented = df_augmented.withColumn('_year', F.year(date_feat))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Date to int
date_feats = [x['name'] for x in df_augmented.schema.jsonValue()['fields'] if x['type']=='date']

df_date_int = df_augmented

for feat in date_feats:
    print(f'Casting date feature {feat} to int ...')
    df_date_int = df_date_int.withColumn(feat+'_int', F.unix_timestamp(feat))


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

string_feats = [x['name'] for x in df_date_int.schema.jsonValue()['fields'] if x['type']=='string']
string_feats_indexed = [feat+'_indexed' for feat in string_feats]
if training:
    indexer = StringIndexer(inputCols=string_feats, outputCols=string_feats_indexed, stringOrderType='frequencyDesc')
    model = indexer.fit(df_date_int)
    model.write().overwrite().save(model_path + '/' + '_ijungle_indexer.pkl')
else:
    model = StringIndexerModel.load(model_path + '/' + '_ijungle_indexer.pkl')
df_string_indexed = model.transform(df_date_int)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Assemble features to scalate
columns = df_string_indexed.schema.fieldNames()
feats_to_remove = id_feat + date_feats + string_feats
feats = [feat for feat in columns if not feat in feats_to_remove]
assembler = VectorAssembler(inputCols=feats, outputCol='feats')
df_assembled = assembler.transform(df_string_indexed).select(id_feat + ['feats'])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Store features 
if training:
    spark.createDataFrame(zip(range(len(feats)), feats),['id','feat']).write.mode('overwrite').parquet(features_path)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Scalate features
if training:
    scaler = StandardScaler(inputCol='feats', outputCol='scaled')
    model = scaler.fit(df_assembled)
    model.write().overwrite().save(model_path + '/' + '_ijungle_scaler.pkl')
else:
    model = StandardScalerModel.load(model_path + '/' + '_ijungle_scaler.pkl')
df_scaled = model.transform(df_assembled).select(id_feat+['scaled'])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Write scaled data as parquet files
df_scaled.write.mode('overwrite').parquet(prepped_data_path)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
