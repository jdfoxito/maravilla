# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse_name": "",
# META       "default_lakehouse_workspace_id": ""
# META     }
# META   }
# META }

# CELL ********************

# MAGIC %%configure -f
# MAGIC {
# MAGIC     "defaultLakehouse": {
# MAGIC         "name": "ADSD"
# MAGIC     }
# MAGIC }

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import joblib
from pyspark.ml.functions import vector_to_array
from pyspark.ml.feature import IndexToString, StringIndexerModel
import pyspark.sql.functions as F
import pandas as pd
from io import BytesIO

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

batch_id = ''
best_iforest_path = ''
prepped_data_path = ''
results_path = ''
id_feat = ''
id_feat_types = ''
time_slice_folder = ''
model_path = ''
database_name = ''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

if best_iforest_path != "":
    best_iforest_path = "/".join(best_iforest_path.split("/")[:-1]) + "/" + time_slice_folder + "/" + best_iforest_path.split("/")[-1]
    print(f'best_iforest_path = {best_iforest_path}')
if prepped_data_path != "":
    prepped_data_path = "/".join(prepped_data_path.split("/")[:-1]) + "/" + time_slice_folder + "/" + prepped_data_path.split("/")[-1]
    print(f'prepped_data_path = {prepped_data_path}')
if results_path != "":
    results_path = results_path + "/" + time_slice_folder
    print(f'results_path = {results_path}')

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Casting parameters
id_feat = [i for i in id_feat.split(",")]
id_feat_types = [i for i in id_feat_types.split(",")]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

model_bytes = spark.read.parquet(best_iforest_path).take(1)[0]['model']
clf = joblib.load(BytesIO(model_bytes))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df = spark.read.parquet(prepped_data_path)
print("Number of records: {:,}".format(df.count()))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

num_feats = len(df.take(1)[0]['scaled'])
print(f'Number of features: {str(num_feats)}')
df_unassembled = df.withColumn('f', vector_to_array("scaled")).select(id_feat + [F.col("f")[i] for i in range(num_feats)])
print("Number of records of inference dataset: {:,}".format(df_unassembled.count()))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def ijungle_predict(id_feat, clf):
    def _fun(iterator):
        for pdf in iterator:
            pdf.set_index(id_feat, inplace=True)
            _predict = clf.predict(pdf)
            _score = clf.score_samples(pdf)
            pdf.reset_index(drop=False, inplace=True)
            pdf_out = pd.DataFrame()
            pdf_out[id_feat] = pdf[id_feat]
            pdf_out['predict'] = _predict
            pdf_out['score'] = _score
            yield(pdf_out)
    return(_fun)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

dcc_str = ", ".join([x[0]+" "+x[1] for x in zip(id_feat, id_feat_types)]) + ", predict int, score float"
df_results = df_unassembled.mapInPandas(ijungle_predict(id_feat, clf),dcc_str)



vocab_df_final = spark.sql(
    f"SELECT entity_target_id, entity_target_id_indexed "
    f"FROM {database_name}.batch_{batch_id}_working_entity_id_vocab"
)
df_results = df_results.join(vocab_df_final, on="entity_target_id_indexed", how="left")




# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_results.write.mode('overwrite').parquet(results_path)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


table_name = f"{database_name}.batch_{batch_id}_output_results_{time_slice_folder}"

print(f"Saving results to table: {table_name}")

# Guardar en tabla Delta
df_results.write \
    .mode("overwrite") \
    .format("delta") \
    .saveAsTable(table_name)

print(f"Results saved successfully to {table_name}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
