# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

# MAGIC %%configure -f
# MAGIC {
# MAGIC     "defaultLakehouse": {
# MAGIC         "name": "ADSD"
# MAGIC     }
# MAGIC }


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

transaction_path = ''
working_container_name = ''
batch_id = ''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import json
from notebookutils import mssparkutils

#transaction_path =  "input/transaction"


files = mssparkutils.fs.ls(f"Files/{transaction_path}")

zip_files = [
    {"name": f.name, "path": f.path}
    for f in files
    if f.name.endswith(".zip")
]

#mssparkutils.notebook.exit(json.dumps(zip_files))

zip_files

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import os
import shutil
import gzip
import zipfile


base_path = f"/lakehouse/default/Files/{transaction_path}"
target_dir = f"/lakehouse/default/Files/{working_container_name}/{batch_id}/data_engineering/transaction/uncompressed"

# 2. LIST SOURCE FILES
print("-" * 60)
print(f"Scanning for source files in: {base_path}")
print("-" * 60)

if os.path.exists(base_path):
    # List all files and filter by compression extensions
    all_entries = os.listdir(base_path)
    files_to_process = [f for f in all_entries if f.endswith(('.zip', '.gz'))]
    
    if files_to_process:
        print(f"Found {len(files_to_process)} file(s) for decompression:")
        for idx, file_name in enumerate(files_to_process, 1):
            # Calculate size in MB for visibility
            size_mb = os.path.getsize(os.path.join(base_path, file_name)) / (1024**2)
            print(f"  {idx}. {file_name} ({size_mb:.2f} MB)")
    else:
        print("No .zip or .gz files found in the /test directory.")
else:
    print(f"Error: The path {base_path} does not exist. Please check your Lakehouse structure.")
    files_to_process = []

print("-" * 60)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# 3. STREAMING DECOMPRESSION FUNCTION
def decompress_massive_file(file_path, dest_dir):
    """
    Decompresses files using streaming chunks to prevent Driver OOM (Out of Memory)
    errors when handling large datasets (15GB+).
    """
    file_name = os.path.basename(file_path)
    os.makedirs(dest_dir, exist_ok=True)
    
    # Case: GZIP
    if file_path.endswith('.gz'):
        output_path = os.path.join(dest_dir, file_name[:-3])
        print(f"\n>>> Decompressing GZ: {file_name}")
        with gzip.open(file_path, 'rb') as f_in:
            with open(output_path, 'wb') as f_out:
                # Use 10MB buffer chunks for stability
                shutil.copyfileobj(f_in, f_out, length=1024*1024*10)

    # Case: ZIP
    elif file_path.endswith('.zip'):
        print(f"\n>>> Processing ZIP archive: {file_name}")
        with zipfile.ZipFile(file_path, 'r') as z:
            for member in z.infolist():
                # Skip directory entries
                if member.is_dir(): continue
                
                output_path = os.path.join(dest_dir, member.filename)
                # Create sub-directories if the ZIP has internal folder structures
                os.makedirs(os.path.dirname(output_path), exist_ok=True)
                
                print(f"    Extracting: {member.filename} ({member.file_size / 1e9:.2f} GB)")
                with z.open(member) as f_in:
                    with open(output_path, 'wb') as f_out:
                        shutil.copyfileobj(f_in, f_out, length=1024*1024*10)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# 4. EXECUTION BLOCK
if files_to_process:

    print("Starting decompression process...")
    
    for file in files_to_process:
        full_path = os.path.join(base_path, file)
        try:
            decompress_massive_file(full_path, target_dir)
        except Exception as e:
            print(f"Critical error processing {file}: {e}")
            
    print("\n" + "="*60)
    print("PROCESS COMPLETED SUCCESSFULLY")
    print(f"Uncompressed files are located in: {target_dir}")
    print("="*60)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
