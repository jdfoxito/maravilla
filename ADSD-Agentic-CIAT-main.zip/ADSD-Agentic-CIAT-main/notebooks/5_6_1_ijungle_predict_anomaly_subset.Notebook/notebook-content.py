# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse_name": "",
# META       "default_lakehouse_workspace_id": ""
# META     }
# META   }
# META }

# CELL ********************

# MAGIC %%configure -f
# MAGIC {
# MAGIC     "defaultLakehouse": {
# MAGIC         "name": "ADSD"
# MAGIC     }
# MAGIC }

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import joblib
from pyspark.ml.functions import vector_to_array
from pyspark.ml.feature import IndexToString, StringIndexerModel
import pyspark.sql.functions as F
import pandas as pd
from io import BytesIO

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

batch_id = ''
best_iforest_path = ''
prepped_data_path = ''
results_path = ''
id_feat = ''
id_feat_types = ''
time_slice_folder = ''
model_path = ''
database_name = ''
specific_domain_naming_path = ''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_specific_domain_naming = spark.read.json(specific_domain_naming_path)
rename_map = df_specific_domain_naming.select("ADSDColumnName", "DomainColumnName") \
    .rdd.collectAsMap()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


time_slice_folder = "by_year"

table_name = f"{database_name}.batch_{batch_id}_output_results_{time_slice_folder}"

df_top1000 = spark.table(table_name) \
    .orderBy("score", ascending=True) \
    .limit(1000)

df_top1000.show()

print(f"Results successfully read from {table_name}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from delta.tables import DeltaTable
from pyspark.sql.functions import year, month

# Load master_adsd_table
df_master = spark.table(f"batch_{batch_id}_master_adsd_table")

# Get unique entity_target_ids from anomalies results
# importer_id in output_results maps to entity_target_id in master_adsd_table
df_anomaly_ids = df_top1000.select("entity_target_id").distinct()

# Join to get only master records that belong to anomalous issuers

df_anomalies_master = df_master.join(
    df_anomaly_ids,
    on="entity_target_id",
    how="left_semi"
)



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Add partition columns
df_anomalies_master = df_anomalies_master \
    .withColumn("year", year("transaction_date01")) \
    .withColumn("month", month("transaction_date01"))

# Write optimized table
print('Writing anomalies_master_table...')
df_anomalies_master.write \
    .mode("overwrite") \
    .format("delta") \
    .partitionBy("year", "month") \
    .option("overwriteSchema", "true") \
    .option("delta.autoOptimize.optimizeWrite", "true") \
    .option("delta.autoOptimize.autoCompact", "true") \
    .saveAsTable(f"batch_{batch_id}_anomalies_master_table")

# Optimize with Z-ORDER matching master_adsd_table strategy
print('Optimizing anomalies_master_table...')
delta_anomalies = DeltaTable.forName(spark, f"batch_{batch_id}_anomalies_master_table")

delta_anomalies.optimize().executeZOrderBy(
    "entity_target_id",
    "entity_subtarget_id",
    "document_type",
    "segment_group"
)

print('anomalies_master_table ready.')

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from delta.tables import DeltaTable

def append_with_partition_guard(df, table_name, partition_cols=None, opts={}):
    table_exists = spark.catalog.tableExists(table_name)

    if not table_exists:
        writer = df.write.format("delta").mode("append").options(**opts)
        if partition_cols:
            writer = writer.partitionBy(*partition_cols)
        writer.saveAsTable(table_name)
        print(f"Table created: {table_name}")
    else:
        df.write \
            .format("delta") \
            .mode("append") \
            .options(**opts) \
            .insertInto(table_name)
        print(f"Inserted in existing table: {table_name}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def apply_domain_rename(df, rename_map):
    """Mapping to specific domain"""
    for old_name, new_name in rename_map.items():
        if old_name in df.columns:
            df = df.withColumnRenamed(old_name, new_name)
    return df

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Check domain mapping of entity_target_id
rename_map = df_specific_domain_naming.select("ADSDColumnName", "DomainColumnName") \
    .rdd.collectAsMap()

domain_entity_target_id = rename_map.get("entity_target_id", "NOT FOUND")
print(f"entity_target_id → {domain_entity_target_id}")

domain_transaction_date01 = rename_map.get("transaction_date01", "NOT FOUND")
print(f"transaction_date01 → {domain_transaction_date01}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F
from delta.tables import DeltaTable
from datetime import date


run_date = date.today()

print(f"batch_id  : {batch_id}")
print(f"database  : {database_name}")
print(f"run_date  : {run_date}")

# ── Table names ───────────────────────────────────────────────────────────
src_master = f"{database_name}.batch_{batch_id}_anomalies_master_table"
src_scores = f"{database_name}.batch_{batch_id}_output_results_by_year"
tgt_master = f"{database_name}.all_batches_anomalies_master_table"
tgt_scores = f"{database_name}.all_batches_scores"


# ── 1. Load raw batch tables ──────────────────────────────────────────────
df_master = spark.table(src_master)
df_scores = spark.table(src_scores)

# Rename the current batch columns to match the specific domian columns in the all_batches_tables
df_master = apply_domain_rename(df_master, rename_map)
df_scores = apply_domain_rename(df_scores, rename_map)

print(f"Loaded master : {df_master.count()} rows")
print(f"Loaded scores : {df_scores.count()} rows")

# ── 2. Inject batch_id + batch_run_date as first two columns ─────────────
batch_cols = [
    F.lit(batch_id).alias("batch_id"),
    F.lit(str(run_date)).cast("date").alias("batch_run_date"),
]

df_master = df_master \
    .select(*batch_cols, "*") \
    .withColumn("transaction_year",
                F.year(F.to_date(F.col(domain_transaction_date01))))

df_scores = df_scores.select(*batch_cols, "*")

# ── 3. Write options — all Delta properties set here ─────────────────────
write_opts = {
    "mergeSchema"                        : "true",
    "delta.autoOptimize.optimizeWrite"   : "true",
    "delta.autoOptimize.autoCompact"     : "true",
    "delta.deletedFileRetentionDuration" : "interval 30 days",
    "delta.logRetentionDuration"         : "interval 60 days",
}

# ── 4. Append master — partitioned by batch_id + transaction_year ───
append_with_partition_guard(
    df_master, tgt_master,
    partition_cols=["batch_id", "transaction_year"],
    opts=write_opts
)

append_with_partition_guard(
    df_scores, tgt_scores,
    opts=write_opts
)

print(f"Appended master : {df_master.count()} rows")
print(f"Appended scores : {df_scores.count()} rows")

# ── 5. Optimize — Z-order using DeltaTable Python API ────────────────────
#    master: batch → transaction date → entity (most common filter order)
#    scores: batch → entity only (no transaction date in scores)

dt_master = DeltaTable.forName(spark, tgt_master)
dt_scores = DeltaTable.forName(spark, tgt_scores)

dt_master.optimize().executeZOrderBy(domain_entity_target_id)

dt_scores.optimize().executeZOrderBy(
    "batch_id",
    domain_entity_target_id
)

print("Z-order optimization complete.")

# ── 6. Vacuum — remove old deleted files using DeltaTable Python API ──────
#    720 hours = 30 days of history retained for time-travel

dt_master.vacuum(720)
dt_scores.vacuum(720)

print("Vacuum complete. Pipeline done.")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
