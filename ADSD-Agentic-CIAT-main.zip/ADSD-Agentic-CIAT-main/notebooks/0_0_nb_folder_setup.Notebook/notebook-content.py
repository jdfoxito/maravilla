# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

# MAGIC %%configure -f
# MAGIC {
# MAGIC     "defaultLakehouse": {
# MAGIC         "name": "ADSD"
# MAGIC     }
# MAGIC }


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# Required directory structure
REQUIRED_DIRECTORIES = [
    "input/entity",
    "input/exchange_rate",
    "input/intermediate_naming",
    "input/transaction",
    "model",
    "output",
    "working",
]

BASE_PATH = 'Files'

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# ============================================================
# IMPORTS
# ============================================================

from notebookutils import mssparkutils
import json
from datetime import datetime

print(f"[{datetime.now()}] Starting directory structure validation for Lakehouse")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# ============================================================
# HELPER FUNCTIONS
# ============================================================

def directory_exists(path: str) -> bool:
    """Check if a directory exists in the Lakehouse."""
    try:
        mssparkutils.fs.ls(path)
        return True
    except Exception:
        return False

def create_directory(path: str) -> bool:
    """Create a directory in the Lakehouse. Returns True if successful."""
    try:
        mssparkutils.fs.mkdirs(path)
        return True
    except Exception as e:
        print(f"ERROR creating {path}: {str(e)}")
        return False

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# ============================================================
# MAIN VALIDATION & CREATION LOGIC
# ============================================================

results = []

print(f"\n{'='*60}")
print(f"  DIRECTORY STRUCTURE CHECK ")
print(f"{'='*60}\n")

for relative_path in REQUIRED_DIRECTORIES:
    full_path = f"{BASE_PATH}/{relative_path}"
    
    exists = directory_exists(full_path)
    
    if exists:
        status = "EXISTS"
        action = "No action needed"
        icon   = " OK "
    else:
        print(f"  MISSING: {relative_path}")
        created = create_directory(full_path)
        if created:
            status = "CREATED"
            action = "Directory created successfully"
            icon   = " NEW "
        else:
            status = "ERROR"
            action = "Failed to create directory"
            icon   = " FAILED "
    
    print(f"  {icon} [{status}] Files/{relative_path}")
    
    results.append({
        "path":   f"Files/{relative_path}",
        "status": status,
        "action": action,
    })

print(f"\n{'='*60}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
