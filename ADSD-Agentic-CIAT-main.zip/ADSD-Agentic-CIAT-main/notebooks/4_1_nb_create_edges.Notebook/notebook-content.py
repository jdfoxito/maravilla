# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse_name": "",
# META       "default_lakehouse_workspace_id": ""
# META     }
# META   }
# META }

# MARKDOWN ********************

# ## This notebook creates the edges to calculate some of the graph features

# MARKDOWN ********************

# ### Load Packages

# CELL ********************

# MAGIC %%configure -f
# MAGIC {
# MAGIC     "defaultLakehouse": {
# MAGIC         "name": "ADSD"
# MAGIC     }
# MAGIC }

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.ml.feature import StringIndexer
from pyspark.sql.functions import col, when
import pyspark.sql.functions as F
import time
import numpy as np

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# NEW
from pyspark.sql import Row
from pyspark.sql.functions import col, when
import pyspark.sql.functions as F
import time
import numpy as np
# NEW

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ### Load Input Files

# PARAMETERS CELL ********************

batch_id = ''
transaction_cleaned_path = ''
edge_path = ''
model_path = ''
heatmap_path = ''
database_name = ''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print('Loading cleaned transaction files')
df = spark.sql(f"SELECT * FROM {database_name}.batch_{batch_id}_cleaned_data")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ### Create edges and save output

# CELL ********************




print('Creating edges for dataset')

# Build entity_target_id vocabulary distributed — replaces StringIndexer.fit()
# Same ordering: frequency DESC, alphabetical ASC tiebreaker
vocab_df = (
    df.groupBy("entity_target_id")
      .agg(F.count("*").alias("_freq"))
      .orderBy(F.desc("_freq"), F.asc("entity_target_id"))
)

# zipWithIndex: assigns sequential 0-based index without additional shuffle
# Order is preserved from the already-sorted DataFrame
vocab_rdd = (
    vocab_df.select("entity_target_id")
            .rdd
            .map(lambda x: x[0])
            .zipWithIndex()
)
vocab_df_final = vocab_rdd.map(
    lambda x: Row(entity_target_id=x[0], entity_target_id_indexed=int(x[1]))
).toDF()

# num_labels: assigned to unseen values — replicates handleInvalid='keep'
num_labels = vocab_df_final.count()

# Persist vocabulary to Delta — replaces the .pkl model artifact
# Consumed by notebooks 4_3, 5_5 and 5_6
vocab_df_final.write.mode("overwrite").format("delta") \
    .saveAsTable(f"{database_name}.batch_{batch_id}_working_entity_id_vocab")

# Reload from Delta so Spark has table statistics for join optimization
vocab_df_final = spark.sql(
    f"SELECT entity_target_id, entity_target_id_indexed "
    f"FROM {database_name}.batch_{batch_id}_working_entity_id_vocab"
)

# Apply vocab to entity_target_id — replaces model.transform(df) first call
df = df.join(vocab_df_final, on="entity_target_id", how="left") \
       .withColumn(
           "entity_target_id_indexed",
           F.coalesce(col("entity_target_id_indexed"), F.lit(num_labels)).cast("Integer")
       )

# Apply SAME vocab to entity_subtarget_id — replaces model.setInputCol() + model.transform()
# Subtargets not present in issuer vocab get num_labels (handleInvalid='keep' exact behavior)
subtarget_vocab = vocab_df_final.select(
    col("entity_target_id").alias("entity_subtarget_id"),
    col("entity_target_id_indexed").alias("entity_subtarget_id_indexed")
)
df = df.join(subtarget_vocab, on="entity_subtarget_id", how="left") \
       .withColumn(
           "entity_subtarget_id_indexed",
           F.coalesce(col("entity_subtarget_id_indexed"), F.lit(num_labels)).cast("Integer")
       )



all_issuers = df.groupby('entity_target_id_indexed').count()
edges = df.groupby('entity_target_id_indexed','entity_subtarget_id_indexed').count()
edges = edges.toDF(*['seller','buyer','edge_count'])
edges_trimmed = edges.join(all_issuers,edges['buyer']==all_issuers['entity_target_id_indexed']).drop('entity_target_id_indexed').drop('count')
edges_trimmed_df = edges_trimmed.toDF(*['entity_target_id_indexed','entity_subtarget_id_indexed','edge_count'])
edges_trimmed_df = edges_trimmed_df.withColumn("entity_target_id_equals_entity_subtarget_id",when(col("entity_target_id_indexed")==col("entity_subtarget_id_indexed"),1).otherwise(0))
edges_trimmed_df = edges_trimmed_df.filter(col("entity_target_id_equals_entity_subtarget_id")==0).drop("entity_target_id_equals_entity_subtarget_id")



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print('Saving edges to ADLS')

edges_trimmed_df \
    .write \
    .mode("overwrite") \
    .format("delta") \
    .saveAsTable(f"batch_{batch_id}_output_edges")

#edges_trimmed_df.write.mode("overwrite").option("header", "true").save(edge_path,format='parquet')

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ### Create activiy heatmap and save output

# CELL ********************

print('Creating heatmap of dataset')

df = df.withColumn('DD_code',col('segment_group').substr(1,2))
activity_types = df.groupby('entity_target_id').agg(F.array_distinct(F.collect_list('DD_code')))
code_receiver_counts = df.groupby('DD_code','entity_subtarget_id').count()
code_versus_code = code_receiver_counts.join(activity_types,code_receiver_counts['entity_subtarget_id']==activity_types['entity_target_id']).collect()

heatmap_cells = {i:{j:0 for j in range(10,100)} for i in range(10,100)}
dd_code_hist = {i:0 for i in range(10,100)}
for c in code_versus_code:
    dd_code_hist[int(c[0])] += 1
    for d in c[4]:
        heatmap_cells[int(c[0])][int(d)] += c[2]

heatmap_list = []
for i in heatmap_cells:
    user_dict = {"DD_issue":i}
    receive_dict = {"DD_receive_fraction_{}".format(j):float(heatmap_cells[i][j]/max(1,np.sum([heatmap_cells[i][j] for j in heatmap_cells[i]] ))) for j in heatmap_cells[i] if j < 11}
    user_dict.update(receive_dict)
    heatmap_list.append(user_dict)

dd_issue = []
dd_receive = []
fraction = []
for row in heatmap_list:
    ddi = row['DD_issue']
    for key in row:
        if 'rec' not in key: continue
        ddr = int(key[-2:])
        frac = row[key]
        dd_issue += [ddi]
        dd_receive += [ddr]
        fraction += [frac]

heatmap_list = []
for a,b,c in zip(dd_issue, dd_receive, fraction):
    heatmap_list += [
        {"issuer_activity_code":a,
        "receiver_activity_code":b,
        "fraction":c }
    ]

print('Saving heatmap to ADLS')

heatmap_df = spark.createDataFrame(heatmap_list)
#heatmap_df.write.mode("overwrite").option("header", "true").save(heatmap_path,format='parquet')

heatmap_df \
    .write \
    .mode("overwrite") \
    .format("delta") \
    .saveAsTable(f"batch_{batch_id}_output_heatmap")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
