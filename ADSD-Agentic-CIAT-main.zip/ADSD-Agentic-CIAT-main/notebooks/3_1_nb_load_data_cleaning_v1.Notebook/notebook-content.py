# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse_name": "",
# META       "default_lakehouse_workspace_id": ""
# META     }
# META   }
# META }

# CELL ********************

# MAGIC %%configure -f
# MAGIC {
# MAGIC     "defaultLakehouse": {
# MAGIC         "name": "ADSD"
# MAGIC     }
# MAGIC }

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

batch_id = ''
transaction_schema_applied_path = ''
transaction_cleaned_path = ''
statistics_path = ''
exchange_rates_file = ''
data_separator = ''
data_encoding = ''
drop_records_threshold = 0
local_currency_iso_code = ''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

drop_records_threshold = float(drop_records_threshold)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import datetime
import csv
import pandas as pd
import os
from datetime import date
from calendar import monthrange
import time
from pyspark.sql.functions import col, year, month, dayofmonth, isnan, when, count, length, trim
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType, TimestampType, FloatType

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def deep_ls(path: str, max_depth=1):
    """
    List all files and folders in specified path and
    subfolders within maximum recursion depth.
    """

    # List all files in path
    li = mssparkutils.fs.ls(path)

    # Return all files
    for x in li:
        if x.size != 0:
            yield x

    # If the max_depth has not been reached, start
    # listing files and folders in subdirectories
    if max_depth > 1:
        for x in li:
            if x.size != 0:
                continue
            for y in deep_ls(x.path, max_depth - 1):
                yield y

    # If max_depth has been reached,
    # return the folders
    else:
        for x in li:
            if x.size == 0:
                yield x

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_total_nulls(df, colname) :
    if [dtype for name, dtype in df.dtypes if name == colname][0] not in ("timestamp", "date"):
        total_rows = df.where(col(colname).contains('None') | col(colname).contains('NULL') | (col(colname) == '' ) | col(colname).isNull() | isnan(colname)).count()
    else:
        total_rows = df.where(col(colname).contains('None') | col(colname).contains('NULL') | (col(colname) == '' ) | col(colname).isNull()).count()
    return total_rows

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def apply_cleansing_rules(fileName, fullFilePath, df_exchange_rate) :
    from pyspark.sql.functions import col, year, month, dayofmonth, isnan, when, count, length, trim
    from pyspark.sql.types import StringType, DateType, FloatType, IntegerType
    
    df = spark.read.csv(fullFilePath, sep=data_separator,inferSchema=True, header=True)

    # Change data types
    df = df.withColumn('main_operation_type' , df['main_operation_type'].cast(StringType()))
    df = df.withColumn('entity_target_id' , df['entity_target_id'].cast(StringType()))
    df = df.withColumn('segment_group' , df['segment_group'].cast(StringType()))
    df = df.withColumn('entity_c_id' , df['entity_c_id'].cast(StringType()))
    df = df.withColumn('entity_subtarget_id' , df['entity_subtarget_id'].cast(StringType()))
    df = df.withColumn('document_type' , df['document_type'].cast(StringType()))
    df = df.withColumn('document_id' , df['document_id'].cast(StringType()))
    df = df.withColumn('transaction_date01' , df['transaction_date01'].cast(TimestampType()))
    df = df.withColumn('entity_c_name' , df['entity_c_name'].cast(StringType()))
    df = df.withColumn('tax_rate01' , df['tax_rate01'].cast(IntegerType()))
    df = df.withColumn('currency01' , df['currency01'].cast(StringType()))
    df = df.withColumn('exchange_rate_main' , df['exchange_rate_main'].cast(FloatType()))
    df = df.withColumn('payment_type01' , df['payment_type01'].cast(StringType()))
    df = df.withColumn('transaction_reference_a' , df['transaction_reference_a'].cast(StringType()))
    df = df.withColumn('tax_type01' , df['tax_type01'].cast(StringType()))
    df = df.withColumn('transaction_origin' , df['transaction_origin'].cast(StringType()))
    df = df.withColumn('item_code01' , df['item_code01'].cast(StringType()))
    df = df.withColumn('item_description01' , df['item_description01'].cast(StringType()))
    df = df.withColumn('item_spec_volume_q01' , df['item_spec_volume_q01'].cast(FloatType()))
    df = df.withColumn('item_spec_volume_q02' , df['item_spec_volume_q02'].cast(FloatType()))
    df = df.withColumn('item_spec_volume_q05' , df['item_spec_volume_q05'].cast(FloatType()))
    df = df.withColumn('item_spec_volume_q03' , df['item_spec_volume_q03'].cast(FloatType()))
    df = df.withColumn('item_spec_volume_q06' , df['item_spec_volume_q06'].cast(FloatType()))
    df = df.withColumn('item_spec_value_q01' , df['item_spec_value_q01'].cast(FloatType()))
    df = df.withColumn('item_spec_value_q02' , df['item_spec_value_q02'].cast(FloatType()))
    df = df.withColumn('item_spec_volume_q04' , df['item_spec_volume_q04'].cast(FloatType()))
    df = df.withColumn('item_spec_price_q01' , df['item_spec_price_q01'].cast(FloatType()))
    df = df.withColumn('item_spec_tax_q01' , df['item_spec_tax_q01'].cast(FloatType()))

    # Remove rows where null values are under the allowed threshold
    total_rows_in_dataset = df.count() 
    print(f'Total rows in dataset to be cleaned: {total_rows_in_dataset}')

    #entity_target_id.	Drop records if < 1%.Stop, review, fix if > 1%
    total_rows_null_entity_target_id = get_total_nulls(df,"entity_target_id")
    print(f'Total rows with null entity_target_id: {total_rows_null_entity_target_id}')
    per_rows_null_entity_target_id = total_rows_null_entity_target_id / total_rows_in_dataset
    if (per_rows_null_entity_target_id <= drop_records_threshold) :
        df.na.drop(subset=["entity_target_id"])

    #transaction_date01. Drop records if < 1%.Stop, review, fix if > 1%
    total_rows_null_transaction_date01 = get_total_nulls(df,"transaction_date01")
    per_rows_null_transaction_date01 = total_rows_null_transaction_date01 / total_rows_in_dataset
    if (per_rows_null_entity_target_id <= drop_records_threshold) :
        df.na.drop(subset=["transaction_date01"])    

    #item_spec_price_q01. Drop records if < 1%.Stop, review, fix if > 1%
    total_rows_null_item_spec_price_q01 = get_total_nulls(df,"item_spec_price_q01")
    per_rows_null_item_spec_price_q01 = total_rows_null_item_spec_price_q01 / total_rows_in_dataset
    if (per_rows_null_item_spec_price_q01 <= drop_records_threshold) :
        df = df.filter(col("item_spec_price_q01").isNotNull() & ~isnan("item_spec_price_q01")) 

    #item_spec_tax_q01. Drop records if < 1%.Stop, review, fix if > 1% 
    total_rows_null_item_spec_tax_q01 = get_total_nulls(df,"item_spec_tax_q01")
    per_rows_null_item_spec_tax_q01 = total_rows_null_item_spec_tax_q01 / total_rows_in_dataset
    if (per_rows_null_item_spec_tax_q01 <= drop_records_threshold) :
        df = df.filter(col("item_spec_tax_q01").isNotNull() & ~isnan("item_spec_tax_q01")) 


    #item_spec_price_q01. Replace with 0.0 if Null. Replace iwth 0.0 if any alpha character
    df = df.fillna(value=0, subset=['item_spec_price_q01'])

    #item_spec_tax_q01. Replace with 0.0 if Null. Replace iwth 0.0 if any alpha character
    df = df.fillna(value=0, subset=['item_spec_tax_q01'])

    #document_id	String	8 to 100-character code that identifies the document number.	Set to “no_identified_document”
    df = df.fillna(value="no_identified_document", subset=['document_id'])

    #Currency	String	Currency code according to ISO 4217	Set to local currency
    df = df.fillna(value=local_currency_iso_code, subset=['currency01'])

    #document_type	string	Alphanumeric code that identifies the type of electronic voucher: Example: I: transaction, D: Debit Note, C: Credit Note, O: Order, G: Goods certificate, T: Tender Receipt, TC: Tender Contract, etc.	Set to “I” = to transaction
    df = df.fillna(value='A', subset=['document_type'])

    #entity_subtarget_id	String	Tax ID associated with the entity who received the transaction.	Set to no_identified_receiver
    df = df.fillna(value="no_identified_receiver", subset=['entity_subtarget_id'])

    #entity_subtarget_id. Set to no_identified_receiver if any value > 256 characters.
    df = df.withColumn("entity_subtarget_id", \
              when(length(df["entity_subtarget_id"]) > 256, 'no_identified_entity_subtarget_id').otherwise(df["entity_subtarget_id"]))

    #segment_group	String	Indicates the code of the economic activity to which the electronic receipt corresponds.	
    #Replace with activiy code "999999" if Null.
    #Replace with activiy code "999999" if lenght > 8 digits.
    #Replace with activiy code "999999" if length code < 4 digits
    
    df = df.fillna(value="999999", subset=['segment_group'])


    #item_spec_volume_q06.	Set to 0 (currency)
    df = df.fillna(value=0, subset=['item_spec_volume_q06'])

    #item_spec_value_q01.	Set to 0 (currency)
    df = df.fillna(value=0, subset=['item_spec_value_q01'])

    #item_spec_value_q02. Set to 0 (currency)
    df = df.fillna(value=0, subset=['item_spec_value_q02'])

    #item_spec_volume_q04.	Set to 0 (currency)
    df = df.fillna(value=0, subset=['item_spec_volume_q04'])

    #item_spec_volume_q01.	Set to 0
    df = df.fillna(value=0, subset=['item_spec_volume_q01'])

    #item_spec_volume_q02.	Set to 0
    df = df.fillna(value=0, subset=['item_spec_volume_q02'])

    #item_spec_volume_q05. Set to 0
    df = df.fillna(value=0, subset=['item_spec_volume_q05'])

    #item_spec_volume_q03. Set to 0
    df = df.fillna(value=0, subset=['item_spec_volume_q03'])  
  
    #main_operation_type	Replace with "NT" if Null
    df = df.fillna(value="NT", subset=['main_operation_type'])

    #entity_c_id	Replace with "NT" if Null
    df = df.fillna(value="NT", subset=['entity_c_id'])

    #entity_c_name	Replace with "00" if Null
    df = df.fillna(value="00", subset=['entity_c_name'])

    #tax_rate01	Replace with "00" if Null
    df = df.fillna(value="00", subset=['tax_rate01'])

    #exchange_rate_main. Replace with 1.0 if null
    df = df.fillna(value=1, subset=['exchange_rate_main'])


    # merge df and df_er so df has all the exchange rates
    
    df = df.join(df_exchange_rate, (df['currency01'] == df_exchange_rate['currency_exchange_rate']) & (df['transaction_date01'] == df_exchange_rate['date_exchange_rate']), how='left')    

    #set the local currency to rows where the currency does not need to be converted

    df = df.fillna(value=local_currency_iso_code, subset=['currency_exchange_rate'])
    df = df.fillna(value=1, subset=['exchange_rate_value'])

    #remove columns no longer needed

    df = df.drop('date_exchange_rate') 


    # apply exchange rates and create new columns for freshly transformed columns
    monetary_cols = ['item_spec_volume_q01',
                    'item_spec_tax_q01',
                    'item_spec_volume_q02',
                    'item_spec_volume_q03',
                    'item_spec_volume_q05',
                    'item_spec_volume_q06',
                    'item_spec_value_q01',
                    'item_spec_value_q02',
                    'item_spec_volume_q04',
                    'item_spec_price_q01']
    for col in monetary_cols:
        transformed_col = 'transformed_' + col
        df = df.withColumn(transformed_col,  df[col]*df['exchange_rate_value'])

    #remove columns no longer needed
    df = df.drop('currency_exchange_rate') 

    #return the cleansed dataset for this file
    return df
    

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # Data cleaning 
# 
# In this code we read all the loaded files and we apply the cleaning rules, new columns are created using the exchange rate

# CELL ********************


from delta.tables import DeltaTable
from pyspark.sql.functions import year, month

# read in exchange rate file
print('Reading in exchange rate dictionary')
df_exchangerate = spark.read.csv(exchange_rates_file, sep=data_separator,inferSchema=True, header=True).toPandas()

print('Extracting exchange rate info')
ignore_cols = ['ISO_CODE','DESCRIPTION']
# only read in exchange rate values
dates = [x for x in df_exchangerate.columns if x not in ignore_cols]
exchange_rate_ll = []

for row in df_exchangerate.iterrows():
    # ISO_CODE is basically just currency
    country = row[1]['ISO_CODE']
    for date in dates:
        # modify date format to match that of original df dates
        transaction_date01_parts = str(pd.to_datetime(date).date()).split('-')
        transaction_date01 = transaction_date01_parts[0] + '-' + transaction_date01_parts[1] + '-' + transaction_date01_parts[2]
        # remove commas from exchange_rate num values (e.g. 1,000)
        exchange_rate = float(row[1][date])
        exchange_rate_ll.append([country,transaction_date01,exchange_rate])


df_er = pd.DataFrame(exchange_rate_ll,columns=['currency_exchange_rate','date_exchange_rate','exchange_rate_value'])

#Create PySpark DataFrame from Pandas
df_exchange_rate =spark.createDataFrame(df_er) 


file_names = mssparkutils.fs.ls(transaction_schema_applied_path)

firstFile = True
for filename in file_names:  
    print(f'Applying cleansing rules for transaction file: {filename.name}')
    df_cleansed_file_data = apply_cleansing_rules(filename.name, filename.path, df_exchange_rate)
    
    if firstFile == True:
        df_all_cleansed_data = df_cleansed_file_data
        firstFile = False
    else:
        df_all_cleansed_data = df_all_cleansed_data.union(df_cleansed_file_data)


df_all_cleansed_data.write \
    .mode("overwrite") \
    .format("delta") \
    .saveAsTable(f"batch_{batch_id}_cleaned_data")

print(f'batch_{batch_id}_cleaned_data saved.')

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Save master_adsd_table optimized for Power BI / DAX
from delta.tables import DeltaTable
from pyspark.sql.functions import year, month

# Read back from saved table to avoid any lazy evaluation issues
df_master = df_all_cleansed_data \
    .withColumn("year", year("transaction_date01")) \
    .withColumn("month", month("transaction_date01"))

# Write master_adsd_table
print('Writing master_adsd_table...')
df_master.write \
    .mode("overwrite") \
    .format("delta") \
    .partitionBy("year", "month") \
    .option("delta.autoOptimize.optimizeWrite", "true") \
    .option("delta.autoOptimize.autoCompact", "true") \
    .saveAsTable(f"batch_{batch_id}_master_adsd_table")

# Optimize
print('Optimizing master_adsd_table...')
delta_table = DeltaTable.forName(spark, f"batch_{batch_id}_master_adsd_table")

delta_table.optimize().executeZOrderBy(
    "entity_target_id",
    "entity_subtarget_id",
    "document_type",
    "segment_group"
)

print('master_adsd_table ready.')


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
