# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse_name": "",
# META       "default_lakehouse_workspace_id": ""
# META     }
# META   }
# META }

# CELL ********************

# MAGIC %%configure -f
# MAGIC {
# MAGIC     "defaultLakehouse": {
# MAGIC         "name": "ADSD"
# MAGIC     }
# MAGIC }

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import pyodbc
from pyspark.sql.types import StructType, StructField, StringType
from pyspark.sql import SparkSession
from pyspark.sql.functions import col
import pandas as pd  # Assuming the dataframe conversion is required


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

specific_domain_naming_path = ''
database_name = ''
batch_id = ''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************



# Define the schema explicitly
schema = StructType([
    StructField("ADSDColumnName", StringType(), True),
    StructField("DomainColumnName", StringType(), True)
])

df_specific_domain_naming = spark.read.json(specific_domain_naming_path)



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # Tables to be renamed


# CELL ********************

# List of table names
table_names = [
    "_output_edges",
    "_output_heatmap",
    "_output_ijungle_output_by_day",
    "_output_ijungle_output_by_month",
    "_output_ijungle_output_by_quarter",
    "_output_ijungle_output_by_week",
    "_output_ijungle_output_by_year",
    "_output_ijungle_output_exploded_by_day",
    "_output_ijungle_output_exploded_by_month",
    "_output_ijungle_output_exploded_by_quarter",
    "_output_ijungle_output_exploded_by_week",
    "_output_ijungle_output_exploded_by_year",
    "_output_results_by_day",
    "_output_results_by_month",
    "_output_results_by_quarter",
    "_output_results_by_week",
    "_output_results_by_year",
    "_output_statistics_dataset_data_quality",
    "_output_statistics_file_data_quality",
    "_output_statistics_load_stats",
    "_output_statistics_load_stats_unique_receiver_issuer",
    "_output_transformed_data_by_day",
    "_output_transformed_data_by_month",
    "_output_transformed_data_by_quarter",
    "_output_transformed_data_by_week",
    "_output_transformed_data_by_year",
    "_output_statistics_load_stats_main_entity_profile",
    "_cleaned_data",
    "_master_adsd_table",
    "_anomalies_master_table"
    
]



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# List of columns whose values must be changed to specific domain names
table_columns_to_update = {
    "_output_iJungle_output_by_day": ["feat1", "feat2", "feat3", "feat4", "feat5", "feat6", "feat7", "feat8", "feat9", "feat10"],
    "_output_iJungle_output_by_month": ["feat1", "feat2", "feat3", "feat4", "feat5", "feat6", "feat7", "feat8", "feat9", "feat10"],
    "_output_iJungle_output_by_quarter": ["feat1", "feat2", "feat3", "feat4", "feat5", "feat6", "feat7", "feat8", "feat9", "feat10"],
    "_output_iJungle_output_by_week": ["feat1", "feat2", "feat3", "feat4", "feat5", "feat6", "feat7", "feat8", "feat9", "feat10"],
    "_output_iJungle_output_by_year": ["feat1", "feat2", "feat3", "feat4", "feat5", "feat6", "feat7", "feat8", "feat9", "feat10"],
    "_output_iJungle_output_exploded_by_day": ["feature"],
    "_output_iJungle_output_exploded_by_month": ["feature"],
    "_output_iJungle_output_exploded_by_quarter": ["feature"],
    "_output_iJungle_output_exploded_by_week": ["feature"],
    "_output_iJungle_output_exploded_by_year": ["feature"]
}

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def rename_table_columns(table_name, df_specific_domain_naming):
    """
    Renames columns in a Delta table in Fabric Lakehouse based on the provided mapping.
    
    Parameters:
        table_name (str): Full table name including database (e.g., 'ADSD.batch_cf706fe3_output_results_by_day')
        df_specific_domain_naming (DataFrame): DataFrame with columns 'ADSDColumnName' and 'DomainColumnName'
    
    Returns:
        DataFrame: The renamed dataframe
    """
    
    print(f"Starting column rename for table: {table_name}")
    
    # Create mapping dictionary: ADSDColumnName -> DomainColumnName
    rename_map = df_specific_domain_naming.select("ADSDColumnName", "DomainColumnName") \
        .rdd.collectAsMap()
    
    # Read the current table
    df_original = spark.table(table_name)
    
    print(f"Original columns: {df_original.columns}")
    
    # Rename columns according to the mapping
    df_renamed = df_original
    renamed_count = 0
    
    for old_name, new_name in rename_map.items():
        if old_name in df_renamed.columns:
            df_renamed = df_renamed.withColumnRenamed(old_name, new_name)
            print(f"  Renamed: {old_name} -> {new_name}")
            renamed_count += 1
    
    print(f"New columns: {df_renamed.columns}")
    print(f"Total columns renamed: {renamed_count}")
    
    # Overwrite table with renamed columns
    print(f"Overwriting table with renamed columns...")
    df_renamed.write \
        .mode("overwrite") \
        .format("delta") \
        .option("overwriteSchema", "true") \
        .saveAsTable(table_name)
    
    print(f"Table {table_name} successfully updated with new column names\n")
    
    return df_renamed

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Rename columns for all tables
print(f"Starting batch column rename process for batch_id: {batch_id}")
print(f"Total tables to process: {len(table_names)}")

for table_suffix in table_names:
    # Build full table name: database.batch_{batch_id}{table_suffix}
    full_table_name = f"{database_name}.batch_{batch_id}{table_suffix}"
    
    print(f"\nProcessing: {full_table_name}")
    
    try:
        rename_table_columns(full_table_name, df_specific_domain_naming)
    except Exception as e:
        print(f"Error processing {full_table_name}: {str(e)}")
        continue

tgt_master = f"{database_name}.all_batches_anomalies_master_table"
rename_table_columns(tgt_master, df_specific_domain_naming)

tgt_scores = f"{database_name}.all_batches_scores"
rename_table_columns(tgt_scores, df_specific_domain_naming)

print(f"\nBatch column rename process completed")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.functions import create_map, lit, when, col as spark_col

def update_table_column_values(table_name, columns_to_update, df_specific_domain_naming):
    """
    Updates values in specific columns of a Delta table based on the provided mapping.
    
    Parameters:
        table_name (str): Full table name including database (e.g., 'ADSD.batch_cf706fe3_output_iJungle_output_by_day')
        columns_to_update (list): List of column names whose values need to be updated
        df_specific_domain_naming (DataFrame): DataFrame with columns 'ADSDColumnName' and 'DomainColumnName'
    
    Returns:
        DataFrame: The updated dataframe
    """
    
    print(f"Updating column values for table: {table_name}")
    
    # Read the current table
    df_original = spark.table(table_name)
    
    # Convert df_specific_domain_naming to pandas and then to dictionary for value mapping
    pandas_df = df_specific_domain_naming.toPandas()
    domain_naming_dict = dict(pandas_df.values)
    
    print(f"  Value mappings to apply: {len(domain_naming_dict)} entries")
    
    # Convert dictionary to a structure compatible with create_map()
    mapping_expr = create_map([lit(x) for pair in domain_naming_dict.items() for x in pair])
    
    # Apply transformation to specific columns
    df_updated = df_original
    updated_count = 0
    
    for column_name in columns_to_update:
        if column_name in df_updated.columns:
            df_updated = df_updated.withColumn(
                column_name,
                when(mapping_expr[spark_col(column_name)].isNotNull(), mapping_expr[spark_col(column_name)])
                .otherwise(spark_col(column_name))
            )
            print(f"  Updated values in column: {column_name}")
            updated_count += 1
        else:
            print(f"  Column '{column_name}' not found in table")
    
    print(f"  Total columns updated: {updated_count}")
    
    # Overwrite table with updated values
    print(f"  Saving updated table...")
    df_updated.write \
        .mode("overwrite") \
        .format("delta") \
        .option("overwriteSchema", "true") \
        .saveAsTable(table_name)
    
    print(f"Table {table_name} successfully updated\n")
    
    return df_updated

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Process all tables that need column value updates
print(f"Starting column value update process for batch_id: {batch_id}")
print(f"Total tables to process: {len(table_columns_to_update)}")

for table_suffix, columns_to_update in table_columns_to_update.items():
    # Build full table name: database.batch_{batch_id}{table_suffix}
    full_table_name = f"{database_name}.batch_{batch_id}{table_suffix}"
    
    try:
        update_table_column_values(full_table_name, columns_to_update, df_specific_domain_naming)
    except Exception as e:
        print(f" Error processing {full_table_name}: {str(e)}")
        continue

print(f"\n Column value update process completed")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
