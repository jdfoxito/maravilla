# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse_name": "",
# META       "default_lakehouse_workspace_id": ""
# META     }
# META   }
# META }

# CELL ********************

# MAGIC %%configure -f
# MAGIC {
# MAGIC     "defaultLakehouse": {
# MAGIC         "name": "ADSD"
# MAGIC     }
# MAGIC }

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

batch_id = ''
entity_profile_schema_applied_path = ''
entity_profile_cleaned_path = ''
statistics_path = ''
data_separator = ''
data_encoding = ''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import datetime
import csv
import pandas as pd
from datetime import date
from calendar import monthrange
import time
from pyspark.sql.functions import col, year, month, dayofmonth, isnan, when, count
from pyspark.sql.types import StructType,StructField, StringType, IntegerType, DoubleType, FloatType

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def deep_ls(path: str, max_depth=1):
    """
    List all files and folders in specified path and
    subfolders within maximum recursion depth.
    """

    # List all files in path
    li = mssparkutils.fs.ls(path)

    # Return all files
    for x in li:
        if x.size != 0:
            yield x

    # If the max_depth has not been reached, start
    # listing files and folders in subdirectories
    if max_depth > 1:
        for x in li:
            if x.size != 0:
                continue
            for y in deep_ls(x.path, max_depth - 1):
                yield y

    # If max_depth has been reached,
    # return the folders
    else:
        for x in li:
            if x.size == 0:
                yield x

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # Tax payer profile cleaning

# CELL ********************

fullFilePath = entity_profile_schema_applied_path + 'entity_profile'
df = spark.read.csv(fullFilePath, sep=data_separator,inferSchema=True, header=True)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

col_names = ['entity_profile_target_id', 'entity_target_type_c01','entity_target_tax_spec_c01',
    'entity_target_tax_spec_c02', 'entity_target_tax_spec_c03',
    'entity_target_tax_spec_c04', 'entity_target_tax_spec_c05','entity_target_tax_spec_c06','entity_target_spec_q01',
    'entity_target_date_01', 'entity_target_date_02','entity_target_date_03','entity_target_spec_q02',
    'entity_target_spec_q03','entity_target_spec_q04', 'entity_target_spec_q05',
    'entity_target_spec_q06','entity_target_spec_q07','entity_target_spec_q08',
    'entity_target_spec_q09','entity_target_spec_q10','entity_target_spec_q11',
    'entity_target_spec_g01','entity_target_spec_g02','entity_target_spec_g03']

stringtype_col_names = ['entity_profile_target_id','entity_target_type_c01', 'entity_target_tax_spec_c01',
'entity_target_tax_spec_c02','entity_target_tax_spec_c03','entity_target_tax_spec_c04', 
'entity_target_tax_spec_c05','entity_target_tax_spec_c06','entity_target_spec_g01','entity_target_spec_g02','entity_target_spec_g03']

datetype_col_names = ['entity_target_date_01', 'entity_target_date_02','entity_target_date_03']

numerictype_col_names = ['entity_target_spec_q01',
    'entity_target_spec_q03','entity_target_spec_q04','entity_target_spec_q02','entity_target_spec_q05',
    'entity_target_spec_q06','entity_target_spec_q07','entity_target_spec_q08',
    'entity_target_spec_q09','entity_target_spec_q10','entity_target_spec_q11']

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#change all columns to string type in order to clean it before type conversion
df = df.select([col('`{}`'.format(c)).cast(StringType()).alias(c) for c in col_names])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # Invalid values handling
# 
# In the input dataset several numeric, date and string columns have invalid values like #N/A, -, null, NULL we clean this data here

# CELL ********************

# replace invalid values in columns, string columns will be set to null initially and in the next process we will replace with the proper value specific for each column
for colname in stringtype_col_names:
    df = df.withColumn(colname, 
       when((col(colname) == "")  | (col(colname) == "#N/A") | (col(colname) == "-") | (col(colname) == "null") | (col(colname) == "NULL"), None) 
          .otherwise(col(colname))) 


for colname in numerictype_col_names:
    df = df.withColumn(colname, 
       when((col(colname) == "")  | (col(colname) == "#N/A") | (col(colname) == "-") | (col(colname) == "null") | (col(colname) == "NULL"), 0) 
          .otherwise(col(colname))) 


for colname in datetype_col_names:
    df = df.withColumn(colname, 
       when((col(colname) == "")  | (col(colname) == "#N/A") | (col(colname) == "-") | (col(colname) == "null") | (col(colname) == "NULL"), "31-12-50") 
          .otherwise(col(colname))) 

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#Get All column names and it's types
from pyspark.sql.functions import col,isnan, when, count

for col in df.dtypes:
    print(f'{col[0]} , {col[1]}')


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Find Count of Null, None, NaN of All DataFrame Columns
from pyspark.sql.functions import col,isnan, when, count
df.select([count(when(isnan(c) | col(c).isNull(), c)).alias(c) for c in df.columns]
   ).show(vertical=True)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ## Apply the cleansing rules for each column

# CELL ********************

#entity_target_type_c01	StringType	Replace Nulls with "no_entity_target_type_c01". Replace any value with three or more characters with "no_entity_type"
df = df.na.fill("no_entity_target_type_c01",["entity_target_type_c01"])

#entity_target_tax_spec_c01	StringType	Replace Nulls with "no_entity_target_tax_spec_c01". Replace any value with three or more characters with "no_entity_target_tax_spec_c01"
df = df.na.fill("no_entity_target_tax_spec_c01",["entity_target_tax_spec_c01"])

#entity_target_tax_spec_c02	StringType	Replace Nulls with "no_entity_target_tax_spec_c02".
df = df.na.fill("no_entity_target_tax_spec_c02",["entity_target_tax_spec_c02"])

#entity_target_tax_spec_c03	StringType	Replace Nulls with "no_entity_target_tax_spec_c03". Convert long names to the two character codes. Convert any local language name to the English equivalent in two digit codes.
df = df.na.fill("no_entity_target_tax_spec_c03",["entity_target_tax_spec_c03"])

#entity_target_tax_spec_c04	StringType	Replace Nulls with code "999999". Replace any value < 3 characters and > 8 characters with code "999999". Replace any value between 4 to 8 characters that is not a numeric string characters with code "999999".
df = df.na.fill("999999",["entity_target_tax_spec_c04"])

#entity_target_tax_spec_c05	StringType	Replace Nulls with code "999999". Replace any value < 3 characters and > 8 characters with code "999999". Replace any value between 4 to 8 characters that is not a numeric string characters with code "999999".
df = df.na.fill("999999",["entity_target_tax_spec_c05"])

#entity_target_tax_spec_c06	StringType	Replace Nulls with code "999999". Replace any value < 3 characters and > 8 characters with code "999999". Replace any value between 4 to 8 characters that is not a numeric string characters with code "999999".
df = df.na.fill("999999",["entity_target_tax_spec_c06"])

#entity_target_spec_q01	IntegerType	Replace Nulls with integer "1". Replace any float number, alpha characters with integer "1".
df = df.na.fill(1,["entity_target_spec_q01"])

#entity_target_date_01	DateType	Replace Nulls with 1900-1-1. Replace any other value different that DataType to 1900-1-1
df = df.na.fill("1900-1-1",["entity_target_date_01"])

#entity_target_date_02	DateType	Replace Nulls with 1900-1-1. Replace any other value different that DataType to 1900-1-1
df = df.na.fill("1900-1-1",["entity_target_date_02"])

#entity_target_date_03	DataType	Replace Nulls with 1900-1-1. Replace any other value different that DataType to 1900-1-1
df = df.na.fill("1900-1-1",["entity_target_date_03"])

#entity_target_spec_q02	IntegerType.	Replace Nulls with value "0". Convert any locale value to English equivalent. Replace any other value to "0"
df = df.na.fill(0,["entity_target_spec_q02"])

#entity_target_spec_q03	FloatType	Replace Nulls with Float Number "1.0". Replace any alpha value with float number "1.0". Covert integers to float.
df = df.na.fill(1.0,["entity_target_spec_q03"])

#entity_target_spec_q04	FloatType	Replace Nulls with Float Number "1.0". Replace any alpha value with float number "1.0". Covert integers to float.
df = df.na.fill(1.0,["entity_target_spec_q04"])

#entity_target_spec_q05	FloatType	Replace Nulls with Float Number "1.0". Replace any alpha value with float number "1.0". Covert integers to float.
df = df.na.fill(1.0,["entity_target_spec_q05"])

#entity_target_spec_q06	FloatType	Replace Nulls with Float Number "1.0". Replace any alpha value with float number "1.0". Covert integers to float.
df = df.na.fill(1.0,["entity_target_spec_q06"])

#entity_target_spec_q07	FloatType	Replace Nulls with Float Number "1.0". Replace any alpha value with float number "1.0". Covert integers to float.
df = df.na.fill(1.0,["entity_target_spec_q07"])

#entity_target_spec_q08	FloatType	Replace Nulls with Float Number "1.0". Replace any alpha value with float number "1.0". Covert integers to float.
df = df.na.fill(1.0,["entity_target_spec_q08"])

#entity_target_spec_q09	FloatType	Replace Nulls with Float Number "1.0". Replace any alpha value with float number "1.0". Covert integers to float.
df = df.na.fill(1.0,["entity_target_spec_q09"])

#entity_target_spec_q10	FloatType	Replace Nulls with Float Number "1.0". Replace any alpha value with float number "1.0". Covert integers to float.
df = df.na.fill(1.0,["entity_target_spec_q10"])

#entity_target_spec_q11	FloatType	Replace Nulls with Float Number "1.0". Replace any alpha value with float number "1.0". Covert integers to float.
df = df.na.fill(1.0,["entity_target_spec_q11"])

#entity_target_spec_g01	StringType	Replace Nulls with code "00". If there are values in the format of "006, 0006, 00006, 000006, etc., keep the first two characters from right to left, and remove the rest. If there are values in zero "0", "00", "000", etc., replace with the code "00".
df = df.na.fill("00",["entity_target_spec_g01"])

#entity_target_spec_g02	StringType	Replace Nulls with "000000" code. Covert any other code out of the range of 000001 to 999999 to "000000"
df = df.na.fill("000000",["entity_target_spec_g02"])

#entity_target_spec_g03	StringType	Replace Nulls with "000000" code. Covert any other code out of t
df = df.na.fill("000000",["entity_target_spec_g03"])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Check we don't have any null values left 
# Find Count of Null, None, NaN of All DataFrame Columns
df.select([count(when(isnan(c) | col(c).isNull(), c)).alias(c) for c in df.columns]
   ).show(vertical=True)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # Write out the clean file to the bronze zone
# 


# CELL ********************

df.write \
    .mode("overwrite") \
    .format("delta") \
    .saveAsTable(f"batch_{batch_id}_entity_cleaned_data")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
