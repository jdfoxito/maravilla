# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse_name": "",
# META       "default_lakehouse_workspace_id": ""
# META     }
# META   }
# META }

# MARKDOWN ********************

# # Change source tax payer profile to standard schema
# Reads the file with the tax payer profiles and applies the standard naming schema to the columns. The output is dataset with new columns names without any change to the data values.


# CELL ********************

# MAGIC %%configure -f
# MAGIC {
# MAGIC     "defaultLakehouse": {
# MAGIC         "name": "ADSD"
# MAGIC     }
# MAGIC }

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

batch_id = ''
entity_profile_uncompressed_path = ''
entity_profile_schema_applied_path = ''
statistics_path = ''
data_separator = ''
data_encoding = ''
specific_domain_naming_path = ''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import datetime
import csv
import pandas as pd
from datetime import date
from calendar import monthrange
import time
import pyodbc
from pyspark.sql.functions import col, year, month, dayofmonth, isnan, when, count
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType, DateType, FloatType

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Define the schema explicitly
schema = StructType([
    StructField("ADSDColumnName", StringType(), True),
    StructField("DomainColumnName", StringType(), True)
])

df_specific_domain_naming = spark.read.json(specific_domain_naming_path)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def deep_ls(path: str, max_depth=1):
    """
    List all files and folders in specified path and
    subfolders within maximum recursion depth.
    """

    # List all files in path
    li = mssparkutils.fs.ls(path)

    # Return all files
    for x in li:
        if x.size != 0:
            yield x

    # If the max_depth has not been reached, start
    # listing files and folders in subdirectories
    if max_depth > 1:
        for x in li:
            if x.size != 0:
                continue
            for y in deep_ls(x.path, max_depth - 1):
                yield y

    # If max_depth has been reached,
    # return the folders
    else:
        for x in li:
            if x.size == 0:
                yield x

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def rename_from_domain_specific_to_adsd(df) :
    # Convertir el DataFrame de mapeo a un diccionario
    mapping_dict = df_specific_domain_naming.select("DomainColumnName", "ADSDColumnName").rdd.collectAsMap()
    
    # Renombrar las columnas del DataFrame original
    for old_name, new_name in mapping_dict.items():
        df = df.withColumnRenamed(old_name, new_name)
    
    return df

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def applySchema(fileName, fullFilePath) :
    df = spark.read.csv(fullFilePath, sep=data_separator,inferSchema=True, header=True)

    df = rename_from_domain_specific_to_adsd(df)

    col_names = ['entity_profile_target_id', 'entity_target_type_c01','entity_target_tax_spec_c01',
    'entity_target_tax_spec_c02', 'entity_target_tax_spec_c03',
    'entity_target_tax_spec_c04', 'entity_target_tax_spec_c05','entity_target_tax_spec_c06','entity_target_spec_q01',
    'entity_target_date_01', 'entity_target_date_02','entity_target_date_03','entity_target_spec_q02',
    'entity_target_spec_q03','entity_target_spec_q04', 'entity_target_spec_q05',
    'entity_target_spec_q06','entity_target_spec_q07','entity_target_spec_q08',
    'entity_target_spec_q09','entity_target_spec_q10','entity_target_spec_q11',
    'entity_target_spec_g01','entity_target_spec_g02','entity_target_spec_g03']

    df = df.select(*col_names)

    # Change data types
    df = df.withColumn('entity_profile_target_id' , df['entity_profile_target_id'].cast(StringType()))
    df = df.withColumn('entity_target_type_c01' , df['entity_target_type_c01'].cast(StringType()))
    df = df.withColumn('entity_target_tax_spec_c01' , df['entity_target_tax_spec_c01'].cast(StringType()))
    df = df.withColumn('entity_target_tax_spec_c02' , df['entity_target_tax_spec_c02'].cast(StringType()))
    df = df.withColumn('entity_target_tax_spec_c03' , df['entity_target_tax_spec_c03'].cast(StringType()))
    df = df.withColumn('entity_target_tax_spec_c04' , df['entity_target_tax_spec_c04'].cast(StringType()))
    df = df.withColumn('entity_target_tax_spec_c05' , df['entity_target_tax_spec_c05'].cast(StringType()))
    df = df.withColumn('entity_target_tax_spec_c06' , df['entity_target_tax_spec_c06'].cast(StringType()))
    df = df.withColumn('entity_target_spec_q01' , df['entity_target_spec_q01'].cast(IntegerType()))
    df = df.withColumn('entity_target_date_01' , df['entity_target_date_01'].cast(DateType()))
    df = df.withColumn('entity_target_date_02' , df['entity_target_date_02'].cast(DateType()))
    df = df.withColumn('entity_target_date_03' , df['entity_target_date_03'].cast(DateType()))
    df = df.withColumn('entity_target_spec_q02' , df['entity_target_spec_q02'].cast(IntegerType()))
    df = df.withColumn('entity_target_spec_q03' , df['entity_target_spec_q03'].cast(FloatType()))
    df = df.withColumn('entity_target_spec_q04' , df['entity_target_spec_q04'].cast(FloatType()))
    df = df.withColumn('entity_target_spec_q05' , df['entity_target_spec_q05'].cast(FloatType()))
    df = df.withColumn('entity_target_spec_q06' , df['entity_target_spec_q06'].cast(FloatType()))
    df = df.withColumn('entity_target_spec_q07' , df['entity_target_spec_q07'].cast(FloatType()))
    df = df.withColumn('entity_target_spec_q08' , df['entity_target_spec_q08'].cast(FloatType()))
    df = df.withColumn('entity_target_spec_q09' , df['entity_target_spec_q09'].cast(FloatType()))
    df = df.withColumn('entity_target_spec_q10' , df['entity_target_spec_q10'].cast(FloatType()))
    df = df.withColumn('entity_target_spec_q11' , df['entity_target_spec_q11'].cast(FloatType()))
    df = df.withColumn('entity_target_spec_g01' , df['entity_target_spec_g01'].cast(StringType()))
    df = df.withColumn('entity_target_spec_g02' , df['entity_target_spec_g02'].cast(StringType()))
    df = df.withColumn('entity_target_spec_g03' , df['entity_target_spec_g03'].cast(StringType()))
    
    df.write.mode("overwrite").option("encoding", "UTF-8").csv(f'{entity_profile_schema_applied_path}entity_profile', header=True, sep=data_separator)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

entity_profile_schema_applied_path

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

file_names = deep_ls(entity_profile_uncompressed_path,20)
for filename in file_names:  
    print(f'Processing file: {filename.name}')
    applySchema(filename.name.replace('.CSV',''), filename.path)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
