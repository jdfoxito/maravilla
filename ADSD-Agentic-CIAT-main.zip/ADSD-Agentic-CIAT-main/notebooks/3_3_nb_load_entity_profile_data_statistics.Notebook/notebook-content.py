# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse_name": "",
# META       "default_lakehouse_workspace_id": ""
# META     }
# META   }
# META }

# MARKDOWN ********************

# # Calculate entity profile data statistics
# Calculates statistics of the uploaded data
# 
# 
# - Total number of entity profiles reported 
# 
# - Total number of nulls 
#  


# CELL ********************

# MAGIC %%configure -f
# MAGIC {
# MAGIC     "defaultLakehouse": {
# MAGIC         "name": "ADSD"
# MAGIC     }
# MAGIC }

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

batch_id = ''
entity_profile_schema_applied_path = ''
entity_profile_cleaned_path = ''
statistics_path = ''
data_separator = ''
data_encoding = ''
database_name = ''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import datetime
import csv
import pandas as pd
from datetime import date
from calendar import monthrange
import time
from pyspark.sql.functions import col, year, month, dayofmonth, isnan, when, count
from pyspark.sql.types import StructType,StructField, StringType, IntegerType, DoubleType, FloatType
import pyodbc

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def deep_ls(path: str, max_depth=1):
    """
    List all files and folders in specified path and
    subfolders within maximum recursion depth.
    """

    # List all files in path
    li = mssparkutils.fs.ls(path)

    # Return all files
    for x in li:
        if x.size != 0:
            yield x

    # If the max_depth has not been reached, start
    # listing files and folders in subdirectories
    if max_depth > 1:
        for x in li:
            if x.size != 0:
                continue
            for y in deep_ls(x.path, max_depth - 1):
                yield y

    # If max_depth has been reached,
    # return the folders
    else:
        for x in li:
            if x.size == 0:
                yield x

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # Entity profile read

# CELL ********************

fullFilePath = entity_profile_schema_applied_path + 'entity_profile'
df = spark.read.csv(fullFilePath, sep=data_separator,inferSchema=True, header=True)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

col_names = ['entity_profile_target_id', 'entity_target_type_c01','entity_target_tax_spec_c01',
    'entity_target_tax_spec_c02', 'entity_target_tax_spec_c03',
    'entity_target_tax_spec_c04', 'entity_target_tax_spec_c05','entity_target_tax_spec_c06','entity_target_spec_q01',
    'entity_target_date_01', 'entity_target_date_02','entity_target_date_03','entity_target_spec_q02',
    'entity_target_spec_q03','entity_target_spec_q04', 'entity_target_spec_q05',
    'entity_target_spec_q06','entity_target_spec_q07','entity_target_spec_q08',
    'entity_target_spec_q09','entity_target_spec_q10','entity_target_spec_q11',
    'entity_target_spec_g01','entity_target_spec_g02','entity_target_spec_g03']

stringtype_col_names = ['entity_profile_target_id','entity_target_type_c01', 'entity_target_tax_spec_c01',
'entity_target_tax_spec_c02','entity_target_tax_spec_c03','entity_target_tax_spec_c04', 
'entity_target_tax_spec_c05','entity_target_tax_spec_c06','entity_target_spec_g01','entity_target_spec_g02','entity_target_spec_g03']

datetype_col_names = ['entity_target_date_01', 'entity_target_date_02','entity_target_date_03']

numerictype_col_names = ['entity_target_spec_q01',
    'entity_target_spec_q03','entity_target_spec_q04','entity_target_spec_q02','entity_target_spec_q05',
    'entity_target_spec_q06','entity_target_spec_q07','entity_target_spec_q08',
    'entity_target_spec_q09','entity_target_spec_q10','entity_target_spec_q11']

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

schema_entity_data_statistics = StructType([ 
    StructField("num_entity_profiles",DoubleType(),True), 
    StructField("num_null_entity_profile_target_id",DoubleType(),True), 
    StructField("num_null_entity_target_type_c01",DoubleType(),True),
    StructField("num_null_entity_target_tax_spec_c01",DoubleType(),True),
    StructField("num_null_entity_target_tax_spec_c02",DoubleType(),True),
    StructField("num_null_entity_target_tax_spec_c03",DoubleType(),True),
    StructField("num_null_entity_target_tax_spec_c04",DoubleType(),True),
    StructField("num_null_entity_target_tax_spec_c05",DoubleType(),True),
    StructField("num_null_entity_target_tax_spec_c06",DoubleType(),True),
    StructField("num_null_entity_target_spec_q01",DoubleType(),True),
    StructField("num_null_entity_target_date_01",DoubleType(),True),
    StructField("num_null_entity_target_date_02",DoubleType(),True),
    StructField("num_null_entity_target_date_03",DoubleType(),True),
    StructField("num_null_entity_target_spec_q02",DoubleType(),True),
    StructField("num_null_entity_target_spec_q03",DoubleType(),True),
    StructField("num_null_entity_target_spec_q04",DoubleType(),True),
    StructField("num_null_entity_target_spec_q05",DoubleType(),True),
    StructField("num_null_entity_target_spec_q06",DoubleType(),True),
    StructField("num_null_entity_target_spec_q07",DoubleType(),True),
    StructField("num_null_entity_target_spec_q08",DoubleType(),True),
    StructField("num_null_entity_target_spec_q09",DoubleType(),True),
    StructField("num_null_entity_target_spec_q10",DoubleType(),True),        
    StructField("num_null_entity_target_spec_q11",DoubleType(),True),        
    StructField("num_null_entity_target_spec_g01",DoubleType(),True),        
    StructField("num_null_entity_target_spec_g02",DoubleType(),True),        
    StructField("num_null_entity_target_spec_g03",DoubleType(),True)
  ])

emptyRDD = spark.sparkContext.emptyRDD()
df_entity_data_statistics = spark.createDataFrame(emptyRDD, schema=schema_entity_data_statistics)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#change all columns to string type in order to clean it before type conversion
df = df.select([col('`{}`'.format(c)).cast(StringType()).alias(c) for c in col_names])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_counts = df.count()   

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # Invalid values handling
# 
# In the input dataset several numeric, date and string columns have invalid values like #N/A, -, null, NULL we clean this data here

# CELL ********************

# replace invalid values in columns, string columns will be set to null initially and in the next process we will replace with the proper value specific for each column
for colname in stringtype_col_names:
    df = df.withColumn(colname, 
       when((col(colname) == "")  | (col(colname) == "#N/A") | (col(colname) == "-") | (col(colname) == "null") | (col(colname) == "NULL"), None) 
          .otherwise(col(colname))) 


for colname in numerictype_col_names:
    df = df.withColumn(colname, 
       when((col(colname) == "")  | (col(colname) == "#N/A") | (col(colname) == "-") | (col(colname) == "null") | (col(colname) == "NULL"), 0) 
          .otherwise(col(colname))) 


for colname in datetype_col_names:
    df = df.withColumn(colname, 
       when((col(colname) == "")  | (col(colname) == "#N/A") | (col(colname) == "-") | (col(colname) == "null") | (col(colname) == "NULL"), "31-12-50") 
          .otherwise(col(colname))) 

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#Get All column names and it's types
from pyspark.sql.functions import col,isnan, when, count

for col in df.dtypes:
    print(f'{col[0]} , {col[1]}')


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Find Count of Null, None, NaN of All DataFrame Columns
from pyspark.sql.functions import col,isnan, when, count
df_null_count = df.select([count(when(isnan(c) | col(c).isNull(), c)).alias(c) for c in df.columns]
   )

row_list = df_null_count.collect()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(row_list)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

new_row = [[df_counts,row_list[0].__getitem__('entity_profile_target_id'), row_list[0].__getitem__('entity_target_type_c01'), 
            row_list[0].__getitem__('entity_target_tax_spec_c01'), row_list[0].__getitem__('entity_target_tax_spec_c02'),
            row_list[0].__getitem__('entity_target_tax_spec_c03'), row_list[0].__getitem__('entity_target_tax_spec_c04'),
            row_list[0].__getitem__('entity_target_tax_spec_c05'), row_list[0].__getitem__('entity_target_tax_spec_c06'),
            row_list[0].__getitem__('entity_target_spec_q01'), row_list[0].__getitem__('entity_target_date_01'),
            row_list[0].__getitem__('entity_target_date_02'), row_list[0].__getitem__('entity_target_date_03'),
            row_list[0].__getitem__('entity_target_spec_q02'), row_list[0].__getitem__('entity_target_spec_q03'),
            row_list[0].__getitem__('entity_target_spec_q04'), row_list[0].__getitem__('entity_target_spec_q05'),
            row_list[0].__getitem__('entity_target_spec_q06'), row_list[0].__getitem__('entity_target_spec_q07'),                                    
            row_list[0].__getitem__('entity_target_spec_q08'), row_list[0].__getitem__('entity_target_spec_q09'),
            row_list[0].__getitem__('entity_target_spec_q10'), row_list[0].__getitem__('entity_target_spec_q11'),
            row_list[0].__getitem__('entity_target_spec_g01'), row_list[0].__getitem__('entity_target_spec_g02'),                                    
            row_list[0].__getitem__('entity_target_spec_g03')]]



    
unknown_df = spark.createDataFrame(new_row)
df_entity_data_statistics = df_entity_data_statistics.union(unknown_df)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_entity_data_statistics.show(vertical=True)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df.groupby('entity_target_tax_spec_c03').count().show()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df.groupby('entity_target_type_c01').count().show()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df.groupby('entity_target_tax_spec_c04').count().show()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.functions import size
from pyspark.sql.functions import col
from pyspark.sql.functions import length

df.filter(length('entity_target_tax_spec_c04') <= 5).count()


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.functions import size
from pyspark.sql.functions import col
from pyspark.sql.functions import length

df.filter(length('entity_target_tax_spec_c04') == 6).count()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.functions import size
from pyspark.sql.functions import col
from pyspark.sql.functions import length

df.filter(length('entity_target_tax_spec_c04') > 6).count()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df.groupby('entity_target_spec_g01').count().show()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df.groupby('entity_target_spec_g02').count().show()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df.groupby('entity_target_spec_g03').count().show()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df.groupby('entity_target_date_01').count().show(100)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # Write out the statistics
# if the notebook receives the "run_time_stamp" parameter from Synapse Ingest the parameter is used to create a folder to store the statistics, if no parameter is received we write the statistics to the default output folder
# 


# CELL ********************

df.write \
    .mode("overwrite") \
    .format("delta") \
    .saveAsTable(f"batch_{batch_id}_output_statistics_load_stats_main_entity_profile")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
