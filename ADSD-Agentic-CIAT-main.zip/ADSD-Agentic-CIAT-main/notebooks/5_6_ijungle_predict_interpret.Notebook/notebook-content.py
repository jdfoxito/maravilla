# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse_name": "",
# META       "default_lakehouse_workspace_id": ""
# META     }
# META   }
# META }

# CELL ********************

# MAGIC %%configure -f
# MAGIC {
# MAGIC     "defaultLakehouse": {
# MAGIC         "name": "ADSD"
# MAGIC     }
# MAGIC }

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import pyspark.sql.functions as F
from pyspark.ml.functions import vector_to_array
from pyspark.ml.feature import IndexToString, StringIndexerModel
from pyspark.sql.types import FloatType
import joblib
import numpy as np
import shap
from io import BytesIO

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

batch_id = ''
best_iforest_path = ''
prepped_data_path = ''
results_path = ''
features_path = ''
interpret_path = ''
id_feat = ''
id_feat_types = ''
score_threshold = ''
time_slice_folder = ''
number_of_interpret_features = ''
database_name = ''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

if best_iforest_path != "":
    best_iforest_path = "/".join(best_iforest_path.split("/")[:-1]) + "/" + time_slice_folder + "/" + best_iforest_path.split("/")[-1]
    print(f'best_iforest_path = {best_iforest_path}')
if prepped_data_path != "":
    prepped_data_path = "/".join(prepped_data_path.split("/")[:-1]) + "/" + time_slice_folder + "/" + prepped_data_path.split("/")[-1]
    print(f'prepped_data_path = {prepped_data_path}')
if results_path != "":
    results_path = results_path + "/" + time_slice_folder
    print(f'results_path = {results_path}')
if features_path != "":
    features_path = "/".join(features_path.split("/")[:-1]) + "/" + time_slice_folder + "/" + features_path.split("/")[-1]
    print(f'features_path = {features_path}')
if interpret_path != "":
    interpret_path = interpret_path + "/" + time_slice_folder
    print(f'interpret_path = {interpret_path}')

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Cast parameters
id_feat = [i for i in id_feat.split(",")]
id_feat_types = [i for i in id_feat_types.split(",")]
score_threshold = float(score_threshold)
number_of_interpret_features = int(number_of_interpret_features)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_results = spark.read.parquet(results_path).where(F.col('score')<=score_threshold)
print(f'Number of records passing anomaly threshold: {df_results.count()}')

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_assembled = df_results.join(spark.read.parquet(prepped_data_path), on=id_feat)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

num_feats = len(df_assembled.take(1)[0]['scaled'])
df_unassembled = df_assembled.withColumn('f', vector_to_array("scaled")).select(id_feat + ['score'] + [F.col("f")[i] for i in range(num_feats)])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

model_bytes = spark.read.parquet(best_iforest_path).take(1)[0]['model']
clf = joblib.load(BytesIO(model_bytes))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

feats = np.array([row['feat'] for row in spark.read.parquet(features_path).orderBy('id').collect()])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

top_n_feat_lst = ['feat'+str(i+1) for i in range(number_of_interpret_features)]
top_n_score_lst = ['score'+str(i+1) for i in range(number_of_interpret_features)]
feat_score_lst = list(np.array(list(zip(top_n_feat_lst, top_n_score_lst))).reshape(len(top_n_feat_lst)*2))
dcc_str = ", ".join([x[0]+" "+x[1] for x in zip(id_feat, id_feat_types)]) + ", score float, "
dcc_str += ", ".join([x[0]+" "+x[1] for x in zip(feat_score_lst + ['sum_other_features'], ['string', 'float']*len(top_n_feat_lst) + ['float'])])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def ijungle_interpret(id_feat, clf, feats, top_n_feat_lst, top_n_score_lst,feat_score_lst):
    def _fun(iterator):
        explainer = shap.TreeExplainer(clf)
        for pdf in iterator:
            pdf.set_index(id_feat + ['score'], inplace=True)
            shap_values = explainer.shap_values(pdf)
            top_feats = feats[shap_values.argsort()[:,:len(top_n_feat_lst)]]
            pdf_out = pdf.reset_index()
            pdf_out = pdf_out[id_feat + ['score']]
            norm_fracs = np.array(pdf_out['score'])/np.sum(shap_values,axis=1)
            top_scores = np.sort(shap_values)[:,:len(top_n_feat_lst)]*norm_fracs.reshape(norm_fracs.shape[0],-1)
            pdf_out[top_n_feat_lst] = top_feats
            pdf_out[top_n_score_lst] = top_scores
            pdf_out['sum_other_features'] = np.sum(np.sort(shap_values)[:,len(top_n_feat_lst):],axis=1)*norm_fracs
            pdf_out = pdf_out[id_feat + ['score'] + feat_score_lst + ['sum_other_features']]
            yield(pdf_out)
    return(_fun)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************




df_interpret = df_unassembled.mapInPandas(ijungle_interpret(id_feat, clf, feats, top_n_feat_lst, top_n_score_lst,feat_score_lst), dcc_str)

# Replaces StringIndexerModel.load() + IndexToString
# Reverse lookup: entity_target_id_indexed -> entity_target_id via distributed join
vocab_df_final = spark.sql(
    f"SELECT entity_target_id, entity_target_id_indexed "
    f"FROM {database_name}.batch_{batch_id}_working_entity_id_vocab"
)
df_interpret = df_interpret.join(vocab_df_final, on="entity_target_id_indexed", how="left")




# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print('Saving interpret data to ADLS')
df_interpret.write.mode('overwrite').parquet(interpret_path)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

table_name_interpret = f"{database_name}.batch_{batch_id}_output_iJungle_output_{time_slice_folder}"

print(f"Saving interpret data to table: {table_name_interpret}")

df_interpret.write \
    .mode("overwrite") \
    .format("delta") \
    .saveAsTable(table_name_interpret)

print(f"Interpret data saved successfully to {table_name_interpret}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

new_rows = ['entity_target_id','transaction_date01']
new_rows += [F.array(F.array(F.lit('total_score'),'score'),*[F.array(feat, score) for idx, (feat, score) in enumerate(zip(top_n_feat_lst, top_n_score_lst))],F.array(F.lit('sum_other_features'),'sum_other_features')).alias("merged_rows")]
df_interpret_by_row = df_interpret.select(*new_rows)
df_interpret_by_row = df_interpret_by_row.select('entity_target_id','transaction_date01',F.explode('merged_rows').alias('key_value'))
df_interpret_by_row = df_interpret_by_row.withColumn('feature',df_interpret_by_row['key_value'].getItem(0)).withColumn('score',df_interpret_by_row['key_value'].getItem(1).cast(FloatType())).drop('key_value')

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

interpret_path_by_row = '/'.join(interpret_path.split("/")[:-1]) + "_exploded" + "/" + interpret_path.split("/")[-1]
print(interpret_path)
print(interpret_path_by_row)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print('Saving interpret by row data to ADLS')
df_interpret_by_row.write.mode('overwrite').parquet(interpret_path_by_row)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Guardar df_interpret_by_row
table_name_exploded = f"{database_name}.batch_{batch_id}_output_iJungle_output_exploded_{time_slice_folder}"

print(f"Saving exploded interpret data to table: {table_name_exploded}")

df_interpret_by_row.write.mode("overwrite").format("delta").saveAsTable(table_name_exploded)
print(f"Exploded: {table_name_exploded}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
