# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse_name": "",
# META       "default_lakehouse_workspace_id": ""
# META     }
# META   }
# META }

# MARKDOWN ********************

# ## This notebook prepares the raw etransaction data for the Anomaly Detector 

# MARKDOWN ********************

# ### Load packages

# CELL ********************

# MAGIC %%configure -f
# MAGIC {
# MAGIC     "defaultLakehouse": {
# MAGIC         "name": "ADSD"
# MAGIC     }
# MAGIC }

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.ml.feature import StringIndexerModel
from pyspark.sql import Row
from pyspark.sql.functions import row_number, lit, col, when, count, sum, countDistinct, desc, unix_timestamp, concat, to_timestamp
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType, DateType, FloatType, ShortType
from pyspark.sql.window import Window
import pyspark.sql.functions as F
from scipy import sparse
import numpy as np
import pandas as pd

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

batch_id = ''
transaction_cleaned_path = ''
entity_profile_cleaned_path = ''
edge_path = ''
page_rank_path = ''
transformed_data_path = ''
model_path = ''
time_slice_list = ''
depth_of_supply_chain_max_iter = ''
database_name = ''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

time_slices = [i for i in time_slice_list.split(",")]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ### Load the data from CSVs in Azure Data Lake Storage into Synapse

# CELL ********************

print('Load cleaned transaction files')
    
# df = spark.read.parquet(transaction_cleaned_path,inferSchema=True, header=True)
df = spark.sql(f"SELECT * FROM {database_name}.batch_{batch_id}_cleaned_data")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print('Load page rank file')

# df_pagerank = spark.read.parquet(page_rank_path,inferSchema=True, header=True)

table_name = f"{database_name}.batch_{batch_id}_working_pagerank_scores"

df_pagerank = spark.table(table_name)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print('Load entity profile file')

# df_profile = spark.read.parquet(entity_profile_cleaned_path,inferSchema=True, header=True)

table_name = f"{database_name}.batch_{batch_id}_entity_cleaned_data"
df_profile = spark.table(table_name)

df_profile = df_profile.withColumn('entity_target_id', col('entity_profile_target_id')).drop('entity_profile_target_id')
df_profile = df_profile.withColumn('entity_target_id', df_profile['entity_target_id'].cast(StringType()))
df_profile = df_profile.withColumn('entity_target_type_c01', df_profile['entity_target_type_c01'].cast(StringType()))
df_profile = df_profile.withColumn('entity_target_tax_spec_c01', df_profile['entity_target_tax_spec_c01'].cast(StringType()))
df_profile = df_profile.withColumn('entity_target_tax_spec_c02', df_profile['entity_target_tax_spec_c02'].cast(StringType()))
df_profile = df_profile.withColumn('entity_target_tax_spec_c03', df_profile['entity_target_tax_spec_c03'].cast(StringType()))
df_profile = df_profile.withColumn('entity_target_tax_spec_c04', df_profile['entity_target_tax_spec_c04'].cast(StringType()))
df_profile = df_profile.withColumn('entity_target_tax_spec_c05', df_profile['entity_target_tax_spec_c05'].cast(StringType()))
df_profile = df_profile.withColumn('entity_target_tax_spec_c06', df_profile['entity_target_tax_spec_c06'].cast(StringType()))
df_profile = df_profile.withColumn('entity_target_spec_q01', df_profile['entity_target_spec_q01'].cast(IntegerType()))
df_profile = df_profile.withColumn('entity_target_date_01', df_profile['entity_target_date_01'].cast(DateType()))
df_profile = df_profile.withColumn('entity_target_date_02', df_profile['entity_target_date_02'].cast(DateType()))
df_profile = df_profile.withColumn('entity_target_date_03', df_profile['entity_target_date_03'].cast(DateType()))
df_profile = df_profile.withColumn('entity_target_spec_q02', df_profile['entity_target_spec_q02'].cast(IntegerType()))
df_profile = df_profile.withColumn('entity_target_spec_q03', df_profile['entity_target_spec_q03'].cast(FloatType()))
df_profile = df_profile.withColumn('entity_target_spec_q04', df_profile['entity_target_spec_q04'].cast(FloatType()))
df_profile = df_profile.withColumn('entity_target_spec_q05', df_profile['entity_target_spec_q05'].cast(FloatType()))
df_profile = df_profile.withColumn('entity_target_spec_q06', df_profile['entity_target_spec_q06'].cast(FloatType()))
df_profile = df_profile.withColumn('entity_target_spec_q07', df_profile['entity_target_spec_q07'].cast(FloatType()))
df_profile = df_profile.withColumn('entity_target_spec_q08', df_profile['entity_target_spec_q08'].cast(FloatType()))
df_profile = df_profile.withColumn('entity_target_spec_q09', df_profile['entity_target_spec_q09'].cast(FloatType()))
df_profile = df_profile.withColumn('entity_target_spec_q10', df_profile['entity_target_spec_q10'].cast(FloatType()))
df_profile = df_profile.withColumn('entity_target_spec_q11', df_profile['entity_target_spec_q11'].cast(FloatType()))
df_profile = df_profile.withColumn('entity_target_spec_g01', df_profile['entity_target_spec_g01'].cast(StringType()))
df_profile = df_profile.withColumn('entity_target_spec_g02', df_profile['entity_target_spec_g02'].cast(StringType()))
df_profile = df_profile.withColumn('entity_target_spec_g03', df_profile['entity_target_spec_g03'].cast(StringType()))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print('Load edges file')
    
# edges_trimmed_df = spark.read.parquet(edge_path,inferSchema=True, header=True)

table_name = f"{database_name}.batch_{batch_id}_output_edges"
edges_trimmed_df = spark.table(table_name)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

model_path

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# print('Load StringIndexer model')




# Load vocabulary table built in 4_1 — replaces StringIndexerModel.load()
print('Load entity_target_id vocabulary from Delta')

vocab_df_final = spark.sql(
    f"SELECT entity_target_id, entity_target_id_indexed "
    f"FROM {database_name}.batch_{batch_id}_working_entity_id_vocab"
)
num_labels = vocab_df_final.count()


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ### Transform data for input to Anomaly Detector

# MARKDOWN ********************

# #### Add new columns

# CELL ********************

spark.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")
for i in ['C','B','A','D','E']:
    df = df.withColumn("document_type_equals_{}".format(i), when(df.document_type == i, 1).otherwise(0))
df = df.withColumn("entity_target_id_equals_entity_subtarget_id",when(col("entity_target_id")==col("entity_subtarget_id"),1).otherwise(0))
df = df.withColumn("total_document_to_self",when(col("entity_target_id")==col("entity_subtarget_id"),col("transformed_item_spec_price_q01")).otherwise(0))

#df = df.withColumn('entity_target_id',col('entity_target_id').cast("Integer"))
#df = df.withColumn('entity_subtarget_id',col('entity_subtarget_id').cast("Integer"))

df = df.withColumn('transaction_date01', to_timestamp(col('transaction_date01')))

df = df.withColumn('day_of_week', F.dayofweek(col('transaction_date01')))
df = df.withColumn('day_of_month', F.dayofmonth(col('transaction_date01')))
df = df.withColumn('day_of_year', F.dayofyear(col('transaction_date01')))
df = df.withColumn('week_of_year', F.weekofyear(col('transaction_date01')))
df = df.withColumn('month', F.month(col('transaction_date01')))
df = df.withColumn('quarter', F.quarter(col('transaction_date01')))
df = df.withColumn('year', F.year(col('transaction_date01')))
df = df.withColumn('hour', F.hour(col('transaction_date01')))
df = df.withColumn('week', F.date_format('transaction_date01', 'W'))
df = df.withColumn('day', F.dayofmonth(col('transaction_date01')))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# #### Index entity_target_id

# CELL ********************

print('Index dataset')




df = df.join(vocab_df_final, on="entity_target_id", how="left") \
       .withColumn(
           "entity_target_id_indexed",
           F.coalesce(col("entity_target_id_indexed"), F.lit(num_labels)).cast("Integer")
       )


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# #### Filter out events with year less than 1950

# CELL ********************

df = df.where(F.year('transaction_date01') >= 1950)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# #### Dataset wide features

# CELL ********************

print('Calculate features')

#First and last transaction_date01 removed so that anomaly detector runs.
df_additional = df.join(df_profile.select('entity_target_id','entity_target_date_02','entity_target_date_03'),on='entity_target_id',how='leftouter')
df_additional = df_additional.groupby('entity_target_id').agg(
    F.min('item_spec_price_q01'),
    F.max('item_spec_price_q01'),
    F.min('item_spec_tax_q01'),
    F.max('item_spec_tax_q01'),
    F.sum('item_spec_price_q01'),
    #F.min('transaction_date01'),
    #F.max('transaction_date01'),
    F.datediff(F.max('transaction_date01'),F.min('transaction_date01')) + 1,
    F.datediff(F.min('transaction_date01'),F.first('entity_target_date_02')) + 1,
    F.datediff(F.min('transaction_date01'),F.first('entity_target_date_03')) + 1
)
df_additional = df_additional.toDF(
    "entity_target_id", "min_item_spec_price_q01_dataset", "max_item_spec_price_q01_dataset", 
    "min_item_spec_tax_q01_dataset","max_item_spec_tax_q01_dataset","item_spec_price_q01_dataset",
    #"first_transaction_date01_dataset","last_transaction_date01_dataset",
    "num_days_submitting_dataset","time_to_submit_reg", "time_to_submit_enroll")

df_month = df.groupby('entity_target_id','month','year').agg(
    F.lit('01'),
    F.countDistinct('entity_subtarget_id')
)
df_month = df_month.toDF('entity_target_id','month','year','day','monthly_total_subtarget_entities')
df_month = df_month.withColumn('date',F.concat_ws('-',col('year'),col('month'),col('day')).cast('date'))
df_month = df_month.toDF('entity_target_id','month','year','day','monthly_total_subtarget_entities','date')
w1 = Window.orderBy('date')
df_month = df_month.withColumn('end_date', F.coalesce(F.add_months(F.lead('date').over(w1),-1),'date'))
df_month = df_month.toDF('entity_target_id','month','year','day','monthly_total_subtarget_entities','date','end_date')
df_month = df_month.selectExpr("entity_target_id", """
    inline_outer(
        transform(
            sequence(0,int(months_between(end_date, date)+1)),
            i -> (add_months(date,i) as date, IF(i=0,monthly_total_subtarget_entities,0) as monthly_total_subtarget_entities)
        )
    )
""")
df_month = df_month.groupby('entity_target_id').agg(
    F.sum('monthly_total_subtarget_entities'),
    F.count('monthly_total_subtarget_entities')
)
df_month = df_month.toDF("entity_target_id","average_monthly_total_subtarget_entities","denominator")
df_month = df_month.withColumn("average_monthly_total_subtarget_entities",col('average_monthly_total_subtarget_entities')/col('denominator')).drop('denominator')

all_issuers = df.groupby('entity_target_id').count()

df_month_r = df.groupby('entity_subtarget_id','month','year').agg(
    F.lit('01'),
    F.countDistinct('entity_target_id')
)

df_month_r = df_month_r.toDF('entity_target_id','month','year','day','monthly_total_entity_c_entities')
df_month_r = df_month_r.withColumn('date',F.concat_ws('-',col('year'),col('month'),col('day')).cast('date'))
df_month_r = df_month_r.join(all_issuers,on=['entity_target_id'],how='inner').drop('count')
w1 = Window.orderBy('date')
df_month_r = df_month_r.withColumn('end_date', F.coalesce(F.add_months(F.lead('date').over(w1),-1),'date'))
df_month_r = df_month_r.toDF('entity_target_id','month','year','day','monthly_total_entity_c_entities','date','end_date')
df_month_r = df_month_r.selectExpr("entity_target_id", """
    inline_outer(
        transform(
            sequence(0,int(months_between(end_date, date))),
            i -> (add_months(date,i) as date, IF(i=0,monthly_total_entity_c_entities,0) as monthly_total_entity_c_entities)
        )
    )
""")
df_month_r = df_month_r.groupby('entity_target_id').agg(
    F.sum('monthly_total_entity_c_entities'),
    F.count('monthly_total_entity_c_entities')
)
df_month_r = df_month_r.toDF("entity_target_id","average_monthly_total_entity_c_entities","denominator")
df_month_r = df_month_r.withColumn("average_monthly_total_entity_c_entities",col('average_monthly_total_entity_c_entities')/col('denominator')).drop('denominator')
df_month = df_month.join(df_month_r,on=['entity_target_id'],how='outer').fillna(0)
df_additional = df_additional.join(df_month,on='entity_target_id',how='leftouter')

df_month_voucher = df.groupby('entity_target_id','month','year').agg(
    F.lit('01'),
    F.sum('transformed_item_spec_price_q01')
)
df_month_voucher = df_month_voucher.toDF('entity_target_id','month','year','day','monthly_item_spec_price_q01',)
df_month_voucher = df_month_voucher.withColumn('date',F.concat_ws('-',col('year'),col('month'),col('day')).cast('date'))
df_month_voucher = df_month_voucher.toDF('entity_target_id','month','year','day','monthly_item_spec_price_q01','date')
w1 = Window.orderBy('date')
df_month_voucher = df_month_voucher.withColumn('end_date', F.coalesce(F.add_months(F.lead('date').over(w1),-1),'date'))
df_month_voucher = df_month_voucher.toDF('entity_target_id','month','year','day','monthly_item_spec_price_q01','date','end_date')
df_month_voucher = df_month_voucher.selectExpr("entity_target_id", """
    inline_outer(
        transform(
            sequence(0,int(months_between(end_date, date)+1)),
            i -> (add_months(date,i) as date, IF(i=0,monthly_item_spec_price_q01,0) as monthly_item_spec_price_q01)
        )
    )
""")
df_month_voucher = df_month_voucher.groupby('entity_target_id').agg(
    F.sum('monthly_item_spec_price_q01'),
    F.count('monthly_item_spec_price_q01')
)
df_month_voucher = df_month_voucher.toDF("entity_target_id","average_monthly_item_spec_price_q01","denominator")
df_month_voucher = df_month_voucher.withColumn("average_monthly_item_spec_price_q01",col('average_monthly_item_spec_price_q01')/col('denominator')).drop('denominator')
df_additional = df_additional.join(df_month_voucher,on='entity_target_id',how='leftouter')

df_month_tax = df.groupby('entity_target_id','month','year').agg(
    F.lit('01'),
    F.sum('transformed_item_spec_tax_q01')
)
df_month_tax = df_month_tax.toDF('entity_target_id','month','year','day','monthly_item_spec_tax_q01',)
df_month_tax = df_month_tax.withColumn('date',F.concat_ws('-',col('year'),col('month'),col('day')).cast('date'))
df_month_tax = df_month_tax.toDF('entity_target_id','month','year','day','monthly_item_spec_tax_q01','date')
w1 = Window.orderBy('date')
df_month_tax = df_month_tax.withColumn('end_date', F.coalesce(F.add_months(F.lead('date').over(w1),-1),'date'))
df_month_tax = df_month_tax.toDF('entity_target_id','month','year','day','monthly_item_spec_tax_q01','date','end_date')
df_month_tax = df_month_tax.selectExpr("entity_target_id", """
    inline_outer(
        transform(
            sequence(0,int(months_between(end_date, date)+1)),
            i -> (add_months(date,i) as date, IF(i=0,monthly_item_spec_tax_q01,0) as monthly_item_spec_tax_q01)
        )
    )
""")
df_month_tax = df_month_tax.groupby('entity_target_id').agg(
    F.sum('monthly_item_spec_tax_q01'),
    F.count('monthly_item_spec_tax_q01')
)
df_month_tax = df_month_tax.toDF("entity_target_id","average_monthly_item_spec_tax_q01","denominator")
df_month_tax = df_month_tax.withColumn("average_monthly_item_spec_tax_q01",col('average_monthly_item_spec_tax_q01')/col('denominator')).drop('denominator')
df_additional = df_additional.join(df_month_tax,on='entity_target_id',how='leftouter')

df_day_voucher = df.groupby('entity_target_id','month','year','day').agg(
    F.sum('transformed_item_spec_price_q01')
)
df_day_voucher = df_day_voucher.toDF('entity_target_id','month','year','day','daily_item_spec_price_q01')
df_day_voucher = df_day_voucher.withColumn('date',F.concat_ws('-',col('year'),col('month'),col('day')).cast('date'))
df_day_voucher = df_day_voucher.toDF('entity_target_id','month','year','day','daily_item_spec_price_q01','date')
w1 = Window.orderBy('date')
df_day_voucher = df_day_voucher.withColumn('end_date', F.coalesce(F.add_months(F.lead('date').over(w1),-1),'date'))
df_day_voucher = df_day_voucher.toDF('entity_target_id','month','year','day','daily_item_spec_price_q01','date','end_date')
df_day_voucher = df_day_voucher.selectExpr("entity_target_id", """
    inline_outer(
        transform(
            sequence(0,int(datediff(end_date, date)+1)),
            i -> (date_add(date,i) as date, IF(i=0,daily_item_spec_price_q01,0) as daily_item_spec_price_q01)
        )
    )
""")
df_day_voucher = df_day_voucher.groupby('entity_target_id').agg(
    F.sum('daily_item_spec_price_q01'),
    F.count('daily_item_spec_price_q01')
)
df_day_voucher = df_day_voucher.toDF("entity_target_id","average_daily_item_spec_price_q01","denominator")
df_day_voucher = df_day_voucher.withColumn("average_daily_item_spec_price_q01",col('average_daily_item_spec_price_q01')/col('denominator')).drop('denominator')
df_additional = df_additional.join(df_day_voucher,on='entity_target_id',how='leftouter')

df_day_tax = df.groupby('entity_target_id','month','year','day').agg(
    F.sum('transformed_item_spec_tax_q01')
)
df_day_tax = df_day_tax.toDF('entity_target_id','month','year','day','daily_item_spec_tax_q01')
df_day_tax = df_day_tax.withColumn('date',F.concat_ws('-',col('year'),col('month'),col('day')).cast('date'))
df_day_tax = df_day_tax.toDF('entity_target_id','month','year','day','daily_item_spec_tax_q01','date')
w1 = Window.orderBy('date')
df_day_tax = df_day_tax.withColumn('end_date', F.coalesce(F.add_months(F.lead('date').over(w1),-1),'date'))
df_day_tax = df_day_tax.toDF('entity_target_id','month','year','day','daily_item_spec_tax_q01','date','end_date')
df_day_tax = df_day_tax.selectExpr("entity_target_id", """
    inline_outer(
        transform(
            sequence(0,int(datediff(end_date, date)+1)),
            i -> (date_add(date,i) as date, IF(i=0,daily_item_spec_tax_q01,0) as daily_item_spec_tax_q01)
        )
    )
""")
df_day_tax = df_day_tax.groupby('entity_target_id').agg(
    F.sum('daily_item_spec_tax_q01'),
    F.count('daily_item_spec_tax_q01')
)
df_day_tax = df_day_tax.toDF("entity_target_id","average_daily_item_spec_tax_q01","denominator")
df_day_tax = df_day_tax.withColumn("average_daily_item_spec_tax_q01",col('average_daily_item_spec_tax_q01')/col('denominator')).drop('denominator')
df_additional = df_additional.join(df_day_tax,on='entity_target_id',how='leftouter')

df_month12_week4 = df.where((df.week==4) & (df.month==12)).groupby('entity_target_id').agg(
    F.sum('transformed_item_spec_price_q01')
).toDF('entity_target_id','week4_month12_item_spec_price_q01')
df_month12_week4_r = df.groupby('entity_subtarget_id').agg(
    F.sum('transformed_item_spec_price_q01')
).toDF('entity_target_id','week4_month12_total_entity_c_value')
df_month12_week4_r = df_month12_week4_r.join(all_issuers,on=['entity_target_id'],how='inner').drop('count')
df_month12_week4 = df_month12_week4.join(df_month12_week4_r,on='entity_target_id',how='outer').fillna(0)
df_additional = df_additional.join(df_month12_week4, on='entity_target_id',how='leftouter').fillna(0)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#Code to create additional features, but these features are at transaction level and so are not included yet
'''
df_dd = df.join(df_profile.select("entity_target_id","entity_target_tax_spec_c04","entity_target_tax_spec_c05","entity_target_tax_spec_c06"), on='entity_target_id',how="leftouter")
df_r = df_profile.select("entity_target_id","entity_target_tax_spec_c04","entity_target_tax_spec_c05","entity_target_tax_spec_c06").toDF("entity_subtarget_id","entity_target_tax_spec_c04_r","entity_target_tax_spec_c05_r","entity_target_tax_spec_c06_r")
df_dd = df_dd.join(df_r,on="entity_subtarget_id",how="leftouter")
df_dd = df_dd.withColumn('DD_code',col('segment_group').substr(1,2))
df_dd = df_dd.withColumn('DD_code_main',col('entity_target_tax_spec_c04').substr(1,2))
df_dd = df_dd.withColumn('DD_code_sec1',col('entity_target_tax_spec_c05').substr(1,2))
df_dd = df_dd.withColumn('DD_code_sec2',col('entity_target_tax_spec_c06').substr(1,2))
df_dd = df_dd.withColumn('DD_code_main_r',col('entity_target_tax_spec_c04_r').substr(1,2))
df_dd = df_dd.withColumn('DD_code_sec1_r',col('entity_target_tax_spec_c05_r').substr(1,2))
df_dd = df_dd.withColumn('DD_code_sec2_r',col('entity_target_tax_spec_c06_r').substr(1,2))
df_dd = df_dd.withColumn("activity_variation",when((col("DD_code")==col("DD_code_main_r")) | (col("DD_code")==col("DD_code_sec1_r")) | (col("DD_code")==col("DD_code_sec2_r")) ,0).otherwise(1))
df_dd = df_dd.withColumn("self_activity_variation",when((col("DD_code")==col("DD_code_main")) | (col("DD_code")==col("DD_code_sec1")) | (col("DD_code")==col("DD_code_sec2")) ,0).otherwise(1))
df_dd = df_dd.select("entity_target_id","entity_subtarget_id","transaction_date01","DD_code","activity_variation","self_activity_variation")
'''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# #### Run groupby / aggregate

# CELL ********************

#time aggregations
aggregation_dict = {
    'by_hour':['hour','day_of_month','month','year'],
    'by_day':['day_of_month','month','year'],
    'by_week':['week_of_year','year'],
    'by_month':['month','year'],
    'by_quarter':['quarter','year'],
    'by_year':['year']
}

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

transformed_dfs = {}
for key in time_slices:
    issuer_groupby_item = ['entity_target_id'] + aggregation_dict[key]
    transformed_data_issuer = df.groupby(*issuer_groupby_item).agg(
        F.first('transaction_date01'),
        F.count('document_type'),
        F.countDistinct('entity_subtarget_id'),
        F.sum('document_type_equals_C'),
        F.sum('document_type_equals_B'),
        F.sum('document_type_equals_A'),
        F.sum('document_type_equals_D'),
        F.sum('document_type_equals_E'),
        F.sum('entity_target_id_equals_entity_subtarget_id'),
        F.sum('total_document_to_self'),
        F.sum('transformed_item_spec_volume_q01'),
        F.sum('transformed_item_spec_volume_q02'),
        F.sum('transformed_item_spec_volume_q05'),
        F.sum('transformed_item_spec_volume_q03'),
        F.sum('transformed_item_spec_volume_q06'),
        F.sum('transformed_item_spec_value_q01'),
        F.sum('transformed_item_spec_value_q02'),
        F.sum('transformed_item_spec_volume_q04'),
        F.sum('transformed_item_spec_price_q01'),
        F.sum('transformed_item_spec_tax_q01'),
        F.min('transformed_item_spec_price_q01'),
        F.max('transformed_item_spec_price_q01'),
        F.min('transformed_item_spec_tax_q01'),
        F.max('transformed_item_spec_tax_q01'),
        #F.min('transaction_date01'),
        #F.max('transaction_date01'),
        F.datediff(F.max('transaction_date01'),F.min('transaction_date01')) + 1,
        F.first('entity_target_id_indexed')
    )
    
    all_issuers = df.groupby('entity_target_id').count()

    receiver_groupby_item = ['entity_subtarget_id'] + aggregation_dict[key]

    transformed_data_receiver = df.groupby(*receiver_groupby_item).agg(
        F.first('transaction_date01'),
        count('document_type'),
        countDistinct('entity_target_id'),
        sum('transformed_item_spec_price_q01')
    )

    #I = transaction, D = Debit Note, C = Credit Note, O = Order, P = Purchase, G = Goods certificate, T = Tender, X: Export transaction

    #total_document_typeC: where document_type==C
    #total_document_typeA: where document_type==A
    #total_document_typeB: where document_type==B
    #total_document_typeE: where document_type==E

    new_col_names_issuer = ['entity_target_id']
    new_col_names_issuer +=  aggregation_dict[key]
    new_col_names_issuer += [
        'transaction_date01',
        'number_of_transactions', 'total_entity_subtarget',
        'total_document_typeC', 'total_document_typeB',
        'total_document_typeA', 'total_document_typeD',
        'total_document_typeE', 'number_of_transactions_to_self', 'total_document_to_self',
        'item_spec_volume_q01', 'item_spec_volume_q02',
        'item_spec_volume_q05', 'item_spec_volume_q03',
        'item_spec_volume_q06', 'item_spec_value_q01',
        'item_spec_value_q02', 'item_spec_volume_q04',
        'item_spec_price_q01','item_spec_tax_q01',
        'min_item_spec_price_q01_period','max_item_spec_price_q01_period',
        'min_item_spec_tax_q01_period', 'max_item_spec_tax_q01_period',
        #'first_transaction_date01_period','last_transaction_date01_period',
        'num_days_issuing_period','entity_target_id_indexed'
    ]

    new_col_names_receiver = ['entity_target_id']
    new_col_names_receiver +=  aggregation_dict[key]
    new_col_names_receiver += [
        'transaction_date01_r',
        'number_of_entity_c_operations', 'total_entity_c_entities',
        'total_entity_c_value'
    ]

    transformed_data_issuer = transformed_data_issuer.toDF(*new_col_names_issuer)
    transformed_data_receiver = transformed_data_receiver.toDF(*new_col_names_receiver)
    transformed_data_receiver_trimmed = transformed_data_receiver.join(all_issuers, on=['entity_target_id'],how='inner').drop('count')
    



    transformed_data_receiver_trimmed = transformed_data_receiver_trimmed.join(
        vocab_df_final, on="entity_target_id", how="left"
    ).withColumn(
        "entity_subtarget_id_indexed",
        F.coalesce(col("entity_target_id_indexed"), F.lit(num_labels)).cast("Integer")
    ).drop("entity_target_id_indexed")    


    transformed_data = transformed_data_issuer.join(transformed_data_receiver_trimmed, on=['entity_target_id']+aggregation_dict[key],how='outer')
    transformed_data = transformed_data.withColumn('entity_target_id_indexed', when(F.isnull('entity_target_id_indexed'), col('entity_subtarget_id_indexed')).otherwise(col('entity_target_id_indexed'))).drop('entity_subtarget_id_indexed')
    transformed_data = transformed_data.withColumn('entity_target_id',col('entity_target_id').cast("String"))
    transformed_data = transformed_data.withColumn('transaction_date01',F.coalesce(col('transaction_date01'),col('transaction_date01_r')))
    transformed_data = transformed_data.drop(*aggregation_dict[key]).drop("transaction_date01_r")
    transformed_data = transformed_data.fillna(0)
    transformed_data = transformed_data.join(df_pagerank,on=['entity_target_id_indexed'],how='outer').fillna(0,'pagerank_score')
    transformed_data = transformed_data.join(df_additional,on=['entity_target_id'],how='leftouter')
    transformed_dfs[key] = transformed_data.join(df_profile,on=['entity_target_id'],how='leftouter').fillna(0,'entity_target_spec_q01')


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ### Calculate Ratios

# CELL ********************

for key in transformed_dfs:
    transformed_data = transformed_dfs[key]
    transformed_data = transformed_data.withColumn("ratio_item_spec_value_q02_entity_c_value", when(col('total_entity_c_value')>0, col('item_spec_value_q02')/col('total_entity_c_value')).otherwise(col('item_spec_value_q02')))
    transformed_data = transformed_data.withColumn("ratio_item_spec_tax_q01_item_spec_value_q02", when(col('item_spec_value_q02')>0, col('item_spec_tax_q01')/col('item_spec_value_q02')).otherwise(col('item_spec_tax_q01')))
    transformed_data = transformed_data.withColumn("ratio_item_spec_value_q02_entity_target_spec_q01", when(col('entity_target_spec_q01')>0, col('item_spec_value_q02')/col('entity_target_spec_q01')).otherwise(col('item_spec_value_q02')/0.1))
    transformed_data = transformed_data.withColumn("ratio_total_entity_subtarget_total_entity_c_entities", when(col('total_entity_c_entities')>0, col('total_entity_subtarget')/col('total_entity_c_entities')).otherwise(col('total_entity_subtarget')))
    transformed_data = transformed_data.withColumn("ratio_item_spec_value_q02_entity_target_spec_q03", when(col('entity_target_spec_q04')>0, col('item_spec_price_q01_dataset')/col('entity_target_spec_q04')).otherwise(col('item_spec_price_q01_dataset')))
    transformed_dfs[key] = transformed_data.withColumn("ratio_in_out", when(col('number_of_entity_c_operations')>0, col('number_of_transactions')/col('number_of_entity_c_operations')).otherwise(col('number_of_transactions')))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ### Economic Activity

# CELL ********************

df2 = df.groupby('entity_target_id','segment_group').agg(sum('item_spec_price_q01'))
w2 = Window.partitionBy("entity_target_id").orderBy(desc("sum(item_spec_price_q01)"))
df3 = df2.withColumn("row",row_number().over(w2)).filter(col("row") == 1).drop('row').toDF("entity_target_id","segment_01","item_spec_price_q01_segment_01")
df3 = df3.join(df2.withColumn("row",row_number().over(w2)).filter(col("row") == 2).drop('row').toDF("entity_target_id","segment_02","item_spec_price_q01_segment_02"),on=['entity_target_id'],how='outer').fillna(0)
df3 = df3.join(df2.withColumn("row",row_number().over(w2)).filter(col("row") == 3).drop('row').toDF("entity_target_id","segment_03","item_spec_price_q01_segment_03"),on=['entity_target_id'],how='outer').fillna(0)
df3 = df3.join(df2.withColumn("row",row_number().over(w2)).filter(col("row") == 4).drop('row').toDF("entity_target_id","segment_04","item_spec_price_q01_segment_04"),on=['entity_target_id'],how='outer').fillna(0)
df3 = df3.join(df2.withColumn("row",row_number().over(w2)).filter(col("row") == 5).drop('row').toDF("entity_target_id","segment_05","item_spec_price_q01_segment_05"),on=['entity_target_id'],how='outer').fillna(0)
df3 = df3.na.fill('0')

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

for key in transformed_dfs:
    transformed_dfs[key] = transformed_dfs[key].join(df3,on=['entity_target_id'])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ### In-Memory Depth of Supply Chain Calculation/Network Analysis

# CELL ********************

node_child_df = edges_trimmed_df.groupby("entity_target_id_indexed").agg(F.collect_list("entity_subtarget_id_indexed")).toPandas()
node_child_df.columns = ['parent', 'child']
print(f'node_child_df.shape: {node_child_df.shape}')

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#DFS cycle removal algorithm
def find_edges_to_remove(df):
    edges_to_remove = []
    visited = {}
    for node in df.parent:
        if node not in visited:
            visited[node] = 0
        if visited[node] == 0:
            stack = [(node,0)]
            visited[node] = 1
            while len(stack) > 0:
                t, op = stack.pop()
                if op == 0:
                    stack.append((t,1))
                    #Exception handling for case where issuer has no receivers in trimmed data (final retailer)
                    try:
                        children = df[df.parent == t].child.tolist()[0]
                    except:
                        children = []
                    for child in children:
                        if child not in visited:
                            visited[child] = 0
                        if visited[child] == 1:
                            edges_to_remove.append((int(t),int(child)))
                        else:
                            if visited[child] == 0:
                                stack.append((child,0))
                                visited[child] = 1
                else:
                    visited[t] = 2
    return edges_to_remove

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

edges_to_remove = find_edges_to_remove(node_child_df)
del node_child_df

schema = StructType([
    StructField("entity_target_id_indexed", IntegerType(), True),
    StructField("entity_subtarget_id_indexed", IntegerType(), True)
])
remove_df = spark.createDataFrame(edges_to_remove, schema)
del edges_to_remove

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

edges_dag = edges_trimmed_df.join(remove_df, on=["entity_target_id_indexed","entity_subtarget_id_indexed"],how='leftanti').select(["entity_target_id_indexed","entity_subtarget_id_indexed"]).toDF("I","R")
edges_dag = edges_dag.withColumn("V",F.lit(1))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def calculate_left_sc_length_pyspark_max(df, max_iter=2):
    '''
    Expected columns are I, R, and V. V starts out at 1.
    
    Returns:
        pyspark dataframe with columns node, sc_left. columns that are zero-length are left out, but can be recovered via a join and fillna
    '''
    left_matrix = df
    i = 0
    while True:
        i += 1
        if i > max_iter: break
        left_vector = left_matrix.groupBy('R').agg(F.max('V')+1).toDF('R_new','V_new')
        left_matrix = df.join(left_vector,df.I==left_vector.R_new,how="leftouter").fillna(0)
        left_matrix = left_matrix.withColumn('V',F.when(F.col('V_new')==0,F.col('V')).otherwise(F.col('V_new'))).drop("R_new").drop("V_new")
    sample_left_length = left_matrix.groupBy('R').agg(F.max('V')).toDF('node','sc_left')
    return sample_left_length

def calculate_right_sc_length_pyspark_max(df, max_iter=2):
    '''
    Expected columns are I, R, and V. V starts out at 1.

    Returns:
        pyspark dataframe with columns node, sc_right. columns that are zero-length are left out, but can be recovered via a join and fillna
    '''
    right_matrix = df
    i = 0
    while True:
        i += 1
        if i > max_iter: break
        right_vector = right_matrix.groupBy('I').agg(F.max('V')+1).toDF('I_new','V_new')
        right_matrix = df.join(right_vector,df.R==right_vector.I_new,how="leftouter").fillna(0)
        right_matrix = right_matrix.withColumn('V',F.when(F.col('V_new')==0,F.col('V')).otherwise(F.col('V_new'))).drop("I_new").drop("V_new")
    sample_right_length = right_matrix.groupBy('I').agg(F.max('V')).toDF('node','sc_right')
    return sample_right_length

def calculate_left_sc_length_pyspark_min(df, max_iter=2):
    '''
    Expected columns are I, R, and V. V starts out at 1.
    
    Returns:
        pyspark dataframe with columns node, sc_left. columns that are zero-length are left out, but can be recovered via a join and fillna
    '''
    left_matrix = df
    i = 0
    while True:
        i += 1
        if i > max_iter: break
        left_vector = left_matrix.groupBy('R').agg(F.min('V')+1).toDF('R_new','V_new')
        left_matrix = df.join(left_vector,df.I==left_vector.R_new,how="leftouter").fillna(0)
        left_matrix = left_matrix.withColumn('V',F.when(F.col('V_new')==0,F.col('V')).otherwise(F.col('V_new'))).drop("R_new").drop("V_new")
    sample_left_length = left_matrix.groupBy('R').agg(F.min('V')).toDF('node','sc_left')
    return sample_left_length

def calculate_right_sc_length_pyspark_min(df, max_iter=2):
    '''
    Expected columns are I, R, and V. V starts out at 1.

    Returns:
        pyspark dataframe with columns node, sc_right. columns that are zero-length are left out, but can be recovered via a join and fillna
    '''
    right_matrix = df
    i = 0
    while True:
        i += 1
        if i > max_iter: break
        right_vector = right_matrix.groupBy('I').agg(F.min('V')+1).toDF('I_new','V_new')
        right_matrix = df.join(right_vector,df.R==right_vector.I_new,how="leftouter").fillna(0)
        right_matrix = right_matrix.withColumn('V',F.when(F.col('V_new')==0,F.col('V')).otherwise(F.col('V_new'))).drop("I_new").drop("V_new")
    sample_right_length = right_matrix.groupBy('I').agg(F.min('V')).toDF('node','sc_right')
    return sample_right_length

def calculate_sc_length(edges_df, max_iter=-1):
    sc_left_min = calculate_left_sc_length_pyspark_min(edges_df,max_iter)
    sc_right_min = calculate_right_sc_length_pyspark_min(edges_df,max_iter)
    sc_min = sc_left_min.join(sc_right_min,'node','outer').fillna(0)
    sc_min = sc_min.withColumn('length',F.col('sc_left')+F.col('sc_right'))
    sc_min = sc_min.withColumn('frac',F.col("sc_left")/F.col('length'))
    sc_min = sc_min.toDF('entity_target_id_indexed','min_distance_from_entity_c','min_distance_from_entity_subtarget','min_depth_of_network','min_place_in_network')
    sc_left_max = calculate_left_sc_length_pyspark_max(edges_df,max_iter)
    sc_right_max = calculate_right_sc_length_pyspark_max(edges_df,max_iter)
    sc_max = sc_left_max.join(sc_right_max,'node','outer').fillna(0)
    sc_max = sc_max.withColumn('length',F.col('sc_left')+F.col('sc_right'))
    sc_max = sc_max.withColumn('frac',F.col("sc_left")/F.col('length'))
    sc_max = sc_max.toDF('entity_target_id_indexed','max_distance_from_entity_c','max_distance_from_subtarget_entity','max_depth_of_network','max_place_in_network')
    return sc_max.join(sc_min,'entity_target_id_indexed')

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

nodes = calculate_sc_length(edges_dag, max_iter=depth_of_supply_chain_max_iter)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

for key in transformed_dfs:
    transformed_dfs[key] = transformed_dfs[key].join(nodes,on=['entity_target_id_indexed'],how='leftouter')
    transformed_dfs[key] = transformed_dfs[key].fillna(
        value=0,
        subset=['min_distance_from_entity_c','min_distance_from_entity_subtarget','min_depth_of_network','min_place_in_network',
                'max_distance_from_entity_c','max_distance_from_subtarget_entity','max_depth_of_network','max_place_in_network']
    )

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ### Run job and save output to container

# CELL ********************

for key in transformed_dfs:
    print(f'Saving features for {key} aggregation to ADLS')
    transformed_data = transformed_dfs[key]
    # transformed_data.write.mode("overwrite").option("header", "true").save(transformed_data_path + '/' + key,format='parquet')
    table_name = f"{database_name}.batch_{batch_id}_output_transformed_data_{key}"
    transformed_data.write \
        .mode("overwrite") \
        .format("delta") \
        .saveAsTable(table_name)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
