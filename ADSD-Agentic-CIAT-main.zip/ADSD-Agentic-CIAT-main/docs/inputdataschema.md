# Input Data Schema for ADSD

The ADSD Accelerator requires three types of files to be prepared to enable the processing pipelines in Azure Synapse. These include
- Transaction Data file(s) (**CSV**)
- Entity Profile file (**CSV**)
- Exchange Rate file (**CSV**)

The following sections will detail the specification for each file type.

---
## Transaction Data File(s)

ADSD_FIELD NAME | MANDATORY | TYPE  | LENGTH | DESCRIPTION
|--|--|--|--|--|
|main_operation_type  |N  |String |1 to 24  |String code to identify the operation category.   |
|entity_target_id  |Y  |String  |6 to 64  |ID of the main entity or subject for the analysis. It is the entity/subject where the transaction is associated. Example: Device ID, Company ID, User ID, etc. |
|segment_group  |N  |String  |2 to 16  |Group or segment where the main entity or operation type is associated. |
|entity_c_id  |N  |String  |1 to 64 |Secondary referenced entity. This entity correlates to the main entity in the transactional data but does not have a direct relationship, such as the sub-target entity. This entity has the attribute to support unstructured string naming conventions – free text.  |
|entity_subtarget_id  |Y  |String |6 to 16  |The sub-target entity ID is an entity connected to the main entity target. For example, the entity target is the seller, and the entity sub-target is the buyer. |
|document_type  | Y  | String  | 1  | String (alphanumeric) code that identifies the type of document: A – Transaction Type A, B - Transaction Type B, C – Transaction Type C, D – Transaction Type D, E – Transaction Type E |
|document_id  |Y |String  |8 to 100  |8 to 100-character code that identifies the digital document ID of the transaction. document_id is a unique value (no duplicates accepted). |
|transaction_date01  |Y  |Date  |  |Date and time at which the digital document is accepted/processed/received by the government agency in the format yyyy-mm-dd hh:mm:ss z. Types of transaction dates: accepted/processed/received = Use a consistent date  |
|entity_c_name  |N  |String  |64 |TThe entity_c name in text. |
|tax_rate01  |N  |Float  |1 to 12 |Rate value associated with the transaction. In government, this is typically a tax rate. |
|currency01  |N  |String  |3  |Currency code according to ISO 4217 |
|exchange_rate_main  |Y  |Float  |2 to 8  |National Central Bank reference sales exchange rate on the day of issuance of the voucher. Currency rate reported by issuer but not necessarily validated. Format: XX.YYYY. Example: 11.5867|
|payment_type01  |N  |String  |1 to 16  |Tariff payment type (e.g., Usance credit payable at sight, bond, card, cash).  |
|transaction_reference_a  |N  |String  |1 to 16  |It is the identification of the location where the transaction is placed. It could be a location catalog or geolocation data. |
|tax_type01  |N  |String  |1 to 16  |Tax Types (VAT, Income, Corporate, Property, Permits, Foreign Trade and Customs) |
|transaction_origin  |N  |String  |1 to 32  |It is the identification of the location where the transaction is placed. It could be a location catalog or geolocation data. |
|item_code01  |N  |String  |1 to 16  |Code associated with the item reported in the transaction. |
|item_description01  |N  |String  |1 to 32  |Item description reported. |
|item_spec_volume_q01  |N  |Float  |2 to 18  |This is the Item quantity data about volume or other digital/physical specification. |
|item_spec_volume_q02  |N  |Float  |2 to 18  |This is the Item quantity data about volume or other digital/physical specification. |
|item_spec_volume_q05  |N  |Float  |2 to 18  |This is the Item quantity data about volume or other digital/physical specification. |
|item_spec_volume_q03  |N  |Float  |2 to 18  |This is the Item quantity data about volume or other digital/physical specification. |
|item_spec_volume_q06  |N  |Float  |2 to 18  |This is the Item quantity data about volume or other digital/physical specification. |
|item_spec_value_q01  |N  |Float  |2 to 18  |This is the Item quantity data about value. |
|item_spec_value_q02  |N  |Float  |2 to 18  |This is the Item quantity data about value. |
|item_spec_volume_q04  |N  |Float  |2 to 18  |This is the Item quantity data about volume or other digital/physical specification. |
|item_spec_price_q01  |Y  |Float  |2 to 18  |This is the Item quantity data about price. |
|item_spec_tax_q01  |Y  |Float  |2 to 18  |This is the Item quantity data about tax. |

---

## entity profile file

|ENTITY  |FIELD NAME | TYPE  | LENGTH  | DESCRIPTION  
|--|--|--|--|--|
|entity_profile_target_id   |Y  |String  |6 to 64  |ID of the main entity or subject for the analysis. It is the entity/subject where the transaction is associated. Example: Device ID, Company ID, User ID, etc.  |
|entity_target_type_c01  |N  |String |1 to 16  |It is a code to identify the type of target entity. The entity type definition is flexible but needs to be standardized. |
|entity_target_tax_spec_c01  |N  |String  |2 to 16 |It is a code that identifies an attribute in a government agency's registration record, typically the tax database.  |
|entity_target_tax_spec_c02  |N  |String  |2 to 16  |It is a code that identifies an attribute in a government agency's registration record, typically the tax database. |
|entity_target_tax_spec_c03  |N  |String  |2 to 16  |It is a code that identifies an attribute in a government agency's registration record, typically the tax database. |
|entity_target_tax_spec_c04  |N  |String  |2 to 16  |It is a code that identifies an attribute in a government agency's registration record, typically the tax database. |
|entity_target_tax_spec_c06  |N  |String  |2 to 16  |It is a code that identifies an attribute in a government agency's registration record, typically the tax database. |
|entity_target_spec_q01  |N  |Integer  |0 to 24  |It is a numeric attribute of the main entity.  |
|entity_target_date_01 |N  |Date  |YYYY-MM-DD  |It is a date attribute of the main entity, in the format YYYY-MM-DD  |
|entity_target_date_02 |N  |Date  |YYYY-MM-DD  |It is a date attribute of the main entity, in the format YYYY-MM-DD  |
|entity_target_date_03 |N  |Date  |YYYY-MM-DD  |It is a date attribute of the main entity, in the format YYYY-MM-DD  |
|entity_target_spec_q02  |N  |Integer  |1 to 24 |It is a numeric integer attribute of the main entity. |
|entity_target_spec_q03  |N  |Float  |4 to 24  |It is a numeric decimal attribute of the main entity.  |
|entity_target_spec_q04  |N  |Float  |4 to 24  |It is a numeric decimal attribute of the main entity.  |
|entity_target_spec_q05  |N  |Float  |4 to 24  |It is a numeric decimal attribute of the main entity.  |
|entity_target_spec_q06  |N  |Float  |4 to 24  |It is a numeric decimal attribute of the main entity.  |
|entity_target_spec_q07  |N  |Float  |4 to 24  |It is a numeric decimal attribute of the main entity.  |
|entity_target_spec_q08  |N  |Float  |4 to 24  |It is a numeric decimal attribute of the main entity.  |
|entity_target_spec_q09  |N  |Float  |4 to 24  |It is a numeric decimal attribute of the main entity.  |
|entity_target_spec_q10  |N  |Float  |4 to 24  |It is a numeric decimal attribute of the main entity.  |
|entity_target_spec_q11  |N  |Float  |4 to 24  |It is a numeric decimal attribute of the main entity.  |
|entity_target_spec_g01  |N  |String  |2 to 24  |It is a geolocation code attribute of the main entity.  |
|entity_target_spec_g02  |N  |String  |2 to 24  |It is a geolocation code attribute of the main entity.  |
|entity_target_spec_g03  |N  |String  |2 to 24  |It is a geolocation code attribute of the main entity.  |

---

## Exchange Rate file
|ENTITY  |FIELD  |TYPE  |LENGHT  |DESCRIPTION  |
|--|--|--|--|--|
|Exchange Rate  |ISO_CODE  |String  |3  |ISO Code for the different currencies supported by the national e-Invoicing system. Code according to ISO 4217 <br/><br/> Reference: <https://en.wikipedia.org/wiki/ISO_4217>
|Exchange Rate  |DESCRIPTION  |String  |256  |Currency Name. Example: USA Dollar, Pound Sterling, Mexican Peso, etc.   |
|Exchange Rate  |Day  |Date  |YYYY-MM-DD  |Historical day in the format YYYY-MM-DD, from the minimum issued_date reported in the transaction dataset to the maximum date reported in the issued_date in the transaction dataset   |
