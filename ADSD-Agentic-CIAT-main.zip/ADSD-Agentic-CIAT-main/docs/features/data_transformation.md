# Data Transformation

The Data Transformation section of the pipeline is a critical phase that converts raw data into a structured format suitable for analysis and anomaly detection. This section ensures that the data is in its most useful form before moving on to the Data Science Pipeline.

The Data Transformation section includes:

### Schema Mapping

Transforming and mapping input data to a predefined schema to ensure consistency. This involves reading JSON files and applying specific mappings as defined in the [`adsd_to_customs_specific_mapping.json`](/tests/test_data/intermediate_naming/adsd_to_customs_specific_mapping.json) file.

Note: In the JSON context, "ADSD to Customs" refers to mapping fields from the ADSD schema to their corresponding fields in the Customs schema.

The `adsd_to_customs_specific_mapping.json` file contains the necessary mappings to convert the Customs specific data fields into a Generic schema recognized by the ADSD pipeline. Here are the steps to use it:

1. **Define Your Schema**: Start by defining your data schema. This is a structured data format that you are using for your transaction data.
2. **Create JSON Mapping Files**: Use the `adsd_to_customs_specific_mapping.json` to map your schema fields to the Generic schema fields required by the ADSD pipeline. Ensure each Customs field is appropriately mapped to its corresponding Generic field.
3. **Apply Schema Mapping**: During the data transformation process, the system reads your JSON mapping files and applies these mappings to the input data. This transforms your Customs formatted data into the Generic schema.
4. **Verification**: After mapping, verify that the data has been correctly transformed by comparing the output against the expected generic schema for consistency and ready for further processing.

This process outlines the steps to convert Customs data formats into the Generic and standardized format required by the ADSD pipeline.

### Data Enrichment

Enhancing the dataset with additional information, such as domain specific mappings and reference data. This step ensures that all necessary contextual information is available for downstream processing.

### Normalization

Standardizing data formats for accurate comparisons and calculations. This includes converting all relevant fields to a common format, such as dates, numerical values, and categorical data.

### Data Aggregation

Summarizing and grouping data to create high level insights and metrics. This step involves combining multiple data points to form aggregated metrics that provide a more comprehensive view of the dataset.

The Data Transformation section consists of Jupyter Notebooks and pipeline activities:

## Jupyter Notebooks

![Data Transformation Notebooks](../images/ADSD_data_engineering_notebooks.png)

- **4_1_nb_create_edges**
- **4_2_nb_network_analysis**
- **4_3_nb_create_features**

## Pipeline Activities

![Data Transformation Pipeline](../images/ADSD_data_engineering_pipeline_overview.png)

- Copy data
  - Copy entity profile from input to uncompress folder
- Get Metadata
  - Get list of transaction zip files
- ForEach
  - Decompress transaction zip files
  - Apply transaction standard schema
- Notebooks
  - Apply entity standard schema
  - Calculate statistics about loaded data
  - Calculate Data Quality
  - Clean the main entity profile
  - Main entity profile statistics
  - Clean the datasets
- Execute Pipeline
  - Execute Data Science Pipeline

## JSON Mapping Files

![JSON Mapping Files](../images/json_files.png)

The transformation process leverages JSON mapping files to standardize and enrich the data. These mapping files include:

- [`adsd_to_adsd_specific_mapping.json`](/tests/test_data/intermediate_naming/adsd_to_adsd_specific_mapping.json)
- [`adsd_to_customs_specific_mapping.json`](/tests/test_data/intermediate_naming/adsd_to_customs_specific_mapping.json)
- [`adsd_to_invoicing_specific_mapping.json`](/tests/test_data/intermediate_naming/adsd_to_invoicing_specific_mapping.json)

These files are located in the `input/intermediate_naming` directory. The data is accurately mapped to the expected schema for further processing.

### Using JSON Mapping Files

The JSON mapping files are essential for converting data from one format to another. Overview of each file:

**`adsd_to_adsd_specific_mapping.json`**:
    - **Function**: Maps the standardized ADSD schema to specific format within the ADSD framework.
    - **Usage**: Ensures that data has been converted to the ADSD generic schema.
**`adsd_to_customs_specific_mapping.json`**:
    - **Function**: Maps the Customs specific data fields into the Generic ADSD schema.
    - **Usage**: This file is used to transform Customs data into the standardized schema recognized by the ADSD pipeline.

**`adsd_to_invoicing_specific_mapping.json`**:
    - **Function**: Maps the generic transaction schema back to the e-Invoicing specific format.
    - **Usage**: Reverts processed and analyzed data back to the original e-Invoicing schema.


### Example: Transforming Customs Data

Here's an example of how Customs data is transformed using the `json` files.

```json

1. **Customs Data**:
{
  "declaration_id": "U79733101U-001",
  "issuer_id": "Company_ID",
  "acceptance_date": "8/2/2023  3:03:17 AM",
  "tariff_value": 123,
  "average_daily_package_set_units": 50,
  "tax_type": "FTA"
}

2. **Mapping File** `adsd_to_customs_specific_mapping.json`:
{
  "ADSDColumnName": "document_id",
  "DomainColumnName": "declaration_id"
},
{
  "ADSDColumnName": "entity_target_id",
  "DomainColumnName": "issuer_id"
},
{
  "ADSDColumnName": "transaction_date01",
  "DomainColumnName": "acceptance_date"
},
{
  "ADSDColumnName": "item_spec_value_q02",
  "DomainColumnName": "tariff_value"
},
{
  "ADSDColumnName": "average_daily_item_spec_price_q01",
  "DomainColumnName": "average_daily_package_set_units"
},
{
  "ADSDColumnName": "tax_type01",
  "DomainColumnName": "tax_type"
}

3. **Transformed Data**:
{
  "document_id": "U79733101U-001",
  "entity_target_id": "Company_ID",
  "transaction_date01": "8/2/2023  3:03:17 AM",
  "item_spec_value_q02": 123,
  "average_daily_item_spec_price_q01": 50,
  "tax_type01": "FTA"
}
```

## Steps to Use the Mapping Files

1. Create Your Own Mapping File: As needed, create a domain specific JSON mapping file to map the internal ADSD version your data schema version.

2. Place the JSON Mapping File: Ensure the relevant JSON mapping file (e.g., adsd_to_customs_specific_mapping.json) is loaded in the `input/intermediate_naming` directory.

3. Run the Transformation Pipeline: Executes the relevant Jupyter notebook (e.g., 4_3_nb_create_features) that uses the mapping file to transform the data.

4. Verify the Output: Check the output directory `output/transformed_data` for the transformed data files and ensure they match the expected schema.

---

By ensuring data consistency, enrichment, normalization, and aggregation, the Data Transformation section prepares the dataset for effective anomaly detection in the subsequent Data Science Pipeline.
