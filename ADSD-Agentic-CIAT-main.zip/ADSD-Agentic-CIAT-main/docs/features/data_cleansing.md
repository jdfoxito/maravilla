# Data Cleansing

Data Cleansing is the last stage in the Data Engineering Pipeline for the ADSD Accelerator. This stage is critical to ensure the data has consistency without gaps and invalid values to enable a successful run of the data science pipeline.

Both the transaction data files and the entity profile data file are cleansed using the following set of rules:

## Transaction Cleansing Specification

Entity | Field | Cleansing Action
---|---|---
|Entity  |main_operation_type  | Replace NULL values with string literal "NT".
|Entity  |entity_target_id  | Drop records if < "drop_records_threshold" hyper-parameter (defaulted to 1%).
|Entity  |segment_group  | Replace NULL values, values > 8 characters, and values < 4 characters with "999999".
|Entity  |entity_c_id  | Replace NULL values with string literal "NT".
|Entity  |entity_subtarget_id  | Replace NULL values or values > 16 characters with string literal "no_identified_receiver".
|Document  | document_type  | Replace NULL values with string literal "I".
|Document  |document_id  | Replace NULL values with string literal "no_identified_document".
|Document  |transaction_date01  | Drop records if < "drop_records_threshold" hyper-parameter (defaulted to 1%).
|Document  |entity_c_name  | Replace NULL values with string literal "00".
|Document  |tax_rate01  | Replace NULL values with string literal "00".
|Document  |currency01  | Replace NULL values with "local_currency_iso_code" hyper-parameter (defaulted to "EUR").
|Document  |exchange_rate_main  | Replace NULL values with "1.0" Float value.
|Document  |payment_type01  | Replace NULL values or values > 2 characters with string literal "00".
|Document  |transaction_reference_a  | Replace NULL values or values > 2 characters with string literal "00".
|Document  |tax_type01  | Replace NULL values or values > 2 characters with string literal "00".
|Document  |transaction_origin   | Replace NULL values or values > 2 characters with string literal "00".
|Document  |item_code01  | Replace NULL values or values > 2 characters with string literal "00".
|Document  |item_description01  | Replace NULL values or values > 2 characters with string literal "00".
|Transaction  |item_spec_volume_q01  | Replace NULL values with "0.0" Float value.
|Transaction  |item_spec_volume_q02  | Replace NULL values with "0.0" Float value.
|Transaction  |item_spec_volume_q05  | Replace NULL values with "0.0" Float value.
|Transaction  |item_spec_volume_q03  | Replace NULL values with "0.0" Float value.
|Transaction  |item_spec_volume_q06  | Replace NULL values with "0.0" Float value.
|Transaction  |item_spec_value_q01  | Replace NULL values with "0.0" Float value.
|Transaction  |item_spec_value_q02  | Replace NULL values with "0.0" Float value.
|Transaction  |item_spec_volume_q04  | Replace NULL values with "0.0" Float value.
|Transaction  |item_spec_price_q01  | Drop records if < "drop_records_threshold" hyper-parameter (defaulted to 1%). Else, replace NULL values with "0.0" Float value.
|Transaction  |item_spec_tax_q01  | Drop records if < "drop_records_threshold" hyper-parameter (defaulted to 1%). Else, replace NULL values with "0.0" Float value.

## Entity Profile Cleansing Specification

Field | Cleansing Action
---|---
entity_profile_target_id  | Drop records with NULL values. Drop duplicated records. Delete first record when duplicate|
entity_target_type_c01 | Replace Nulls with string literal "no_entity_type".
entity_target_tax_spec_c01 | Replace Nulls with string literal "no_fiscal_condition".
entity_target_tax_spec_c02 | Replace Nulls with string literal "no_regime_name".
entity_target_tax_spec_c03 | Replace Nulls with string literal "no_entity_size".
entity_target_tax_spec_c04 | Replace Nulls with value "999999".
entity_target_tax_spec_c05 | Replace Nulls with value "999999".
entity_target_tax_spec_c06 | Replace Nulls with value "999999".
entity_target_spec_q01 | Replace Nulls with integer "1".
entity_target_date_01 | Replace Nulls with "1900-1-1".
entity_target_date_02 | Replace Nulls with "1900-1-1".
entity_target_date_03 | Replace Nulls with "1900-1-1".
entity_target_spec_q02  | Replace Nulls with value "0".
entity_target_spec_q03  | Replace Nulls with Float Number "1.0".
entity_target_spec_q04  | Replace Nulls with Float Number "1.0".
entity_target_spec_q05 | Replace Nulls with Float Number "1.0"
entity_target_spec_q06 | Replace Nulls with Float Number "1.0".
entity_target_spec_q07  | Replace Nulls with Float Number "1.0"
entity_target_spec_q08 | Replace Nulls with Float Number "1.0".
entity_target_spec_q09  | Replace Nulls with Float Number "1.0".
entity_target_spec_q10  | Replace Nulls with Float Number "1.0".
entity_target_spec_q11 | Replace Nulls with Float Number "1.0".
entity_target_spec_g01  | Replace Nulls with code "00".
entity_target_spec_g02 | Replace Nulls with "000000" code.
entity_target_spec_g03 | Replace Nulls with "000000" code.
