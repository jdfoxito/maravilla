# Input Data Schema for ADSD, version 1.1 (CUSTOMS)

The ADSD Accelerator for CUSTOMS requires three types of files to be prepared to enable the processing pipelines in Azure Synapse. These include:
- Transaction Data file(s) (**CSV**)
- Entity Profile file (**CSV**)
- Exchange Rate file (**CSV**)

The following sections will detail the specification for each file type.

---
## Transaction Data File(s)

| ADSD_FIELD NAME | MANDATORY | TYPE  | LENGTH | DESCRIPTION
|--|--|--|--|--|
|customs_type |	N |	String | 1 to 24 | String code to identify the customs operation category. |
|importer_id | Y | String |	6 | to 64 | ID of the Entity who declares the item, importer, or the one that declares the import to the Customs Agency. |
|trade_agreements |	N | String	|2 to 16 |	List of trade agreements codes reported in the import transaction separated by a “–“ symbol. |
|seller_id | N	| String | 1 to 64 | ID of the Entity who sells the product to the importer. Note: If no ID is provided, this field can be the seller name string removing spaces and special characters. |
|broker_id | Y	| String | 6 to 16 | ID of the Broker who acts on behalf of the importer. |
|document_type | Y | String | 1 | String alphanumeric code that identifies the type of document: (Fixed value not possible to be customized). A = Import, B = Export, C = Transit |
|declaration_id | Y | String | 8 to 100 | Character code that identifies the customs declaration ID. declaration_id is a unique value not possible to be duplicate. If data records are loaded by product/service line, you should add a consecutive number to de declaration_id value. Declaration_id + Consecutive Number by product. Example: 2abcdf00001, 2abcdf00002. Unique value not possible to be duplicated |
|acceptance_date | Y	 | Date | Universal Format | Date and time at which the declaration is accepted by the customs agency in the format YYYY-MM-DD HH:MM:SS |
|seller_name	| N | String | 1 to 64 | Name of the company selling the products/services. |
|tax_rate | N | Float | 2 to 12 | Tax rate of the item (%) |
|currency | N	| String | 3 | Currency code according to ISO 4217 |
|exchange_rate | Y	| Float | 2 to 8 | The National Central Bank exchange reference rate on the day of the transaction. Format: XX.YYYY. Example: 11.5867. |
|payment_type | N | String | 1 to 16 | Tariff payment type (e.g., Usance credit payable at sight, bond, card, cash). |
|office_id_entry | N | String | 1 to 16 | Customs office that receives the declaration (e.g., Seoul regional customs) |
|tax_type | N | String | 1 to 16 | FTA Preferential rate. If more than one rate, add the preferential rates separated by a dash "-". |
|country_of_origin_code | N | String | 1 to 32 |It is the identification of the location where the transaction is placed. It could be a location catalog or geolocation data. Consider one of these options: Country of origin, Country of manufacturing, Country of Selling, Country of Re-expedition |
|hs_code | N | String |	1 to 16 | 8 to 14-digit product HS code (e.g., 090121xxxx = Coffee, Roasted, Not Decaffeinated) |
|hs_product_description | N | String | 1 to 128 | Description of the imported item in text |
|net_mass |	N | Float | 2 to 18 | Mass without any packaging (kg) |
|gross_mass |	N |	Float | 2 to 18 | Gross Mass of the item (kg) |
|Item_price |	N | Float |	2 to 18	| Assessed value of an item |
|unit_mass |	N | Float | 2 to 18	| Unit mass of the item |
|tariff_taxable |	N | Float |	2 to 18 | Taxable tariff of the item |
|total_value_declared | Y | Float | 2 to 18 | total value declared of the item |
|tariff_value | Y | Float | 2 to 18 | Tariff value of the item |
|volumetric_size | N | Float | 2 to 18 | Volumetric size of the item |
|package_set_units | N | Float | 2 to 18 | Total Units declared in every package of the declaration |
|package_set_weight | N | Float | 2 to 18 | Total Weight declared for inevery package of the declaration |

---

## entity profile file

|ENTITY  |FIELD NAME | TYPE  | LENGTH  | DESCRIPTION  
|--|--|--|--|--|
|importer_id   |Y  |String  |6 to 64  |ID of the importer  |
|importer_type  |N  |String |1 to 16  |Importer Type |
|importer_condition  |N  |String  |2 to 16 |Active, Inactive, Suspended  |
|importer_segment  |N  |String  |2 to 16  |Sector or classification of the importer. |
|importer_size  |N  |String  |2 to 16  |Two character code that identifies the size of the target entity. XS = Extra Small, SS = Small, MS = Medium Small, MM = Medium, LL = Large, XL = Extra Large or Big Entity |
|nace_code1  |N  |String  |2 to 16  |String value (numeric value) that indicates the code of the primary economic activity of the target entity. The activity code should follow (recommended) the International Standard Industrial Classification of All Economic Activities (ISIC) defined by the United Nations, or NACE.  |
|nace_code2  |N  |String  |2 to 16  |String value (numeric value) that indicates the code of the primary economic activity of the target entity. The activity code should follow (recommended) the International Standard Industrial Classification of All Economic Activities (ISIC) defined by the United Nations, or NACE.  |
|nace_code3  |N  |Integer  |0 to 24  |String value (numeric value) that indicates the code of the primary economic activity of the target entity. The activity code should follow (recommended) the International Standard Industrial Classification of All Economic Activities (ISIC) defined by the United Nations, or NACE.   |
|employees_number  |N  |Integer  |1 to 24 |Number of employees declared by the company on the registration, or updated during reporting. |
|legal_reg_date |N  |Date |YYYY-MM-DD  |Date at which the target entity is registered at the Ministry of Economy, or Chambers of Commerce or equivalent government entity, in the format YYYY-MM-DD  |
|gov_reg_date |N  |Date  |YYYY-MM-DD |Date at which the target entity first registered to the government agency in the format YYYY-MM-DD  |
|enroll_date |N  |Date  |YYYY-MM-DD  |Date at which the target entity is enrolled to submit transactions of interest, in the format YYYY-MM-DD  |
|reported_assets  |N  |Integer  |1 to 24 |Confirmation if the target entity reported any assets to any government agency. 1 = Yes, 0 =N |
|total_capital  |N  |Float  |4 to 24  |Numeric data with 2 to 5 decimal places, corresponds to the total amount of capital informed by the target entity.  |
|social_capital  |N  |Float  |4 to 24  |Numeric data with 2 to 5 decimal places, corresponds to the social amount of capital informed by the target entity.  |
|total_assets  |N  |Float  |4 to 24  |Numeric data with 2 to 5 decimal places, corresponds to the total assets informed by the target entity.  |
|total_fixed_assets  |N  |Float  |4 to 24  |Numeric data with 2 to 5 decimal places, corresponds to the total fixed assets of capital informed by the target entity.  |
|total_liabilities  |N  |Float  |4 to 24  |Numeric data with 2 to 5 decimal places, corresponds to the total liabilities informed by the target entity.  |
|gross_income  |N  |Float  |4 to 24  |Numeric data with 2 to 5 decimal places, corresponds to target entity gross income reported.  |
|net_income  |N  |Float  |4 to 24  |Numeric data with 2 to 5 decimal places, corresponds to target entity net income reported  |
|period_imports_value  |N  |Float  |4 to 24  |Numeric data with 2 to 5 decimal places, corresponds to the total value of operations reported by the target entity to the government.  |
|period_exports_value  |N  |Float  |4 to 24  |Numeric data with 2 to 5 decimal places, corresponds to any additional value of operations reported by the target entity to the government.  |
|state  |N  |String  |2 to 24  |Code to identify the state of registration for the target entity. It is a geolocation code attribute of the main entity.  |
|municipality  |N  |String  |2 to 24  |Code to identify the municipality of registration for the target entity. It is a geolocation code attribute of the main entity.  |
|city  |N  |String  |2 to 24  |Code to identify the city of registration for the target entity. It is a geolocation code attribute of the main entity.  |

---

## Exchange Rate file
|ENTITY  |FIELD  |TYPE  |LENGHT  |DESCRIPTION  |
|--|--|--|--|--|
|Exchange Rate  |ISO_CODE  |String  |3  |ISO Code for the different currencies supported by the national e-Invoicing system. Code according to ISO 4217 <br/><br/> Reference: <https://en.wikipedia.org/wiki/ISO_4217>
|Exchange Rate  |DESCRIPTION  |String  |256  |Currency Name. Example: USA Dollar, Pound Sterling, Mexican Peso, etc.   |
|Exchange Rate  |Day  |Date  |YYYY-MM-DD  |Historical day in the format YYYY-MM-DD, from the minimum issued_date reported in the transaction dataset to the maximum date reported in the issued_date in the transaction dataset   |
