# ADSD Accelerator – Cost Estimation (Microsoft Fabric)

## Overview

The ADSD Accelerator now runs entirely on **Microsoft Fabric**, simplifying the architecture and consolidating services such as data engineering, storage, and analytics into a single platform.

Cost estimation is primarily driven by:

- **Fabric Capacity (compute)**
- **Data volume (storage and processing)**
- **Concurrency and performance requirements**
- **Power BI licensing**

---

## Key Considerations

The total cost of the solution depends on:

- Volume of data processed (GB / TB / PB)
- Frequency of pipeline execution
- Number of concurrent users
- Performance expectations (latency, refresh times)
- Environment strategy (Dev / Test / Prod separation)

---

## Fabric Capacity Guidance (Critical)

Microsoft Fabric uses a **capacity-based model (F-SKUs)**.

> ⚠️ **Important Recommendation:**
>
> - Capacities **below F64 (F2–F32)** are intended **only for development, testing, and exploration**
> - **Production environments must use a minimum of F64 capacity**

### Why F64 for Production?

- Provides sufficient compute for:
  - Large-scale data processing
  - Concurrent workloads (pipelines, notebooks, SQL, Power BI)
- Avoids throttling due to Fabric capacity limits
- Ensures stable performance under load
- Supports enterprise-grade workloads and SLA expectations

---

## Fabric Capacity Pricing

Below are example SKUs and typical use cases:

| SKU | Use Case | Approx Monthly Cost (USD) |
|-----|---------|---------------------------|
| F2  | Small dev / PoC | ~$250 |
| F4  | Dev / light workloads | ~$500 |
| F8  | Standard dev / test | ~$1,000 |
| F16 | Medium testing workloads | ~$2,000 |
| F32 | Advanced testing / pre-prod | ~$4,000 |
| F64 | **Minimum production baseline** | ~$8,000+ |

> ⚠️ These values are approximate and depend on region and billing model (Pay-As-You-Go vs Reserved).

---

## Power BI Licensing

Each user accessing reports requires a license.

| License | Use Case | Approx Cost (USD / user / month) |
|--------|---------|----------------------------------|
| Power BI Pro | Standard reporting and sharing | ~$10 |
| Power BI Premium Per User (PPU) | Advanced features | ~$20 |

> ⚠️ Minimum requirement: **Power BI Pro**

---

## Sample Cost Scenarios

### 1. Sandbox Environment / Initial Exploration 

- Fabric Capacity: **F4**
- Users: 5 (Power BI Pro)

**Estimated Monthly Cost:**

- Fabric: ~$500  
- Power BI: ~$50  
- **Total: ~$550/month**

---

### 2. Test / Development

- Fabric Capacity: **F8–F32**
- Users: 10 (Power BI Pro)

**Estimated Monthly Cost:**

- Fabric: ~$1,000 – $4,000  
- Power BI: ~$100  
- **Total: ~$1,100 – $4,100/month**

---

### 3. Production Environment

- Fabric Capacity: **F64 (minimum)**
- Users: 20 (Power BI Pro)

**Estimated Monthly Cost:**

- Fabric: ~$8,000+  
- Power BI: ~$200  
- **Total: ~$8,200+/month**

> ⚠️ For high-volume or mission-critical workloads, consider **F128 or higher**

---

## Architecture Simplification (Fabric)

With Microsoft Fabric, the following legacy Azure services are **no longer required**:

- ❌ Synapse Workspace  
- ❌ Spark Pools (separate provisioning)  
- ❌ ADLS Gen2 (managed by OneLake)  
- ❌ Log Analytics (basic monitoring included)  

### Replaced by:

- ✅ OneLake (storage)  
- ✅ Fabric Data Engineering (Spark)  
- ✅ Fabric Pipelines  
- ✅ Lakehouse + SQL Endpoint  
- ✅ Built-in monitoring  

---

## Pricing Reference

Pricing estimates are based on publicly available Microsoft pricing as of:

**📅 April 2026**

For the most accurate and updated pricing, refer to:

- Microsoft Fabric Pricing  
- Power BI Pricing  

---

## Notes

- Costs may vary significantly depending on workload patterns  
- Reserved capacity can reduce costs (up to ~40%)  
- Capacity can be paused to reduce compute cost (storage still applies)  
- It is recommended to use separate capacities for Dev/Test/Prod  

---

## Summary

The ADSD Accelerator cost model in Fabric is:

- **Simpler** (single platform)
- **Scalable** (capacity-based)
- **Flexible** (pay-as-you-go or reserved)

> ⚠️ **Key takeaway:**  
> Use **F2–F32 for development/testing only** and **F64 or higher for production workloads**

---

At this point this step is complete, please return to the [Deployment Overview](/README.md#deployment-overview) step and continue.
