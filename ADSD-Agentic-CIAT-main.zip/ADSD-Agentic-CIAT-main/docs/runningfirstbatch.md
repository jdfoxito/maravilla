# Running your First Batch (Microsoft Fabric)

Before running your first batch, please ensure you have verified the following prerequisites:

- [Input data schemas](inputdataschema.md)  
- [Data is uploaded properly](datauploadspec.md)  
- [Hyperparameters have been tuned for your dataset](hyperparameters.md)  

Once the prerequisites are completed, you can proceed with executing the ADSD Accelerator pipelines in Microsoft Fabric.

---

## Important – Test Dataset

A large synthetic dataset is available for testing the ADSD Accelerator [Test Data](/test_data/readme.md)

This dataset can be used to validate performance and scalability.

---

## Step 1 — Access Microsoft Fabric Workspace

All pipeline execution and monitoring is now performed directly within **Microsoft Fabric**.

### Instructions

1. Navigate to Microsoft Fabric:
   ```
   https://app.fabric.microsoft.com
   ```
2. Sign in using your organizational account  
3. Open the workspace where the ADSD Accelerator was deployed  

---

## Step 2 — Validate Lakehouse and Data Availability

Before running the pipeline, confirm that:

- The Lakehouse is created and accessible  
- The folder structure exists:
  ```
  Files/input/
  ```
- All required files are uploaded to their corresponding folders  
- The setup notebook (`0_0_nb_folder_setup.Notebook`) has been executed successfully  

---

## Step 3 — Locate the Pipeline

1. Inside the workspace, navigate to the **Data Factory / Pipelines** section  
2. Locate the pipeline:

```
2_main_data_load
```

This is the main orchestration pipeline responsible for processing all input data.

---

## Step 4 — Execute the Pipeline

### Instructions

1. Open the pipeline `2_main_data_load`  
2. Click **Run** or **Trigger now**  
3. A parameters panel will appear  

### Parameters

- Use default values unless you need to override hyperparameters  
- If required, apply the values defined in the **Hyperparameters configuration step**

4. Click **Run** to start execution  

---

## Step 5 — Monitor Pipeline Execution

Microsoft Fabric provides built-in monitoring capabilities.

### Option 1 — Fabric Monitoring Hub

1. Navigate to the **Monitoring Hub** in Fabric  
2. Filter by:
   - Pipeline runs  
   - Notebook executions  
3. Locate your execution of `2_main_data_load`  
4. Review:
   - Execution status  
   - Duration  
   - Errors (if any)

---

### Option 2 — Pipeline Execution Details

1. Open the pipeline  
2. Select the active run  
3. Review each activity:
   - Data ingestion  
   - Transformations  
   - Data processing steps  

This allows you to identify failures or performance bottlenecks.

---

## Step 6 — Validate Results

Once the pipeline completes successfully, validate the outputs.

### Expected Outputs

- Data is loaded into Lakehouse tables  
- Transformations are applied correctly  
- Output datasets are available for analysis  

### Batch Validation

1. Navigate to the Lakehouse SQL Endpoint  
2. Query the following table:

```
batch_status
```

3. Confirm:

- A new row exists  
- A valid `batch_id` is generated  

> ⚠️ **Important:**  
> Save the `batch_id`, as it is required for Power BI validation and reporting.

---

## Step 7 — Power BI Validation (Optional but Recommended)

Once the batch is complete:

1. Open the Power BI template (`ADSD_Customs.pbit`)  
2. Configure:
   - `batch_num` = batch_id obtained  
   - `sql_endpoint` = Lakehouse SQL endpoint  
   - `database` = ADSD  
3. Validate that the report loads data correctly  

---

## Troubleshooting

### Common Issues

#### Pipeline fails to start
- Verify workspace is assigned to a Fabric capacity  
- Ensure permissions are correctly configured  

#### Missing input data
- Confirm files are uploaded to:
  ```
  Files/input/
  ```
- Validate folder structure  

#### No data in output tables
- Check pipeline execution logs  
- Validate transformations completed successfully  

#### No batch_id generated
- Confirm pipeline completed without errors  
- Validate `batch_status` table  

---

## Notes

- Fabric replaces Azure Synapse for ADSD execution  
- All processing (Spark, SQL, Pipelines) runs within Fabric capacity  
- Performance depends on selected Fabric SKU  
- For production workloads, use **F64 or higher capacity**  

---

## Summary

The ADSD execution flow in Microsoft Fabric is:

1. Prepare data in Lakehouse  
2. Run setup notebook  
3. Execute pipeline (`2_main_data_load`)  
4. Monitor execution  
5. Validate outputs and batch_id  
6. Analyze results in Power BI  

This streamlined approach leverages Fabric as a unified platform for data engineering, processing, and analytics.
