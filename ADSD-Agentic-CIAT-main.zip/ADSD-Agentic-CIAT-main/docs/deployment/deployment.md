
# ADSD Deployment Guide – Microsoft Fabric + GitHub

## Overview

This guide describes the end-to-end deployment process for the ADSD solution using **GitHub** and **Microsoft Fabric**.

The deployment flow is based on:
1. Forking the repository
2. Creating Fabric capacity
3. Creating and configuring a workspace
4. Connecting the workspace to GitHub
5. Synchronizing and validating artifacts

---

## Step 1 — Fork the Repository

Each user must create their own copy of the repository.

### Instructions

1. Go to the original repository in GitHub
2. Click on **Fork** (top-right corner)
3. Select your GitHub account as the destination
4. Wait until the fork is created

### Expected Outcome

- A new repository is created under your account:
  
```
https://github.com/<your-username>/<repository-name>
```

---

## Step 2 — Generate Personal Access Token (PAT)

This token is required to connect Fabric to GitHub.

### Instructions

1. Go to GitHub → Settings  
2. Navigate to:
   ```
   Developer Settings → Personal Access Tokens → Tokens (classic)
   ```
3. Click **Generate new token**
4. Configure:
   - Expiration: Recommended 30–90 days
   - Scopes:
     - ✅ repo
     - ✅ workflow (optional but recommended)

5. Click **Generate token**
6. Copy and securely store the token

> ⚠️ You will not be able to see the token again after closing the page.

---

## Step 3 — Create Fabric Capacity

Fabric requires a capacity to run workloads.

### Instructions

1. Go to Azure Portal
2. Search for **Microsoft Fabric**
3. Click **Create**
4. Configure:
   - Subscription
   - Resource Group
   - Region
   - Capacity Name
   - SKU (recommended):
     - Dev/Test: **F2 / F4 / F8**
     - Production: **F64 or higher**

5. Click **Review + Create**
6. Wait for deployment

---

## Step 4 — Create Fabric Workspace

### Instructions

1. Go to Microsoft Fabric
2. Click **Workspaces**
3. Click **New workspace**
4. Configure:
   - Name
   - Description (optional)
5. Click **Advanced**
6. Assign the workspace to the Fabric capacity created in Step 3
7. Click **Create**

### Expected Outcome

- Workspace created and linked to Fabric capacity

---

## Step 5 — Connect Workspace to GitHub

### Instructions

1. Open the workspace
2. Click **Settings**
3. Go to **Git integration**
4. Click **Connect to Git**
5. Configure:
   - Git provider: GitHub
   - Repository: your forked repo
   - Branch: main (or desired branch)
   - Folder: root (or specific path if applicable)

6. Authenticate using:
   - Your GitHub username
   - Personal Access Token (PAT)

7. Click **Connect and Sync**

---

## Step 6 — Initial Synchronization

### Instructions

1. After connecting, click **Sync**
2. Wait for synchronization to complete

### Important Notes

- Some artifacts may fail if:
  - Connections are missing
  - Permissions are not configured
- This is expected in the first sync

---

## Step 7 — Post-Sync Configuration (Critical)

After synchronization, manual adjustments are required.

### 1. Fix Lakehouse References

- Open notebooks and pipelines
- Update:
  - Lakehouse name
  - `workspaceId`
  - `artifactId`

### 2. Validate Connections

- Ensure all connections exist and are accessible
- Recreate connections if necessary

### 3. Verify Pipelines

- Open pipelines
- Validate:
  - Source paths
  - Destination paths
  - Parameters

---

## Step 8 — Deploy Lakehouse and Run Setup

### Instructions

1. Create or validate Lakehouse exists
2. Run the setup notebook:

```
0_0_nb_folder_setup.Notebook
```

3. Confirm folder structure is created:

```
Files/
└── input/
    ├── main_entity_profiles/
    ├── transactional_data/
    ├── exchange_rates/
    └── mappings/
```

---

## Step 9 — Upload Test Data

Upload test files into the Lakehouse under:

```
Files/input/
```

Ensure correct placement by category.

---

## Step 10 — Execute Pipelines

### Instructions

1. Run pipeline:

```
2_main_data_load
```

2. Validate execution

---

## Step 11 — Validation

### Expected Results

- Data successfully ingested
- Transformations completed
- Output tables generated

### Batch Validation

- A new row is created in:
  ```
  batch_status
  ```
- Capture the `batch_id`

> ⚠️ This `batch_id` is required for Power BI parameter configuration

---

## Troubleshooting

### Common Issues

- Git sync errors → Check permissions and PAT
- Missing connections → Recreate in workspace
- Pipeline failures → Validate file paths
- Lakehouse errors → Verify folder structure

---

## Best Practices

- Use separate capacities for Dev/Test/Prod
- Keep Git repository clean (code only)
- Store data only in Lakehouse
- Always validate after sync

---

## Summary

This deployment process ensures:

- Isolated environments per user (via fork)
- Proper integration between GitHub and Fabric
- Reproducible setup for testing and execution
