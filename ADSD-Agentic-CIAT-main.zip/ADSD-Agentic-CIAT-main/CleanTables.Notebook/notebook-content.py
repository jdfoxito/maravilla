# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse_name": "",
# META       "default_lakehouse_workspace_id": ""
# META     }
# META   }
# META }

# CELL ********************

# MAGIC %%configure -f
# MAGIC {
# MAGIC     "defaultLakehouse": {
# MAGIC         "name": "ADSD"
# MAGIC     }
# MAGIC }

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def drop_all_tables_except_batch_status(database_name):
    """
    Drops all tables in the specified database except batch_status table.
    
    Parameters:
        database_name (str): Name of the database/schema (e.g., 'ADSD')
    """
    
    print(f"Starting table cleanup process for database: {database_name}")
    
    # Get list of all tables in the database
    tables_df = spark.sql(f"SHOW TABLES IN {database_name}")
    all_tables = tables_df.select("tableName").rdd.flatMap(lambda x: x).collect()
    
    print(f"Total tables found: {len(all_tables)}")
    
    # Filter out batch_status
    tables_to_drop = [table for table in all_tables if table != "batch_status"]
    
    print(f"Tables to drop: {len(tables_to_drop)}")
    print(f"Table to keep: batch_status")
    
    if len(tables_to_drop) == 0:
        print("No tables to drop.")
        return
    
    # Drop each table
    dropped_count = 0
    error_count = 0
    
    for table_name in tables_to_drop:
        full_table_name = f"{database_name}.{table_name}"
        try:
            spark.sql(f"DROP TABLE IF EXISTS {full_table_name}")
            print(f"  ✓ Dropped: {table_name}")
            dropped_count += 1
        except Exception as e:
            print(f"  ✗ Error dropping {table_name}: {str(e)}")
            error_count += 1
    
    print(f"\n{'='*60}")
    print(f"Table cleanup completed")
    print(f"✓ Tables dropped: {dropped_count}")
    print(f"✗ Errors: {error_count}")
    print(f"✓ Tables preserved: 1 (batch_status)")
    print(f"{'='*60}")



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Get current workspace ID programmatically
workspace_id = notebookutils.runtime.context.get("currentWorkspaceId")
print(f"Workspace ID: {workspace_id}")

# Get lakehouse ID by name
lakehouse_name = "ADSD"  # this comes as parameter
lakehouse_info = notebookutils.lakehouse.get(lakehouse_name, workspace_id)
lakehouse_id = lakehouse_info.id
print(f"Lakehouse ID: {lakehouse_id}")




# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


drop_all_tables_except_batch_status('adsd')

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
