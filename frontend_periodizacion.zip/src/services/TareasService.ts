// frontend/src/services/TareasService.ts
// Ruta relativa: el proxy de Vite (o nginx en producción) la reenvía al backend.
const API_BASE = "/api/v1"

// ---------- Helper común ----------
async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
    const token = localStorage.getItem("access_token")
    const res = await fetch(`${API_BASE}${path}`, {
        ...options,
        headers: {
            "Content-Type": "application/json",
            ...(token && { Authorization: `Bearer ${token}` }),
            ...options.headers,
        },
    })

    if (res.status === 401) {
        localStorage.removeItem("access_token")
        window.location.href = "/login"
        throw new Error("Sesión expirada")
    }
    if (!res.ok) {
        // FastAPI responde {"detail": "..."}; se muestra ese texto y no el JSON crudo
        const cuerpo = await res.text()
        let detalle = cuerpo
        try {
            const json = JSON.parse(cuerpo)
            if (json?.detail) detalle = typeof json.detail === "string" ? json.detail : JSON.stringify(json.detail)
        } catch {
            // no era JSON (p. ej. "Internal Server Error"): se deja el texto
        }
        throw new Error(`Error ${res.status}: ${detalle}`)
    }
    return res.json() as Promise<T>
}

const post = <T>(path: string, body?: unknown) =>
    request<T>(path, { method: "POST", body: body !== undefined ? JSON.stringify(body) : undefined })

// Para lecturas donde la UI prefiere una lista vacía antes que un error
async function conRespaldo<T>(fn: () => Promise<T>, respaldo: T, contexto: string): Promise<T> {
    try {
        return await fn()
    } catch (error) {
        console.error(`Error ${contexto}:`, error)
        return respaldo
    }
}

// ---------- Tipos ----------
interface Conexion {
    id_conexion: number
    tipo: string
    nombre: string
    usuario?: string
    password?: string
    driver?: string
    puerto?: number
    host?: string
    url?: string
    cadena_directo?: string
    motor: string
    activo: boolean
}

export interface Tarea {
    id?: number
    titulo: string
    descripcion?: string
    sql: string
    id_calendario?: number
    fecha_inicio: string
    fecha_fin?: string
    estado_proceso: number
    usuario: string
    configuracion?: any
    id_conexion: number
}

export interface TareaResponse {
    tareas: Tarea[]
    total: number
}

export interface ValidacionSQLResponse {
    valido: boolean
    error?: string
    detalles?: string
}

export interface OracleConfig {
    spark_home: string
    spark_postgres: string
    spark_oracle: string
    wallet_location: string
    donde_corre_redis: string
    directorio_descarga: string
    oracle_home?: string
    tns_admin?: string
    detected_dsns: string[]
    sistema_operativo: string
    ejecutando_en: string
}

export interface WalletValidationRequest {
    host: string
    driver: string
    url?: string
    cadena_directo: string
}

export interface WalletValidationResponse {
    es_valido: boolean
    mensaje: string
    detalles: Record<string, any>
}

type ResultadoPrueba = { estado: string; mensaje: string }

// ---------- Tareas ----------
export const getTareas = (params?: Record<string, unknown>): Promise<TareaResponse> => {
    const query = new URLSearchParams()
    Object.entries(params ?? {}).forEach(([k, v]) => {
        if (v !== undefined && v !== null) query.append(k, String(v))
    })
    return request<TareaResponse>(`/periodizacion/tareas?${query}`)
}

export const crearTarea = (tarea: Tarea): Promise<Tarea> =>
    post<Tarea>("/periodizacion/tareas", {
        ...tarea,
        estado_proceso: Number(tarea.estado_proceso) || 2,
        fecha_inicio: new Date(tarea.fecha_inicio).toISOString(),
        fecha_fin: tarea.fecha_fin ? new Date(tarea.fecha_fin).toISOString() : null,
        id_calendario: tarea.id_calendario || null,
        id_conexion: tarea.id_conexion || null,
        configuracion: tarea.configuracion || {},
    })

export const ejecutarTarea = (id: number) => post<any>(`/periodizacion/tareas/${id}/ejecutar`)
export const detenerTarea = (id: number) => post<any>(`/periodizacion/tareas/${id}/detener`)
export const pausarTarea = (id: number) => post<any>(`/periodizacion/tareas/${id}/pausar`)

export const validarSQL = async (sql: string): Promise<ValidacionSQLResponse> => {
    try {
        return await post<ValidacionSQLResponse>("/periodizacion/validar-sql", { sql })
    } catch (error) {
        console.error("Error validando SQL:", error)
        return {
            valido: false,
            error: "Error de conexión con el servidor",
            detalles: error instanceof Error ? error.message : "Error desconocido",
        }
    }
}

export const obtenerCalendarios = () =>
    conRespaldo(() => request<any[]>("/periodizacion/calendarios"), [], "obteniendo calendarios")

export const obtenerLogsTarea = (id: number) =>
    conRespaldo(() => request<any[]>(`/periodizacion/tareas/${id}/logs`), [], "obteniendo logs")

// ---------- Conexiones ----------
export const obtenerConexiones = () =>
    conRespaldo(() => request<Conexion[]>("/conexiones/"), [], "obteniendo conexiones")

export const crearConexion = (conexion: Partial<Conexion>) =>
    post<Conexion>("/conexiones/", conexion)

export const probarConexion = (id: number) =>
    post<ResultadoPrueba>(`/conexiones/${id}/probar`)

export const probarConexionTemporal = (conexion: Partial<Conexion>) =>
    post<ResultadoPrueba>("/conexiones/probar-temporal", conexion)

// ---------- Oracle / Wallet ----------
export const obtenerConfigOracle = () =>
    request<OracleConfig>("/system-config/oracle-config")

export const validarWallet = (req: WalletValidationRequest) =>
    post<WalletValidationResponse>("/system-config/validate-wallet", req)