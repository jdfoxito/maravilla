import { createFileRoute } from '@tanstack/react-router'
import Periodizacion from '../../components/periodizacion/Periodizacion'

export const Route = createFileRoute('/_layout/periodizacion')({
    component: Periodizacion,
})


