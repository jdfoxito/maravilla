// frontend/src/components/periodizacion/ModalAgregarTarea.tsx
import React, { useState, useEffect, useCallback } from 'react';
import {
    Dialog,
    Field,
    Input,
    Textarea,
    VStack,
    HStack,
    Text,
    Grid,
    Card,
    Alert,
    NativeSelect,
    Button
} from "@chakra-ui/react";
import { Tarea, Conexion, ValidacionSQLResponse } from './types';

interface ModalAgregarTareaProps {
    isOpen: boolean;
    onClose: () => void;
    nuevaTarea: Partial<Tarea>;
    setNuevaTarea: (tarea: Partial<Tarea>) => void;
    conexiones: Conexion[];
    calendarios: any[];
    resultadoValidacion: ValidacionSQLResponse | null;
    validandoSQL: boolean;
    onValidarSQL: () => void;
    onCreateTarea: () => void;
    formatearTipoPeriodizacion: (tipo: string) => string;
    onGestionarConexiones: () => void;
}

const ModalAgregarTarea: React.FC<ModalAgregarTareaProps> = ({
    isOpen,
    onClose,
    nuevaTarea,
    setNuevaTarea,
    conexiones,
    calendarios,
    resultadoValidacion,
    validandoSQL,
    onValidarSQL,
    onCreateTarea,
    formatearTipoPeriodizacion,
    onGestionarConexiones
}) => {
    const [fechaMinima, setFechaMinima] = useState<string>('');
    const [errores, setErrores] = useState<{ [key: string]: string }>({});
    const [descripcionCaracteres, setDescripcionCaracteres] = useState(0);
    const conexionSeleccionada = conexiones.find(c => c.id_conexion === nuevaTarea.id_conexion);

    // Calcular fecha mínima (2 minutos en el futuro) cuando se abre el modal
    useEffect(() => {
        if (isOpen) {
            const ahora = new Date();
            ahora.setMinutes(ahora.getMinutes() + 2); // 2 minutos en el futuro
            const fechaMin = ahora.toISOString().slice(0, 16); // Formato YYYY-MM-DDTHH:mm
            setFechaMinima(fechaMin);

            // Si no hay fecha de inicio o es anterior a la mínima, establecer la mínima
            if (!nuevaTarea.fecha_inicio || new Date(nuevaTarea.fecha_inicio) < ahora) {
                setNuevaTarea({
                    ...nuevaTarea,
                    fecha_inicio: fechaMin
                });
            }
        }
    }, [isOpen]);

    // Actualizar contador de caracteres de descripción
    useEffect(() => {
        setDescripcionCaracteres(nuevaTarea.descripcion?.length || 0);
    }, [nuevaTarea.descripcion]);

    // Función de validación que NO actualiza el estado (para usar en disabled)
    const validarCamposSinEstado = useCallback(() => {
        // Validar conexión obligatoria
        if (!nuevaTarea.id_conexion) {
            return false;
        }

        // Validar fecha de inicio
        if (nuevaTarea.fecha_inicio) {
            const fechaSeleccionada = new Date(nuevaTarea.fecha_inicio);
            const fechaMinimaPermitida = new Date();
            fechaMinimaPermitida.setMinutes(fechaMinimaPermitida.getMinutes() + 2);

            if (fechaSeleccionada < fechaMinimaPermitida) {
                return false;
            }
        } else {
            return false;
        }

        // Validar título
        if (!nuevaTarea.titulo?.trim()) {
            return false;
        }

        // Validar SQL
        if (!nuevaTarea.sql?.trim()) {
            return false;
        }

        // Validar periodización
        if (!nuevaTarea.id_calendario) {
            return false;
        }

        return true;
    }, [nuevaTarea]);

    // Validar campos y actualizar estado de errores (solo cuando se necesite mostrar errores)
    const validarCamposConEstado = () => {
        const nuevosErrores: { [key: string]: string } = {};

        // Validar conexión obligatoria
        if (!nuevaTarea.id_conexion) {
            nuevosErrores.id_conexion = 'La conexión es obligatoria';
        }

        // Validar fecha de inicio
        if (nuevaTarea.fecha_inicio) {
            const fechaSeleccionada = new Date(nuevaTarea.fecha_inicio);
            const fechaMinimaPermitida = new Date();
            fechaMinimaPermitida.setMinutes(fechaMinimaPermitida.getMinutes() + 2);

            if (fechaSeleccionada < fechaMinimaPermitida) {
                nuevosErrores.fecha_inicio = 'La fecha de inicio debe ser al menos 2 minutos en el futuro';
            }
        } else {
            nuevosErrores.fecha_inicio = 'La fecha de inicio es obligatoria';
        }

        // Validar título
        if (!nuevaTarea.titulo?.trim()) {
            nuevosErrores.titulo = 'El título es obligatorio';
        }

        // Validar SQL
        if (!nuevaTarea.sql?.trim()) {
            nuevosErrores.sql = 'El SQL es obligatorio';
        }

        // Validar periodización
        if (!nuevaTarea.id_calendario) {
            nuevosErrores.id_calendario = 'La periodización es obligatoria';
        }

        setErrores(nuevosErrores);
        return Object.keys(nuevosErrores).length === 0;
    };

    // Validar antes de crear tarea
    const handleCrearTarea = () => {
        if (validarCamposConEstado()) {
            onCreateTarea();
        }
    };

    // Manejar cambios en los campos con validación
    const handleChangeConexion = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const value = e.target.value ? parseInt(e.target.value) : undefined;
        setNuevaTarea({
            ...nuevaTarea,
            id_conexion: value
        });
        // Limpiar error si existe
        if (errores.id_conexion) {
            setErrores(prev => ({ ...prev, id_conexion: '' }));
        }
    };

    const handleChangeFechaInicio = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        setNuevaTarea({
            ...nuevaTarea,
            fecha_inicio: value
        });
        // Limpiar error si existe
        if (errores.fecha_inicio) {
            setErrores(prev => ({ ...prev, fecha_inicio: '' }));
        }
    };

    const handleChangeTitulo = (e: React.ChangeEvent<HTMLInputElement>) => {
        setNuevaTarea({
            ...nuevaTarea,
            titulo: e.target.value
        });
        if (errores.titulo) {
            setErrores(prev => ({ ...prev, titulo: '' }));
        }
    };

    const handleChangeSQL = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
        setNuevaTarea({
            ...nuevaTarea,
            sql: e.target.value
        });
        if (errores.sql) {
            setErrores(prev => ({ ...prev, sql: '' }));
        }
    };

    const handleChangeDescripcion = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
        setNuevaTarea({
            ...nuevaTarea,
            descripcion: e.target.value
        });
    };

    const handleChangeCalendario = (id: number) => {
        setNuevaTarea({
            ...nuevaTarea,
            id_calendario: id
        });
        if (errores.id_calendario) {
            setErrores(prev => ({ ...prev, id_calendario: '' }));
        }
    };

    return (
        <Dialog.Root open={isOpen} onOpenChange={(e) => !e.open && onClose()}>
            <Dialog.Backdrop />
            <Dialog.Positioner>
                <Dialog.Content maxW="1080px" maxH="90vh" overflow="auto">
                    <Dialog.Header>
                        <VStack align="start" gap={1}>
                            <Dialog.Title>Agregar Nueva Tarea</Dialog.Title>
                            <Text fontSize="sm" color="gray.600">
                                Una tarea ejecuta una consulta SQL sobre la conexión elegida y deja el resultado en un archivo CSV.
                                Se ejecuta por primera vez en la fecha de inicio y luego se repite según la periodización.
                                Los campos con * son obligatorios.
                            </Text>
                        </VStack>
                    </Dialog.Header>
                    <Dialog.Body>
                        <VStack gap={4}>
                            {/* Título */}
                            <Field.Root width="100%">
                                <Field.Label>Título *</Field.Label>
                                <Input
                                    value={nuevaTarea.titulo || ''}
                                    onChange={handleChangeTitulo}
                                    placeholder="Título de la tarea"
                                />
                                <Field.HelperText>
                                    Nombre corto con el que verá la tarea en la lista (ej. "Ventas mensuales por provincia").
                                </Field.HelperText>
                                {errores.titulo && (
                                    <Field.HelperText color="red.500">
                                        {errores.titulo}
                                    </Field.HelperText>
                                )}
                            </Field.Root>

                            <Grid templateColumns="6fr 4fr" gap={6} width="100%">
                                <VStack gap={4}>
                                    <Field.Root width="100%">
                                        <Field.Label>Descripción</Field.Label>
                                        <Textarea
                                            value={nuevaTarea.descripcion || ''}
                                            onChange={handleChangeDescripcion}
                                            placeholder="Descripción de la tarea"
                                            rows={3}
                                        />
                                        <Field.HelperText>
                                            {descripcionCaracteres}/500 caracteres · Para qué sirve, quién la usa o qué filtra la consulta.
                                        </Field.HelperText>
                                    </Field.Root>
                                </VStack>

                                <VStack gap={4}>
                                    <Field.Root width="100%">
                                        <Field.Label>Conexión de Base de Datos *</Field.Label>
                                        <NativeSelect.Root>
                                            <NativeSelect.Field
                                                value={nuevaTarea.id_conexion?.toString() || ''}
                                                onChange={handleChangeConexion}
                                            >
                                                <option value="">Seleccionar conexión</option>
                                                {conexiones.map((conexion) => (
                                                    <option key={conexion.id_conexion} value={conexion.id_conexion.toString()}>
                                                        {conexion.nombre} ({conexion.motor})
                                                    </option>
                                                ))}
                                            </NativeSelect.Field>
                                            <NativeSelect.Indicator />
                                        </NativeSelect.Root>
                                        {errores.id_conexion && (
                                            <Field.HelperText color="red.500">
                                                {errores.id_conexion}
                                            </Field.HelperText>
                                        )}
                                        <Button
                                            size="sm"
                                            variant="ghost"
                                            onClick={onGestionarConexiones}
                                            mt={1}
                                        >
                                            Gestionar Conexiones
                                        </Button>
                                        <Field.HelperText>
                                            Base de datos donde se ejecutará el SQL. Si no aparece, créela y pruébela en "Gestionar Conexiones".
                                        </Field.HelperText>
                                    </Field.Root>

                                    {conexionSeleccionada && (
                                        <Card.Root variant="outline" width="100%">
                                            <Card.Body>
                                                <VStack align="start" gap={1}>
                                                    <Text fontSize="sm" fontWeight="medium">
                                                        {conexionSeleccionada.nombre}
                                                    </Text>
                                                    {conexionSeleccionada.tipo === 'wallet' ? (
                                                        <Text fontSize="xs" color="gray.600">
                                                            Oracle Wallet · DSN {conexionSeleccionada.nombre} · credenciales del wallet del servidor
                                                        </Text>
                                                    ) : (
                                                        <>
                                                            <Text fontSize="xs" color="gray.600">
                                                                {conexionSeleccionada.motor} - {conexionSeleccionada.host}:{conexionSeleccionada.puerto}
                                                                {conexionSeleccionada.driver ? ` / ${conexionSeleccionada.driver}` : ''}
                                                            </Text>
                                                            <Text fontSize="xs" color="gray.500">
                                                                Usuario: {conexionSeleccionada.usuario}
                                                            </Text>
                                                        </>
                                                    )}
                                                </VStack>
                                            </Card.Body>
                                        </Card.Root>
                                    )}
                                </VStack>
                            </Grid>

                            <Grid templateColumns="1fr 1fr" gap={6} width="100%">
                                <VStack gap={4}>
                                    <Field.Root>
                                        <Field.Label>SQL *</Field.Label>
                                        <Textarea
                                            fontFamily="monospace"
                                            value={nuevaTarea.sql || ''}
                                            onChange={handleChangeSQL}
                                            placeholder="SELECT * FROM tabla"
                                            rows={8}
                                        />
                                        <Field.HelperText>
                                            Escriba la consulta en el dialecto de la conexión (Oracle, PostgreSQL…) y sin ";" al final.
                                            Use "Validar SQL" antes de crear la tarea.
                                        </Field.HelperText>
                                        {errores.sql && (
                                            <Field.HelperText color="red.500">
                                                {errores.sql}
                                            </Field.HelperText>
                                        )}
                                    </Field.Root>

                                    <Button
                                        onClick={onValidarSQL}
                                        colorScheme={resultadoValidacion?.valido ? "green" : "blue"}
                                        disabled={validandoSQL || !nuevaTarea.sql?.trim()}
                                        width="100%"
                                    >
                                        {validandoSQL ? "Validando..." : "Validar SQL"}
                                    </Button>

                                    {resultadoValidacion && (
                                        <Alert.Root status={resultadoValidacion.valido ? "success" : "error"}>
                                            <Alert.Content>
                                                <Alert.Description>
                                                    {resultadoValidacion.valido ?
                                                        resultadoValidacion.detalles : resultadoValidacion.error}
                                                </Alert.Description>
                                            </Alert.Content>
                                        </Alert.Root>
                                    )}

                                    <Field.Root>
                                        <Field.Label>Fecha Inicio *</Field.Label>
                                        <Input
                                            type="datetime-local"
                                            value={nuevaTarea.fecha_inicio || ''}
                                            onChange={handleChangeFechaInicio}
                                            min={fechaMinima}
                                        />
                                        {errores.fecha_inicio && (
                                            <Field.HelperText color="red.500">
                                                {errores.fecha_inicio}
                                            </Field.HelperText>
                                        )}
                                        <Field.HelperText>
                                            Primera ejecución. Debe ser al menos 2 minutos en el futuro.
                                        </Field.HelperText>
                                    </Field.Root>
                                </VStack>

                                <VStack gap={4}>
                                    <Field.Root>
                                        <Field.Label>Periodización *</Field.Label>
                                        <Grid templateColumns="1fr 1fr" gap={2}>
                                            {calendarios.map((calendario) => (
                                                <Button
                                                    key={calendario.id}
                                                    size="sm"
                                                    variant={nuevaTarea.id_calendario === calendario.id ? "solid" : "outline"}
                                                    onClick={() => handleChangeCalendario(calendario.id)}
                                                >
                                                    {formatearTipoPeriodizacion(calendario.tipo_periodizacion)}
                                                </Button>
                                            ))}
                                        </Grid>
                                        {errores.id_calendario && (
                                            <Field.HelperText color="red.500">
                                                {errores.id_calendario}
                                            </Field.HelperText>
                                        )}
                                        <Field.HelperText>
                                            Cada cuánto se repite la tarea después de la primera ejecución.
                                        </Field.HelperText>
                                    </Field.Root>
                                    {nuevaTarea.id_calendario && (
                                        <Card.Root variant="outline">
                                            <Card.Body>
                                                <VStack align="start" gap={2}>
                                                    <Text fontSize="sm" fontWeight="medium">
                                                        {formatearTipoPeriodizacion(
                                                            calendarios.find(c => c.id === nuevaTarea.id_calendario)?.tipo_periodizacion
                                                        )}
                                                    </Text>
                                                    <Text fontSize="sm" color="gray.600">
                                                        {calendarios.find(c => c.id === nuevaTarea.id_calendario)?.descripcion}
                                                    </Text>
                                                    {calendarios.find(c => c.id === nuevaTarea.id_calendario)?.parametros && (
                                                        <Text fontSize="xs" color="gray.500">
                                                            Parámetros: {JSON.stringify(
                                                                calendarios.find(c => c.id === nuevaTarea.id_calendario)?.parametros
                                                            )}
                                                        </Text>
                                                    )}
                                                </VStack>
                                            </Card.Body>
                                        </Card.Root>
                                    )}
                                </VStack>
                            </Grid>

                            <HStack gap={3} justify="end" width="100%">
                                <Button variant="ghost" onClick={onClose}>
                                    Cancelar
                                </Button>
                                <Button
                                    colorScheme="blue"
                                    onClick={handleCrearTarea}
                                    disabled={!validarCamposSinEstado()}
                                >
                                    Crear Tarea
                                </Button>
                            </HStack>
                        </VStack>
                    </Dialog.Body>
                </Dialog.Content>
            </Dialog.Positioner>
        </Dialog.Root>
    );
};

export default ModalAgregarTarea;