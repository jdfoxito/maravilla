// frontend/src/components/periodizacion/ModalConexiones.tsx
import React, { useState, useEffect, useCallback } from 'react';
import {
    Dialog,
    VStack,
    Grid,
    Field,
    Input,
    Button,
    HStack,
    Alert,
    NativeSelect,
    Text,
    Spinner,
    Box
} from "@chakra-ui/react";
import { Conexion } from './types';
import { obtenerConfigOracle, validarWallet, OracleConfig } from '../../services/TareasService';

interface ModalConexionesProps {
    isOpen: boolean;
    onClose: () => void;
    nuevaConexion: Partial<Conexion>;
    setNuevaConexion: (conexion: Partial<Conexion>) => void;
    conexiones: Conexion[];
    probandoConexion: boolean;
    resultadoPrueba: { estado: string, mensaje: string } | null;
    onProbarConexion: () => void;
    onCreateConexion: () => void;
    validarCamposConexion: () => boolean;
    conexionYaExiste: () => boolean;
    puedeCrearConexion: () => boolean;
    onResetResultadoPrueba: () => void;
}

const ModalConexiones: React.FC<ModalConexionesProps> = ({
    isOpen,
    onClose,
    nuevaConexion,
    setNuevaConexion,
    conexiones,
    probandoConexion,
    resultadoPrueba,
    onProbarConexion,
    onCreateConexion,
    validarCamposConexion,
    conexionYaExiste,
    puedeCrearConexion,
    onResetResultadoPrueba
}) => {
    const [oracleConfig, setOracleConfig] = useState<OracleConfig | null>(null);
    const [cargandoConfig, setCargandoConfig] = useState(false);
    const [configError, setConfigError] = useState<string | null>(null);
    const [validacionWallet, setValidacionWallet] = useState<{ es_valido: boolean, mensaje: string, detalles: any } | null>(null);
    const [dsnSeleccionado, setDsnSeleccionado] = useState<string>('');

    // Cargar configuración Oracle cuando se abre el modal
    useEffect(() => {
        if (isOpen) {
            cargarConfiguracionOracle();
            setConfigError(null);
        }
    }, [isOpen]);

    // Auto-configurar cuando cambia a Wallet
    useEffect(() => {
        if (nuevaConexion.tipo === 'wallet' && oracleConfig) {
            autoConfigurarWallet();
        }
    }, [nuevaConexion.tipo, oracleConfig]);

    const cargarConfiguracionOracle = async () => {
        setCargandoConfig(true);
        setConfigError(null);
        try {
            const config = await obtenerConfigOracle();
            setOracleConfig(config);
        } catch (error) {
            console.error('Error cargando configuración Oracle:', error);
            setConfigError('No se pudo cargar la configuración del sistema. Verifique que el servidor esté funcionando correctamente.');
        } finally {
            setCargandoConfig(false);
        }
    };

    const autoConfigurarWallet = useCallback(() => {
        if (!oracleConfig) return;

        const updates: Partial<Conexion> = {
            host: oracleConfig.donde_corre_redis || 'localhost',
            url: oracleConfig.oracle_home,
            cadena_directo: oracleConfig.wallet_location
        };

        // Auto-seleccionar el primer DSN detectado si hay disponibles
        if (oracleConfig.detected_dsns && oracleConfig.detected_dsns.length > 0 && !nuevaConexion.driver) {
            updates.driver = oracleConfig.detected_dsns[0];
            // También auto-completar el nombre de la conexión con el DSN seleccionado
            updates.nombre = oracleConfig.detected_dsns[0];
            setDsnSeleccionado(oracleConfig.detected_dsns[0]);
        }

        setNuevaConexion({ ...nuevaConexion, ...updates });
    }, [nuevaConexion, oracleConfig, setNuevaConexion]);

    // Función para validar wallet en tiempo real
    const validarWalletEnTiempoReal = async () => {
        if (!nuevaConexion.driver) {
            return;
        }

        try {
            const resultado = await validarWallet({
                host: oracleConfig?.donde_corre_redis || 'localhost',
                driver: nuevaConexion.driver,
                url: oracleConfig?.oracle_home,
                cadena_directo: oracleConfig?.wallet_location || ''
            });

            setValidacionWallet(resultado);
        } catch (error) {
            console.error('Error validando wallet:', error);
            setValidacionWallet({
                es_valido: false,
                mensaje: 'Error al validar el wallet',
                detalles: {}
            });
        }
    };

    // Efecto para validación en tiempo real
    useEffect(() => {
        if (nuevaConexion.tipo === 'wallet' && nuevaConexion.driver) {
            const timeoutId = setTimeout(() => {
                validarWalletEnTiempoReal();
            }, 1000);

            return () => clearTimeout(timeoutId);
        }
    }, [nuevaConexion.driver]);

    // Manejar cambios en el DSN
    const handleDriverChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const driver = e.target.value;
        setDsnSeleccionado(driver);

        // Driver y nombre en una sola actualización: con dos llamadas seguidas
        // la segunda partía del estado viejo y deshacía la primera.
        // "other" limpia ambos para que el usuario escriba el DSN a mano.
        const valor = driver === 'other' ? '' : driver;
        setNuevaConexion({ ...nuevaConexion, driver: valor, nombre: valor });
        onResetResultadoPrueba();
        setValidacionWallet(null);
    };

    // Manejar cambios manuales en el DSN cuando es "other"
    const handleDriverManualChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const driver = e.target.value;
        // En wallet el nombre de la conexión ES el DSN: se actualizan juntos
        // (antes, con dos llamadas seguidas, la segunda pisaba a la primera y el nombre se quedaba en 1 letra)
        setNuevaConexion({ ...nuevaConexion, driver, nombre: driver });
        onResetResultadoPrueba();
        setValidacionWallet(null);
    };

    // Manejar cambios en los inputs
    const handleInputChange = (field: keyof Conexion, value: any) => {
        setNuevaConexion({ ...nuevaConexion, [field]: value });
        onResetResultadoPrueba();
        setValidacionWallet(null);
    };

    const handleMotorChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const motor = e.target.value;
        setNuevaConexion({
            ...nuevaConexion,
            motor,
            // Resetear campos específicos del motor anterior
            host: motor === 'oracle' ? 'localhost' : nuevaConexion.host,
            puerto: motor === 'postgres' ? 5432 : motor === 'mysql' ? 3306 : motor === 'sqlserver' ? 1433 : nuevaConexion.puerto
        });
        onResetResultadoPrueba();
    };

    // Función para formatear el mensaje de resultado de prueba
    const formatearMensajePrueba = () => {
        if (!resultadoPrueba) return null;

        const etiqueta = nuevaConexion.tipo === 'wallet' ? 'Wallet' : 'Conexión';
        if (resultadoPrueba.estado === 'conectado') {
            return `✅ ${etiqueta} ${nuevaConexion.nombre} conectado correctamente. Ya puede pulsar "Crear Conexión".`;
        } else {
            return `❌ ${etiqueta} ${nuevaConexion.nombre} no tiene conexión: ${resultadoPrueba.mensaje}`;
        }
    };

    return (
        <Dialog.Root open={isOpen} onOpenChange={(e) => {
            // En v3 onOpenChange recibe { open }, no un booleano
            if (!e.open) {
                onClose();
                setConfigError(null);
                setValidacionWallet(null);
                setDsnSeleccionado('');
            }
        }}>
            <Dialog.Backdrop />
            <Dialog.Positioner>
                <Dialog.Content maxW="720px">
                    <Dialog.Header>
                        <VStack align="start" gap={1}>
                            <Dialog.Title>Gestión de Conexiones</Dialog.Title>
                            <Text fontSize="sm" color="gray.600">
                                Registre aquí la base de datos de donde las tareas leerán la información.
                                Pasos: 1) elija el tipo, 2) complete los datos, 3) pulse <strong>Probar Conexión</strong>
                                y 4) si la prueba es exitosa, <strong>Crear Conexión</strong> la deja lista para usarla en las tareas.
                            </Text>
                        </VStack>
                        {cargandoConfig && (
                            <HStack gap={2}>
                                <Spinner size="sm" />
                                <Text fontSize="sm">Cargando configuración del sistema...</Text>
                            </HStack>
                        )}
                    </Dialog.Header>
                    <Dialog.Body>
                        <VStack gap={4}>
                            {configError && (
                                <Alert.Root status="error">
                                    <Alert.Content>
                                        <Alert.Description>
                                            {configError}
                                        </Alert.Description>
                                    </Alert.Content>
                                </Alert.Root>
                            )}

                            <Grid templateColumns="1fr 1fr" gap={4} width="100%">
                                <Field.Root>
                                    <Field.Label>Tipo</Field.Label>
                                    <HStack gap={3}>
                                        <Button
                                            size="sm"
                                            variant={nuevaConexion.tipo === 'normal' ? "solid" : "outline"}
                                            onClick={() => {
                                                setNuevaConexion({
                                                    ...nuevaConexion,
                                                    tipo: 'normal',
                                                    motor: nuevaConexion.motor === 'oracle' ? 'postgres' : nuevaConexion.motor
                                                });
                                                onResetResultadoPrueba();
                                                setValidacionWallet(null);
                                                setDsnSeleccionado('');
                                            }}
                                        >
                                            Normal
                                        </Button>
                                        <Button
                                            size="sm"
                                            variant={nuevaConexion.tipo === 'wallet' ? "solid" : "outline"}
                                            onClick={() => {
                                                setNuevaConexion({
                                                    ...nuevaConexion,
                                                    tipo: 'wallet',
                                                    motor: 'oracle'
                                                });
                                                onResetResultadoPrueba();
                                            }}
                                        >
                                            Wallet
                                        </Button>
                                    </HStack>
                                    <Field.HelperText>
                                        {nuevaConexion.tipo === 'wallet'
                                            ? 'Wallet: Oracle sin escribir usuario ni clave; se usan las credenciales guardadas en el wallet del servidor.'
                                            : 'Normal: se conecta con host, puerto, usuario y contraseña.'}
                                    </Field.HelperText>
                                </Field.Root>

                                <Field.Root>
                                    <Field.Label>Motor *</Field.Label>
                                    {nuevaConexion.tipo === 'wallet' ? (
                                        <Input
                                            value="Oracle"
                                            readOnly
                                            backgroundColor="gray.50"
                                        />
                                    ) : (
                                        <NativeSelect.Root>
                                            <NativeSelect.Field value={nuevaConexion.motor || ''} onChange={handleMotorChange}>
                                                <option value="">Seleccionar motor</option>
                                                <option value="postgres">PostgreSQL</option>
                                                <option value="oracle">Oracle</option>
                                                <option value="mysql">MySQL</option>
                                                <option value="sqlserver">SQL Server</option>
                                                <option value="mongo">MongoDB</option>
                                            </NativeSelect.Field>
                                        </NativeSelect.Root>
                                    )}
                                </Field.Root>
                            </Grid>

                            {/* Campos específicos para conexión WALLET - ORDEN MEJORADO */}
                            {nuevaConexion.tipo === 'wallet' && (
                                <>
                                    {/* Información de configuración del sistema */}
                                    <Box width="100%" p={3} backgroundColor="blue.50" borderRadius="md">
                                        <VStack align="start" gap={2}>
                                            <Text fontWeight="medium">Configuración del Sistema Detectada</Text>
                                            <Text fontSize="sm">
                                                <strong>ORACLE_HOME:</strong> {oracleConfig?.oracle_home || 'No detectado'}
                                            </Text>
                                            <Text fontSize="sm">
                                                <strong>Wallet Location:</strong> {oracleConfig?.wallet_location || 'No detectado'}
                                            </Text>
                                            <Text fontSize="sm">
                                                <strong>Host:</strong> {oracleConfig?.donde_corre_redis || 'localhost'}
                                            </Text>
                                            <Text fontSize="sm" color="blue.600">
                                                ✅ Estos valores se usarán automáticamente desde la configuración del sistema
                                            </Text>
                                            <Text fontSize="xs" color="gray.600">
                                                Las rutas del cliente Oracle y del wallet las pone el servidor; no se guardan en la conexión.
                                                Solo necesita elegir el DSN.
                                            </Text>
                                        </VStack>
                                    </Box>

                                    {/* DSN PRIMERO - porque determina el nombre */}
                                    <Field.Root width="100%">
                                        <Field.Label>DSN (TNS Name) *</Field.Label>
                                        <NativeSelect.Root>
                                            <NativeSelect.Field
                                                value={dsnSeleccionado === 'other' ? 'other' : (nuevaConexion.driver || '')}
                                                onChange={handleDriverChange}
                                            >
                                                <option value="">Seleccionar DSN</option>
                                                {oracleConfig?.detected_dsns?.map(dsn => (
                                                    <option key={dsn} value={dsn}>{dsn}</option>
                                                ))}
                                                <option value="other">Otro (especificar)</option>
                                            </NativeSelect.Field>
                                        </NativeSelect.Root>
                                        {dsnSeleccionado === 'other' && (
                                            <Input
                                                mt={2}
                                                value={nuevaConexion.driver === 'other' ? '' : (nuevaConexion.driver || '')}
                                                onChange={handleDriverManualChange}
                                                placeholder="Ingrese el DSN manualmente"
                                            />
                                        )}
                                        <Field.HelperText>
                                            {oracleConfig?.detected_dsns && oracleConfig.detected_dsns.length > 0 ? (
                                                <Text color="green.500">
                                                    ✅ {oracleConfig.detected_dsns.length} DSNs detectados
                                                </Text>
                                            ) : (
                                                <Text color="orange.500">
                                                    ⚠️ No se detectaron DSNs automáticamente
                                                </Text>
                                            )}
                                            Alias definido en tnsnames.ora del wallet (ej. STAR_DESA). Es la base a la que
                                            apuntarán las tareas que usen esta conexión.
                                        </Field.HelperText>
                                    </Field.Root>

                                    {/* NOMBRE DE CONEXIÓN - se auto-completa con el DSN */}
                                    <Field.Root width="100%">
                                        <Field.Label>Nombre de Conexión *</Field.Label>
                                        <Input
                                            value={nuevaConexion.nombre || ''}
                                            onChange={(e) => handleInputChange('nombre', e.target.value)}
                                            placeholder="Nombre automático del wallet"
                                            backgroundColor={dsnSeleccionado && dsnSeleccionado !== 'other' ? 'gray.50' : 'white'}
                                            readOnly={!!dsnSeleccionado && dsnSeleccionado !== 'other'}
                                        />
                                        <Field.HelperText>
                                            {dsnSeleccionado && dsnSeleccionado !== 'other' ? (
                                                <Text color="blue.500">
                                                    🔒 Nombre sincronizado con el DSN seleccionado: en wallet el nombre de la conexión es el DSN
                                                </Text>
                                            ) : (
                                                <Text color="orange.500">
                                                    ⚠️ Ingrese manualmente el nombre del wallet
                                                </Text>
                                            )}
                                            {conexionYaExiste() && (
                                                <Text color="orange.500">
                                                    ⚠️ Ya existe una conexión con este nombre
                                                </Text>
                                            )}
                                        </Field.HelperText>
                                    </Field.Root>
                                </>
                            )}

                            {/* Campos específicos para conexión NORMAL */}
                            {nuevaConexion.tipo === 'normal' && (
                                <>
                                    <Field.Root width="100%">
                                        <Field.Label>Nombre de Conexión *</Field.Label>
                                        <Input
                                            value={nuevaConexion.nombre || ''}
                                            onChange={(e) => handleInputChange('nombre', e.target.value)}
                                            placeholder="Mi Conexión Oracle"
                                        />
                                        <Field.HelperText>
                                            <Text>Nombre con el que aparecerá al elegir la conexión en una tarea. Debe ser único.</Text>
                                            {conexionYaExiste() && (
                                                <Text color="orange.500">
                                                    ⚠️ Ya existe una conexión con este nombre
                                                </Text>
                                            )}
                                        </Field.HelperText>
                                    </Field.Root>

                                    <Grid templateColumns="1fr 1fr" gap={4} width="100%">
                                        <Field.Root>
                                            <Field.Label>Host *</Field.Label>
                                            <Input
                                                value={nuevaConexion.host || ''}
                                                onChange={(e) => handleInputChange('host', e.target.value)}
                                                placeholder="localhost"
                                            />
                                        </Field.Root>

                                        <Field.Root>
                                            <Field.Label>Puerto *</Field.Label>
                                            <Input
                                                type="number"
                                                value={nuevaConexion.puerto || ''}
                                                onChange={(e) => handleInputChange('puerto', parseInt(e.target.value) || undefined)}
                                                placeholder={
                                                    nuevaConexion.motor === 'postgres' ? '5432' :
                                                        nuevaConexion.motor === 'mysql' ? '3306' :
                                                            nuevaConexion.motor === 'sqlserver' ? '1433' :
                                                                nuevaConexion.motor === 'oracle' ? '1521' : '5432'
                                                }
                                            />
                                        </Field.Root>
                                    </Grid>

                                    <Grid templateColumns="1fr 1fr" gap={4} width="100%">
                                        <Field.Root>
                                            <Field.Label>Usuario *</Field.Label>
                                            <Input
                                                value={nuevaConexion.usuario || ''}
                                                onChange={(e) => handleInputChange('usuario', e.target.value)}
                                                placeholder="usuario"
                                            />
                                        </Field.Root>

                                        <Field.Root>
                                            <Field.Label>Contraseña *</Field.Label>
                                            <Input
                                                type="password"
                                                value={nuevaConexion.password || ''}
                                                onChange={(e) => handleInputChange('password', e.target.value)}
                                                placeholder="contraseña"
                                            />
                                        </Field.Root>
                                    </Grid>

                                    <Field.Root width="100%">
                                        <Field.Label>
                                            {nuevaConexion.motor === 'oracle' ? 'Service Name *' : 'Base de Datos *'}
                                        </Field.Label>
                                        <Input
                                            value={nuevaConexion.driver || ''}
                                            onChange={(e) => handleInputChange('driver', e.target.value)}
                                            placeholder={
                                                nuevaConexion.motor === 'oracle' ? 'ORCL' :
                                                    nuevaConexion.motor === 'postgres' ? 'mi_base_datos' :
                                                        nuevaConexion.motor === 'mysql' ? 'mi_base_datos' :
                                                            nuevaConexion.motor === 'sqlserver' ? 'mi_base_datos' : 'nombre_base_datos'
                                            }
                                        />
                                        <Field.HelperText>
                                            {nuevaConexion.motor === 'oracle'
                                                ? 'Service name de la instancia Oracle (no el SID).'
                                                : 'Nombre de la base de datos dentro del servidor.'}
                                        </Field.HelperText>
                                    </Field.Root>
                                </>
                            )}

                            {/* Validación en tiempo real del Wallet */}
                            {nuevaConexion.tipo === 'wallet' && validacionWallet && (
                                <Alert.Root status={validacionWallet.es_valido ? "success" : "error"}>
                                    <Alert.Content>
                                        <Alert.Description>
                                            {validacionWallet.mensaje}
                                            {validacionWallet.detalles && (
                                                <VStack align="start" mt={2}>
                                                    {validacionWallet.detalles.archivos_encontrados && (
                                                        <Text fontSize="sm">
                                                            ✅ Archivos: {validacionWallet.detalles.archivos_encontrados.join(', ')}
                                                        </Text>
                                                    )}
                                                    {validacionWallet.detalles.archivos_faltantes && validacionWallet.detalles.archivos_faltantes.length > 0 && (
                                                        <Text fontSize="sm">
                                                            ❌ Faltan: {validacionWallet.detalles.archivos_faltantes.join(', ')}
                                                        </Text>
                                                    )}
                                                    {validacionWallet.detalles.dsn_encontrado && (
                                                        <Text fontSize="sm">✅ DSN encontrado en tnsnames.ora</Text>
                                                    )}
                                                </VStack>
                                            )}
                                        </Alert.Description>
                                    </Alert.Content>
                                </Alert.Root>
                            )}

                            {/* Resultado de prueba de conexión */}
                            {resultadoPrueba && (
                                <Alert.Root status={resultadoPrueba.estado === 'conectado' ? 'success' : 'error'}>
                                    <Alert.Content>
                                        <Alert.Description>
                                            {formatearMensajePrueba()}
                                        </Alert.Description>
                                    </Alert.Content>
                                </Alert.Root>
                            )}

                            {!puedeCrearConexion() && validarCamposConexion() && !conexionYaExiste() && (
                                <Text fontSize="sm" color="gray.600" width="100%" textAlign="right">
                                    "Crear Conexión" se habilita después de una prueba exitosa.
                                </Text>
                            )}

                            <HStack gap={3} justify="end" width="100%">
                                <Button
                                    onClick={onProbarConexion}
                                    disabled={probandoConexion || !validarCamposConexion()}
                                    variant="outline"
                                >
                                    {probandoConexion ? "Probando..." : "Probar Conexión"}
                                </Button>
                                <Button variant="ghost" onClick={onClose}>
                                    Cancelar
                                </Button>
                                <Button
                                    colorScheme="blue"
                                    onClick={onCreateConexion}
                                    disabled={!puedeCrearConexion()}
                                >
                                    Crear Conexión
                                </Button>
                            </HStack>
                        </VStack>
                    </Dialog.Body>
                </Dialog.Content>
            </Dialog.Positioner>
        </Dialog.Root>
    );
};

export default ModalConexiones;