# -*- coding: utf-8 -*-
"""Interfaz de linea de comandos (CLI) del exportador.

app-main.py

Contiene el punto de entrada Click, utilidades de pantalla,
menu interactivo y subcomando verificar.

NOTA PYINSTALLER: Cuando se ejecuta como ejecutable --onefile,
PyInstaller descomprime en /tmp/_MEIxxxxxx. El codigo detecta
sys.frozen y usa el directorio del ejecutable real (sys.executable)
como directorio de trabajo para leer/escribir archivos.

Historial:
+--------------------+---------+------------------------------------------+
| Autor              | Version | Cambios                                  |
+--------------------+---------+------------------------------------------+
| Jim A. Gonzalez    | 1.0.0   | Extraido de exportador.py (Regla 43 SRI) |
| Jim A. Gonzalez    | 1.1.1   | Refactor main: complejidad 36 -> <20     |
| Jim A. Gonzalez    | 1.2.0   | Fix estado correo en verificacion remota   |
| Jim A. Gonzalez    | 1.3.0   | Deteccion PyInstaller frozen + rutas reales|
+--------------------+---------+------------------------------------------+
"""

from datetime import datetime
import logging
from pathlib import Path
import platform
import sys
from typing import Any, Dict, List, Optional, Tuple

import click

from app.da_comunes import resolver_raiz_proyecto
from app.da_config_manager import get_config_manager
from app.da_excepciones import TrazabilidadExcepciones
from app.da_exportador import ExportadorDatosAbiertos
from app.da_notificacion import NotificadorEmail
from app.da_validador import VerificadorRemoto


def _detectar_ruta_base() -> Path:
    """Detecta la ruta base del proyecto, considerando PyInstaller frozen.

    Delega en da_comunes.resolver_raiz_proyecto para no duplicar la
    logica de deteccion de rutas (Regla 43 SRI). Pasa __file__ para que
    en modo desarrollo la raiz se calcule subiendo desde app/.

    Returns:
        Path a la raiz del proyecto o directorio del ejecutable.
    """
    return resolver_raiz_proyecto(Path(__file__))


def _sembrar_consultas_empaquetadas(logger: logging.Logger) -> None:
    """Copia las consultas JSON empaquetadas en el binario hacia disco.

    PyInstaller --onefile descomprime los --add-data en sys._MEIPASS
    (/tmp/_MEIxxxxxx), que se destruye al terminar el proceso. Si
    data/input/consultas/ no existe o esta vacio junto al proyecto,
    se siembran ahi las consultas incluidas en el ejecutable. Asi el
    binario es autosuficiente: "solo copiar el binario" (Regla 57).
    Los JSON ya presentes en disco NUNCA se sobreescriben.
    """
    if not getattr(sys, 'frozen', False):
        return
    origen = Path(getattr(sys, '_MEIPASS', '')) / 'data' / 'input' / 'consultas'
    if not origen.is_dir():
        return
    destino = _detectar_ruta_base() / 'data' / 'input' / 'consultas'
    try:
        destino.mkdir(parents=True, exist_ok=True)
        sembrados = 0
        for json_origen in origen.glob('*.json'):
            json_destino = destino / json_origen.name
            if not json_destino.exists():
                json_destino.write_bytes(json_origen.read_bytes())
                sembrados += 1
        if sembrados:
            _log(logger, logging.INFO,
                 'Consultas sembradas desde el ejecutable: %s -> %s',
                 sembrados, destino)
    except OSError as exc:
        _log(logger, logging.WARNING,
             'No se pudieron sembrar consultas empaquetadas: %s', exc)


def _crear_logger() -> logging.Logger:
    """Crea y configura el logger raiz compartido por toda la aplicacion."""
    logger_raiz = logging.getLogger('app')
    if not logger_raiz.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter(
            '%(asctime)s [%(levelname)s] %(name)s: %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        ))
        logger_raiz.addHandler(handler)
        logger_raiz.setLevel(logging.INFO)
        # Sin esto, si algun modulo configura el logger raiz (basicConfig),
        # cada linea se imprimia dos veces en consola.
        logger_raiz.propagate = False
    return logger_raiz


def _log(logger: logging.Logger, level: int, msg: str, *args: object, exc_info: bool = False) -> None:
    """Registra un mensaje con formato lazy % para compatibilidad con Pylint."""
    logger.log(level, msg, *args, exc_info=exc_info)


_CMD_PYTHON_MODULO = "python -m app.main"
_SUFIJO_VERIFICAR = "%s verificar"
_SUFIJO_HISTORIA1 = "%s -d facturacion_sql_historia1"
VERSION = '1.0.0'


def _detectar_comando_base() -> str:
    """Detecta el modo de ejecucion examinando argv[0] via pathlib.

    Funciona identico en Windows y Linux, incluyendo PyInstaller frozen.
    """
    argv0 = Path(sys.argv[0]).resolve()
    ejecutable = argv0.name

    if ejecutable.startswith(("sri_datos_abiertos", "datos_abiertos1_0")):
        return f"./{ejecutable}"

    ruta_str = str(argv0)
    if "__pypackages__" in ruta_str or ".venv" in ruta_str or "venv" in ruta_str:
        return "pdm run start"

    return _CMD_PYTHON_MODULO


def _banner() -> None:
    """Muestra la pantalla de bienvenida con estado del ETL de Facturacion."""
    sistema = platform.system()
    cmd = _detectar_comando_base()
    formato = "%Y-%m-%d  %H:%M:%S"
    color = 'yellow'
    click.echo()
    click.echo(click.style("╔══════════════════════════════════════════════════════╗", fg="cyan"))
    click.echo(click.style("║   SRI — Exportador de Datos Abiertos Facturacion     ║", fg="cyan", bold=True, ))
    click.echo(click.style("╚══════════════════════════════════════════════════════╝", fg="cyan"))
    click.echo(f"  Sistema   : {sistema}")
    click.echo(f"  Version   : {VERSION}")
    click.echo(f"  Fecha     : {datetime.now().strftime(formato)}")
    click.echo(f"  Comando   : {click.style(cmd, fg=color)}")
    click.echo()


def _pantalla_ayuda(cmd: str) -> None:
    """Muestra la ayuda completa organizada por los tres modos de ejecucion."""
    comando_exportador = "pdm run exportador"
    if cmd.startswith("./") or cmd in ("sri_datos_abiertos", "datos_abiertos1_0"):
        cmd_pdm = comando_exportador
        cmd_py = _CMD_PYTHON_MODULO
    elif cmd.startswith("pdm "):
        cmd_pdm = cmd
        cmd_py = _CMD_PYTHON_MODULO
    else:
        cmd_pdm = comando_exportador
        cmd_py = cmd

    cmd_exe = "./sri_datos_abiertos.1.0.0"

    click.echo()
    click.echo(click.style("╔══════════════════════════════════════════════════════════════╗", fg="yellow"))
    click.echo(click.style("║              AYUDA — MODOS DE USO                            ║", fg="yellow", bold=True))
    click.echo(click.style("╚══════════════════════════════════════════════════════════════╝", fg="yellow"))
    click.echo()
    click.echo(click.style("  1. EJECUTABLE COMPILADO  (produccion y pruebas)", fg="green", bold=True))
    click.echo("     Solo copiar el binario. Sin instalar nada.")
    click.echo()
    for cmd_ej, descripcion in [
        (cmd_exe, "[Menu interactivo]"),
        (f"{cmd_exe} --listar", "Lista de consultas disponibles"),
        (_SUFIJO_HISTORIA1 % cmd_exe, "Ejecutar Historia 1 sin menu"),
        (f"{cmd_exe} facturacion_sql_historia1", "Ejecutar Historia 1 sin menu (sin -d)"),
        (_SUFIJO_VERIFICAR % cmd_exe, "Verificar archivos en los servidores"),
        (f"{cmd_exe} verificar --anio 2024", "Verificar archivos del anio 2024"),
    ]:
        cmd_estilizado = click.style(cmd_ej, fg="cyan")
        click.echo(f"     {cmd_estilizado:<58} {descripcion}")
    click.echo()
    click.echo(click.style("  2. CON PDM  (desarrollo con entorno virtual)", fg="green", bold=True))
    click.echo("     Requiere: pdm install")
    click.echo("     Scripts en pyproject.toml -> [tool.pdm.scripts]")
    click.echo()
    for cmd_ej, descripcion in [
        (cmd_pdm, "Menu interactivo"),
        ("pdm run exportador", "Menu interactivo (alias)"),
        ("pdm run listar", "Lista consultas disponibles"),
        ("pdm run historia1", "Ejecutar Historia 1"),
        ("pdm run historia2", "Ejecutar Historia 2"),
        ("pdm run historia3", "Ejecutar Historia 3"),
        ("pdm run historia5", "Ejecutar Historia 5 (Vehiculos nuevos)"),
        ("pdm run verificar", "Verificar archivos en servidores"),
        ("pdm run verificar-anio -- --anio 2024", "Verificar anio especifico"),
    ]:
        cmd_estilizado = click.style(cmd_ej, fg="cyan")
        click.echo(f"     {cmd_estilizado:<55} {descripcion}")
    click.echo()
    click.echo(click.style("  3. CON PYTHON -m  (venv activo, sin PDM)", fg="green", bold=True))
    click.echo("     Linux:   source venv/bin/activate")
    click.echo("     Windows: venv\\Scripts\\activate")
    click.echo()
    for cmd_ej, descripcion in [
        (cmd_py, "Menu interactivo"),
        (f"{cmd_py} --listar", "Lista consultas disponibles"),
        (_SUFIJO_HISTORIA1 % cmd_py, "Ejecutar Historia 1 sin menu"),
        (f"{cmd_py} facturacion_sql_historia1", "Ejecutar Historia 1 sin menu (sin -d)"),
        (_SUFIJO_VERIFICAR % cmd_py, "Verificar archivos en servidores"),
        (f"{cmd_py} -c /ruta/config.toml", "Usar TOML alternativo"),
    ]:
        cmd_estilizado = click.style(cmd_ej, fg="cyan")
        click.echo(f"     {cmd_estilizado:<65} {descripcion}")
    click.echo()
    click.echo(click.style("  CRON  (ejecucion automatica mensual)", fg="green", bold=True))
    cmd_cron = "/home/python/sri_datos_abiertos_facturacion/venv/bin/python -m app.main"
    for cron_ej, descripcion in [
        (_SUFIJO_HISTORIA1 % cmd_cron, "1 de cada mes 01:00"),
        (f"{cmd_cron} -d facturacion_sql_historia2", "1 de cada mes 02:00"),
        (f"{cmd_cron} -d facturacion_sql_historia3", "1 de cada mes 03:00"),
        (f"{cmd_cron} -d facturacion_sql_historia5", "1 de cada mes 04:00"),
        (_SUFIJO_VERIFICAR % cmd_cron, "1 de cada mes 05:00"),
    ]:
        click.echo(f"     {click.style(cron_ej, fg='yellow')}")
        click.echo(f"       -> {descripcion}")
    click.echo()
    linea_division = "─" * 64
    click.echo(f"  {linea_division}")
    click.echo("  Consultas JSON : data/input/consultas/*.json")
    click.echo("  Config Linux   : config/configlnx.toml")
    click.echo("  Config Windows : config/configwin.toml")
    click.echo("  Scripts PDM    : pyproject.toml -> [tool.pdm.scripts]")
    click.echo(f"  {linea_division}")
    click.echo()


def _mostrar_lista(consultas: List[Tuple[str, str]]) -> None:
    """Lista simple de consultas disponibles (para --listar)."""
    click.echo("\nConsultas disponibles:")
    click.echo("─" * 65)
    for cid, nombre in consultas:
        cid_estilizado = click.style(cid, fg="cyan", bold=True)
        click.echo(f"  {cid_estilizado:<40} {nombre}")
    click.echo()


def _mostrar_menu_interactivo(consultas: List[Tuple[str, str]]) -> None:
    """Menu numerado con opciones 0=salir y ?=ayuda."""
    click.echo(click.style("  Consultas disponibles:", fg="white", bold=True))
    linea_corta = "─" * 62
    click.echo(f"  {linea_corta}")
    for num, (cid, nombre) in enumerate(consultas, 1):
        num_estilizado = click.style(str(num), fg="yellow", bold=True)
        cid_estilizado = click.style(cid, fg="cyan")
        click.echo(f"  {num_estilizado}.  {cid_estilizado:<38} {nombre}")
    click.echo(f"  {linea_corta}")
    salir_estilizado = click.style("0", fg="red", bold=True)
    ayuda_estilizada = click.style("?", fg="yellow", bold=True)
    click.echo(f"  {salir_estilizado}.  Salir       {ayuda_estilizada} Ayuda / mas opciones")
    click.echo()


def _construir_resumen_verificacion(resultados: List[Dict[str, Any]], anio: int) -> str:
    """Construye el texto del resumen de verificacion por servidor."""
    lineas = [f"Verificacion de archivos — Anio {anio}", "=" * 55]
    for res in resultados:
        estado_srv = "OK" if res["exito"] else "ERROR"
        lineas.append(f"\n{estado_srv} {res['servidor']} ({res['ip']})")
        for err in res["errores"]:
            lineas.append(f"   ERROR: {err}")
        for arch in res["archivos"]:
            estado_arch = "OK" if arch["ok"] else "ADVERTENCIA"
            lineas.append(
                f"   {estado_arch} {arch['nombre']} "
                f"({arch['tamanio_kb']} KB) — {arch['fecha_mod']}"
            )
        if not res["archivos"] and not res["errores"]:
            lineas.append("   Sin archivos encontrados para este anio")
    return "\n".join(lineas)


def _enviar_correo_verificacion(cfg_email: Dict[str, Any], anio: int, exito: bool, resumen: str, logger: logging.Logger) -> None:
    """Envia el correo de verificacion si hay servidor SMTP configurado."""
    if not cfg_email.get("smtp_server"):
        return
    try:
        correo_ok = NotificadorEmail(cfg_email, logger).enviar_notificacion(
            asunto=f"VERIFICACION {'OK' if exito else 'CON PROBLEMAS'} — {anio}",
            consulta_id=f"verificar_{anio}",
            resultado_transferencia={
                "exito": exito,
                "tipo": "verificacion",
                "archivo_destino": f"Verificacion {anio}",
                "tamanio_bytes": 0,
                "tamanio_mb": 0,
                "mensaje": resumen,
            },
            error=None if exito else f"Problemas detectados en servidores ({VERSION})",
        )
        if correo_ok:
            _log(logger, logging.INFO, "Correo de verificacion enviado")
        else:
            _log(logger, logging.WARNING, "Correo de verificacion no enviado (fallo SMTP)")
    except TrazabilidadExcepciones.ALL_NON_CRITICAL as exc:
        _log(logger, logging.WARNING, "Correo de verificacion no enviado: %s", exc)


def _notificar_verificacion(
    resultados: List[Dict[str, Any]],
    anio: int,
    cfg_email: Dict[str, Any],
    cfg_rutas: Dict[str, Any],
    logger: logging.Logger
) -> None:
    """Envia correo y guarda copia local con el resumen de verificacion."""
    exito = all(res["exito"] and res["archivos"] for res in resultados)
    resumen = _construir_resumen_verificacion(resultados, anio)
    _enviar_correo_verificacion(cfg_email, anio, exito, resumen, logger)
    dir_mails = cfg_rutas["mails"]
    dir_mails.mkdir(parents=True, exist_ok=True)
    marca = datetime.now().strftime("%Y%m%d_%H%M%S")
    estado = "OK" if exito else "ERROR"
    ruta = dir_mails / f"{marca}_verificacion_{anio}_{estado}.txt"
    ruta.write_text(resumen, encoding="utf-8")
    _log(logger, logging.INFO, "Reporte de verificacion guardado: %s", ruta)


def _modo_listar(exportador: ExportadorDatosAbiertos) -> None:
    """Modo --listar: Muestra consultas y sale."""
    consultas = exportador.listar_consultas()
    if not consultas:
        click.echo("No se encontraron consultas configuradas")
        sys.exit(1)
    _mostrar_lista(consultas)


def _modo_directo(exportador: ExportadorDatosAbiertos, consulta_id: Optional[str], cmd: str, ) -> None:
    """Modo --directo: Ejecuta una consulta sin menu y sale."""
    if not consulta_id:
        click.echo(click.style("ERROR: ", fg="red", bold=True) + "Se requiere CONSULTA_ID con --directo")
        click.echo(f"  Uso: {click.style(f'{cmd} -d <ID>', fg='yellow')}")
        sys.exit(1)
    consulta = exportador.encontrar_consulta(consulta_id)
    if not consulta:
        click.echo(f'Consulta "{consulta_id}" no encontrada')
        sys.exit(1)
    click.echo(f"\nEjecutando: {click.style(consulta.nombre, fg='green', bold=True)}")
    sys.exit(0 if exportador.procesar_consulta(consulta) else 1)


def _despedida(exito: bool = True) -> None:
    """Muestra mensaje de salida con timestamp."""
    despedida = click.style("Hasta luego.", fg="cyan")
    hora = datetime.now().strftime("%H:%M:%S")
    click.echo(f"\n  {despedida}  {hora}\n")
    sys.exit(0 if exito else 1)


def _resolver_seleccion(consultas: List[Tuple[str, str]], seleccion: str, ) -> Optional[str]:
    """Convierte la entrada del usuario en un consulta_id valido."""
    if seleccion.isdigit():
        idx = int(seleccion) - 1
        if 0 <= idx < len(consultas):
            return consultas[idx][0]
        click.echo(click.style(
            f"  Numero invalido. Entre 1 y {len(consultas)}, "
            "0 para salir o ? para ayuda.\n",
            fg="red",
        ))
        return None
    return seleccion


def _ejecutar_consulta_interactiva(exportador: ExportadorDatosAbiertos, consulta: Any, ) -> bool:
    """Ejecuta una consulta en modo interactivo y muestra resultado."""
    click.echo()
    click.echo(f"  Ejecutando: {click.style(consulta.nombre, fg='green', bold=True)}")
    click.echo(f"  ID  : {consulta.id_}")
    click.echo(f"  SQL : {consulta.sql[:75]}...")
    click.echo()
    exito = exportador.procesar_consulta(consulta)
    if exito:
        click.echo(click.style("\n  Proceso completado con exito.\n", fg="green", bold=True))
    else:
        click.echo(click.style("\n  El proceso termino con errores. Revise el log.\n", fg="red", bold=True,))
    return exito


def _modo_interactivo(exportador: ExportadorDatosAbiertos, cmd: str,) -> None:
    """Modo interactivo: Menu en loop hasta que el usuario salga."""
    _banner()
    consultas = exportador.listar_consultas()
    if not consultas:
        click.echo(click.style("  Sin consultas configuradas.", fg="yellow"))
        sys.exit(1)
    while True:
        _mostrar_menu_interactivo(consultas)
        try:
            seleccion = input(click.style("  Seleccione -> ", fg="white", bold=True)).strip()
        except (EOFError, KeyboardInterrupt):
            click.echo()
            click.echo("\n  Cancelado.\n")
            sys.exit(0)
        if seleccion in ("0", "salir", "exit", "q"):
            _despedida()
            return
        if seleccion in ("?", "h", "ayuda", "help"):
            _pantalla_ayuda(cmd)
            continue
        consulta_id = _resolver_seleccion(consultas, seleccion)
        if consulta_id is None:
            continue
        consulta = exportador.encontrar_consulta(consulta_id)
        if not consulta:
            click.echo(click.style(f'  Consulta "{consulta_id}" no encontrada.\n', fg="red"))
            continue
        exito = _ejecutar_consulta_interactiva(exportador, consulta)
        if not click.confirm(click.style("  Ejecutar otra consulta?", fg="cyan"), default=False, ):
            _despedida(exito)
            return


@click.group(invoke_without_command=True)
@click.argument("consulta_id", required=False)
@click.option("--listar", "-l", is_flag=True, help="Lista todas las consultas disponibles")
@click.option("--directo", "-d", is_flag=True, help="Ejecuta sin menu (ideal para cron.d)")
@click.option("--config", "-c", "ruta_config", help="Ruta alternativa al archivo TOML")
@click.pass_context
def main(ctx, consulta_id, listar, directo, ruta_config):
    """Punto de entrada del exportador de Datos Abiertos SRI (Oracle a servidores)."""
    if ctx.invoked_subcommand is not None:
        return
    logger = _crear_logger()
    _sembrar_consultas_empaquetadas(logger)
    exportador = ExportadorDatosAbiertos(ruta_config, logger)
    cmd = _detectar_comando_base()
    if listar:
        _modo_listar(exportador)
        return
    if directo or consulta_id:
        _modo_directo(exportador, consulta_id, cmd)
        return
    _modo_interactivo(exportador, cmd)


@main.command("verificar")
@click.option("--anio", "-a", type=int, default=None, help="Anio a verificar (por defecto: anio actual)", )
@click.option("--config", "-c", "ruta_config", default=None, help="Ruta alternativa al TOML")
def cmd_verificar(anio: Optional[int], ruta_config: Optional[str]):
    """Verifica que los archivos esten en los servidores de descarga.

    Comprueba existencia, tamano y fecha en Quito y Guayaquil.
    Envia correo con el resultado.

    Ejemplos:
      exportador verificar
      exportador verificar --anio 2024
    """
    logger = _crear_logger()
    _sembrar_consultas_empaquetadas(logger)
    gestor = get_config_manager(ruta_config, logger)
    servidores = gestor.get_servidores_descarga()
    cfg_ver = gestor.get_verificacion_config()
    cfg_email = gestor.get_email_config()
    cfg_rutas = gestor.get_rutas()
    anio_ver = anio or datetime.now().year
    anio_estilizado = click.style(str(anio_ver), fg="cyan", bold=True)
    click.echo(
        f"\nVerificando archivos anio {anio_estilizado} "
        f"en {len(servidores)} servidor(es)...\n"
    )
    verificador = VerificadorRemoto(servidores, cfg_ver, logger)
    resultados = verificador.verificar_todos(anio_ver)
    total_archivos = sum(len(res["archivos"]) for res in resultados)
    con_errores = sum(1 for res in resultados if res["errores"])
    click.echo(f"\n{'─' * 55}")
    click.echo(f"  Servidores verificados : {len(resultados)}")
    click.echo(f"  Archivos encontrados   : {total_archivos}")
    click.echo(f"  Servidores con errores : {con_errores}")
    click.echo(f"{'─' * 55}")
    _notificar_verificacion(resultados, anio_ver, cfg_email, cfg_rutas, logger)
    # Mismo criterio que el correo: conexion OK *y* archivos presentes.
    # Antes cron reportaba exito (exit 0) aunque no hubiera ningun archivo
    # publicado, mientras el correo decia CON PROBLEMAS.
    todo_ok = all(res["exito"] and res["archivos"] for res in resultados)
    sys.exit(0 if todo_ok else 1)


if __name__ == "__main__":
    main.main()
