"""
Pruebas unitarias para app.da_exportador.

Cubre la carga y busqueda de consultas, la fusion de configuracion,
el periodo y los marcadores del SQL, el ZIP y la union de las
particiones de Spark, la validacion previa y el nombre del archivo,
el pipeline de da_dataframe, el particionamiento y el listado. La
publicacion esta en test_da_exportador_publicacion.py.
"""

from datetime import datetime
import json
import shutil
from unittest.mock import MagicMock, patch
import zipfile

import pandas as pd
import pandera.pandas as pa
from pandera.pandas import Column, DataFrameSchema
import pytest

from app.da_exportador import ExportadorDatosAbiertos
from app.da_modelos import ConsultaDefinicion

ESQUEMA_CONSULTAS_CARGADAS = DataFrameSchema(
    {
        'id': Column(str, pa.Check.str_length(min_value=1)),
        'nombre': Column(str, pa.Check.str_length(min_value=1)),
        'sql': Column(str, pa.Check.str_length(min_value=1)),
        'nombre_archivo': Column(str, pa.Check.str_length(min_value=1)),
        'delimitador': Column(str, pa.Check.isin(['|', ',', ';', '\t'])),
    }
)


class TestCargarConsultas:
    """Carga de las consultas JSON desde disco."""

    def test_carga_dos_consultas(self, exportador_con_consultas):
        """Con dos JSONs en el directorio debe cargar dos consultas."""
        consultas = exportador_con_consultas.cargar_consultas()
        assert len(consultas) == 2

    def test_consultas_son_instancias_correctas(self, exportador_con_consultas):
        """
        Las consultas cargadas deben ser
        instancias de ConsultaDefinicion.
        """
        consultas = exportador_con_consultas.cargar_consultas()
        for consulta in consultas:
            assert isinstance(consulta, ConsultaDefinicion)

    def test_directorio_inexistente_retorna_lista_vacia(self, exportador, tmp_path):
        """Sin directorio de consultas debe retornar lista vacía."""

        dir_c = tmp_path / 'input' / 'consultas'
        if dir_c.exists():
            shutil.rmtree(dir_c)
        consultas = exportador.cargar_consultas()
        assert consultas == []

    def test_json_invalido_no_detiene_la_carga(self, dir_consultas, crear_exportador):
        """Un JSON malformado no debe detener la carga de los demás."""
        directorio, tmp_path = dir_consultas
        toml_path = tmp_path / 'config' / 'configtest.toml'
        exp = crear_exportador(toml_path)

        (directorio / 'invalido.json').write_text('{json_roto', encoding='utf-8')
        (directorio / 'ok.json').write_text(json.dumps({'id': 'ok', 'nombre': 'OK', 'sql': 'SELECT 1', 'nombre_archivo': 'ok'}), encoding='utf-8')
        consultas = exp.cargar_consultas()
        ids = [c.id_ for c in consultas]
        assert 'ok' in ids

    def test_carga_ordenada_por_nombre_archivo(self, exportador_con_consultas):
        """
        Las consultas se cargan en orden alfabético de archivos JSON.
        """
        consultas = exportador_con_consultas.cargar_consultas()
        assert consultas[0].id_ == 'facturacion_sql_historia1'
        assert consultas[1].id_ == 'facturacion_sql_historia2'


class TestEncontrarConsulta:
    """Busqueda de una consulta por ID exacto."""

    def test_encuentra_por_id_exacto(self, exportador_con_consultas):
        """Debe encontrar la consulta con el ID exacto."""
        consulta = exportador_con_consultas.encontrar_consulta('facturacion_sql_historia1')
        assert consulta is not None
        assert consulta.id_ == 'facturacion_sql_historia1'

    def test_retorna_none_para_id_inexistente(self, exportador_con_consultas):
        """Un ID que no existe debe retornar None."""
        consulta = exportador_con_consultas.encontrar_consulta('id_inexistente')
        assert consulta is None

    def test_no_confunde_ids_distintos(self, exportador_con_consultas):
        """No debe confundir historia1 con historia2."""
        c1 = exportador_con_consultas.encontrar_consulta('facturacion_sql_historia1')
        c2 = exportador_con_consultas.encontrar_consulta('facturacion_sql_historia2')
        assert c1.id_ != c2.id_

    def test_id_parcial_no_retorna_resultado(self, exportador_con_consultas):
        """Un ID parcial no debe retornar resultado."""
        consulta = exportador_con_consultas.encontrar_consulta('historia1')
        assert consulta is None


class TestFusionarConfig:
    """Precedencia JSON de la consulta sobre el TOML."""

    def _consulta(self, extra=None):
        """Consulta."""
        datos = {'id': 'h1', 'nombre': 'H1', 'sql': 'SELECT 1', 'nombre_archivo': 'h1'}
        if extra:
            datos.update(extra)
        return ConsultaDefinicion.desde_dict(datos)

    def test_spark_url_de_consulta_sobreescribe_toml(self, exportador):
        """
        Un spark_url en la consulta tiene precedencia sobre el TOML.
        """
        consulta = self._consulta({'spark': 'sc://192.168.1.10:15002'})
        config = exportador.fusionar_config(consulta)
        assert config['spark']['spark_url'] == 'sc://192.168.1.10:15002'

    def test_jdbc_url_de_consulta_sobreescribe_toml(self, exportador):
        """
        Un jdbc_url en la consulta tiene precedencia sobre el TOML.
        """
        consulta = self._consulta({'jdbc_url': 'jdbc:oracle:thin:@BI_DWH_DESA'})
        config = exportador.fusionar_config(consulta)
        assert config['spark']['jdbc_url'] == 'jdbc:oracle:thin:@BI_DWH_DESA'

    def test_sin_sobreescrituras_usa_config_toml(self, exportador):
        """Sin overrides en la consulta se usa la config del TOML."""
        consulta = self._consulta()
        config = exportador.fusionar_config(consulta)
        assert config['spark']['spark_url'] == 'sc://localhost:15002'

    def test_email_de_consulta_se_fusiona(self, exportador):
        """
        La config de email de la consulta se fusiona con la del TOML.
        """
        consulta = self._consulta({'email': {'smtp_server': 'mail_especifico.sri.gob.ec'}})
        config = exportador.fusionar_config(consulta)
        assert config['email']['smtp_server'] == 'mail_especifico.sri.gob.ec'

    def test_destino_de_consulta_sobreescribe_default(self, exportador):
        """
        El destino de la consulta reemplaza el destino default del TOML.
        """
        consulta = self._consulta({'destino': {'tipo': 'sftp', 'directorio_remoto': '/remotos'}})
        config = exportador.fusionar_config(consulta)
        assert config['destino']['tipo'] == 'sftp'


class TestResolverSqlConPeriodo:
    """Sustitucion de :ANIO, :MES_INI y :MES_FIN."""

    def _consulta(self, sql, anio=None, mes_ini=None, mes_fin=None):
        """
        Crea ConsultaDefinicion y le setea el período directamente.
        """
        consulta = ConsultaDefinicion.desde_dict({'id': 'h', 'nombre': 'H', 'sql': sql, 'nombre_archivo': 'h'})
        consulta.anio = anio
        consulta.mes_ini = mes_ini
        consulta.mes_fin = mes_fin
        return consulta

    def test_sustituye_anio_explicito(self, exportador):
        """
        :ANIO se reemplaza por el año dado directamente en la consulta.
        """
        consulta = self._consulta('SELECT * FROM t WHERE anio = :ANIO', anio=2025)
        sql = exportador._resolver_sql_con_periodo(consulta.sql, consulta)
        assert ':ANIO' not in sql
        assert '2025' in sql

    def test_sustituye_mes_ini_y_mes_fin(self, exportador):
        """:MES_INI y :MES_FIN se reemplazan con los meses dados."""
        consulta = self._consulta('SELECT * FROM t WHERE mes BETWEEN :MES_INI AND :MES_FIN', anio=2025, mes_ini=1, mes_fin=6)
        sql = exportador._resolver_sql_con_periodo(consulta.sql, consulta)
        assert ':MES_INI' not in sql
        assert ':MES_FIN' not in sql
        assert '1' in sql
        assert '6' in sql

    def test_marcador_con_espacio_sustituido(self, exportador):
        """': ANIO' (con espacio) también debe sustituirse."""
        consulta = self._consulta('SELECT * FROM t WHERE m >= :ANIO AND m <= :MES_FIN', anio=2025, mes_ini=1, mes_fin=11)
        sql = exportador._resolver_sql_con_periodo(consulta.sql, consulta)
        assert ': ANIO' not in sql
        assert ': MES_FIN' not in sql
        assert '2025' in sql
        assert '11' in sql

    def test_sin_anio_usa_anio_actual(self, exportador):
        """Sin anio en la consulta se usa el año actual."""
        consulta = self._consulta('SELECT * FROM t WHERE anio = :ANIO')
        sql = exportador._resolver_sql_con_periodo(consulta.sql, consulta)
        assert str(datetime.now().year) in sql

    def test_sql_sin_marcadores_no_cambia(self, exportador):
        """Un SQL sin marcadores retorna idéntico."""
        consulta = self._consulta('SELECT * FROM tabla_sin_periodo')
        sql = exportador._resolver_sql_con_periodo(consulta.sql, consulta)
        assert sql == 'SELECT * FROM tabla_sin_periodo'

    def test_anio_minusculas_tambien_sustituido(self, exportador):
        """El marcador :anio en minúsculas también debe sustituirse."""
        consulta = self._consulta('SELECT * FROM t WHERE a = :anio')
        consulta.anio = 2024
        sql = exportador._resolver_sql_con_periodo(consulta.sql, consulta)
        assert ':anio' not in sql
        assert '2024' in sql


class TestComprimirCsv:
    """ZIP generado a partir del CSV."""

    def test_genera_zip_no_vacio(self, exportador, tmp_path):
        """El ZIP generado debe existir y tener tamaño > 0."""
        csv = tmp_path / 'datos.csv'
        csv.write_text('id|nombre\n1|Alpha\n2|Beta\n', encoding='utf-8')
        zip_out = tmp_path / 'datos.zip'
        exportador._comprimir_csv(csv, zip_out)
        assert zip_out.exists()
        assert zip_out.stat().st_size > 0

    def test_zip_contiene_csv_original(self, exportador, tmp_path):
        """El ZIP debe contener el CSV con su nombre original."""
        csv = tmp_path / 'exportacion_2025.csv'
        csv.write_text('col1|col2\nv1|v2\n', encoding='utf-8')
        zip_out = tmp_path / 'exportacion_2025.zip'
        exportador._comprimir_csv(csv, zip_out)
        with zipfile.ZipFile(zip_out, 'r') as zf:
            nombres = zf.namelist()
        assert 'exportacion_2025.csv' in nombres

    def test_zip_es_valido(self, exportador, tmp_path):
        """El archivo ZIP debe ser válido según zipfile.is_zipfile."""
        csv = tmp_path / 'datos.csv'
        csv.write_text('x|y\n1|2\n', encoding='utf-8')
        zip_out = tmp_path / 'datos.zip'
        exportador._comprimir_csv(csv, zip_out)
        assert zipfile.is_zipfile(zip_out)

    def test_zip_menor_que_csv_original(self, exportador, tmp_path):
        """
        El ZIP con deflate debe ser más pequeño que el CSV original.
        """
        csv = tmp_path / 'grande.csv'
        filas = '\n'.join(f'id|nombre|valor\n{i}|Alpha|100' for i in range(1000))
        csv.write_text(filas, encoding='utf-8')
        zip_out = tmp_path / 'grande.zip'
        exportador._comprimir_csv(csv, zip_out)
        assert zip_out.stat().st_size < csv.stat().st_size


class TestCombinarParticiones:
    """Union de los part-*.csv de Spark con una sola cabecera."""

    def test_combina_dos_particiones_en_uno(self, exportador, tmp_path):
        """
        Dos archivos part-*.csv deben consolidarse en un único CSV.
        """
        dir_spark = tmp_path / 'spark_out'
        dir_spark.mkdir()
        cabecera = 'id|nombre|valor\n'
        (dir_spark / 'part-00000.csv').write_text(cabecera + '1|Alpha|100\n2|Beta|200\n', encoding='utf-8')
        (dir_spark / 'part-00001.csv').write_text(cabecera + '3|Gamma|300\n4|Delta|400\n', encoding='utf-8')
        salida = tmp_path / 'resultado.csv'
        exportador._combinar_particiones(dir_spark, salida)
        assert salida.exists()
        contenido = salida.read_text(encoding='utf-8')
        assert '1|Alpha|100' in contenido
        assert '3|Gamma|300' in contenido

    def test_csv_consolidado_tiene_una_sola_cabecera(self, exportador, tmp_path):
        """El CSV consolidado no debe duplicar la cabecera."""
        dir_spark = tmp_path / 'spark_out2'
        dir_spark.mkdir()
        cabecera = 'id|nombre\n'
        for num, datos in [('00000', '1|A\n'), ('00001', '2|B\n'), ('00002', '3|C\n')]:
            (dir_spark / f'part-{num}.csv').write_text(cabecera + datos, encoding='utf-8')
        salida = tmp_path / 'consolidado.csv'
        exportador._combinar_particiones(dir_spark, salida)
        lineas = salida.read_text(encoding='utf-8').splitlines()
        cabeceras = [ln for ln in lineas if ln.startswith('id|')]
        assert len(cabeceras) == 1

    def test_datos_de_todas_las_particiones_presentes(self, exportador, tmp_path):
        """
        Los datos de todas las particiones deben estar en el CSV final.
        """
        dir_spark = tmp_path / 'spark_out3'
        dir_spark.mkdir()
        for num in range(3):
            (dir_spark / f'part-0000{num}.csv').write_text(f'col\ndato{num}\n', encoding='utf-8')
        salida = tmp_path / 'out.csv'
        exportador._combinar_particiones(dir_spark, salida)
        contenido = salida.read_text(encoding='utf-8')
        for num in range(3):
            assert f'dato{num}' in contenido

    def test_directorio_vacio_lanza_file_not_found(self, exportador, tmp_path):
        """
        Un directorio sin archivos part-*.csv
        debe lanzar FileNotFoundError.
        """
        dir_vacio = tmp_path / 'vacio'
        dir_vacio.mkdir()
        with pytest.raises(FileNotFoundError):
            exportador._combinar_particiones(dir_vacio, tmp_path / 'out.csv')

    def test_directorio_spark_eliminado_tras_combinar(self, exportador, tmp_path):
        """
        El directorio temporal Spark debe
        eliminarse después de combinar.
        """
        dir_spark = tmp_path / 'spark_tmp'
        dir_spark.mkdir()
        (dir_spark / 'part-00000.csv').write_text('a|b\n1|x\n', encoding='utf-8')
        salida = tmp_path / 'out.csv'
        exportador._combinar_particiones(dir_spark, salida)
        assert not dir_spark.exists()


class TestEsRutaValida:
    """Distingue rutas de nombres TNS."""

    def test_ruta_unix_es_valida(self, exportador):
        """Ruta unix es valida."""
        assert exportador._es_ruta_valida('/oracle/wallet') is True

    def test_ruta_windows_con_backslash_es_valida(self, exportador):
        """Ruta windows con backslash es valida."""
        assert exportador._es_ruta_valida('D:\\oracle\\wallet') is True

    def test_ruta_windows_con_slash_es_valida(self, exportador):
        """Ruta windows con slash es valida."""
        assert exportador._es_ruta_valida('D:/oracle/wallet') is True

    def test_nombre_tns_sin_separadores_no_es_ruta(self, exportador):
        """Nombre tns sin separadores no es ruta."""
        assert exportador._es_ruta_valida('STAR_BI_DWH') is False

    def test_cadena_vacia_no_es_ruta(self, exportador):
        """Cadena vacia no es ruta."""
        assert exportador._es_ruta_valida('') is False

    def test_ruta_con_dos_puntos_es_valida(self, exportador):
        """Una URL JDBC tiene : por lo que se considera ruta."""
        assert exportador._es_ruta_valida('jdbc:oracle:thin:@TNS') is True


class TestPanderaConsultasCargadas:
    """Esquema Pandera de las consultas cargadas."""

    def test_consultas_validan_esquema(self, exportador_con_consultas):
        """
        Las consultas cargadas desde disco
        superan la validación Pandera.
        """
        consultas = exportador_con_consultas.cargar_consultas()
        filas = [{'id': c.id_, 'nombre': c.nombre, 'sql': c.sql, 'nombre_archivo': c.nombre_archivo, 'delimitador': c.delimitador} for c in consultas]
        df = pd.DataFrame(filas)
        resultado = ESQUEMA_CONSULTAS_CARGADAS.validate(df)
        assert len(resultado) == 2

    def test_sql_no_vacio_en_ninguna_consulta(self, exportador_con_consultas):
        """Ninguna consulta cargada debe tener SQL vacío."""
        consultas = exportador_con_consultas.cargar_consultas()
        for c in consultas:
            assert len(c.sql.strip()) > 0

    def test_delimitador_valido_en_todas(self, exportador_con_consultas):
        """
        Todas las consultas deben tener un
        delimitador admitido por el esquema.
        """
        consultas = exportador_con_consultas.cargar_consultas()
        delimitadores_validos = {'|', ',', ';', '\t'}
        for c in consultas:
            assert c.delimitador in delimitadores_validos


class TestProcesarConsulta:
    """Validacion previa, nombre del archivo y captura de errores."""

    def test_validacion_con_advertencias_continua(self, exportador):
        """Advertencias no detienen el flujo."""
        consulta = ConsultaDefinicion.desde_dict({'id': 'q', 'sql': 'SELECT 1'})
        with (
            patch.object(exportador._validador, 'validar_todo', return_value=(True, [], ['Advertencia leve'])),
            patch.object(exportador, '_ejecutar_flujo_exportacion', return_value=True),
        ):
            assert exportador.procesar_consulta(consulta) is True

    def test_flujo_exitoso(self, exportador):
        """Flujo completo exitoso -> True."""
        consulta = ConsultaDefinicion.desde_dict({'id': 'q', 'sql': 'SELECT 1', 'nombre': 'Test', 'nombre_archivo': 'test'})
        with (
            patch.object(exportador._validador, 'validar_todo', return_value=(True, [], [])),
            patch.object(exportador, '_ejecutar_flujo_exportacion', return_value=True),
        ):
            assert exportador.procesar_consulta(consulta) is True

    def test_error_no_critico_se_captura_y_notifica(self, exportador):
        """
        Un error no critico (ValueError) en el flujo se captura, se
        notifica el error y procesar_consulta devuelve False.
        """
        consulta = ConsultaDefinicion.desde_dict({'id': 'q', 'sql': 'SELECT 1', 'nombre': 'Test', 'nombre_archivo': 'test'})
        with (
            patch.object(exportador._validador, 'validar_todo', return_value=(True, [], [])),
            patch.object(exportador, '_ejecutar_flujo_exportacion', side_effect=ValueError('fallo')),
            patch.object(exportador, '_notificar') as mock_notificar,
        ):
            resultado = exportador.procesar_consulta(consulta)
        assert resultado is False
        mock_notificar.assert_called_once()
        _, kwargs = mock_notificar.call_args
        assert kwargs.get('exito') is False
        assert 'fallo' in str(kwargs.get('error', ''))

    def test_error_critico_propaga(self, exportador):
        """Un MemoryError (critico) NO se captura: debe propagar."""
        consulta = ConsultaDefinicion.desde_dict({'id': 'q', 'sql': 'SELECT 1', 'nombre': 'Test', 'nombre_archivo': 'test'})
        with (
            patch.object(exportador._validador, 'validar_todo', return_value=(True, [], [])),
            patch.object(exportador, '_ejecutar_flujo_exportacion', side_effect=MemoryError('sin RAM')),
        ):
            with pytest.raises(MemoryError):
                exportador.procesar_consulta(consulta)

    def test_nombre_zip_con_anio(self, exportador):
        """
        El nombre del ZIP incluye nombre_archivo y el anio del periodo.

        Cuando la consulta declara 'anio', ese anio
        manda (es el periodo de los datos), no el anio
        de la fecha de corrida: una regeneracion en 2026
        del dataset 2024 debe producir 'datos_2024.zip'.
        """
        consulta = ConsultaDefinicion.desde_dict({'id': 'q', 'sql': 'SELECT 1', 'nombre': 'Test', 'nombre_archivo': 'datos', 'anio': 2024})
        with (
            patch.object(exportador._validador, 'validar_todo', return_value=(True, [], [])),
            patch.object(exportador, '_ejecutar_flujo_exportacion') as mock_flujo,
        ):
            exportador.procesar_consulta(consulta)
        nombres = mock_flujo.call_args.args[3]
        assert nombres == {'publicado': 'datos_2024.zip', 'csv': 'datos_2024.csv'}


class TestResolverRutaWallet:
    """La ruta del wallet debe existir en disco; si no, None."""

    def test_ruta_existente_retorna_path(self, exportador, tmp_path):
        """Ruta existente retorna path."""
        wallet = tmp_path / 'wallet'
        wallet.mkdir()
        assert exportador._resolver_ruta_wallet(str(wallet)) == wallet

    def test_ruta_inexistente_retorna_none(self, exportador, tmp_path):
        """Ruta inexistente retorna none."""
        assert exportador._resolver_ruta_wallet(str(tmp_path / 'no_esta')) is None

    def test_referencia_vacia_retorna_none(self, exportador):
        """Referencia vacia retorna none."""
        assert exportador._resolver_ruta_wallet('') is None


class TestResolverPeriodo:
    """Punto unico de verdad del periodo (anio, mes_ini, mes_fin)."""

    def test_overrides_explicitos_ganan(self, exportador, consulta_prueba):
        """anio/mes_ini/mes_fin del JSON se respetan tal cual."""
        consulta = consulta_prueba(anio=2024, mes_ini=3, mes_fin=9)
        assert exportador._resolver_periodo(consulta) == (2024, 3, 9)

    def test_default_mes_anterior(self, exportador, consulta_prueba):
        """Sin overrides en junio: enero..mayo del anio actual."""
        ahora = datetime.now()
        if ahora.month > 1:
            anio, mes_ini, mes_fin = exportador._resolver_periodo(consulta_prueba())
            assert (anio, mes_ini, mes_fin) == (ahora.year, 1, ahora.month - 1)

    def test_correccion_de_enero(self, exportador, consulta_prueba):
        """
        En enero sin overrides: el periodo
        es ene..dic del ANIO ANTERIOR.
        """
        enero = datetime(2026, 1, 15, 10, 0, 0)
        with patch('app.da_exportador.datetime') as mock_dt:
            mock_dt.now.return_value = enero
            anio, mes_ini, mes_fin = exportador._resolver_periodo(consulta_prueba())
        assert (anio, mes_ini, mes_fin) == (2025, 1, 12)

    def test_enero_con_override_anio_no_retrocede(self, exportador, consulta_prueba):
        """Si el JSON fija anio, la correccion de enero NO aplica."""
        enero = datetime(2026, 1, 15, 10, 0, 0)
        with patch('app.da_exportador.datetime') as mock_dt:
            mock_dt.now.return_value = enero
            anio, _, _ = exportador._resolver_periodo(consulta_prueba(anio=2026))
        assert anio == 2026


class TestResolverSqlCasosExtra:
    """Punto y coma final y frontera de palabra de los marcadores."""

    def test_punto_y_coma_final_se_elimina(self, exportador, consulta_prueba):
        """Oracle via JDBC no acepta ';' (ORA-00933 en subquery)."""
        sql = exportador._resolver_sql_con_periodo('SELECT * FROM t WHERE anio = :ANIO;', consulta_prueba(anio=2026))
        assert not sql.rstrip().endswith(';')
        assert '2026' in sql

    def test_anio_no_corrompe_anio_inicio(self, exportador, consulta_prueba):
        """La frontera \\b protege marcadores mas largos."""
        sql = exportador._resolver_sql_con_periodo('SELECT :ANIO_INICIO, :ANIO FROM t', consulta_prueba(anio=2026))
        assert ':ANIO_INICIO' in sql
        assert ', 2026 FROM' in sql


class TestAplicarProcesoDataframe:
    """Unico punto de acoplamiento del exportador con da_dataframe."""

    def test_consulta_none_retorna_df_intacto(self, exportador):
        """Consulta none retorna df intacto."""
        df = MagicMock()
        assert exportador._aplicar_proceso_dataframe(df, None, {}) is df

    def test_sin_declaraciones_retorna_df_intacto(self, exportador, consulta_prueba):
        """
        Historias 1-3: sin proceso/columnas/orden, NO se transforma.
        """
        df = MagicMock()
        consulta = consulta_prueba()
        assert exportador._aplicar_proceso_dataframe(df, consulta, {}) is df

    @patch('app.da_exportador.ProcesadorDataFrame')
    def test_con_proceso_invoca_al_procesador(self, mock_procesador, exportador, consulta_prueba):
        """Con proceso invoca al procesador."""
        df = MagicMock()
        df_transformado = MagicMock()
        mock_procesador.return_value.aplicar.return_value = df_transformado
        consulta = consulta_prueba(proceso='proceso_caso2')

        resultado = exportador._aplicar_proceso_dataframe(df, consulta, {'url': 'jdbc:oracle:thin:@X'})

        assert resultado is df_transformado
        mock_procesador.return_value.aplicar.assert_called_once()
        contexto = mock_procesador.return_value.aplicar.call_args[0][1]
        assert contexto.consulta is consulta
        assert contexto.jdbc_opts == {'url': 'jdbc:oracle:thin:@X'}

    @patch('app.da_exportador.ProcesadorDataFrame')
    def test_solo_columnas_tambien_dispara_pipeline(self, mock_procesador, exportador, consulta_prueba):
        """
        columnas sin proceso tambien activa el pipeline declarativo.
        """
        df = MagicMock()
        consulta = consulta_prueba(columnas={'a': 'A'})
        exportador._aplicar_proceso_dataframe(df, consulta, {})
        mock_procesador.return_value.aplicar.assert_called_once()


class TestAplicarParticionamiento:
    """Rangos MIN/MAX con agregacion Spark y opciones de particion."""

    @staticmethod
    def _spark_con_rango(vmin, vmax):
        """Spark simulado cuya agregacion devuelve el rango."""
        spark_mock = MagicMock()
        cadena = spark_mock.read.format.return_value.options.return_value
        cadena.option.return_value = cadena
        cadena.load.return_value.agg.return_value.collect.return_value = [{'vmin': vmin, 'vmax': vmax}]
        return spark_mock, cadena

    def test_configura_rangos_en_el_lector(self, exportador):
        """Configura rangos en el lector."""
        exportador._spark, _ = self._spark_con_rango(1, 900000)
        lector = MagicMock()
        lector.option.side_effect = lambda *a, **k: lector
        with patch('app.da_exportador.fn'):
            resultado = exportador._aplicar_particionamiento(lector, {'url': 'jdbc:oracle:thin:@X'}, 'SELECT * FROM t', 'ID_FILA', 8)
        lector.option.assert_any_call('partitionColumn', 'ID_FILA')
        lector.option.assert_any_call('lowerBound', '1')
        lector.option.assert_any_call('upperBound', '900000')
        lector.option.assert_any_call('numPartitions', '8')
        assert resultado is lector

    def test_rangos_sin_sql_armado_por_texto(self, exportador):
        """
        El SQL original va intacto en 'query'; MIN/MAX se piden con
        agregacion Spark (pushDownAggregate), sin concatenar SQL.
        """
        exportador._spark, cadena = self._spark_con_rango(10, 20)
        with patch('app.da_exportador.fn') as mock_fn:
            exportador._aplicar_particionamiento(MagicMock(), {'url': 'u'}, 'SELECT 1 FROM t', 'C', 4)
        cadena.option.assert_any_call('query', 'SELECT 1 FROM t')
        cadena.option.assert_any_call('pushDownAggregate', 'true')
        mock_fn.min.assert_called_once_with('C')
        mock_fn.max.assert_called_once_with('C')


class TestListarConsultas:
    """Listado (id, nombre) para el modo --listar."""

    def test_retorna_tuplas_id_nombre(self, exportador, tmp_path):
        """Retorna tuplas id nombre."""
        dir_c = tmp_path / 'input' / 'consultas'
        (dir_c / 'a.json').write_text(json.dumps({'id': 'q1', 'nombre': 'Consulta Uno', 'sql': 'SELECT 1 FROM DUAL'}), encoding='utf-8')
        (dir_c / 'b.json').write_text(json.dumps({'id': 'q2', 'nombre': 'Consulta Dos', 'sql': 'SELECT 2 FROM DUAL'}), encoding='utf-8')

        assert exportador.listar_consultas() == [('q1', 'Consulta Uno'), ('q2', 'Consulta Dos')]

    def test_sin_consultas_lista_vacia(self, exportador):
        """Sin consultas lista vacia."""
        assert exportador.listar_consultas() == []


class TestNombresSalida:
    """Nombre publicado y del CSV interno, con y sin probar_sufijo."""

    @pytest.mark.parametrize(
        'datos, publicado, csv',
        [
            ({'nombre_archivo': 'FACTURACION_FISICA', 'nombre_csv': 'SRI_autorizaciones_fisicas'}, 'FACTURACION_FISICA_2026.zip',
             'SRI_autorizaciones_fisicas_2026.csv'),
            ({'nombre_archivo': 'COMPROBANTES_CEL', 'nombre_csv': 'Comprobantes_CEL'}, 'COMPROBANTES_CEL_2026.zip', 'Comprobantes_CEL_2026.csv'),
            ({'nombre_archivo': 'SRI_Vehiculos_Nuevos_', 'comprimir': False}, 'SRI_Vehiculos_Nuevos_2026.csv', 'SRI_Vehiculos_Nuevos_2026.csv'),
            ({'nombre_archivo': 'FACTURACION_FISICA', 'nombre_csv': 'SRI_af', 'probar_sufijo': '_a'}, 'FACTURACION_FISICA_2026_a.zip',
             'SRI_af_2026_a.csv'),
            ({'nombre_archivo': 'SRI_Vehiculos_Nuevos', 'comprimir': False, 'probar_sufijo': '_a'}, 'SRI_Vehiculos_Nuevos_2026_a.csv',
             'SRI_Vehiculos_Nuevos_2026_a.csv'),
        ],
    )
    def test_nombres(self, datos, publicado, csv):
        """Nombres."""
        nombres = ExportadorDatosAbiertos.nombres_salida(ConsultaDefinicion.desde_dict({'id': 'q', **datos}), 2026)
        assert (nombres['publicado'], nombres['csv']) == (publicado, csv)


class TestSqlConSysdate:
    """Las consultas actuales calculan el periodo con SYSDATE."""

    def test_sql_sin_marcadores_pasa_intacto(self, exportador, consulta_prueba):
        """Sql sin marcadores pasa intacto."""
        sql = "SELECT * FROM t WHERE fecha >= TRUNC(SYSDATE, 'YYYY') AND fecha < TRUNC(SYSDATE, 'MM')"
        assert exportador.sql_para_ejecucion(consulta_prueba(sql=sql)) == sql


class TestCargaYConfiguracionExtra:
    """JSON con lista de consultas y wallet declarado como ruta."""

    def test_json_con_lista_de_consultas(self, exportador, tmp_path):
        """Un JSON con una lista carga cada consulta."""
        (tmp_path / 'input' / 'consultas' / 'varias.json').write_text(json.dumps([{'id': 'a'}, {'id': 'b'}]), encoding='utf-8')
        assert [c.id_ for c in exportador.cargar_consultas()] == ['a', 'b']

    def test_wallet_como_ruta_existente(self, exportador, tmp_path):
        """
        Un wallet declarado como ruta existente reemplaza el del TOML.
        """
        wallet = tmp_path / 'wallet_alt'
        wallet.mkdir()
        config = exportador.fusionar_config(ConsultaDefinicion.desde_dict({'id': 'q', 'wallet': str(wallet)}))
        assert config['spark']['wallet_path'] == str(wallet)

    def test_wallet_como_ruta_inexistente(self, exportador, tmp_path):
        """Si la ruta del wallet no existe se conserva la del TOML."""
        config = exportador.fusionar_config(ConsultaDefinicion.desde_dict({'id': 'q', 'wallet': str(tmp_path / 'no')}))
        assert config['spark']['wallet_path'] == '/oracle/wallet'


class TestDiagnosticoYValidacion:
    """Diagnostico real una vez por ejecucion y validacion fallida."""

    def test_diagnostico_se_hace_una_vez(self, exportador):
        """
        Sin diagnostico previo lo ejecuta; luego reutiliza el resultado.
        """
        exportador._conectividad = None
        with patch('app.da_exportador.DiagnosticoConectividad') as mock_diag:
            primero = exportador.diagnosticar_conectividad()
            segundo = exportador.diagnosticar_conectividad()
        assert primero is segundo
        mock_diag.return_value.ejecutar.assert_called_once_with(incluir_servidores=True)

    def test_forzar_repite_el_diagnostico(self, exportador):
        """forzar=True vuelve a diagnosticar."""
        with patch('app.da_exportador.DiagnosticoConectividad') as mock_diag:
            exportador.diagnosticar_conectividad(forzar=True)
        mock_diag.return_value.ejecutar.assert_called_once()

    def test_validacion_fallida_no_exporta(self, exportador):
        """Si la validacion previa falla no se ejecuta el flujo."""
        consulta = ConsultaDefinicion.desde_dict({'id': 'q', 'sql': 'SELECT 1'})
        with (
            patch.object(exportador._validador, 'validar_todo', return_value=(False, ['Wallet: no existe'], [])),
            patch.object(exportador, '_ejecutar_flujo_exportacion') as mock_flujo,
        ):
            assert exportador.procesar_consulta(consulta) is False
        mock_flujo.assert_not_called()


class TestExportarConSpark:
    """Exportacion con Spark simulado (una sola lectura a Oracle)."""

    @staticmethod
    def _spark(columnas=('A', 'B')):
        """
        Spark simulado; el lector y el DataFrame quedan accesibles.
        """
        spark = MagicMock()
        lector = spark.read.format.return_value.options.return_value
        df = lector.option.return_value.load.return_value
        df.columns = list(columnas)
        return spark, lector, df

    def test_exporta_y_cuenta_desde_el_csv(self, exportador, tmp_path):
        """
        Escribe con Spark, une las partes y cuenta las filas del CSV.
        """
        spark, lector, df = self._spark()
        salida = tmp_path / 'salida.csv'

        def combinar(_dir, archivo, _delim, _columnas):
            archivo.write_text('A|B\n1|x\n2|y\n', encoding='utf-8')

        config = exportador.fusionar_config(ConsultaDefinicion.desde_dict({'id': 'q'}))
        with (
            patch('app.da_exportador.crear_sesion_spark', return_value=spark),
            patch('app.da_exportador.normalizar_decimales', side_effect=lambda d, _l: d),
            patch.object(exportador, '_combinar_particiones', side_effect=combinar),
        ):
            total = exportador._exportar_con_spark(config, 'SELECT 1', str(salida), ConsultaDefinicion.desde_dict({'id': 'q'}))
        assert total == 2
        lector.option.assert_called_once_with('query', 'SELECT 1')
        df.write.option.assert_called_once_with('delimiter', '|')
        spark.stop.assert_called_once()
        assert exportador._spark is None

    def test_particionado_y_sin_filas(self, exportador, tmp_path, caplog):
        """
        Con columna de particion usa rangos; sin filas lo advierte.
        """
        spark, _, _ = self._spark()
        consulta = ConsultaDefinicion.desde_dict({'id': 'q', 'columna_particion': 'ID', 'num_particiones': 4})

        def combinar(_dir, archivo, _delim, _columnas):
            archivo.write_text('A|B\n', encoding='utf-8')

        with (
            patch('app.da_exportador.crear_sesion_spark', return_value=spark),
            patch('app.da_exportador.normalizar_decimales', side_effect=lambda d, _l: d),
            patch.object(exportador, '_aplicar_particionamiento', side_effect=lambda lector, *_a: lector) as mock_part,
            patch.object(exportador, '_combinar_particiones', side_effect=combinar),
            caplog.at_level('WARNING'),
        ):
            total = exportador._exportar_con_spark(exportador.fusionar_config(consulta), 'S', str(tmp_path / 's.csv'), consulta)
        assert total == 0
        assert mock_part.call_args.args[3:] == ('ID', 4)
        assert 'no devolvio filas' in caplog.text

    def test_spark_se_cierra_si_falla(self, exportador, tmp_path):
        """Un error de lectura cierra la sesion Spark igual."""
        spark, lector, _ = self._spark()
        lector.option.return_value.load.side_effect = RuntimeError('ORA-00942')
        with patch('app.da_exportador.crear_sesion_spark', return_value=spark), pytest.raises(RuntimeError):
            exportador._exportar_con_spark(exportador.fusionar_config(ConsultaDefinicion.desde_dict({'id': 'q'})), 'S', str(tmp_path / 's.csv'),
                                           ConsultaDefinicion.desde_dict({'id': 'q'}))
        spark.stop.assert_called_once()


class TestCombinarCasosExtra:
    """Sin particiones con columnas y delimitador incorrecto."""

    def test_sin_partes_escribe_cabecera(self, exportador, tmp_path):
        """Consulta sin filas: el CSV queda solo con la cabecera."""
        dir_spark = tmp_path / 'vacio'
        dir_spark.mkdir()
        salida = tmp_path / 'out.csv'
        exportador._combinar_particiones(dir_spark, salida, '|', ['A', 'B'])
        assert salida.read_text(encoding='utf-8') == 'A|B\n'
        assert not dir_spark.exists()

    def test_delimitador_incorrecto(self, exportador, tmp_path):
        """
        Una cabecera con comas cuando se espera pipe detiene el proceso.
        """
        dir_spark = tmp_path / 'coma'
        dir_spark.mkdir()
        (dir_spark / 'part-00000.csv').write_text('A,B\n1,2\n', encoding='utf-8')
        with pytest.raises(ValueError, match='DELIMITADOR INCORRECTO'):
            exportador._combinar_particiones(dir_spark, tmp_path / 'out.csv', '|')
