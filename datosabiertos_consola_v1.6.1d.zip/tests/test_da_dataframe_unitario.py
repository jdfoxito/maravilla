"""
Tests unitarios de da_dataframe sin Spark.

DataFrames y pyspark.sql.functions simulados: verifican que cada
funcion arme las operaciones correctas sin levantar una JVM. Las
pruebas con Spark real estan en test_da_dataframe.py y solo corren con
PRUEBAS_SPARK=1.
"""

import logging
from types import SimpleNamespace
from unittest.mock import MagicMock

from pyspark.sql.types import DecimalType, StringType, StructField
import pytest

import app.da_dataframe as modulo
from app.da_dataframe import (
    _aplicar_catalogo_canton,
    _aplicar_mapa_persona,
    _aplicar_proteccion,
    _leer_catalogo,
    _texto_sin_ceros,
    ContextoProceso,
    normalizar_decimales,
    proceso_caso1,
    proceso_caso2,
    ProcesadorDataFrame,
)
from app.da_modelos import ConsultaDefinicion


@pytest.fixture(autouse=True)
def fn_simulado(monkeypatch):
    """Simula pyspark.sql.functions (fn.col exige una sesion Spark)."""
    simulado = MagicMock()
    monkeypatch.setattr(modulo, 'fn', simulado)
    return simulado


@pytest.fixture
def logger():
    """Logger de prueba."""
    return logging.getLogger('test_da_dataframe_unitario')


def _df(columnas):
    """DataFrame simulado con columnas y operaciones encadenables."""
    df = MagicMock()
    df.columns = list(columnas)
    df.withColumn.return_value = df
    df.withColumns.return_value = df
    return df


def _ctx(logger, catalogos=None, lector=None, **datos):
    """Contexto de proceso con una consulta de prueba."""
    consulta = ConsultaDefinicion.desde_dict({'id': 'q', 'catalogos': catalogos or {}, **datos})
    return ContextoProceso(spark=MagicMock(), jdbc_opts={'url': 'u'}, consulta=consulta, logger=logger, lector_catalogos=lector)


class TestLeerCatalogo:
    """Catalogo auxiliar: lector inyectado o JDBC."""

    def test_lector_inyectado(self, logger):
        """Usa el lector inyectado con el SQL recibido."""
        lector = MagicMock(return_value='catalogo')
        assert _leer_catalogo(_ctx(logger, lector=lector), 'SELECT 1') == 'catalogo'
        lector.assert_called_once_with('SELECT 1')

    def test_jdbc(self, logger):
        """
        Sin lector inyectado lee por JDBC con las opciones del contexto.
        """
        ctx = _ctx(logger)
        _leer_catalogo(ctx, 'SELECT 2')
        ctx.spark.read.format.assert_called_once_with('jdbc')
        ctx.spark.read.format.return_value.options.return_value.option.assert_called_once_with('query', 'SELECT 2')


class TestNormalizarDecimales:
    """Solo las columnas decimales con escala se convierten."""

    def test_convierte_solo_decimales_con_escala(self, logger):
        """Decimal(38,10) se normaliza; Decimal(10,0) y texto no."""
        df = _df(['ANIO', 'ENTERO', 'TEXTO'])
        df.schema.fields = [
            StructField('ANIO', DecimalType(38, 10)),
            StructField('ENTERO', DecimalType(10, 0)),
            StructField('TEXTO', StringType()),
        ]
        assert normalizar_decimales(df, logger) is df
        assert list(df.withColumns.call_args.args[0]) == ['ANIO']

    def test_sin_decimales_no_proyecta(self, logger):
        """Sin columnas decimales el DataFrame no se toca."""
        df = _df(['TEXTO'])
        df.schema.fields = [StructField('TEXTO', StringType())]
        assert normalizar_decimales(df, logger) is df
        df.withColumns.assert_not_called()

    def test_texto_sin_ceros(self, fn_simulado):
        """Dos reemplazos: ceros finales y punto final sin decimales."""
        _texto_sin_ceros('MONTO')
        fn_simulado.col.assert_called_once_with('`MONTO`')
        patrones = [llamada.args[1] for llamada in fn_simulado.regexp_replace.call_args_list]
        assert patrones == [r'(\.\d*?[1-9])0+$', r'\.0+$']


class TestProcesos:
    """Procesos de negocio registrados."""

    def test_caso1_sin_cambios(self, logger):
        """Caso 1 devuelve el mismo DataFrame."""
        df = _df(['A'])
        assert proceso_caso1(df, _ctx(logger)) is df

    def test_caso2_aplica_las_tres_reglas(self, logger, monkeypatch):
        """Caso 2: proteccion, persona y canton, en ese orden."""
        orden = []
        monkeypatch.setattr(modulo, '_aplicar_proteccion', lambda df, ctx: orden.append('proteccion') or df)
        monkeypatch.setattr(modulo, '_aplicar_mapa_persona', lambda df, ctx: orden.append('persona') or df)
        monkeypatch.setattr(modulo, '_aplicar_catalogo_canton', lambda df, ctx: orden.append('canton') or df)
        df = _df(['A'])
        assert proceso_caso2(df, _ctx(logger)) is df
        assert orden == ['proteccion', 'persona', 'canton']

    def test_proteccion_columnas_presentes(self, logger, fn_simulado):
        """Ambas columnas protegidas se transforman con factor 1.5."""
        df = _df(['codigo_vehiculo', 'codigo_sub_categoria'])
        _aplicar_proteccion(df, _ctx(logger))
        assert [llamada.args[0] for llamada in df.withColumn.call_args_list] == ['codigo_vehiculo', 'codigo_sub_categoria']
        fn_simulado.lit.assert_called_with(1.5)

    def test_proteccion_columna_ausente(self, logger, caplog):
        """Una columna protegida ausente solo se advierte."""
        df = _df(['codigo_sub_categoria'])
        with caplog.at_level(logging.WARNING):
            _aplicar_proteccion(df, _ctx(logger))
        assert 'codigo_vehiculo no existe' in caplog.text
        assert df.withColumn.call_count == 1

    def test_mapa_persona(self, logger, fn_simulado):
        """C, P y R generan una expresion when por codigo."""
        df = _df(['tipo_identificac_potenc_prop'])
        _aplicar_mapa_persona(df, _ctx(logger))
        assert fn_simulado.when.call_count == 3
        df.withColumn.assert_called_once()

    def test_mapa_persona_sin_columna(self, logger):
        """Sin la columna de persona no se mapea."""
        df = _df(['otra'])
        assert _aplicar_mapa_persona(df, _ctx(logger)) is df
        df.withColumn.assert_not_called()


class TestCatalogoCanton:
    """Reemplazo de codigo_canton por la descripcion del catalogo."""

    def test_sin_columna_canton(self, logger):
        """Sin codigo_canton no se lee el catalogo."""
        lector = MagicMock()
        df = _df(['A'])
        assert _aplicar_catalogo_canton(df, _ctx(logger, {'canton_sql': 'S'}, lector)) is df
        lector.assert_not_called()

    def test_sin_canton_sql(self, logger):
        """Sin catalogos.canton_sql se conserva el codigo."""
        df = _df(['codigo_canton'])
        assert _aplicar_catalogo_canton(df, _ctx(logger)) is df

    def test_catalogo_invalido(self, logger):
        """Un catalogo de menos de 2 columnas detiene el proceso."""
        lector = MagicMock(return_value=SimpleNamespace(columns=['CODIGO']))
        with pytest.raises(ValueError, match='Catalogo de cantones invalido'):
            _aplicar_catalogo_canton(_df(['codigo_canton']), _ctx(logger, {'canton_sql': 'S'}, lector))

    def test_join_con_broadcast(self, logger, fn_simulado):
        """
        Join LEFT con el catalogo en broadcast y limpieza de auxiliares.
        """
        catalogo = MagicMock()
        catalogo.columns = ['CODIGO_CANTON', 'DESCRIPCION']
        df = _df(['codigo_canton'])
        unidos = df.join.return_value
        resultado = _aplicar_catalogo_canton(df, _ctx(logger, {'canton_sql': 'S'}, MagicMock(return_value=catalogo)))
        fn_simulado.broadcast.assert_called_once()
        assert df.join.call_args.args[2] == 'left'
        unidos.withColumn.return_value.drop.assert_called_once_with('_cat_codigo', '_cat_desc')
        assert resultado is unidos.withColumn.return_value.drop.return_value


class TestProcesadorDataFrame:
    """Pipeline proceso -> columnas -> orden."""

    def test_sin_declaraciones(self, logger):
        """Sin proceso, columnas ni orden el DataFrame pasa igual."""
        df = _df(['A'])
        assert ProcesadorDataFrame(logger).aplicar(df, _ctx(logger)) is df

    def test_proceso_no_registrado(self, logger):
        """
        Un proceso desconocido detiene con la lista de disponibles.
        """
        with pytest.raises(ValueError, match='proceso_caso1'):
            ProcesadorDataFrame(logger).aplicar(_df(['A']), _ctx(logger, proceso='otro'))

    def test_proceso_registrado(self, logger, monkeypatch):
        """El proceso declarado se ejecuta por nombre."""
        llamado = MagicMock(side_effect=lambda df, ctx: df)
        monkeypatch.setitem(ProcesadorDataFrame.PROCESOS, 'proceso_prueba', llamado)
        df = _df(['A'])
        ProcesadorDataFrame(logger).aplicar(df, _ctx(logger, proceso=' proceso_prueba '))
        llamado.assert_called_once()

    def test_columnas(self, logger):
        """Selecciona y renombra las columnas declaradas."""
        df = _df(['a', 'b'])
        ProcesadorDataFrame(logger).aplicar(df, _ctx(logger, columnas={'b': 'B', 'a': 'A'}))
        assert len(df.select.call_args.args[0]) == 2

    def test_columna_faltante(self, logger):
        """Una columna origen inexistente detiene el proceso."""
        with pytest.raises(ValueError, match='Columnas no encontradas'):
            ProcesadorDataFrame(logger).aplicar(_df(['a']), _ctx(logger, columnas={'x': 'X'}))

    def test_orden(self, logger, fn_simulado):
        """Orden ascendente por defecto y descendente si se declara."""
        df = _df(['A', 'B'])
        ProcesadorDataFrame(logger).aplicar(df, _ctx(logger, orden=[{'columna': 'A'}, {'columna': 'B', 'ascendente': False}]))
        fn_simulado.col.return_value.asc.assert_called_once()
        fn_simulado.col.return_value.desc.assert_called_once()
        df.orderBy.assert_called_once()

    def test_orden_columna_inexistente(self, logger):
        """Ordenar por una columna inexistente detiene el proceso."""
        with pytest.raises(ValueError, match='Columna de ordenamiento no existe'):
            ProcesadorDataFrame(logger).aplicar(_df(['A']), _ctx(logger, orden=[{'columna': 'Z'}]))
