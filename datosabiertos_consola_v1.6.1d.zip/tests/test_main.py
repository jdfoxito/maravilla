"""
Tests de la CLI (main.py).

Frontera simulada: ExportadorDatosAbiertos, get_config_manager,
VerificadorRemoto, NotificadorEmail, la prueba previa de consultas y
el diagnostico de conectividad. Usa click.testing.CliRunner. Cubre
helpers de pantalla, resumen de verificacion, seleccion, modos
listar/directo/interactivo, prueba previa, receptores de los JSON,
subcomando verificar, notificaciones y logger.
"""

from datetime import datetime
import logging
from types import SimpleNamespace
from unittest.mock import ANY, MagicMock, patch

from click.testing import CliRunner
import pytest

from app.da_modelos import ConsultaDefinicion
from app.main import (
    _email_con_receptores,
    _detectar_comando_base,
    _construir_resumen_verificacion,
    _resolver_seleccion,
    _mostrar_lista,
    _mostrar_menu_interactivo,
    _ejecutar_consulta_interactiva,
    _despedida,
    _modo_interactivo,
    _modo_listar,
    _modo_directo,
    _crear_logger,
    _log,
    _banner,
    _pantalla_ayuda,
    _enviar_correo_verificacion,
    _notificar_verificacion,
    main,
    cmd_verificar,
    VERSION,
)


@pytest.fixture
def runner():
    """CliRunner aislado."""
    return CliRunner()


@pytest.fixture
def mock_logger(tmp_path):
    """Logger real en archivo temporal para capturar logs de tests."""
    logger = logging.getLogger('test_main')
    logger.setLevel(logging.DEBUG)
    handler = logging.FileHandler(tmp_path / 'test_main.log')
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    yield logger
    logger.removeHandler(handler)
    handler.close()


@pytest.fixture(autouse=True)
def _sin_red(monkeypatch):
    """
    Aisla la CLI de Oracle, Spark, la red y el log real: prueba previa
    OK, sin consultas marcadas y conectividad sin mostrar.
    """
    monkeypatch.setattr('app.main._iniciar', lambda ruta_config: logging.getLogger('app'))
    monkeypatch.setattr('app.main._probar_consultas', MagicMock(return_value=True))
    monkeypatch.setattr('app.main._consultas_sin_credencial', MagicMock(return_value={}))
    monkeypatch.setattr('app.main._mostrar_conectividad', MagicMock())


@pytest.fixture
def exportador_mock():
    """ExportadorDatosAbiertos simulado."""
    exp = MagicMock()
    exp.listar_consultas.return_value = [('fact', 'Facturacion')]
    consulta = SimpleNamespace(id_='fact', nombre='Facturacion', sql='SELECT 1')
    exp.encontrar_consulta.return_value = consulta
    exp.procesar_consulta.return_value = True
    return exp


class TestLogger:
    """_crear_logger y _log."""

    def test_crear_logger_devuelve_logger(self):
        """_crear_logger retorna un logging.Logger."""
        logger = _crear_logger()
        assert isinstance(logger, logging.Logger)
        assert logger.name == 'app'

    def test_crear_logger_no_duplica_handlers(self):
        """Llamar dos veces no duplica handlers."""
        logger1 = _crear_logger()
        count1 = len(logger1.handlers)
        logger2 = _crear_logger()
        count2 = len(logger2.handlers)
        assert count1 == count2

    def test_log_lazy_format(self, caplog):
        """_log usa formato lazy %%."""
        logger = logging.getLogger('test_log')
        logger.setLevel(logging.INFO)
        with caplog.at_level(logging.INFO, logger='test_log'):
            _log(logger, logging.INFO, 'Valor: %s, Otro: %s', 'A', 'B')
        assert 'Valor: A, Otro: B' in caplog.text

    def test_log_con_exc_info(self, caplog):
        """_log pasa exc_info correctamente."""
        logger = logging.getLogger('test_log_exc')
        logger.setLevel(logging.ERROR)
        with caplog.at_level(logging.ERROR, logger='test_log_exc'):
            try:
                raise ValueError('fallo')
            except ValueError:
                _log(logger, logging.ERROR, 'Error: %s', 'test', exc_info=True)
        assert 'Error: test' in caplog.text


class TestHelpersPantalla:
    """Funciones de presentacion que no tocan red."""

    def test_detectar_comando_base_devuelve_str(self):
        """
        _detectar_comando_base siempre devuelve una cadena no vacia.
        """
        cmd = _detectar_comando_base()
        assert isinstance(cmd, str)
        assert cmd

    def test_detectar_comando_base_contiene_python_o_pdm(self):
        """El comando detectado contiene python o pdm o ./"""
        cmd = _detectar_comando_base()
        assert 'python' in cmd or 'pdm' in cmd or cmd.startswith('./')

    def test_mostrar_lista_no_falla(self):
        """_mostrar_lista imprime sin levantar."""
        assert _mostrar_lista([('id1', 'Nombre 1')]) is None

    def test_mostrar_lista_vacia(self):
        """_mostrar_lista con lista vacia no falla."""
        assert _mostrar_lista([]) is None

    def test_banner_no_falla(self):
        """_banner imprime sin levantar."""
        _banner()

    def test_pantalla_ayuda_no_falla(self):
        """_pantalla_ayuda imprime sin levantar."""
        _pantalla_ayuda('python -m app.main')

    def test_mostrar_menu_interactivo_no_falla(self):
        """_mostrar_menu_interactivo imprime sin levantar."""
        _mostrar_menu_interactivo([('a', 'A'), ('b', 'B')], {})

    def test_mostrar_menu_interactivo_vacio(self):
        """_mostrar_menu_interactivo con lista vacia no falla."""
        _mostrar_menu_interactivo([], {})


class TestResumenVerificacion:
    """_construir_resumen_verificacion arma el texto por servidor."""

    def test_resumen_con_archivos(self):
        """Incluye servidor, anio y archivos."""
        resultados = [
            {
                'servidor': 'Quito',
                'ip': '10.0.0.1',
                'exito': True,
                'errores': [],
                'archivos': [{'ok': True, 'nombre': 'f.zip', 'tamanio_kb': 12.0, 'fecha_mod': '2024-01-01'}],
            }
        ]
        resumen = _construir_resumen_verificacion(resultados, 2024)
        assert 'Quito' in resumen
        assert '2024' in resumen
        assert 'f.zip' in resumen
        assert 'OK' in resumen

    def test_resumen_con_errores(self):
        """Incluye los errores del servidor."""
        resultados = [{'servidor': 'Gye', 'ip': '10.0.0.2', 'exito': False, 'errores': ['Auth fallida'], 'archivos': []}]
        resumen = _construir_resumen_verificacion(resultados, 2024)
        assert 'Auth fallida' in resumen
        assert 'ERROR' in resumen

    def test_resumen_sin_archivos_ni_errores(self):
        """Servidor sin archivos ni errores informa 'Sin archivos'."""
        resultados = [{'servidor': 'Q', 'ip': 'x', 'exito': True, 'errores': [], 'archivos': []}]
        resumen = _construir_resumen_verificacion(resultados, 2024)
        assert 'Sin archivos' in resumen

    def test_resumen_advertencia_archivo(self):
        """Archivo con ok=False muestra ADVERTENCIA."""
        resultados = [
            {
                'servidor': 'Q',
                'ip': 'x',
                'exito': True,
                'errores': [],
                'archivos': [{'ok': False, 'nombre': 'f.zip', 'tamanio_kb': 0.5, 'fecha_mod': '2024-01-01'}],
            }
        ]
        resumen = _construir_resumen_verificacion(resultados, 2024)
        assert 'ADVERTENCIA' in resumen

    def test_resumen_multiples_servidores(self):
        """Resumen con multiples servidores."""
        resultados = [
            {'servidor': 'Q', 'ip': 'x', 'exito': True, 'errores': [], 'archivos': []},
            {'servidor': 'G', 'ip': 'y', 'exito': False, 'errores': ['fail'], 'archivos': []},
        ]
        resumen = _construir_resumen_verificacion(resultados, 2024)
        assert 'Q' in resumen
        assert 'G' in resumen


class TestResolverSeleccion:
    """_resolver_seleccion convierte la entrada en consulta_id."""

    def test_numero_valido(self):
        """Numero dentro de rango -> id correspondiente."""
        consultas = [('a', 'A'), ('b', 'B')]
        assert _resolver_seleccion(consultas, '2') == 'b'

    def test_numero_uno(self):
        """Numero 1 -> primer id."""
        consultas = [('a', 'A'), ('b', 'B')]
        assert _resolver_seleccion(consultas, '1') == 'a'

    def test_numero_fuera_de_rango(self):
        """Numero fuera de rango -> None."""
        consultas = [('a', 'A')]
        assert _resolver_seleccion(consultas, '9') is None

    def test_numero_cero(self):
        """Numero 0 -> None (es salir)."""
        consultas = [('a', 'A')]
        assert _resolver_seleccion(consultas, '0') is None

    def test_texto_se_devuelve_igual(self):
        """Un texto (no numerico) se devuelve tal cual."""
        consultas = [('a', 'A')]
        assert _resolver_seleccion(consultas, 'mi_id') == 'mi_id'

    def test_texto_con_espacios(self):
        """Texto con espacios se devuelve tal cual."""
        consultas = [('a', 'A')]
        assert _resolver_seleccion(consultas, 'mi id') == 'mi id'

    def test_lista_vacia(self):
        """Lista vacia y numero 1 -> None."""
        assert _resolver_seleccion([], '1') is None


class TestEjecutarConsultaInteractiva:
    """_ejecutar_consulta_interactiva."""

    def test_exitoso(self, exportador_mock):
        """Proceso exitoso -> True y mensaje verde."""
        resultado = _ejecutar_consulta_interactiva(exportador_mock, exportador_mock.encontrar_consulta.return_value, None)
        assert resultado is True

    def test_fallido(self, exportador_mock):
        """Proceso fallido -> False y mensaje rojo."""
        exportador_mock.procesar_consulta.return_value = False
        resultado = _ejecutar_consulta_interactiva(exportador_mock, exportador_mock.encontrar_consulta.return_value, None)
        assert resultado is False


class TestDespedida:
    """_despedida."""

    def test_despedida_exito(self):
        """Exito=True -> exit code 0."""
        with pytest.raises(SystemExit) as exc_info:
            _despedida(exito=True)
        assert exc_info.value.code == 0

    def test_despedida_fallo(self):
        """Exito=False -> exit code 1."""
        with pytest.raises(SystemExit) as exc_info:
            _despedida(exito=False)
        assert exc_info.value.code == 1


class TestModoListar:
    """_modo_listar."""

    def test_con_consultas(self, exportador_mock):
        """Con consultas, muestra lista y no sale."""
        _modo_listar(exportador_mock)
        exportador_mock.listar_consultas.assert_called_once()

    def test_sin_consultas_sale_1(self, exportador_mock):
        """Sin consultas, sale con codigo 1."""
        exportador_mock.listar_consultas.return_value = []
        with pytest.raises(SystemExit) as exc_info:
            _modo_listar(exportador_mock)
        assert exc_info.value.code == 1


class TestModoDirecto:
    """_modo_directo."""

    def test_sin_id_sale_1(self, exportador_mock):
        """Sin CONSULTA_ID, sale con error 1."""
        with pytest.raises(SystemExit) as exc_info:
            _modo_directo(exportador_mock, None, 'cmd', None)
        assert exc_info.value.code == 1

    def test_id_inexistente_sale_1(self, exportador_mock):
        """ID inexistente, sale con 1."""
        exportador_mock.encontrar_consulta.return_value = None
        with pytest.raises(SystemExit) as exc_info:
            _modo_directo(exportador_mock, 'noexiste', 'cmd', None)
        assert exc_info.value.code == 1

    def test_exitoso_sale_0(self, exportador_mock):
        """Proceso OK, sale con 0."""
        with pytest.raises(SystemExit) as exc_info:
            _modo_directo(exportador_mock, 'fact', 'cmd', None)
        assert exc_info.value.code == 0

    def test_fallido_sale_1(self, exportador_mock):
        """Proceso fallido, sale con 1."""
        exportador_mock.procesar_consulta.return_value = False
        with pytest.raises(SystemExit) as exc_info:
            _modo_directo(exportador_mock, 'fact', 'cmd', None)
        assert exc_info.value.code == 1


class TestModoInteractivo:
    """_modo_interactivo."""

    def test_sin_consultas_sale_1(self, exportador_mock):
        """Sin consultas configuradas, sale con 1."""
        exportador_mock.listar_consultas.return_value = []
        with pytest.raises(SystemExit) as exc_info:
            _modo_interactivo(exportador_mock, 'cmd', None)
        assert exc_info.value.code == 1

    def test_seleccion_salir(self, exportador_mock):
        """Usuario selecciona 0 -> despedida."""
        with pytest.raises(SystemExit) as exc_info:
            with patch('builtins.input', return_value='0'):
                _modo_interactivo(exportador_mock, 'cmd', None)
        assert exc_info.value.code == 0

    def test_seleccion_ayuda(self, exportador_mock):
        """Usuario selecciona ? -> ayuda y continua."""
        with patch('builtins.input', side_effect=['?', '0']):
            with pytest.raises(SystemExit) as exc_info:
                _modo_interactivo(exportador_mock, 'cmd', None)
        assert exc_info.value.code == 0

    def test_seleccion_numero_valido(self, exportador_mock):
        """Usuario selecciona 1 -> ejecuta consulta."""
        with patch('builtins.input', side_effect=['1', '0']), patch('click.confirm', return_value=False):
            with pytest.raises(SystemExit) as exc_info:
                _modo_interactivo(exportador_mock, 'cmd', None)
        assert exc_info.value.code == 0
        exportador_mock.procesar_consulta.assert_called_once()

    def test_seleccion_texto_valido(self, exportador_mock):
        """Usuario escribe ID directo -> ejecuta."""
        with patch('builtins.input', side_effect=['fact', '0']), patch('click.confirm', return_value=False):
            with pytest.raises(SystemExit) as exc_info:
                _modo_interactivo(exportador_mock, 'cmd', None)
        assert exc_info.value.code == 0

    def test_seleccion_invalida(self, exportador_mock):
        """Numero invalido -> muestra error y continua."""
        with patch('builtins.input', side_effect=['99', '0']):
            with pytest.raises(SystemExit) as exc_info:
                _modo_interactivo(exportador_mock, 'cmd', None)
        assert exc_info.value.code == 0

    def test_eof_error(self, exportador_mock):
        """EOFError -> sale con 0."""
        with pytest.raises(SystemExit) as exc_info:
            with patch('builtins.input', side_effect=EOFError()):
                _modo_interactivo(exportador_mock, 'cmd', None)
        assert exc_info.value.code == 0

    def test_keyboard_interrupt(self, exportador_mock):
        """KeyboardInterrupt -> sale con 0."""
        with pytest.raises(SystemExit) as exc_info:
            with patch('builtins.input', side_effect=KeyboardInterrupt()):
                _modo_interactivo(exportador_mock, 'cmd', None)
        assert exc_info.value.code == 0


class TestMainSinSubcomando:
    """main() sin subcomando (modo interactivo por defecto)."""

    def test_main_interactivo(self, runner, exportador_mock):
        """Sin args -> modo interactivo."""
        with (
            patch('app.main.ExportadorDatosAbiertos', return_value=exportador_mock),
            patch('builtins.input', side_effect=['0']),
            patch('app.main._banner'),
        ):
            resultado = runner.invoke(main, [])
        assert resultado.exit_code == 0

    def test_main_con_config(self, runner, exportador_mock):
        """Con --config pasa ruta_config."""
        with patch('app.main.ExportadorDatosAbiertos') as mock_exp:
            mock_exp.return_value = exportador_mock
            with patch('builtins.input', side_effect=['0']), patch('app.main._banner'):
                runner.invoke(main, ['--config', '/tmp/config.toml'])
            mock_exp.assert_called_once_with('/tmp/config.toml', ANY)


class TestMainListar:
    """Modo --listar de la CLI."""

    def test_listar_con_consultas(self, runner, exportador_mock):
        """--listar imprime las consultas disponibles."""
        with patch('app.main.ExportadorDatosAbiertos', return_value=exportador_mock):
            resultado = runner.invoke(main, ['--listar'])
        assert resultado.exit_code == 0
        assert 'fact' in resultado.output

    def test_listar_sin_consultas_sale_1(self, runner, exportador_mock):
        """Sin consultas, --listar sale con codigo 1."""
        exportador_mock.listar_consultas.return_value = []
        with patch('app.main.ExportadorDatosAbiertos', return_value=exportador_mock):
            resultado = runner.invoke(main, ['--listar'])
        assert resultado.exit_code == 1


class TestMainDirecto:
    """Modo --directo de la CLI."""

    def test_directo_sin_id_sale_1(self, runner, exportador_mock):
        """--directo sin CONSULTA_ID sale con error."""
        with patch('app.main.ExportadorDatosAbiertos', return_value=exportador_mock):
            resultado = runner.invoke(main, ['--directo'])
        assert resultado.exit_code == 1

    def test_directo_consulta_inexistente(self, runner, exportador_mock):
        """--directo con id inexistente sale 1."""
        exportador_mock.encontrar_consulta.return_value = None
        with patch('app.main.ExportadorDatosAbiertos', return_value=exportador_mock):
            resultado = runner.invoke(main, ['--directo', 'noexiste'])
        assert resultado.exit_code == 1

    def test_directo_exitoso(self, runner, exportador_mock):
        """--directo con consulta valida y proceso OK sale 0."""
        with patch('app.main.ExportadorDatosAbiertos', return_value=exportador_mock):
            resultado = runner.invoke(main, ['--directo', 'fact'])
        assert resultado.exit_code == 0

    def test_directo_proceso_falla(self, runner, exportador_mock):
        """--directo con proceso fallido sale 1."""
        exportador_mock.procesar_consulta.return_value = False
        with patch('app.main.ExportadorDatosAbiertos', return_value=exportador_mock):
            resultado = runner.invoke(main, ['--directo', 'fact'])
        assert resultado.exit_code == 1

    def test_directo_con_argumento_posicional(self, runner, exportador_mock):
        """--directo con argumento posicional funciona."""
        with patch('app.main.ExportadorDatosAbiertos', return_value=exportador_mock):
            resultado = runner.invoke(main, ['--directo', 'fact'])
        assert resultado.exit_code == 0
        exportador_mock.encontrar_consulta.assert_called_once_with('fact')


class TestCmdVerificar:
    """Subcomando verificar."""

    def _gestor(self, tmp_path):
        """ConfigManager mock para verificar."""
        gestor = MagicMock()
        gestor.get_servidores_descarga.return_value = [{'nombre': 'Quito', 'ip': '10.0.0.1'}]
        gestor.get_verificacion_config.return_value = {'patrones_archivos': [], 'tamanio_minimo_bytes': 1024}
        gestor.get_email_config.return_value = {'smtp_server': ''}
        gestor.get_rutas.return_value = {'mails': tmp_path / 'mails'}
        return gestor

    def test_verificar_todos_ok(self, runner, tmp_path):
        """
        Verificacion con todos los servidores OK (con archivos) sale 0.

        'OK' segun el SDC exige que el servidor tenga los archivos del
        anio publicados: conectar sin archivos NO es exito (se alerta).
        Por eso el servidor de este caso incluye un archivo valido.
        """
        gestor = self._gestor(tmp_path)
        verificador = MagicMock()
        verificador.verificar_todos.return_value = [
            {
                'servidor': 'Quito',
                'ip': '10.0.0.1',
                'exito': True,
                'errores': [],
                'archivos': [{'nombre': 'FACTURACION_FISICA_2024.zip', 'ok': True, 'tamanio_kb': 2048, 'fecha_mod': '2024-01-03', 'advertencia': ''}],
            }
        ]
        with patch('app.main.get_config_manager', return_value=gestor), patch('app.main.VerificadorRemoto', return_value=verificador):
            resultado = runner.invoke(cmd_verificar, ['--anio', '2024'])
        assert resultado.exit_code == 0

    def test_verificar_con_error_sale_1(self, runner, tmp_path):
        """Un servidor sin exito hace salir con codigo 1."""
        gestor = self._gestor(tmp_path)
        verificador = MagicMock()
        verificador.verificar_todos.return_value = [{'servidor': 'Gye', 'ip': '10.0.0.2', 'exito': False, 'errores': ['caido'], 'archivos': []}]
        with patch('app.main.get_config_manager', return_value=gestor), patch('app.main.VerificadorRemoto', return_value=verificador):
            resultado = runner.invoke(cmd_verificar, [])
        assert resultado.exit_code == 1

    def test_verificar_anio_default(self, runner, tmp_path):
        """Sin --anio, usa año actual."""
        gestor = self._gestor(tmp_path)
        verificador = MagicMock()
        verificador.verificar_todos.return_value = [{'servidor': 'Q', 'ip': 'x', 'exito': True, 'errores': [], 'archivos': []}]
        with patch('app.main.get_config_manager', return_value=gestor), patch('app.main.VerificadorRemoto', return_value=verificador) as mock_ver:
            runner.invoke(cmd_verificar, [])
        anio_actual = datetime.now().year
        mock_ver.return_value.verificar_todos.assert_called_once_with(anio_actual)

    def test_verificar_con_config(self, runner, tmp_path):
        """Con --config pasa ruta_config."""
        gestor = self._gestor(tmp_path)
        verificador = MagicMock()
        verificador.verificar_todos.return_value = [{'servidor': 'Q', 'ip': 'x', 'exito': True, 'errores': [], 'archivos': []}]
        with patch('app.main.get_config_manager') as mock_gestor, patch('app.main.VerificadorRemoto', return_value=verificador):
            mock_gestor.return_value = gestor
            runner.invoke(cmd_verificar, ['--config', '/tmp/c.toml'])
        mock_gestor.assert_called_once_with('/tmp/c.toml', ANY)


class TestNotificarVerificacion:
    """_notificar_verificacion guarda reporte local y envia correo."""

    def test_guarda_reporte_local(self, tmp_path):
        """Genera un archivo .txt con el resumen."""
        resultados = [
            {'servidor': 'Q', 'ip': 'x', 'exito': True, 'errores': [], 'archivos': [{'ok': True, 'nombre': 'f', 'tamanio_kb': 1, 'fecha_mod': 'd'}]}
        ]
        logger = MagicMock()
        with patch('app.main._enviar_correo_verificacion'):
            _notificar_verificacion(resultados, 2024, {'smtp_server': ''}, {'mails': tmp_path / 'm'}, logger)
        archivos = list((tmp_path / 'm').glob('*.txt'))
        assert len(archivos) == 1

    def test_exito_false_cuando_faltan_archivos(self, tmp_path):
        """Si algun servidor no tiene archivos, exito=False."""
        resultados = [{'servidor': 'Q', 'ip': 'x', 'exito': True, 'errores': [], 'archivos': []}]
        logger = MagicMock()
        with patch('app.main._enviar_correo_verificacion') as mock_enviar:
            _notificar_verificacion(resultados, 2024, {'smtp_server': ''}, {'mails': tmp_path / 'm'}, logger)
        args = mock_enviar.call_args.args
        assert args[2] is False

    def test_exito_true_cuando_todo_ok(self, tmp_path):
        """Si todos tienen archivos, exito=True."""
        resultados = [
            {'servidor': 'Q', 'ip': 'x', 'exito': True, 'errores': [], 'archivos': [{'ok': True, 'nombre': 'f', 'tamanio_kb': 1, 'fecha_mod': 'd'}]}
        ]
        logger = MagicMock()
        with patch('app.main._enviar_correo_verificacion') as mock_enviar:
            _notificar_verificacion(resultados, 2024, {'smtp_server': ''}, {'mails': tmp_path / 'm'}, logger)
        args = mock_enviar.call_args.args
        assert args[2] is True


class TestEnviarCorreoVerificacion:
    """_enviar_correo_verificacion."""

    def test_sin_smtp_server_no_envia(self, mock_logger):
        """Sin smtp_server, no intenta enviar."""
        with patch('app.main.NotificadorEmail') as mock_notif:
            _enviar_correo_verificacion({}, 2024, True, 'resumen', mock_logger)
        mock_notif.assert_not_called()

    def test_sin_acceso_al_correo_no_envia(self, mock_logger):
        """Si el SMTP no responde, no se intenta enviar."""
        with (
            patch('app.main.probar_correo', return_value=SimpleNamespace(disponible=False)),
            patch('app.main.NotificadorEmail') as mock_notif,
        ):
            _enviar_correo_verificacion({'smtp_server': 'smtp.sri.gob.ec'}, 2024, True, 'resumen', mock_logger)
        mock_notif.assert_not_called()

    def test_con_smtp_envia_correo(self, mock_logger):
        """Con smtp_server, crea NotificadorEmail y envia."""
        with patch('app.main.probar_correo', return_value=SimpleNamespace(disponible=True)), patch('app.main.NotificadorEmail') as mock_notif_cls:
            mock_notif = MagicMock()
            mock_notif.enviar_notificacion.return_value = True
            mock_notif_cls.return_value = mock_notif
            _enviar_correo_verificacion({'smtp_server': 'smtp.sri.gob.ec'}, 2024, True, 'resumen', mock_logger)
        mock_notif_cls.assert_called_once_with({'smtp_server': 'smtp.sri.gob.ec'}, mock_logger)
        mock_notif.enviar_notificacion.assert_called_once()

    def test_correo_fallido_loguea_warning(self, mock_logger):
        """Si enviar_notificacion retorna False, loguea warning."""
        with patch('app.main.probar_correo', return_value=SimpleNamespace(disponible=True)), patch('app.main.NotificadorEmail') as mock_notif_cls:
            mock_notif = MagicMock()
            mock_notif.enviar_notificacion.return_value = False
            mock_notif_cls.return_value = mock_notif
            _enviar_correo_verificacion({'smtp_server': 'smtp.sri.gob.ec'}, 2024, True, 'resumen', mock_logger)

    def test_error_no_critico_no_propaga_y_loguea(self, mock_logger):
        """
        Un error no critico (ValueError) al enviar el correo de
        verificacion se captura y se registra: un fallo SMTP no tumba
        el comando 'verificar'.
        """
        with patch('app.main.probar_correo', return_value=SimpleNamespace(disponible=True)), patch('app.main.NotificadorEmail') as mock_notif_cls:
            mock_notif = MagicMock()
            mock_notif.enviar_notificacion.side_effect = ValueError('fallo')
            mock_notif_cls.return_value = mock_notif
            _enviar_correo_verificacion({'smtp_server': 'smtp.sri.gob.ec'}, 2024, True, 'resumen', mock_logger)
        mock_notif.enviar_notificacion.assert_called_once()


class TestConstantes:
    """Valida constantes del modulo."""

    def test_version_es_string(self):
        """Version es string."""
        assert isinstance(VERSION, str)

    def test_version_no_vacia(self):
        """Version no vacia."""
        assert VERSION


class TestPruebaPrevia:
    """La prueba previa (credencial + 1 fila) bloquea la exportacion."""

    def test_directo_prueba_fallida_no_exporta(self, exportador_mock, monkeypatch):
        """
        -d con prueba fallida: sale con 1 y no llama procesar_consulta.
        """
        monkeypatch.setattr('app.main._probar_consultas', MagicMock(return_value=False))
        with pytest.raises(SystemExit) as exc_info:
            _modo_directo(exportador_mock, 'fact', 'cmd', None)
        assert exc_info.value.code == 1
        exportador_mock.procesar_consulta.assert_not_called()

    def test_interactivo_prueba_fallida_no_exporta(self, exportador_mock, monkeypatch):
        """En el menu, una prueba fallida retorna False sin exportar."""
        monkeypatch.setattr('app.main._probar_consultas', MagicMock(return_value=False))
        assert _ejecutar_consulta_interactiva(exportador_mock, exportador_mock.encontrar_consulta.return_value, None) is False
        exportador_mock.procesar_consulta.assert_not_called()

    def test_menu_marca_consulta_sin_credencial(self, capsys):
        """
        La consulta cuya conexion no esta en tnsnames.ora se marca.
        """
        _mostrar_menu_interactivo([('h5', 'Vehiculos')], {'h5': 'SRIDW_MVEHICULAR'})
        assert 'sin credencial SRIDW_MVEHICULAR' in capsys.readouterr().out


class TestReceptores:
    """
    Las notificaciones de probar/verificar
    usan los receptores de los JSON.
    """

    _TOML = {'smtp_server': 's', 'to_addresses': ['toml@sri.ad']}

    def test_union_sin_repetir(self):
        """Une los receptores de todas las consultas, sin duplicados."""
        consultas = [
            ConsultaDefinicion.desde_dict({'id': 'a', 'receptores': 'jefe@sri.gob.ec, yo@sri.gob.ec'}),
            ConsultaDefinicion.desde_dict({'id': 'b', 'receptores': 'yo@sri.gob.ec; otro@sri.gob.ec'}),
        ]
        assert _email_con_receptores(self._TOML, consultas)['to_addresses'] == ['jefe@sri.gob.ec', 'yo@sri.gob.ec', 'otro@sri.gob.ec']

    def test_sin_receptores_usa_toml(self):
        """Si ningun JSON declara receptores se usan los del TOML."""
        consultas = [ConsultaDefinicion.desde_dict({'id': 'a'})]
        assert _email_con_receptores(self._TOML, consultas) is self._TOML


class TestEnrutamientoCli:
    """
    GrupoExportador: subcomando o CONSULTA_ID como primer argumento.
    """

    def test_verificar_no_se_toma_como_consulta(self, runner):
        """
        'verificar' ejecuta el subcomando, no una consulta llamada asi.
        """
        with patch('app.main.cmd_verificar.callback') as mock_verificar, patch('app.main.cmd_ejecutar.callback') as mock_ejecutar:
            runner.invoke(main, ['verificar'])
        mock_verificar.assert_called_once()
        mock_ejecutar.assert_not_called()

    def test_id_sin_d_ejecuta_la_consulta(self, runner, exportador_mock):
        """main facturacion_x enruta al comando oculto 'ejecutar'."""
        with patch('app.main.ExportadorDatosAbiertos', return_value=exportador_mock):
            resultado = runner.invoke(main, ['fact'])
        assert resultado.exit_code == 0
        exportador_mock.encontrar_consulta.assert_called_once_with('fact')
        exportador_mock.procesar_consulta.assert_called_once()

    def test_probar_una_consulta(self, runner, exportador_mock, monkeypatch):
        """probar <ID> prueba solo esa consulta y sale 0 si funciona."""
        exportador_mock.cargar_consultas.return_value = [ConsultaDefinicion.desde_dict({'id': 'fact'}), ConsultaDefinicion.desde_dict({'id': 'otra'})]
        probar = MagicMock(return_value=True)
        monkeypatch.setattr('app.main._probar_consultas', probar)
        with patch('app.main.ExportadorDatosAbiertos', return_value=exportador_mock):
            resultado = runner.invoke(main, ['probar', 'fact'])
        assert resultado.exit_code == 0
        assert [c.id_ for c in probar.call_args.args[1]] == ['fact']


class TestCasosRestantesCli:
    """Consulta inexistente en el menu y probar sin consultas."""

    def test_menu_consulta_no_encontrada(self, exportador_mock, capsys):
        """Un ID que no existe se informa y el menu sigue."""
        exportador_mock.encontrar_consulta.return_value = None
        with patch('builtins.input', side_effect=['no_existe', '0']), pytest.raises(SystemExit):
            _modo_interactivo(exportador_mock, 'cmd', None)
        assert 'Consulta "no_existe" no encontrada' in capsys.readouterr().out
        exportador_mock.procesar_consulta.assert_not_called()

    def test_probar_sin_consultas(self, runner, exportador_mock):
        """probar con un ID inexistente sale con 1."""
        exportador_mock.cargar_consultas.return_value = []
        with patch('app.main.ExportadorDatosAbiertos', return_value=exportador_mock):
            resultado = runner.invoke(main, ['probar', 'no_existe'])
        assert resultado.exit_code == 1
        assert 'Sin consultas para probar' in resultado.output
