"""
Tests del pipeline de transformaciones de negocio (da_dataframe).

Usa una sesion Spark LOCAL (local[2]) compartida por todo el modulo; el
catalogo de cantones se inyecta via ContextoProceso.lector_catalogos,
asi no se toca Oracle ni Spark Connect (misma tecnica de _prueba_local).

Cubre:
  - proceso_caso1 (paso intacto) y proceso_caso2 (Catastro Vehicular).
  - _aplicar_proteccion: factor 1.5 con redondeo HALF_UP de Spark.
  - _aplicar_mapa_persona: C/P -> NATURAL, R -> JURIDICA.
  - _aplicar_catalogo_canton: join LEFT con broadcast, codigo conservado
    si no hay descripcion, advertencia sin canton_sql, error si el
    catalogo tiene menos de 2 columnas.
  - _leer_catalogo: inyeccion de lector vs lectura JDBC.
  - ProcesadorDataFrame: pipeline proceso -> columnas -> orden, errores
    fail-fast de proceso/columna no encontrados.
"""

from decimal import Decimal
import logging
import os
import sys
from unittest.mock import MagicMock

from pyspark.sql import SparkSession
import pytest

from app.da_dataframe import _leer_catalogo, ContextoProceso, normalizar_decimales, proceso_caso1, proceso_caso2, ProcesadorDataFrame
from app.da_modelos import ConsultaDefinicion


@pytest.fixture(scope='module')
def spark():
    """
    Sesion Spark local compartida por los tests del modulo.

    Solo corre con PRUEBAS_SPARK=1 (levanta una JVM; en el CI se
    suspende). Los workers usan el mismo Python que pytest.
    """
    if os.environ.get('PRUEBAS_SPARK') != '1':
        pytest.skip('Prueba con Spark local suspendida (definir PRUEBAS_SPARK=1 para ejecutarla)')
    anterior = os.environ.get('PYSPARK_PYTHON')
    os.environ['PYSPARK_PYTHON'] = sys.executable
    sesion = SparkSession.builder.master('local[2]').appName('test_da_dataframe').getOrCreate()
    sesion.sparkContext.setLogLevel('ERROR')
    yield sesion
    sesion.stop()
    if anterior is None:
        os.environ.pop('PYSPARK_PYTHON', None)
    else:
        os.environ['PYSPARK_PYTHON'] = anterior


@pytest.fixture
def logger():
    """Logger real con NullHandler."""
    log = logging.getLogger('test_da_dataframe')
    log.setLevel(logging.DEBUG)
    handler = logging.NullHandler()
    log.addHandler(handler)
    yield log
    log.removeHandler(handler)


def _consulta(**override):
    """ConsultaDefinicion de prueba; override puntual por test."""
    datos = {'id': 'consulta_test'}
    datos.update(override)
    return ConsultaDefinicion.desde_dict(datos)


def _ctx(spark, logger, consulta, lector_catalogos=None):
    """
    ContextoProceso con jdbc_opts vacias (nunca se usan con lector).
    """
    return ContextoProceso(spark=spark, jdbc_opts={}, consulta=consulta, logger=logger, lector_catalogos=lector_catalogos)


@pytest.fixture
def df_caso2(spark):
    """
    DataFrame con los valores de la SDC
    Catastro Vehicular (y una fila R).
    """
    return spark.createDataFrame(
        [
            {'codigo_vehiculo': 7222346, 'codigo_sub_categoria': 676163, 'tipo_identificac_potenc_prop': 'C', 'codigo_canton': '11201'},
            {'codigo_vehiculo': 100, 'codigo_sub_categoria': 900000, 'tipo_identificac_potenc_prop': 'R', 'codigo_canton': '99999'},
        ]
    )


@pytest.fixture
def catalogo_falso(spark):
    """Catalogo ADM de cantones inyectado (sin Oracle)."""
    return spark.createDataFrame([('11201', 'GUAYAQUIL'), ('10901', 'QUITO')], ['CODIGO_CANTON', 'DESCRIPCION'])


class TestRegistroProcesos:
    """El dispatcher conoce los procesos declarados."""

    def test_proceso_caso1_registrado(self):
        """Proceso caso1 registrado."""
        assert ProcesadorDataFrame.PROCESOS['proceso_caso1'] is proceso_caso1

    def test_proceso_caso2_registrado(self):
        """Proceso caso2 registrado."""
        assert ProcesadorDataFrame.PROCESOS['proceso_caso2'] is proceso_caso2


class TestProcesoCaso1:
    """Caso 1 (historias 1-3): el DataFrame pasa sin cambios."""

    def test_retorna_el_mismo_dataframe(self, spark, logger, df_caso2):
        """Retorna el mismo dataframe."""
        ctx = _ctx(spark, logger, _consulta(proceso='proceso_caso1'))
        assert proceso_caso1(df_caso2, ctx) is df_caso2


class TestProteccion:
    """proceso_caso2: multiplicacion por 1.5 con redondeo de Spark."""

    def test_redondeo_half_up_no_bankers(self, spark, logger, df_caso2):
        """
        676163 x 1.5 = 1014244.5 -> 1014245 (round Spark, NO Python).
        """
        ctx = _ctx(spark, logger, _consulta())
        filas = {f['codigo_canton']: f for f in proceso_caso2(df_caso2, ctx).collect()}
        assert filas['11201']['codigo_sub_categoria'] == 1014245
        assert filas['11201']['codigo_vehiculo'] == 10833519

    def test_valores_enteros_resultantes(self, spark, logger, df_caso2):
        """El resultado se castea a long (sin decimales en el CSV)."""
        ctx = _ctx(spark, logger, _consulta())
        esquema = dict(proceso_caso2(df_caso2, ctx).dtypes)
        assert esquema['codigo_vehiculo'] == 'bigint'
        assert esquema['codigo_sub_categoria'] == 'bigint'

    def test_nulos_se_conservan(self, spark, logger):
        """Un codigo nulo queda nulo tras la proteccion."""
        df = spark.createDataFrame([(None, 10)], 'codigo_vehiculo BIGINT, codigo_sub_categoria BIGINT')
        ctx = _ctx(spark, logger, _consulta())
        fila = proceso_caso2(df, ctx).collect()[0]
        assert fila['codigo_vehiculo'] is None

    def test_columna_protegida_ausente_no_rompe(self, spark, logger):
        """
        Sin codigo_vehiculo solo se advierte; el df sigue adelante.
        """
        df = spark.createDataFrame([(5, 'C')], ['codigo_sub_categoria', 'tipo_identificac_potenc_prop'])
        ctx = _ctx(spark, logger, _consulta())
        fila = proceso_caso2(df, ctx).collect()[0]
        assert fila['codigo_sub_categoria'] == 8


class TestMapaPersona:
    """C/P -> NATURAL, R -> JURIDICA; lo demas se conserva."""

    def _mapear(self, spark, logger, valores):
        """Mapear."""
        df = spark.createDataFrame([(v,) for v in valores], ['tipo_identificac_potenc_prop'])
        ctx = _ctx(spark, logger, _consulta())
        return [f[0] for f in proceso_caso2(df, ctx).collect()]

    def test_c_y_p_son_natural(self, spark, logger):
        """C y p son natural."""
        assert self._mapear(spark, logger, ['C', 'P']) == ['NATURAL', 'NATURAL']

    def test_r_es_juridica(self, spark, logger):
        """R es juridica."""
        assert self._mapear(spark, logger, ['R']) == ['JURÍDICA']

    def test_minusculas_y_espacios_se_normalizan(self, spark, logger):
        """upper(trim(...)): ' c ' tambien mapea a NATURAL."""
        assert self._mapear(spark, logger, [' c ', 'r']) == ['NATURAL', 'JURÍDICA']

    def test_valor_desconocido_se_conserva(self, spark, logger):
        """Un codigo no mapeado NO se pierde: pasa tal cual."""
        assert self._mapear(spark, logger, ['X']) == ['X']

    def test_columna_ausente_omite_mapeo(self, spark, logger):
        """Sin la columna de persona, el df pasa sin tocar."""
        df = spark.createDataFrame([(1,)], ['codigo_sub_categoria'])
        ctx = _ctx(spark, logger, _consulta())
        resultado = proceso_caso2(df, ctx)
        assert 'tipo_identificac_potenc_prop' not in resultado.columns


class TestCatalogoCanton:
    """
    codigo_canton se reemplaza por la descripcion del catalogo ADM.
    """

    def test_canton_mapeado_por_catalogo(self, spark, logger, df_caso2, catalogo_falso):
        """Canton mapeado por catalogo."""
        consulta = _consulta(catalogos={'canton_sql': 'SELECT ... FROM ADM.ADM_CANTON'})
        ctx = _ctx(spark, logger, consulta, lector_catalogos=lambda _sql: catalogo_falso)
        filas = {f['codigo_vehiculo']: f for f in proceso_caso2(df_caso2, ctx).collect()}
        assert filas[10833519]['codigo_canton'] == 'GUAYAQUIL'

    def test_canton_sin_descripcion_conserva_codigo(self, spark, logger, df_caso2, catalogo_falso):
        """
        Join LEFT: 99999 no esta en el catalogo, se conserva el codigo.
        """
        consulta = _consulta(catalogos={'canton_sql': 'SELECT ...'})
        ctx = _ctx(spark, logger, consulta, lector_catalogos=lambda _sql: catalogo_falso)
        filas = {f['codigo_vehiculo']: f for f in proceso_caso2(df_caso2, ctx).collect()}
        assert filas[150]['codigo_canton'] == '99999'

    def test_columnas_auxiliares_no_quedan_en_resultado(self, spark, logger, df_caso2, catalogo_falso):
        """_cat_codigo/_cat_desc se eliminan tras el join."""
        consulta = _consulta(catalogos={'canton_sql': 'SELECT ...'})
        ctx = _ctx(spark, logger, consulta, lector_catalogos=lambda _sql: catalogo_falso)
        columnas = proceso_caso2(df_caso2, ctx).columns
        assert '_cat_codigo' not in columnas
        assert '_cat_desc' not in columnas

    def test_sin_canton_sql_conserva_codigo(self, spark, logger, df_caso2):
        """
        Sin catalogos.canton_sql en el JSON, el codigo pasa intacto.
        """
        ctx = _ctx(spark, logger, _consulta(catalogos={}))
        cantones = {f['codigo_canton'] for f in proceso_caso2(df_caso2, ctx).collect()}
        assert cantones == {'11201', '99999'}

    def test_sin_columna_canton_no_hace_nada(self, spark, logger, catalogo_falso):
        """Si el SQL no trae codigo_canton, se omite el catalogo."""
        df = spark.createDataFrame([(1, 'C')], ['codigo_sub_categoria', 'tipo_identificac_potenc_prop'])
        consulta = _consulta(catalogos={'canton_sql': 'SELECT ...'})
        ctx = _ctx(spark, logger, consulta, lector_catalogos=lambda _sql: catalogo_falso)
        assert proceso_caso2(df, ctx).columns == df.columns

    def test_catalogo_de_una_columna_lanza_valueerror(self, spark, logger, df_caso2):
        """Catalogo invalido (< 2 columnas) aborta con ValueError."""
        catalogo_invalido = spark.createDataFrame([('11201',)], ['CODIGO_CANTON'])
        consulta = _consulta(catalogos={'canton_sql': 'SELECT ...'})
        ctx = _ctx(spark, logger, consulta, lector_catalogos=lambda _sql: catalogo_invalido)
        with pytest.raises(ValueError, match='Catalogo de cantones invalido'):
            proceso_caso2(df_caso2, ctx)


class TestLeerCatalogo:
    """Lectura de catalogos: inyeccion para tests vs JDBC real."""

    def test_usa_lector_inyectado(self, spark, logger, catalogo_falso):
        """Usa lector inyectado."""
        ctx = _ctx(spark, logger, _consulta(), lector_catalogos=lambda _sql: catalogo_falso)
        assert _leer_catalogo(ctx, 'SELECT 1') is catalogo_falso

    def test_lector_recibe_el_sql(self, spark, logger, catalogo_falso):
        """Lector recibe el sql."""
        recibidos = []
        ctx = _ctx(spark, logger, _consulta(), lector_catalogos=lambda sql: recibidos.append(sql) or catalogo_falso)
        _leer_catalogo(ctx, 'SELECT CODIGO FROM ADM')
        assert recibidos == ['SELECT CODIGO FROM ADM']

    def test_sin_lector_lee_via_jdbc(self, logger):
        """Sin lector_catalogos, se usa spark.read.format('jdbc')."""
        spark_mock = MagicMock()
        ctx = ContextoProceso(
            spark=spark_mock, jdbc_opts={'url': 'jdbc:oracle:thin:@X', 'driver': 'oracle.jdbc.OracleDriver'}, consulta=_consulta(), logger=logger
        )
        _leer_catalogo(ctx, 'SELECT 1 FROM DUAL')
        spark_mock.read.format.assert_called_once_with('jdbc')
        lector = spark_mock.read.format.return_value
        lector.options.assert_called_once_with(url='jdbc:oracle:thin:@X', driver='oracle.jdbc.OracleDriver')
        lector.options.return_value.option.assert_called_once_with('query', 'SELECT 1 FROM DUAL')


class TestDispatcher:
    """ProcesadorDataFrame.aplicar: composicion y errores fail-fast."""

    def test_sin_declaraciones_pasa_intacto(self, spark, logger, df_caso2):
        """
        JSON historico (sin proceso/columnas/orden): el df NO cambia.
        """
        procesador = ProcesadorDataFrame(logger)
        ctx = _ctx(spark, logger, _consulta())
        resultado = procesador.aplicar(df_caso2, ctx)
        assert resultado.columns == df_caso2.columns
        assert resultado.count() == df_caso2.count()

    def test_proceso_no_registrado_lanza_valueerror(self, spark, logger, df_caso2):
        """Proceso no registrado lanza valueerror."""
        procesador = ProcesadorDataFrame(logger)
        ctx = _ctx(spark, logger, _consulta(proceso='proceso_inexistente'))
        with pytest.raises(ValueError, match='no registrado'):
            procesador.aplicar(df_caso2, ctx)

    def test_proceso_con_espacios_se_normaliza(self, spark, logger, df_caso2):
        """'  proceso_caso1  ' (strip) se resuelve igual."""
        procesador = ProcesadorDataFrame(logger)
        ctx = _ctx(spark, logger, _consulta(proceso='  proceso_caso1  '))
        assert procesador.aplicar(df_caso2, ctx).count() == 2

    def test_columnas_renombran_reordenan_y_descartan(self, spark, logger, df_caso2):
        """
        Solo quedan las listadas, con nombre final y en orden del mapa.
        """
        procesador = ProcesadorDataFrame(logger)
        ctx = _ctx(spark, logger, _consulta(columnas={'codigo_sub_categoria': 'CATEGORIA', 'codigo_vehiculo': 'CODIGO_VEHICULO'}))
        resultado = procesador.aplicar(df_caso2, ctx)
        assert resultado.columns == ['CATEGORIA', 'CODIGO_VEHICULO']

    def test_columna_origen_faltante_lanza_valueerror(self, spark, logger, df_caso2):
        """Columna origen faltante lanza valueerror."""
        procesador = ProcesadorDataFrame(logger)
        ctx = _ctx(spark, logger, _consulta(columnas={'no_existe': 'X'}))
        with pytest.raises(ValueError, match='Columnas no encontradas'):
            procesador.aplicar(df_caso2, ctx)

    def test_orden_descendente(self, spark, logger):
        """Orden descendente."""
        df = spark.createDataFrame([(1,), (3,), (2,)], ['N'])
        procesador = ProcesadorDataFrame(logger)
        ctx = _ctx(spark, logger, _consulta(orden=[{'columna': 'N', 'ascendente': False}]))
        assert [f[0] for f in procesador.aplicar(df, ctx).collect()] == [3, 2, 1]

    def test_orden_ascendente_por_defecto(self, spark, logger):
        """Sin 'ascendente' en el item, se ordena ascendente."""
        df = spark.createDataFrame([(3,), (1,), (2,)], ['N'])
        procesador = ProcesadorDataFrame(logger)
        ctx = _ctx(spark, logger, _consulta(orden=[{'columna': 'N'}]))
        assert [f[0] for f in procesador.aplicar(df, ctx).collect()] == [1, 2, 3]

    def test_orden_columna_inexistente_lanza_valueerror(self, spark, logger, df_caso2):
        """Orden columna inexistente lanza valueerror."""
        procesador = ProcesadorDataFrame(logger)
        ctx = _ctx(spark, logger, _consulta(orden=[{'columna': 'NO_ESTA', 'ascendente': True}]))
        with pytest.raises(ValueError, match='Columna de ordenamiento no existe'):
            procesador.aplicar(df_caso2, ctx)

    def test_orden_ve_los_nombres_finales(self, spark, logger, df_caso2):
        """
        El orden se aplica DESPUES del
        renombre (CATEGORIA, no el origen).
        """
        procesador = ProcesadorDataFrame(logger)
        ctx = _ctx(spark, logger, _consulta(columnas={'codigo_sub_categoria': 'CATEGORIA'}, orden=[{'columna': 'CATEGORIA', 'ascendente': False}]))
        resultado = procesador.aplicar(df_caso2, ctx)
        assert [f[0] for f in resultado.collect()] == [900000, 676163]

    def test_pipeline_completo_caso2(self, spark, logger, df_caso2, catalogo_falso):
        """
        proceso -> columnas -> orden, como
        facturacion_sql_historia5.json.
        """
        procesador = ProcesadorDataFrame(logger)
        consulta = _consulta(
            proceso='proceso_caso2',
            catalogos={'canton_sql': 'SELECT CODIGO_CANTON, DESCRIPCION FROM ADM.ADM_CANTON'},
            columnas={
                'codigo_sub_categoria': 'CATEGORIA',
                'codigo_vehiculo': 'CODIGO_VEHICULO',
                'tipo_identificac_potenc_prop': 'PERSONA_NATURAL_JURIDICA',
                'codigo_canton': 'CANTON',
            },
            orden=[{'columna': 'CATEGORIA', 'ascendente': False}],
        )
        ctx = _ctx(spark, logger, consulta, lector_catalogos=lambda _sql: catalogo_falso)
        filas = procesador.aplicar(df_caso2, ctx).collect()

        assert len(filas) == 2
        primera, segunda = filas
        assert primera['CATEGORIA'] == 1350000
        assert segunda['CATEGORIA'] == 1014245
        assert segunda['CODIGO_VEHICULO'] == 10833519
        assert primera['CODIGO_VEHICULO'] == 150
        assert segunda['PERSONA_NATURAL_JURIDICA'] == 'NATURAL'
        assert primera['PERSONA_NATURAL_JURIDICA'] == 'JURÍDICA'
        assert segunda['CANTON'] == 'GUAYAQUIL'
        assert primera['CANTON'] == '99999'


class TestNormalizarDecimales:
    """NUMBER de Oracle sin ceros decimales sobrantes en el CSV."""

    def test_quita_ceros_y_respeta_texto(self, spark, logger):
        """Quita ceros y respeta texto."""
        df = spark.createDataFrame(
            [(Decimal('2026.0000000000'), Decimal('12.5000000000'), '998.34')],
            'ANIO DECIMAL(38,10), MONTO DECIMAL(38,10), AVALUO STRING',
        )
        fila = normalizar_decimales(df, logger).collect()[0]
        assert (fila['ANIO'], fila['MONTO'], fila['AVALUO']) == ('2026', '12.5', '998.34')

    def test_sin_decimales_pasa_igual(self, spark, logger):
        """Sin decimales pasa igual."""
        df = spark.createDataFrame([(1, 'x')], ['N', 'T'])
        assert normalizar_decimales(df, logger) is df
