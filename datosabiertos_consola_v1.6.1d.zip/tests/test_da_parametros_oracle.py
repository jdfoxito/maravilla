"""
Tests de ParametrosOracle (da_parametros_oracle).

Sesion Spark y su lectura JDBC simuladas. Cubre lectura de un
parametro (JSON), parametro inexistente, JSON malformado, expansion
de variables, una sola lectura a Oracle y resolver_password.
"""

import importlib
import logging
import sys
from unittest.mock import MagicMock

import pytest

import app.da_parametros_oracle as modulo
from app.da_parametros_oracle import ParametrosOracle


def _spark_con_valor(valor_texto, hay_fila=True):
    """
    Mock de SparkSession cuya lectura JDBC filtrada devuelve una fila
    {'VALOR_TEXTO': valor_texto}, o ninguna si hay_fila es False.
    """
    spark = MagicMock()
    lector = MagicMock()
    lector.options.return_value = lector
    lector.option.return_value = lector
    filtrado = lector.load.return_value.filter.return_value.select.return_value
    filtrado.limit.return_value.collect.return_value = [{'VALOR_TEXTO': valor_texto}] if hay_fila else []
    spark.read.format.return_value = lector
    return spark


@pytest.fixture(autouse=True)
def _funciones_spark_simuladas(monkeypatch):
    """
    Simula pyspark.sql.functions: fn.col exige una sesion Spark real.
    """
    monkeypatch.setattr('app.da_parametros_oracle.fn', MagicMock())


@pytest.fixture
def mock_logger():
    """Logger real con NullHandler para tests de ParametrosOracle."""
    logger = logging.getLogger('test_parametros_oracle')
    logger.setLevel(logging.DEBUG)
    handler = logging.NullHandler()
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)
    yield logger
    logger.removeHandler(handler)


@pytest.fixture
def ruta_wallet():
    """Ruta de wallet ficticia (no se accede a disco)."""
    return '/opt/oracle/wallet'


class TestObtenerParametro:
    """obtener_parametro: parseo JSON y casos de error."""

    def test_parametro_devuelve_json_parseado(self, ruta_wallet, mock_logger):
        """Un VALOR_TEXTO JSON valido se devuelve como dict."""
        spark = _spark_con_valor('{"smtp_server": "mail.sri.ad"}')
        params = ParametrosOracle(spark, 'jdbc:oracle:thin:/@X', ruta_wallet, mock_logger)
        resultado = params.obtener_parametro('DAT', 'EMAIL')
        assert resultado == {'smtp_server': 'mail.sri.ad'}

    def test_parametro_inexistente_devuelve_none(self, ruta_wallet, mock_logger):
        """Sin filas -> None."""
        spark = _spark_con_valor('{}', hay_fila=False)
        params = ParametrosOracle(spark, 'jdbc:oracle:thin:/@X', ruta_wallet, mock_logger)
        assert params.obtener_parametro('DAT', 'NADA') is None

    def test_json_malformado_propaga_value_error(self, ruta_wallet, mock_logger):
        """Un VALOR_TEXTO no-JSON levanta ValueError (propagado)."""
        spark = _spark_con_valor('esto no es json {')
        params = ParametrosOracle(spark, 'jdbc:oracle:thin:/@X', ruta_wallet, mock_logger)
        with pytest.raises(ValueError):
            params.obtener_parametro('DAT', 'EMAIL')

    def test_expande_variable_de_entorno(self, ruta_wallet, mock_logger, monkeypatch):
        """$VAR en el VALOR_TEXTO se expande antes de json.loads."""
        monkeypatch.setenv('SMTP_HOST', 'mail.local')
        spark = _spark_con_valor('{"host": "$SMTP_HOST"}')
        params = ParametrosOracle(spark, 'jdbc:oracle:thin:/@X', ruta_wallet, mock_logger)
        assert params.obtener_parametro('DAT', 'EMAIL') == {'host': 'mail.local'}


class TestObtenerTodosParametros:
    """obtener_todos_parametros: validacion de obligatorios."""

    def test_falta_spark_levanta_value_error(self, ruta_wallet, mock_logger):
        """Sin config SPARK debe levantar ValueError."""
        spark = _spark_con_valor('null', hay_fila=False)
        params = ParametrosOracle(spark, 'jdbc:oracle:thin:/@X', ruta_wallet, mock_logger)
        with pytest.raises(ValueError, match='SPARK'):
            params.obtener_todos_parametros()


class TestResolverPassword:
    """resolver_password: texto plano y referencias $VAR."""

    def test_texto_plano(self, ruta_wallet, mock_logger):
        """Texto plano se devuelve tal cual."""
        params = ParametrosOracle(MagicMock(), 'jdbc', ruta_wallet, mock_logger)
        assert params.resolver_password('clave123') == 'clave123'

    def test_referencia_var_existente(self, ruta_wallet, mock_logger, monkeypatch):
        """$VAR existente devuelve su valor."""
        monkeypatch.setenv('PWD_DB', 'secreto')
        params = ParametrosOracle(MagicMock(), 'jdbc', ruta_wallet, mock_logger)
        assert params.resolver_password('$PWD_DB') == 'secreto'

    def test_referencia_var_inexistente_devuelve_vacio(self, ruta_wallet, mock_logger):
        """$VAR inexistente devuelve cadena vacia."""
        params = ParametrosOracle(MagicMock(), 'jdbc', ruta_wallet, mock_logger)
        assert params.resolver_password('$NO_EXISTE_XYZ') == ''

    def test_referencia_vacia(self, ruta_wallet, mock_logger):
        """Referencia vacia devuelve cadena vacia."""
        params = ParametrosOracle(MagicMock(), 'jdbc', ruta_wallet, mock_logger)
        assert params.resolver_password('') == ''


class TestUnaSolaLectura:
    """Un parametro se lee con una sola consulta a Oracle."""

    def test_sin_count_y_con_limit(self, ruta_wallet, mock_logger):
        """Sin count y con limit."""
        spark = _spark_con_valor('{"a": 1}')
        ParametrosOracle(spark, 'jdbc:oracle:thin:/@X', ruta_wallet, mock_logger).obtener_parametro('DAT', 'EMAIL')
        filtrado = spark.read.format.return_value.load.return_value.filter.return_value.select.return_value
        filtrado.count.assert_not_called()
        filtrado.limit.assert_called_once_with(1)


class TestErroresYObligatorios:
    """Errores de lectura y parametros obligatorios."""

    @pytest.mark.parametrize('error', [RuntimeError('spark'), OSError('red'), KeyError('VALOR_TEXTO')])
    def test_error_de_lectura_se_propaga(self, ruta_wallet, mock_logger, error):
        """Errores de Spark o de la fila se registran y se propagan."""
        spark = MagicMock()
        spark.read.format.side_effect = error
        with pytest.raises(type(error)):
            ParametrosOracle(spark, 'jdbc', ruta_wallet, mock_logger).obtener_parametro('DAT', 'EMAIL')

    def test_sin_queries_levanta(self, ruta_wallet, mock_logger, monkeypatch):
        """Con SPARK pero sin QUERIES, ValueError."""
        params = ParametrosOracle(MagicMock(), 'jdbc', ruta_wallet, mock_logger)
        monkeypatch.setattr(params, 'obtener_parametro', lambda app, nombre, amb: None if nombre.endswith('QUERIES') else {'x': 1})
        with pytest.raises(ValueError, match='QUERIES'):
            params.obtener_todos_parametros()

    def test_todos_los_parametros(self, ruta_wallet, mock_logger, monkeypatch):
        """Con todos los obligatorios devuelve las seis secciones."""
        params = ParametrosOracle(MagicMock(), 'jdbc', ruta_wallet, mock_logger)
        monkeypatch.setattr(params, 'obtener_parametro', lambda app, nombre, amb: {'nombre': nombre})
        config = params.obtener_todos_parametros('DAT', 'DEV')
        assert sorted(config) == ['email', 'paths', 'queries', 'sftp', 'smb', 'spark']
        assert config['spark'] == {'nombre': 'DATOS_ABIERTOS_SPARK_CONFIG'}

    def test_import_sin_pyspark(self, monkeypatch):
        """El modulo carga aunque pyspark no este instalado."""
        monkeypatch.setitem(sys.modules, 'pyspark.sql', None)
        try:
            importlib.reload(modulo)
            assert modulo.fn is None and modulo.SparkSession is None
        finally:
            monkeypatch.delitem(sys.modules, 'pyspark.sql')
            importlib.reload(modulo)
