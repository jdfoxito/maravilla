"""
Tests de los grupos de excepciones (da_excepciones).

Logica pura, sin mocks: pertenencia con isinstance(), criticos vs
no criticos, alias en ingles, obtener_categoria() y captura real en
la clausula except.
"""

from lxml.etree import DocumentInvalid

import pytest
from sqlalchemy.exc import SQLAlchemyError

from app.da_excepciones import TrazabilidadExcepciones as T


class TestPertenencia:
    """Cada excepcion pertenece a su grupo segun isinstance()."""

    def test_value_error_es_errores_validacion(self):
        """
        isinstance(ValueError(), T.ERRORES_VALIDACION) debe ser True.
        """
        assert isinstance(ValueError('x'), T.ERRORES_VALIDACION) is True

    def test_type_error_es_errores_tipo(self):
        """TypeError pertenece a T.ERRORES_TIPO."""
        assert isinstance(TypeError('x'), T.ERRORES_TIPO) is True

    def test_sqlalchemy_error_es_errores_bd(self):
        """SQLAlchemyError pertenece a T.ERRORES_BD."""
        assert isinstance(SQLAlchemyError('x'), T.ERRORES_BD) is True

    def test_oserror_es_errores_sistema(self):
        """OSError pertenece a T.ERRORES_SISTEMA."""
        assert isinstance(OSError('x'), T.ERRORES_SISTEMA) is True

    def test_ioerror_es_errores_sistema(self):
        """
        IOError pertenece a T.ERRORES_SISTEMA (alias de OSError en Py3).
        """
        assert isinstance(IOError('x'), T.ERRORES_SISTEMA) is True

    def test_filenotfounderror_es_errores_sistema(self):
        """FileNotFoundError pertenece a T.ERRORES_SISTEMA."""
        assert isinstance(FileNotFoundError('x'), T.ERRORES_SISTEMA) is True

    def test_permissionerror_es_errores_sistema(self):
        """PermissionError pertenece a T.ERRORES_SISTEMA."""
        assert isinstance(PermissionError('x'), T.ERRORES_SISTEMA) is True

    def test_runtimeerror_es_errores_sistema(self):
        """RuntimeError pertenece a T.ERRORES_SISTEMA."""
        assert isinstance(RuntimeError('x'), T.ERRORES_SISTEMA) is True

    def test_documentinvalid_es_errores_xml(self):
        """DocumentInvalid pertenece a T.ERRORES_XML."""
        assert isinstance(DocumentInvalid('x'), T.ERRORES_XML) is True

    def test_connection_error_es_errores_red(self):
        """ConnectionError pertenece a T.ERRORES_RED."""
        assert isinstance(ConnectionError('x'), T.ERRORES_RED) is True

    def test_timeout_error_es_errores_red(self):
        """TimeoutError pertenece a T.ERRORES_RED."""
        assert isinstance(TimeoutError('x'), T.ERRORES_RED) is True

    def test_runtime_error_es_errores_pool(self):
        """RuntimeError pertenece a T.ERRORES_POOL."""
        assert isinstance(RuntimeError('x'), T.ERRORES_POOL) is True

    def test_attribute_error_es_errores_pool(self):
        """AttributeError pertenece a T.ERRORES_POOL."""
        assert isinstance(AttributeError('x'), T.ERRORES_POOL) is True

    def test_key_error_es_errores_validacion(self):
        """KeyError pertenece a T.ERRORES_VALIDACION."""
        assert isinstance(KeyError('x'), T.ERRORES_VALIDACION) is True

    def test_index_error_es_errores_validacion(self):
        """IndexError pertenece a T.ERRORES_VALIDACION."""
        assert isinstance(IndexError('x'), T.ERRORES_VALIDACION) is True

    def test_excepcion_ajena_no_pertenece(self):
        """Una excepcion no relacionada NO pertenece al grupo."""
        assert isinstance(ZeroDivisionError('x'), T.ERRORES_BD) is False

    def test_grupos_son_tuplas(self):
        """
        Los grupos son tuplas planas (validas en isinstance y except).
        """
        assert isinstance(T.ERRORES_BD, tuple)
        assert isinstance(T.ERRORES_SISTEMA, tuple)
        assert SQLAlchemyError in T.ERRORES_BD


class TestIsinstanceNegativos:
    """Verifica que excepciones NO pertenezcan a grupos ajenos."""

    def test_value_error_no_es_bd(self):
        """ValueError NO es T.ERRORES_BD."""
        assert isinstance(ValueError('x'), T.ERRORES_BD) is False

    def test_value_error_no_es_sistema(self):
        """ValueError NO es T.ERRORES_SISTEMA."""
        assert isinstance(ValueError('x'), T.ERRORES_SISTEMA) is False

    def test_value_error_no_es_xml(self):
        """ValueError NO es T.ERRORES_XML."""
        assert isinstance(ValueError('x'), T.ERRORES_XML) is False

    def test_value_error_no_es_critico(self):
        """ValueError NO es T.ERRORES_CRITICOS."""
        assert isinstance(ValueError('x'), T.ERRORES_CRITICOS) is False

    def test_oserror_no_es_bd(self):
        """OSError NO es T.ERRORES_BD."""
        assert isinstance(OSError('x'), T.ERRORES_BD) is False

    def test_sqlalchemy_no_es_sistema(self):
        """SQLAlchemyError NO es T.ERRORES_SISTEMA."""
        assert isinstance(SQLAlchemyError('x'), T.ERRORES_SISTEMA) is False

    def test_memory_error_no_es_sistema(self):
        """MemoryError NO es T.ERRORES_SISTEMA."""
        assert isinstance(MemoryError(), T.ERRORES_SISTEMA) is False

    def test_runtime_error_no_es_bd(self):
        """RuntimeError NO es T.ERRORES_BD."""
        assert isinstance(RuntimeError('x'), T.ERRORES_BD) is False

    def test_key_error_no_es_tipo(self):
        """KeyError NO es T.ERRORES_TIPO."""
        assert isinstance(KeyError('x'), T.ERRORES_TIPO) is False

    def test_connection_error_no_es_xml(self):
        """ConnectionError NO es T.ERRORES_XML."""
        assert isinstance(ConnectionError('x'), T.ERRORES_XML) is False


class TestCriticosVsNoCriticos:
    """Los criticos NO deben caer en ALL_NON_CRITICAL."""

    @pytest.mark.parametrize('exc_cls', [SystemExit, KeyboardInterrupt, MemoryError])
    def test_criticos_son_errores_criticos(self, exc_cls):
        """
        SystemExit/KeyboardInterrupt/MemoryError son T.ERRORES_CRITICOS.
        """
        assert isinstance(exc_cls(), T.ERRORES_CRITICOS) is True

    @pytest.mark.parametrize('exc_cls', [SystemExit, KeyboardInterrupt, MemoryError])
    def test_criticos_no_estan_en_all_non_critical(self, exc_cls):
        """
        Los criticos NO pertenecen a ningun grupo de ALL_NON_CRITICAL.
        """
        assert not isinstance(exc_cls(), T.ALL_NON_CRITICAL)

    def test_value_error_si_esta_en_all_non_critical(self):
        """Un no-critico (ValueError) SI cae en ALL_NON_CRITICAL."""
        assert isinstance(ValueError('x'), T.ALL_NON_CRITICAL)

    def test_todos_no_criticos_equivale_a_all_non_critical(self):
        """El alias en ingles y en espanol apuntan al mismo conjunto."""
        assert T.ALL_NON_CRITICAL == T.TODOS_NO_CRITICOS

    def test_errores_bd_sistema_es_tupla(self):
        """
        ERRORES_BD_SISTEMA es una tupla plana que incluye BD y sistema.
        """
        assert isinstance(T.ERRORES_BD_SISTEMA, tuple)
        assert SQLAlchemyError in T.ERRORES_BD_SISTEMA
        assert OSError in T.ERRORES_BD_SISTEMA

    def test_db_system_errors_es_mismo_que_errores_bd_sistema(self):
        """DB_SYSTEM_ERRORS es alias de ERRORES_BD_SISTEMA."""
        assert T.DB_SYSTEM_ERRORS == T.ERRORES_BD_SISTEMA

    def test_isinstance_en_tupla_bd_sistema(self):
        """SQLAlchemyError cae en la tupla ERRORES_BD_SISTEMA."""
        assert isinstance(SQLAlchemyError('x'), T.ERRORES_BD_SISTEMA)

    def test_isinstance_en_tupla_bd_sistema_oserror(self):
        """OSError cae en la tupla ERRORES_BD_SISTEMA."""
        assert isinstance(OSError('x'), T.ERRORES_BD_SISTEMA)


class TestPredicados:
    """Predicados estaticos es_error_*."""

    def test_es_error_bd_true(self):
        """es_error_bd True para SQLAlchemyError."""
        assert T.es_error_bd(SQLAlchemyError('x')) is True

    def test_es_error_bd_false(self):
        """es_error_bd False para un ValueError."""
        assert T.es_error_bd(ValueError('x')) is False

    def test_es_error_sistema_true(self):
        """es_error_sistema True para OSError."""
        assert T.es_error_sistema(OSError('x')) is True

    def test_es_error_sistema_true_filenotfound(self):
        """es_error_sistema True para FileNotFoundError."""
        assert T.es_error_sistema(FileNotFoundError('x')) is True

    def test_es_error_sistema_true_permission(self):
        """es_error_sistema True para PermissionError."""
        assert T.es_error_sistema(PermissionError('x')) is True

    def test_es_error_xml_true_documentinvalid(self):
        """es_error_xml True para DocumentInvalid."""
        assert T.es_error_xml(DocumentInvalid('x')) is True

    def test_es_error_pool_true(self):
        """es_error_pool True para RuntimeError."""
        assert T.es_error_pool(RuntimeError('x')) is True

    def test_es_error_pool_true_attribute(self):
        """es_error_pool True para AttributeError."""
        assert T.es_error_pool(AttributeError('x')) is True

    def test_es_error_pool_false(self):
        """es_error_pool False para ValueError."""
        assert T.es_error_pool(ValueError('x')) is False

    def test_es_error_critico_true(self):
        """es_error_critico True para MemoryError."""
        assert T.es_error_critico(MemoryError()) is True

    def test_es_error_critico_true_systemexit(self):
        """es_error_critico True para SystemExit."""
        assert T.es_error_critico(SystemExit(1)) is True

    def test_es_error_critico_true_keyboard(self):
        """es_error_critico True para KeyboardInterrupt."""
        assert T.es_error_critico(KeyboardInterrupt()) is True

    def test_es_error_critico_false(self):
        """es_error_critico False para un no-critico."""
        assert T.es_error_critico(ValueError('x')) is False


class TestAliasCompatibilidad:
    """
    Verifica que los alias en ingles apunten a los grupos correctos.
    """

    def test_db_errors_es_errores_bd(self):
        """Db errors es errores bd."""
        assert T.DB_ERRORS is T.ERRORES_BD

    def test_system_errors_es_errores_sistema(self):
        """System errors es errores sistema."""
        assert T.SYSTEM_ERRORS is T.ERRORES_SISTEMA

    def test_xml_errors_es_errores_xml(self):
        """Xml errors es errores xml."""
        assert T.XML_ERRORS is T.ERRORES_XML

    def test_type_errors_es_errores_tipo(self):
        """Type errors es errores tipo."""
        assert T.TYPE_ERRORS is T.ERRORES_TIPO

    def test_network_errors_es_errores_red(self):
        """Network errors es errores red."""
        assert T.NETWORK_ERRORS is T.ERRORES_RED

    def test_pool_errors_es_errores_pool(self):
        """Pool errors es errores pool."""
        assert T.POOL_ERRORS is T.ERRORES_POOL

    def test_validation_errors_es_errores_validacion(self):
        """Validation errors es errores validacion."""
        assert T.VALIDATION_ERRORS is T.ERRORES_VALIDACION

    def test_critical_errors_es_errores_criticos(self):
        """Critical errors es errores criticos."""
        assert T.CRITICAL_ERRORS is T.ERRORES_CRITICOS


class TestObtenerCategoria:
    """obtener_categoria() clasifica con prioridad critico primero."""

    def test_categoria_critico(self):
        """MemoryError -> CRITICO."""
        assert T.obtener_categoria(MemoryError()) == 'CRITICO'

    def test_categoria_critico_systemexit(self):
        """SystemExit -> CRITICO."""
        assert T.obtener_categoria(SystemExit(1)) == 'CRITICO'

    def test_categoria_critico_keyboard(self):
        """KeyboardInterrupt -> CRITICO."""
        assert T.obtener_categoria(KeyboardInterrupt()) == 'CRITICO'

    def test_categoria_base_datos(self):
        """SQLAlchemyError -> BASE_DATOS."""
        assert T.obtener_categoria(SQLAlchemyError('x')) == 'BASE_DATOS'

    def test_categoria_sistema(self):
        """OSError -> SISTEMA."""
        assert T.obtener_categoria(OSError('x')) == 'SISTEMA'

    def test_categoria_sistema_filenotfound(self):
        """FileNotFoundError -> SISTEMA."""
        assert T.obtener_categoria(FileNotFoundError('x')) == 'SISTEMA'

    def test_categoria_sistema_permission(self):
        """PermissionError -> SISTEMA."""
        assert T.obtener_categoria(PermissionError('x')) == 'SISTEMA'

    def test_categoria_sistema_ioerror(self):
        """IOError -> SISTEMA."""
        assert T.obtener_categoria(IOError('x')) == 'SISTEMA'

    def test_categoria_xml_documentinvalid(self):
        """DocumentInvalid -> XML."""
        assert T.obtener_categoria(DocumentInvalid('x')) == 'XML'

    def test_categoria_runtime_error_es_sistema(self):
        """
        RuntimeError -> SISTEMA.

        Aunque RuntimeError tambien pertenece a T.ERRORES_POOL,
        obtener_categoria evalua SISTEMA antes que
        POOL_CONEXION, y T.ERRORES_SISTEMA incluye RuntimeError.
        El orden de evaluacion decide la etiqueta.
        """
        assert T.obtener_categoria(RuntimeError('x')) == 'SISTEMA'

    def test_categoria_pool_solo_attribute_error(self):
        """
        AttributeError -> POOL_CONEXION.

        AttributeError NO esta en T.ERRORES_SISTEMA
        pero SI en T.ERRORES_POOL, por lo que es el
        camino real hacia la etiqueta POOL_CONEXION.
        """
        assert T.obtener_categoria(AttributeError('x')) == 'POOL_CONEXION'

    def test_categoria_otro_no_critico_valueerror(self):
        """ValueError puro -> OTRO_NO_CRITICO."""
        assert T.obtener_categoria(ValueError('x')) == 'OTRO_NO_CRITICO'

    def test_categoria_otro_no_critico_keyerror(self):
        """
        KeyError -> OTRO_NO_CRITICO (no
        esta en las categorias evaluadas).
        """
        assert T.obtener_categoria(KeyError('x')) == 'OTRO_NO_CRITICO'

    def test_categoria_otro_no_critico_indexerror(self):
        """IndexError -> OTRO_NO_CRITICO."""
        assert T.obtener_categoria(IndexError('x')) == 'OTRO_NO_CRITICO'

    def test_categoria_otro_no_critico_typeerror(self):
        """TypeError -> OTRO_NO_CRITICO."""
        assert T.obtener_categoria(TypeError('x')) == 'OTRO_NO_CRITICO'

    def test_categoria_connectionerror_es_sistema(self):
        """
        ConnectionError -> OTRO_NO_CRITICO (red no esta en categorias).
        """
        assert T.obtener_categoria(ConnectionError('x')) == 'SISTEMA'

    def test_categoria_timeouterror_es_sistema(self):
        """TimeoutError -> SISTEMA (hereda de OSError)."""
        assert T.obtener_categoria(TimeoutError('x')) == 'SISTEMA'

    def test_categoria_zero_division(self):
        """ZeroDivisionError -> OTRO_NO_CRITICO."""
        assert T.obtener_categoria(ZeroDivisionError('x')) == 'OTRO_NO_CRITICO'


class TestGruposCompuestos:
    """Verifica el comportamiento de isinstance con tuplas de grupos."""

    def test_all_non_critical_atrapa_valueerror(self):
        """ValueError cae en ALL_NON_CRITICAL."""
        assert isinstance(ValueError('x'), T.ALL_NON_CRITICAL)

    def test_all_non_critical_atrapa_oserror(self):
        """OSError cae en ALL_NON_CRITICAL."""
        assert isinstance(OSError('x'), T.ALL_NON_CRITICAL)

    def test_all_non_critical_atrapa_sqlalchemy(self):
        """SQLAlchemyError cae en ALL_NON_CRITICAL."""
        assert isinstance(SQLAlchemyError('x'), T.ALL_NON_CRITICAL)

    def test_all_non_critical_atrapa_xml(self):
        """DocumentInvalid cae en ALL_NON_CRITICAL."""
        assert isinstance(DocumentInvalid('x'), T.ALL_NON_CRITICAL)

    def test_all_non_critical_no_atrapa_critico(self):
        """MemoryError NO cae en ALL_NON_CRITICAL."""
        assert not isinstance(MemoryError(), T.ALL_NON_CRITICAL)

    def test_all_non_critical_atrapa_red(self):
        """ConnectionError cae en ALL_NON_CRITICAL."""
        assert isinstance(ConnectionError('x'), T.ALL_NON_CRITICAL)

    def test_all_non_critical_atrapa_pool(self):
        """RuntimeError cae en ALL_NON_CRITICAL."""
        assert isinstance(RuntimeError('x'), T.ALL_NON_CRITICAL)

    def test_all_non_critical_atrapa_validacion(self):
        """KeyError cae en ALL_NON_CRITICAL."""
        assert isinstance(KeyError('x'), T.ALL_NON_CRITICAL)


class TestExceptCaptura:
    """
    Verifica que 'except GRUPO' capture de verdad.

    Con la antigua metaclase except no capturaba y el correo de error
    nunca salia; con tuplas planas si captura.
    """

    def _captura(self, exc, grupo):
        """
        Retorna True si 'except grupo' captura exc; False si se escapa.
        """
        capturada = False
        try:
            try:
                raise exc
            except grupo:
                capturada = True
        except type(exc):
            capturada = False
        return capturada

    def test_except_all_non_critical_captura_oserror(self):
        """except ALL_NON_CRITICAL captura FileNotFoundError."""
        assert self._captura(FileNotFoundError('x'), T.ALL_NON_CRITICAL) is True

    def test_except_all_non_critical_captura_valueerror(self):
        """except ALL_NON_CRITICAL captura ValueError."""
        assert self._captura(ValueError('x'), T.ALL_NON_CRITICAL) is True

    def test_except_all_non_critical_captura_sqlalchemy(self):
        """except ALL_NON_CRITICAL captura SQLAlchemyError."""
        assert self._captura(SQLAlchemyError('x'), T.ALL_NON_CRITICAL) is True

    def test_except_errores_sistema_captura_oserror(self):
        """except ERRORES_SISTEMA captura OSError."""
        assert self._captura(OSError('x'), T.ERRORES_SISTEMA) is True

    def test_except_errores_bd_captura_sqlalchemy(self):
        """except ERRORES_BD captura SQLAlchemyError."""
        assert self._captura(SQLAlchemyError('x'), T.ERRORES_BD) is True

    def test_except_all_non_critical_no_captura_critico(self):
        """
        except ALL_NON_CRITICAL NO captura MemoryError (se escapa).
        """
        assert self._captura(MemoryError(), T.ALL_NON_CRITICAL) is False

    def test_except_bd_sistema_captura_ambos(self):
        """except ERRORES_BD_SISTEMA captura tanto BD como sistema."""
        assert self._captura(SQLAlchemyError('x'), T.ERRORES_BD_SISTEMA) is True
        assert self._captura(OSError('x'), T.ERRORES_BD_SISTEMA) is True
