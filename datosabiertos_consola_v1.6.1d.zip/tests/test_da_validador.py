"""
Tests de da_validador: ValidadorConectividad y VerificadorRemoto.

Fronteras simuladas: paramiko
(Transport/SFTPClient/RSAKey), SparkSession. El wallet se
simula con archivos reales en tmp_path (deterministico).
"""

import logging
from types import SimpleNamespace
from unittest.mock import patch, MagicMock

import paramiko
import pytest

from app.da_validador import abrir_transporte_sftp, leer_alias_tnsnames, ValidadorConectividad, VerificadorRemoto


def _crear_wallet(tmp_path, con_tns=True):
    """Crea un directorio wallet con los 4 archivos requeridos."""
    wallet = tmp_path / 'wallet'
    wallet.mkdir()
    (wallet / 'cwallet.sso').write_text('x')
    (wallet / 'ewallet.p12').write_text('x')
    (wallet / 'sqlnet.ora').write_text('x')
    if con_tns:
        (wallet / 'tnsnames.ora').write_text('STAR_BI_DWH = (DESCRIPTION=...)\n')
    return wallet


def _config(wallet_path='/no/existe'):
    """Config base del validador."""
    return {'spark': {'wallet_path': str(wallet_path), 'spark_url': 'sc://h:15002'}}


@pytest.fixture
def mock_logger():
    """Logger real con NullHandler para tests de validador."""
    logger = logging.getLogger('test_validador')
    logger.setLevel(logging.DEBUG)
    handler = logging.NullHandler()
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)
    yield logger
    logger.removeHandler(handler)


class TestEsNombreTns:
    """_es_nombre_tns (estatico)."""

    def test_nombre_valido(self):
        """Un identificador simple es nombre TNS."""
        assert ValidadorConectividad._es_nombre_tns('STAR_BI') is True

    def test_ruta_no_es_tns(self):
        """Una ruta con / no es nombre TNS."""
        assert ValidadorConectividad._es_nombre_tns('/opt/wallet') is False

    def test_vacio_no_es_tns(self):
        """Cadena vacia no es nombre TNS."""
        assert ValidadorConectividad._es_nombre_tns('') is False


class TestExtraerTnsDeJdbc:
    """_extraer_tns_de_jdbc (estatico)."""

    def test_extrae_tns(self):
        """Extrae el alias TNS de una URL JDBC."""
        url = 'jdbc:oracle:thin:/@STAR_BI_DWH'
        assert ValidadorConectividad._extraer_tns_de_jdbc(url) == 'STAR_BI_DWH'

    def test_url_vacia_devuelve_none(self):
        """URL vacia -> None."""
        assert ValidadorConectividad._extraer_tns_de_jdbc('') is None

    def test_url_sin_tns_devuelve_none(self):
        """URL sin patron @TNS -> None."""
        assert ValidadorConectividad._extraer_tns_de_jdbc('jdbc:mysql://h') is None


class TestValidarWallet:
    """validar_wallet: estructura y TNS."""

    def test_wallet_completo_ok(self, tmp_path, mock_logger):
        """Wallet con los 4 archivos -> (True, ...)."""
        wallet = _crear_wallet(tmp_path)
        validador = ValidadorConectividad(_config(wallet), mock_logger)
        ok, _ = validador.validar_wallet()
        assert ok is True

    def test_wallet_no_configurado(self, mock_logger):
        """Sin wallet_path -> (False, ...)."""
        validador = ValidadorConectividad({'spark': {}}, mock_logger)
        ok, msg = validador.validar_wallet()
        assert ok is False
        assert 'no configurado' in msg.lower()

    def test_directorio_inexistente(self, mock_logger):
        """Directorio wallet inexistente -> (False, ...)."""
        validador = ValidadorConectividad(_config('/ruta/que/no/existe'), mock_logger)
        ok, msg = validador.validar_wallet()
        assert ok is False
        assert 'no existe' in msg.lower()

    def test_wallet_incompleto_sin_sqlnet(self, tmp_path, mock_logger):
        """Falta sqlnet.ora -> estructura invalida."""
        wallet = _crear_wallet(tmp_path)
        (wallet / 'sqlnet.ora').unlink()
        validador = ValidadorConectividad(_config(wallet), mock_logger)
        ok, msg = validador.validar_wallet()
        assert ok is False
        assert 'sqlnet' in msg.lower()

    def test_tns_requerido_no_en_wallet(self, tmp_path, mock_logger):
        """Un TNS requerido ausente del wallet -> (False, ...)."""
        wallet = _crear_wallet(tmp_path)
        validador = ValidadorConectividad(_config(wallet), mock_logger)
        ok, msg = validador.validar_wallet(jdbc_url='jdbc:oracle:thin:/@INEXISTENTE')
        assert ok is False
        assert 'INEXISTENTE' in msg


class TestValidarSpark:
    """validar_spark con crear_sesion_spark simulada."""

    def test_spark_ok(self, mock_logger):
        """Conexion Spark exitosa -> (True, ...)."""
        validador = ValidadorConectividad(_config(), mock_logger)
        sesion = MagicMock()
        sesion.version = '3.5.0'

        with patch('app.da_validador.crear_sesion_spark', return_value=sesion):
            ok, msg = validador.validar_spark()

        assert ok is True
        assert '3.5.0' in msg

    def test_spark_url_ausente(self, mock_logger):
        """Sin URL Spark -> (False, ...)."""
        validador = ValidadorConectividad({'spark': {}}, mock_logger)
        ok, _ = validador.validar_spark()
        assert ok is False

    def test_spark_falla_conexion(self, mock_logger):
        """Excepcion al conectar -> (False, ...)."""
        validador = ValidadorConectividad(_config(), mock_logger)
        with patch('app.da_validador.crear_sesion_spark', side_effect=RuntimeError('no conecta')):
            ok, msg = validador.validar_spark()
        assert ok is False
        assert 'falló' in msg or 'fallo' in msg.lower()


class TestValidarDestino:
    """validar_destino (estatico)."""

    def test_destino_local_accesible(self, tmp_path):
        """Destino local escribible -> (True, ..., False)."""
        destino = {'tipo': 'local', 'directorio_remoto': str(tmp_path / 'out')}
        ok, _, critico = ValidadorConectividad.validar_destino(destino)
        assert ok is True
        assert critico is False

    def test_destino_sftp_diferido(self):
        """Destino sftp se valida luego -> (True, ..., False)."""
        ok, _, critico = ValidadorConectividad.validar_destino({'tipo': 'sftp'})
        assert ok is True
        assert critico is False

    def test_destino_desconocido_es_critico(self):
        """Tipo no soportado -> (False, ..., True)."""
        ok, _, critico = ValidadorConectividad.validar_destino({'tipo': 'ftp'})
        assert ok is False
        assert critico is True


class TestValidarTodo:
    """validar_todo agrega resultados de las tres validaciones."""

    def test_todo_ok(self, tmp_path, mock_logger):
        """
        Wallet+Spark+destino OK -> puede_proceder True, sin errores.
        """
        wallet = _crear_wallet(tmp_path)
        validador = ValidadorConectividad(_config(wallet), mock_logger)
        consulta = SimpleNamespace(
            wallet=None, jdbc_url=None, spark_url='sc://h:15002', destino={'tipo': 'local', 'directorio_remoto': str(tmp_path / 'd')}
        )
        sesion = MagicMock()
        sesion.version = '3.5'

        with patch('app.da_validador.crear_sesion_spark', return_value=sesion):
            puede, errores, _ = validador.validar_todo(consulta)

        assert puede is True
        assert not errores

    def test_wallet_malo_genera_error(self, tmp_path, mock_logger):
        """Wallet inexistente agrega un error y bloquea."""
        validador = ValidadorConectividad(_config('/no/existe'), mock_logger)
        consulta = SimpleNamespace(
            wallet=None, jdbc_url=None, spark_url='sc://h:15002', destino={'tipo': 'local', 'directorio_remoto': str(tmp_path / 'd')}
        )
        with patch('app.da_validador.crear_sesion_spark', side_effect=RuntimeError('x')):
            puede, errores, _ = validador.validar_todo(consulta)
        assert puede is False
        assert any('Wallet' in e for e in errores)


def _servidor():
    """Config de un servidor de descarga."""
    return {'nombre': 'Quito', 'ip': '10.0.0.1', 'ruta_remota': '/data', 'usuario': 'sri', 'password': 'pass', 'key_file': '', 'puerto': 22}


def _verificador(mock_logger, patrones=None, minimo=1024):
    """Construye un VerificadorRemoto con un servidor."""
    cfg = {'patrones_archivos': patrones or [], 'tamanio_minimo_bytes': minimo}
    return VerificadorRemoto([_servidor()], cfg, mock_logger)


class TestCoincidePatron:
    """_coincide_patron: con y sin patrones."""

    def test_sin_patrones_solo_anio(self, mock_logger):
        """Sin patrones, basta con que el anio este en el nombre."""
        ver = _verificador(mock_logger)
        assert ver._coincide_patron('archivo_2024.zip', 2024) is True
        assert ver._coincide_patron('archivo_2023.zip', 2024) is False

    def test_con_patrones(self, mock_logger):
        """Con patrones, deben coincidir patron y anio."""
        ver = _verificador(mock_logger, patrones=['facturacion'])
        assert ver._coincide_patron('facturacion_2024.zip', 2024) is True
        assert ver._coincide_patron('otra_cosa_2024.zip', 2024) is False


class TestConstruirEntradaArchivo:
    """_construir_entrada_archivo: marca bajo minimo."""

    def test_archivo_valido(self, mock_logger):
        """Tamanio sobre el minimo -> ok True."""
        ver = _verificador(mock_logger, minimo=1000)
        entrada = SimpleNamespace(filename='f.zip', st_size=5000, st_mtime=1700000000)
        info = ver._construir_entrada_archivo(entrada)
        assert info['ok'] is True
        assert info['advertencia'] == ''

    def test_archivo_bajo_minimo(self, mock_logger):
        """Tamanio bajo el minimo -> ok False con advertencia."""
        ver = _verificador(mock_logger, minimo=10000)
        entrada = SimpleNamespace(filename='f.zip', st_size=500, st_mtime=0)
        info = ver._construir_entrada_archivo(entrada)
        assert info['ok'] is False
        assert 'mínimo' in info['advertencia'] or 'minimo' in info['advertencia']


class TestAbrirTransporteSftp:
    """abrir_transporte_sftp: credenciales."""

    def test_sin_credenciales_levanta(self):
        """Sin key_file ni password -> ValueError."""
        srv = _servidor()
        srv['password'] = ''
        srv['key_file'] = ''
        with patch('app.da_validador.paramiko') as mock_par:
            mock_par.Transport.return_value = MagicMock()
            with pytest.raises(ValueError):
                abrir_transporte_sftp(srv)

    def test_con_password_conecta(self):
        """
        Con password, llama transporte.connect con username/password.
        """
        srv = _servidor()
        transporte = MagicMock()
        with patch('app.da_validador.paramiko') as mock_par:
            mock_par.Transport.return_value = transporte
            resultado = abrir_transporte_sftp(srv)
        transporte.connect.assert_called_once()
        assert resultado is transporte


class TestVerificarServidor:
    """_verificar_servidor: feliz y ramas de error."""

    def test_servidor_ok_lista_archivos(self, mock_logger):
        """SFTP lista archivos que coinciden -> exito True."""
        ver = _verificador(mock_logger, patrones=['facturacion'])
        entrada = SimpleNamespace(filename='facturacion_2024.zip', st_size=5000, st_mtime=1700000000)
        transporte = MagicMock()
        sftp = MagicMock()
        sftp.listdir_attr.return_value = [entrada]
        with patch('app.da_validador.paramiko') as mock_par:
            mock_par.Transport.return_value = transporte
            mock_par.SFTPClient.from_transport.return_value = sftp
            resultado = ver._verificar_servidor(_servidor(), 2024)
        assert resultado['exito'] is True
        assert len(resultado['archivos']) == 1

    def test_auth_fallida(self, mock_logger):
        """AuthenticationException registra error y exito False."""

        ver = _verificador(mock_logger)
        transporte = MagicMock()
        with patch('app.da_validador.paramiko') as mock_par:
            mock_par.Transport.return_value = transporte
            mock_par.AuthenticationException = paramiko.AuthenticationException
            mock_par.SSHException = paramiko.SSHException
            mock_par.SFTPClient.from_transport.side_effect = paramiko.AuthenticationException()
            resultado = ver._verificar_servidor(_servidor(), 2024)
        assert resultado['exito'] is False
        assert resultado['errores']

    def test_directorio_inaccesible(self, mock_logger):
        """OSError al listar -> error de directorio no accesible."""

        ver = _verificador(mock_logger)
        transporte = MagicMock()
        sftp = MagicMock()
        sftp.listdir_attr.side_effect = OSError('no existe')
        with patch('app.da_validador.paramiko') as mock_par:
            mock_par.Transport.return_value = transporte
            mock_par.SFTPClient.from_transport.return_value = sftp
            mock_par.AuthenticationException = paramiko.AuthenticationException
            mock_par.SSHException = paramiko.SSHException
            resultado = ver._verificar_servidor(_servidor(), 2024)
        assert resultado['exito'] is False
        assert any('no se pudo' in e.lower() or 'conectar' in e.lower() for e in resultado['errores'])


class TestVerificarTodos:
    """verificar_todos itera sobre los servidores."""

    def test_itera_y_acumula(self, mock_logger):
        """Devuelve un resultado por servidor."""
        ver = _verificador(mock_logger)
        with patch.object(
            ver, '_verificar_servidor', return_value={'servidor': 'Q', 'ip': 'x', 'ruta': '/', 'archivos': [], 'errores': [], 'exito': True}
        ):
            with patch.object(ver, '_mostrar_resultado'):
                resultados = ver.verificar_todos(2024)
        assert len(resultados) == 1


class TestLeerAliasTnsnames:
    """Alias de tnsnames.ora (= credenciales del wallet)."""

    def test_alias_con_punto_guion_y_varios_por_linea(self, tmp_path):
        """Alias con punto guion y varios por linea."""
        tns = tmp_path / 'tnsnames.ora'
        tns.write_text(
            '# comentario = no es alias\n'
            'star_desa =\n  (DESCRIPTION = (ADDRESS = (HOST = x)))\n'
            'DETALLES.WORLD = (D)\n'
            'SRI-MVEH, SRIDW_MVEHICULAR = (D)\n'
            'STAR_DESA = (D)\n',
            encoding='utf-8',
        )
        assert leer_alias_tnsnames(tns) == ['STAR_DESA', 'DETALLES.WORLD', 'SRI-MVEH', 'SRIDW_MVEHICULAR']

    def test_archivo_inexistente(self, tmp_path):
        """Archivo inexistente."""
        with pytest.raises(OSError):
            leer_alias_tnsnames(tmp_path / 'no.ora')


class TestTnsnamesDelWallet:
    """Carga de tnsnames.ora desde el wallet o network_admin."""

    def test_sin_ruta_wallet_no_carga(self, mock_logger):
        """Sin ruta de wallet resuelta no se lee nada."""
        validador = ValidadorConectividad(_config(), mock_logger)
        validador._cargar_tnsnames()
        assert validador.tns_disponibles == []

    def test_usa_network_admin(self, tmp_path, mock_logger):
        """Con [wallet].network_admin el tnsnames.ora se lee de ahi."""
        wallet = _crear_wallet(tmp_path, con_tns=False)
        red = tmp_path / 'red'
        red.mkdir()
        (red / 'tnsnames.ora').write_text('SRIDW_DWH = (D)\n', encoding='utf-8')
        config = {**_config(wallet), 'wallet': {'network_admin': str(red)}}
        validador = ValidadorConectividad(config, mock_logger)
        validador.ruta_wallet = wallet
        validador._cargar_tnsnames()
        assert validador.tns_disponibles == ['SRIDW_DWH']

    def test_sin_tnsnames(self, tmp_path, mock_logger):
        """Si no hay tnsnames.ora queda la lista vacia."""
        wallet = _crear_wallet(tmp_path, con_tns=False)
        validador = ValidadorConectividad(_config(wallet), mock_logger)
        validador.ruta_wallet = wallet
        validador._cargar_tnsnames()
        assert validador.tns_disponibles == []

    def test_error_leyendo_tnsnames(self, tmp_path, mock_logger):
        """Un error de lectura se registra y la lista queda vacia."""
        wallet = _crear_wallet(tmp_path)
        validador = ValidadorConectividad(_config(wallet), mock_logger)
        validador.ruta_wallet = wallet
        with patch('app.da_validador.leer_alias_tnsnames', side_effect=OSError('permiso')):
            validador._cargar_tnsnames()
        assert validador.tns_disponibles == []


class TestRutaYTnsDelWallet:
    """Override del wallet: nombre TNS o ruta."""

    def test_override_es_nombre_tns(self, mock_logger):
        """Un nombre TNS usa la ruta del TOML y se exige ese alias."""
        validador = ValidadorConectividad(_config('/w'), mock_logger)
        assert validador._resolver_ruta_y_tns('STAR_DESA', None) == ('/w', 'STAR_DESA')

    def test_override_es_ruta(self, mock_logger):
        """Una ruta reemplaza la del TOML; el TNS sale del JDBC."""
        validador = ValidadorConectividad(_config('/w'), mock_logger)
        assert validador._resolver_ruta_y_tns('/otra', 'jdbc:oracle:thin:/@SRIDW_DWH') == ('/otra', 'SRIDW_DWH')

    def test_tns_requerido_valido(self, tmp_path, mock_logger):
        """Un alias presente en tnsnames.ora valida el wallet."""
        wallet = _crear_wallet(tmp_path)
        ok, msg = ValidadorConectividad(_config(wallet), mock_logger).validar_wallet('STAR_BI_DWH')
        assert ok is True
        assert "TNS 'STAR_BI_DWH' válido" in msg

    def test_estructura_sin_wallet(self, mock_logger):
        """Sin wallet_path en disco la estructura no es valida."""
        ok, msg = ValidadorConectividad(_config('/no/existe'), mock_logger)._validar_estructura_wallet()
        assert ok is False
        assert 'no existe' in msg

    def test_fecha_de_archivo_inexistente(self, tmp_path, mock_logger):
        """Registrar la fecha de un archivo inexistente no falla."""
        ValidadorConectividad(_config(), mock_logger)._log_fecha_archivo('x.ora', tmp_path / 'x.ora')
        ValidadorConectividad(_config(), mock_logger)._log_fecha_archivo('x.ora', None)


class TestDestinoYValidarTodo:
    """Destino no escribible y advertencias no criticas."""

    def test_destino_local_no_escribible(self, tmp_path):
        """Un error al escribir el destino local es critico."""
        with patch('app.da_validador.Path.write_text', side_effect=PermissionError('solo lectura')):
            ok, msg, critico = ValidadorConectividad.validar_destino({'tipo': 'local', 'directorio_remoto': str(tmp_path / 'o')})
        assert (ok, critico) == (False, True)
        assert 'solo lectura' in msg

    def test_destino_critico_es_error(self, tmp_path, mock_logger):
        """Un destino critico agrega un error y bloquea."""
        validador = ValidadorConectividad(_config(_crear_wallet(tmp_path)), mock_logger)
        consulta = SimpleNamespace(wallet=None, jdbc_url=None, spark_url='sc://h:15002', destino={'tipo': 'ftp'})
        with patch('app.da_validador.crear_sesion_spark', return_value=MagicMock(version='4')):
            puede, errores, _ = validador.validar_todo(consulta)
        assert puede is False
        assert any(e.startswith('Destino:') for e in errores)

    def test_destino_no_critico_es_advertencia(self, tmp_path, mock_logger):
        """Un destino con problema no critico solo advierte."""
        validador = ValidadorConectividad(_config(_crear_wallet(tmp_path)), mock_logger)
        consulta = SimpleNamespace(wallet=None, jdbc_url=None, spark_url='sc://h:15002', destino={'tipo': 'local'})
        with (
            patch('app.da_validador.crear_sesion_spark', return_value=MagicMock(version='4')),
            patch.object(ValidadorConectividad, 'validar_destino', return_value=(False, 'lento', False)),
        ):
            puede, errores, advertencias = validador.validar_todo(consulta)
        assert puede is True and not errores
        assert advertencias == ['Destino: lento']


class TestTransporteYVerificacion:
    """Clave SSH, errores SFTP y salida de la verificacion remota."""

    def test_transporte_con_clave(self, tmp_path):
        """Con key_file existente se autentica con la clave privada."""
        llave = tmp_path / 'k'
        llave.write_text('x', encoding='utf-8')
        transporte = MagicMock()
        with patch('app.da_validador.paramiko') as mock_par, patch('app.da_validador.cargar_clave_privada', return_value='PKEY'):
            mock_par.Transport.return_value = transporte
            abrir_transporte_sftp({**_servidor(), 'key_file': str(llave)})
        transporte.connect.assert_called_once_with(username='sri', pkey='PKEY')

    def test_log_del_verificador(self, mock_logger, caplog):
        """El verificador registra con el logger inyectado."""
        with caplog.at_level(logging.INFO, logger='test_validador'):
            _verificador(mock_logger)._log(logging.INFO, 'hola %s', 'mundo')
        assert 'hola mundo' in caplog.text

    @pytest.mark.parametrize(
        'error, texto', [(ValueError('Sin credenciales'), 'Sin credenciales'), (paramiko.SSHException('banner'), 'Error SSH en Quito')]
    )
    def test_errores_sftp(self, mock_logger, error, texto):
        """
        ValueError y SSHException quedan en los errores del servidor.
        """
        with patch('app.da_validador.abrir_transporte_sftp', side_effect=error):
            resultado = _verificador(mock_logger)._verificar_servidor(_servidor(), 2026)
        assert resultado['exito'] is False
        assert texto in resultado['errores'][0]

    def test_mostrar_resultado_con_errores(self, mock_logger, capsys):
        """Los errores se muestran en consola."""
        _verificador(mock_logger)._mostrar_resultado({'exito': False, 'servidor': 'Q', 'ip': 'x', 'ruta': '/d', 'errores': ['caido'], 'archivos': []})
        assert 'ERROR: caido' in capsys.readouterr().out

    def test_mostrar_resultado_sin_archivos(self, mock_logger, capsys):
        """Sin archivos lo indica."""
        _verificador(mock_logger)._mostrar_resultado({'exito': True, 'servidor': 'Q', 'ip': 'x', 'ruta': '/d', 'errores': [], 'archivos': []})
        assert 'Sin archivos encontrados' in capsys.readouterr().out

    def test_mostrar_resultado_con_archivos(self, mock_logger, capsys):
        """Cada archivo se muestra con su estado y advertencia."""
        archivos = [
            {'nombre': 'A_2026.zip', 'ok': True, 'tamanio_kb': 10, 'fecha_mod': 'f', 'advertencia': ''},
            {'nombre': 'B_2026.zip', 'ok': False, 'tamanio_kb': 0.1, 'fecha_mod': 'f', 'advertencia': 'bajo minimo'},
        ]
        _verificador(mock_logger)._mostrar_resultado({'exito': True, 'servidor': 'Q', 'ip': 'x', 'ruta': '/d', 'errores': [], 'archivos': archivos})
        salida = capsys.readouterr().out
        assert 'OK A_2026.zip' in salida
        assert 'ADVERTENCIA B_2026.zip' in salida and 'bajo minimo' in salida
