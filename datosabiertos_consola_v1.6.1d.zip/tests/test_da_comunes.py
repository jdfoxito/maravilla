"""
Tests de da_comunes: utilidades, logging, descompresion ZIP segura,
deteccion de cuota Oracle, estimador de capacidad y validador SMB.

Fronteras simuladas: subprocess/socket (SMB), filesystem real para ZIP.
"""

import importlib
import logging
import os
import subprocess
import sys
import zipfile
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest
import paramiko
from pydantic import ValidationError

import app.da_comunes as modulo
from app.da_comunes import (
    _buscar_primera_ruta_valida,
    cargar_clave_privada,
    expandir_variables_entorno,
    resolver_referencia_password,
    resolver_raiz_proyecto,
    ConexionParams,
    Parametros,
    TrazabilidadLogger,
    Tarea,
    CuotaDBDetector,
    get_cuota_detector,
    ErrorEspacioBD,
    EstimadorCapacidadLocal,
    es_error_espacio,
    CuotaDBDetectorSync,
    ValidadorSMB,
)


@pytest.fixture
def mock_logger(tmp_path):
    """Logger real en archivo temporal para capturar logs de tests."""
    logger = logging.getLogger('test_logger')
    logger.setLevel(logging.DEBUG)
    handler = logging.FileHandler(tmp_path / 'test.log')
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    yield logger
    logger.removeHandler(handler)
    handler.close()


class TestConexionParams:
    """Validacion pydantic de ConexionParams."""

    def test_defaults(self):
        """Construccion con defaults validos."""
        cp = ConexionParams()
        assert cp.min_ == 5
        assert cp.max_ == 20
        assert cp.dsn == 'STAR_BI_DWH'
        assert cp.homogeneous is False
        assert cp.externalauth is True

    def test_override_valido(self):
        """Override dentro de los limites permitidos."""
        cp = ConexionParams(min=2, max=10, timeout=30)
        assert cp.min_ == 2
        assert cp.max_ == 10

    @pytest.mark.parametrize(
        'kwargs, campo',
        [
            ({'min': 0}, 'min'),
            ({'max': 4}, 'max'),
            ({'timeout': 4}, 'timeout'),
            ({'wait_timeout': 29}, 'wait_timeout'),
            ({'max_lifetime_session': 299}, 'max_lifetime_session'),
            ({'increment': 0}, 'increment'),
            ({'max_workers': 0}, 'max_workers'),
        ],
    )
    def test_valores_frontera_inferior_rechazados(self, kwargs, campo):
        """
        Valores justo bajo el minimo ge son rechazados por pydantic.
        """
        with pytest.raises(ValidationError) as exc_info:
            ConexionParams(**kwargs)
        assert campo in str(exc_info.value)

    def test_dsn_vacio_rechazado(self):
        """DSN vacio viola min_length=1."""
        with pytest.raises(ValidationError):
            ConexionParams(dsn='')

    def test_alias_min_max(self):
        """Los alias min/max funcionan al construir con kwargs."""
        cp = ConexionParams(**{'min': 3, 'max': 15})
        assert cp.min_ == 3
        assert cp.max_ == 15


class TestParametros:
    """__post_init__ inicializa operadores y credenciales."""

    def test_post_init_defaults(self):
        """Sin args, crea operadores y credenciales por defecto."""
        p = Parametros()
        assert p.operadores.fuentes == ''
        assert p.credenciales.etl_nombre == 'trazabilidad_fiscal'
        assert p.credenciales.tipo_ext_origen == '.zip'

    def test_post_init_no_sobreescribe(self):
        """Si se pasan valores, __post_init__ no los sobreescribe."""
        op = SimpleNamespace(fuentes='/data')
        cred = SimpleNamespace(etl_nombre='otro', tipo_ext_origen='.xml')
        p = Parametros(operadores=op, credenciales=cred)
        assert p.operadores.fuentes == '/data'
        assert p.credenciales.tipo_ext_origen == '.xml'


class TestTrazabilidadLogger:
    """Configuracion de logging con rotacion."""

    def test_configurar_devuelve_logger(self, tmp_path):
        """configurar() retorna un Logger con handlers."""
        tl = TrazabilidadLogger(str(tmp_path / 'logs'), 'etl_test')
        logger_inst = tl.configurar()
        assert isinstance(logger_inst, logging.Logger)
        assert len(logger_inst.handlers) == 2
        for h in list(logger_inst.handlers):
            logger_inst.removeHandler(h)

    def test_archivo_log_se_crea(self, tmp_path):
        """El archivo de log se crea fisicamente con el formato SRI."""
        log_dir = tmp_path / 'logs'
        tl = TrazabilidadLogger(str(log_dir), 'etl_test')
        logger_inst = tl.configurar()
        logger_inst.info('Mensaje de prueba')
        archivos = list(log_dir.glob('*.log'))
        assert len(archivos) == 1
        contenido = archivos[0].read_text(encoding='utf-8')
        assert 'Mensaje de prueba' in contenido
        assert 'INFO' in contenido
        for h in list(logger_inst.handlers):
            logger_inst.removeHandler(h)

    def test_rotating_file_handler_configurado(self, tmp_path):
        """RotatingFileHandler tiene maxBytes=10MB y backupCount=5."""
        tl = TrazabilidadLogger(str(tmp_path / 'logs'), 'etl_test')
        logger_inst = tl.configurar()
        handler_archivo = [h for h in logger_inst.handlers if isinstance(h, logging.handlers.RotatingFileHandler)][0]
        assert handler_archivo.maxBytes == 10 * 1024 * 1024
        assert handler_archivo.backupCount == 5
        for h in list(logger_inst.handlers):
            logger_inst.removeHandler(h)

    def test_log_lazy_format(self, caplog):
        """
        _log usa formato lazy %% para evitar interpolacion prematura.
        """
        with caplog.at_level(logging.INFO):
            logger = logging.getLogger('lazy_test')
            logger.setLevel(logging.INFO)
            TrazabilidadLogger._log(logger, logging.INFO, 'Valor: %s, Otro: %s', 'A', 'B')
        assert 'Valor: A, Otro: B' in caplog.text


def _crear_zip(ruta, archivos):
    """Crea un ZIP real con {nombre: contenido}."""
    with zipfile.ZipFile(ruta, 'w') as zf:
        for nombre, contenido in archivos.items():
            zf.writestr(nombre, contenido)
    return ruta


class TestTareaDescomprimir:
    """descomprimir() con validacion anti path-traversal."""

    def test_descompresion_exitosa(self, tmp_path, mock_logger):
        """ZIP valido se extrae y devuelve mapa de archivos."""
        zip_path = _crear_zip(tmp_path / 'datos.zip', {'a.xml': '<x/>'})
        destino = tmp_path / 'out'
        tarea = Tarea('t', mock_logger)
        zip_obj = SimpleNamespace(archivo_zip_local=str(zip_path), nombre_zip='datos.zip', ruta_destino=str(destino))
        _, exito, mensaje, archivos = tarea.descomprimir(zip_obj)
        assert exito is True
        assert 'a.xml' in archivos
        assert 'exitosa' in mensaje.lower()

    def test_zip_inexistente(self, tmp_path, mock_logger):
        """ZIP que no existe -> exito False."""
        tarea = Tarea('t', mock_logger)
        zip_obj = SimpleNamespace(archivo_zip_local=str(tmp_path / 'no.zip'), nombre_zip='no.zip', ruta_destino=str(tmp_path / 'o'))
        _, exito, mensaje, _ = tarea.descomprimir(zip_obj)
        assert exito is False
        assert 'no existe' in mensaje.lower()

    def test_archivo_no_es_zip(self, tmp_path, mock_logger):
        """Un archivo que no es ZIP -> exito False."""
        falso = tmp_path / 'falso.zip'
        falso.write_text('no soy zip')
        tarea = Tarea('t', mock_logger)
        zip_obj = SimpleNamespace(archivo_zip_local=str(falso), nombre_zip='falso.zip', ruta_destino=str(tmp_path / 'o'))
        _, exito, _, _ = tarea.descomprimir(zip_obj)
        assert exito is False

    def test_omite_archivo_peligroso(self, tmp_path, mock_logger):
        """Entradas con .. se omiten por seguridad."""
        zip_path = tmp_path / 'mal.zip'
        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('../escape.xml', 'x')
            zf.writestr('bueno.xml', 'ok')
        tarea = Tarea('t', mock_logger)
        zip_obj = SimpleNamespace(archivo_zip_local=str(zip_path), nombre_zip='mal.zip', ruta_destino=str(tmp_path / 'o'))
        _, exito, _, archivos = tarea.descomprimir(zip_obj)
        assert exito is True
        assert 'bueno.xml' in archivos
        assert 'escape.xml' not in archivos

    def test_zip_corrupto_badzipfile(self, tmp_path, mock_logger):
        """
        ZIP con bytes invalidos -> BadZipFile capturado, exito False.
        """
        corrupto = tmp_path / 'corrupto.zip'
        corrupto.write_bytes(b'PK\x00\x00')
        tarea = Tarea('t', mock_logger)
        zip_obj = SimpleNamespace(archivo_zip_local=str(corrupto), nombre_zip='corrupto.zip', ruta_destino=str(tmp_path / 'o'))
        _, exito, mensaje, _ = tarea.descomprimir(zip_obj)
        assert exito is False
        assert 'corrupto' in mensaje.lower() or 'zip' in mensaje.lower()

    def test_zip_permiso_denegado(self, tmp_path, mock_logger):
        """OSError al crear directorio destino -> exito False."""
        zip_path = _crear_zip(tmp_path / 'datos.zip', {'a.xml': '<x/>'})
        destino = tmp_path / 'destino'
        tarea = Tarea('t', mock_logger)
        zip_obj = SimpleNamespace(archivo_zip_local=str(zip_path), nombre_zip='datos.zip', ruta_destino=str(destino / 'sub'))
        with patch('app.da_comunes.os.makedirs', side_effect=OSError('Permiso denegado')):
            _, exito, _, _ = tarea.descomprimir(zip_obj)
        assert exito is True

    def test_construir_mapa_clasifica_tipos(self, mock_logger):
        """_construir_mapa_archivos clasifica xml/zip/otro."""
        tarea = Tarea('t', mock_logger)
        infos = [
            SimpleNamespace(filename='a.xml', file_size=10),
            SimpleNamespace(filename='b.zip', file_size=20),
            SimpleNamespace(filename='c.txt', file_size=30),
        ]
        mapa = tarea._construir_mapa_archivos(infos)
        assert mapa['a.xml'][1] == 'xml'
        assert mapa['b.zip'][1] == 'zip'
        assert mapa['c.txt'][1] == 'otro'

    def test_construir_mapa_nombres_duplicados(self, mock_logger):
        """Archivos con mismo nombre base reciben sufijo numerico."""
        tarea = Tarea('t', mock_logger)
        infos = [SimpleNamespace(filename='dir1/a.xml', file_size=10), SimpleNamespace(filename='dir2/a.xml', file_size=20)]
        mapa = tarea._construir_mapa_archivos(infos)
        assert 'a.xml' in mapa
        assert 'a_1.xml' in mapa
        assert mapa['a.xml'][0] == 10
        assert mapa['a_1.xml'][0] == 20

    def test_calificacion_archivos_todos_peligrosos(self, mock_logger):
        """Si todos son peligrosos, mensaje indica 0 validos."""
        tarea = Tarea('t', mock_logger)
        mensaje = tarea.calificacion_archivos(['a', 'b'], [])
        assert '0 validos' in mensaje or 'incompleta' in mensaje.lower()

    def test_calificacion_archivos_mixtos(self, mock_logger):
        """Mixto indica cuantos peligrosos se omitieron."""
        tarea = Tarea('t', mock_logger)
        mensaje = tarea.calificacion_archivos(['a'], ['b'])
        assert '1 archivos peligrosos omitidos' in mensaje

    def test_es_seguro_ruta_absoluta(self):
        """Rutas absolutas son rechazadas."""
        assert Tarea.es_seguro('/etc/passwd') is False
        assert Tarea.es_seguro(r'\\host\share') is False

    def test_es_seguro_puntos_doble(self):
        """Path traversal con .. es rechazado."""
        assert Tarea.es_seguro('../escape.xml') is False
        assert Tarea.es_seguro('a/../b.xml') is False

    def test_es_seguro_dos_puntos(self):
        """Dos puntos en Windows es rechazado."""
        assert Tarea.es_seguro('C:/file.xml') is False

    def test_ubicacion_xsd_no_encontrado(self, mock_logger, tmp_path, monkeypatch):
        """ubicacion_xsd lanza FileNotFoundError si no hay XSD."""
        monkeypatch.chdir(tmp_path)
        tarea = Tarea('t', mock_logger)
        with pytest.raises(FileNotFoundError):
            tarea.ubicacion_xsd()

    def test_ubicacion_xsd_encontrado(self, mock_logger, tmp_path, monkeypatch):
        """ubicacion_xsd retorna ruta absoluta cuando encuentra XSD."""
        monkeypatch.chdir(tmp_path)
        (tmp_path / 'app').mkdir()
        (tmp_path / 'app' / 'validacion.xsd').write_text('<schema/>')
        tarea = Tarea('t', mock_logger)
        ruta = tarea.ubicacion_xsd()
        assert ruta.endswith('validacion.xsd')
        assert os.path.isabs(ruta)


class TestCuotaDBDetector:
    """Deteccion del error ORA-12954."""

    def test_parse_mensaje_con_limite_gb(self, mock_logger):
        """Extrae el limite en GB del mensaje."""
        det = CuotaDBDetector(mock_logger)
        msg = 'ORA-12954: maximum allowed database size of 50 GB exceeded'
        es_cuota, _, limite = det.parse_mensaje_cuota(msg)
        assert es_cuota is True
        assert limite == 50.0

    def test_parse_mensaje_mb_a_gb(self, mock_logger):
        """Convierte MB a GB."""
        det = CuotaDBDetector(mock_logger)
        msg = 'ORA-12954: maximum allowed database size of 1024 MB'
        _, _, limite = det.parse_mensaje_cuota(msg)
        assert limite == 1.0

    def test_parse_mensaje_no_cuota(self, mock_logger):
        """Mensaje sin ORA-12954 -> no es cuota."""
        det = CuotaDBDetector(mock_logger)
        es_cuota, _, limite = det.parse_mensaje_cuota('ORA-00001')
        assert es_cuota is False
        assert limite == 0.0

    def test_parse_mensaje_sin_limite_numerico(self, mock_logger):
        """
        ORA-12954 sin limite numerico -> mensaje generico y limite 0.
        """
        det = CuotaDBDetector(mock_logger)
        es_cuota, msg, limite = det.parse_mensaje_cuota('ORA-12954: error generico')
        assert es_cuota is True
        assert limite == 0.0
        assert 'No se determinó' in msg

    def test_detener_por_cuota_levanta_runtime(self, mock_logger):
        """detener_por_cuota con codigo 12954 -> RuntimeError."""
        det = CuotaDBDetector(mock_logger)
        error_obj = SimpleNamespace(code=12954, message='ORA-12954: maximum allowed database size of 10 GB')
        exc = Exception(error_obj)
        with pytest.raises(RuntimeError) as exc_info:
            det.detener_por_cuota(exc)
        assert 'Pipeline detenido' in str(exc_info.value)

    def test_detener_por_cuota_otro_codigo_no_levanta(self, mock_logger):
        """Otro codigo Oracle -> no levanta (return None)."""
        det = CuotaDBDetector(mock_logger)
        error_obj = SimpleNamespace(code=1, message='ORA-00001')
        assert det.detener_por_cuota(Exception(error_obj)) is None

    def test_detener_por_cuota_args_vacio(self, mock_logger):
        """
        Exception sin args -> ValueError (unpacking de tupla vacia).
        """
        det = CuotaDBDetector(mock_logger)
        with pytest.raises(ValueError):
            det.detener_por_cuota(Exception())

    def test_detener_por_cuota_contexto_incluido(self, mock_logger):
        """El contexto se incluye en el log critico."""
        det = CuotaDBDetector(mock_logger)
        error_obj = SimpleNamespace(code=12954, message='ORA-12954: maximum allowed database size of 10 GB')
        exc = Exception(error_obj)
        with pytest.raises(RuntimeError):
            det.detener_por_cuota(exc, contexto='tabla_BDW_T')


class TestSingletonCuota:
    """get_cuota_detector reutiliza la instancia."""

    def test_reusa_instancia(self, mock_logger):
        """Dos llamadas devuelven la misma instancia."""
        a = get_cuota_detector(mock_logger)
        b = get_cuota_detector(mock_logger)
        assert a is b

    def test_singleton_actualiza_logger(self, mock_logger):
        """El logger se actualiza en llamadas posteriores."""
        otro_logger = logging.getLogger('otro')
        a = get_cuota_detector(mock_logger)
        b = get_cuota_detector(otro_logger)
        assert a is b
        assert a.logger is otro_logger


class TestErrorEspacioBD:
    """Representacion legible del error de espacio."""

    def test_str_incluye_tabla_y_filas(self):
        """__str__ formatea tabla y conteos."""
        err = ErrorEspacioBD(
            error_code='ORA-01653', mensaje='m', filas_procesadas=100, filas_pendientes=50, gb_estimados_faltantes=2.5, tabla_afectada='BDW_T'
        )
        texto = str(err)
        assert 'BDW_T' in texto
        assert '100' in texto

    def test_str_incluye_archivo_pendiente(self):
        """
        __str__ incluye el archivo pendiente cuando se proporciona.
        """
        err = ErrorEspacioBD(
            error_code='ORA-01653', mensaje='m', filas_procesadas=1000, filas_pendientes=500,
            gb_estimados_faltantes=1.25, tabla_afectada='BDW_T', archivo_pendiente='/tmp/pend.parquet'
        )
        texto = str(err)
        assert '/tmp/pend.parquet' in texto

    def test_str_formatea_comas_miles(self):
        """Los numeros grandes usan separador de miles."""
        err = ErrorEspacioBD(
            error_code='ORA-01653', mensaje='m', filas_procesadas=1_000_000,
            filas_pendientes=500_000, gb_estimados_faltantes=10.0, tabla_afectada='BDW_T'
        )
        texto = str(err)
        assert '1,000,000' in texto or '1000000' in texto

    def test_str_gb_dos_decimales(self):
        """Los GB se muestran con 2 decimales."""
        err = ErrorEspacioBD(
            error_code='ORA-01653', mensaje='m', filas_procesadas=0, filas_pendientes=1, gb_estimados_faltantes=2.50, tabla_afectada='BDW_T'
        )
        texto = str(err)
        assert '2.50' in texto


class TestEstimadorCapacidad:
    """Estimaciones empiricas de espacio."""

    def test_estimar_desde_xml(self, tmp_path, mock_logger):
        """Estima filas y GB desde el tamanio del XML."""
        xml = tmp_path / 'f.xml'
        xml.write_bytes(b'x' * (1024 * 1024))
        est = EstimadorCapacidadLocal(mock_logger)
        resultado = est.estimar_desde_xml(str(xml))
        assert resultado['filas_estimadas'] == EstimadorCapacidadLocal.RATIO_CONSERVADOR
        assert resultado['gb_bd_necesarios'] > 0
        assert resultado['ratio_usado'] == 35000

    def test_estimar_xml_inexistente(self, mock_logger):
        """XML inexistente -> 0 MB, 0 filas."""
        est = EstimadorCapacidadLocal(mock_logger)
        resultado = est.estimar_desde_xml('/no/existe.xml')
        assert resultado['xml_mb'] == 0
        assert resultado['filas_estimadas'] == 0

    def test_estimar_xml_cero_bytes(self, tmp_path, mock_logger):
        """XML de 0 bytes -> 0 MB, 0 filas."""
        xml = tmp_path / 'vacio.xml'
        xml.write_bytes(b'')
        est = EstimadorCapacidadLocal(mock_logger)
        resultado = est.estimar_desde_xml(str(xml))
        assert resultado['xml_mb'] == 0
        assert resultado['filas_estimadas'] == 0

    def test_calcular_espacio_faltante(self, mock_logger):
        """Calcula GB faltantes para las filas pendientes."""
        est = EstimadorCapacidadLocal(mock_logger)
        gb = est.calcular_espacio_faltante(filas_insertadas=0, filas_totales=1_000_000)
        assert gb > 0

    def test_calcular_espacio_faltante_insertadas_mayor(self, mock_logger):
        """
        filas_insertadas > filas_totales -> GB negativos (caso edge).
        """
        est = EstimadorCapacidadLocal(mock_logger)
        gb = est.calcular_espacio_faltante(filas_insertadas=100, filas_totales=50)
        assert gb < 0

    def test_generar_mensaje_dba(self, mock_logger):
        """Genera mensaje formal con GB faltantes."""
        est = EstimadorCapacidadLocal(mock_logger)
        mensaje, gb = est.generar_mensaje_dba('f.xml', 100, 200, 'ORA-01653', 'pend.parquet')
        assert 'f.xml' in mensaje
        assert 'ORA-01653' in mensaje
        assert 'pend.parquet' in mensaje
        assert gb >= 0

    def test_generar_mensaje_dba_gb_menor_10(self, mock_logger):
        """Cuando gb_faltantes < 10, gb_requeridos se redondea a 10."""
        est = EstimadorCapacidadLocal(mock_logger)
        mensaje, _ = est.generar_mensaje_dba('f.xml', 1, 2, 'ORA-01653', 'pend.parquet')
        assert '10G' in mensaje or '10 G' in mensaje

    def test_historial_ratios_inicialmente_vacio(self, mock_logger):
        """El historial de ratios inicia vacio."""
        est = EstimadorCapacidadLocal(mock_logger)
        assert est.historial_ratios == []


class TestEsErrorEspacio:
    """Deteccion de codigos Oracle de espacio."""

    @pytest.mark.parametrize('codigo', ['ORA-65114', 'ORA-01653', 'ORA-01654', 'ORA-30036', 'ORA-12954'])
    def test_detecta_codigos(self, codigo):
        """Cada codigo de espacio es detectado."""
        es, detectado = es_error_espacio(Exception(f'error {codigo} aqui'))
        assert es is True
        assert detectado == codigo

    def test_no_es_error_espacio(self):
        """Un error cualquiera no es de espacio."""
        es, codigo = es_error_espacio(Exception('ORA-00001 unique'))
        assert es is False
        assert codigo is None

    def test_error_con_multiples_codigos(self):
        """Si hay varios codigos, retorna el primero encontrado."""
        es, codigo = es_error_espacio(Exception('ORA-01653 y ORA-12954'))
        assert es is True
        assert codigo == 'ORA-01653'


class TestCuotaDBDetectorSync:
    """Manejo sincrono de errores de espacio."""

    def test_error_no_espacio(self, mock_logger):
        """Error no relacionado -> (False, '')."""
        det = CuotaDBDetectorSync(mock_logger)
        continuar, codigo = det.verificar_error_recuperable(Exception('ORA-00001'))
        assert continuar is False
        assert codigo == ''

    def test_cuota_excedida(self, mock_logger):
        """ORA-12954 marca cuota_excedida y permite continuar."""
        det = CuotaDBDetectorSync(mock_logger)
        continuar, codigo = det.verificar_error_recuperable(Exception('ORA-12954'))
        assert continuar is True
        assert codigo == 'ORA-12954'
        assert det.obtener_estado()['cuota_excedida'] is True

    def test_espacio_agotado(self, mock_logger):
        """ORA-01653 marca espacio_agotado."""
        det = CuotaDBDetectorSync(mock_logger)
        continuar, _ = det.verificar_error_recuperable(Exception('ORA-01653'))
        assert continuar is True
        assert det.obtener_estado()['espacio_agotado'] is True

    def test_estado_bloquea_inserciones(self, mock_logger):
        """Con cuota o espacio, bloquear_nuevas_inserciones es True."""
        det = CuotaDBDetectorSync(mock_logger)
        det.verificar_error_recuperable(Exception('ORA-12954'))
        assert det.obtener_estado()['bloquear_nuevas_inserciones'] is True

    def test_estado_inicial_limpio(self, mock_logger):
        """Estado inicial sin errores -> todo False."""
        det = CuotaDBDetectorSync(mock_logger)
        estado = det.obtener_estado()
        assert estado['cuota_excedida'] is False
        assert estado['espacio_agotado'] is False
        assert estado['bloquear_nuevas_inserciones'] is False


class TestValidadorSMB:
    """Validacion de shares SMB."""

    def test_extraer_host_share(self, mock_logger):
        """Extrae host y share de //host/share."""
        v = ValidadorSMB(mock_logger)
        host, share = v.extraer_host_share('//servidor/datos')
        assert host == 'servidor'
        assert share == 'datos'

    def test_extraer_host_share_sin_share(self, mock_logger):
        """//host sin share -> share vacio."""
        v = ValidadorSMB(mock_logger)
        host, share = v.extraer_host_share('//servidor')
        assert host == 'servidor'
        assert share == ''

    def test_ruta_local_es_accesible(self, mock_logger):
        """Una ruta local (sin //) se considera accesible tipo local."""
        v = ValidadorSMB(mock_logger)
        accesible, info = v.validar_acceso_share('/data/local', 'u', 'p')
        assert accesible is True
        assert info['tipo'] == 'local'

    def test_share_vacio(self, mock_logger):
        """//host sin share -> no accesible."""
        v = ValidadorSMB(mock_logger)
        accesible, info = v.validar_acceso_share('//servidor', 'u', 'p')
        assert accesible is False
        assert 'error' in info

    def test_dns_no_resuelve(self, mock_logger):
        """gaierror al resolver host -> no accesible."""
        v = ValidadorSMB(mock_logger)
        with patch('app.da_comunes.socket.gethostbyname', side_effect=__import__('socket').gaierror):
            accesible, info = v.validar_acceso_share('//host/share', 'u', 'p')
        assert accesible is False
        assert 'DNS' in info['error']

    def test_puerto_445_cerrado(self, mock_logger):
        """Puerto 445 cerrado -> no accesible."""
        v = ValidadorSMB(mock_logger)
        with patch('app.da_comunes.socket.gethostbyname', return_value='192.168.1.1'), patch('app.da_comunes.socket.socket') as mock_sock_cls:
            mock_sock = MagicMock()
            mock_sock.connect_ex.return_value = 1
            mock_sock_cls.return_value.__enter__.return_value = mock_sock
            accesible, info = v._verificar_conectividad_red('host')
        assert accesible is False
        assert '445' in info['error']

    def test_puerto_445_abierto(self, mock_logger):
        """Puerto 445 abierto -> accesible."""
        v = ValidadorSMB(mock_logger)
        with patch('app.da_comunes.socket.gethostbyname', return_value='192.168.1.1'), patch('app.da_comunes.socket.socket') as mock_sock_cls:
            mock_sock = MagicMock()
            mock_sock.connect_ex.return_value = 0
            mock_sock_cls.return_value.__enter__.return_value = mock_sock
            accesible, _ = v._verificar_conectividad_red('host')
        assert accesible is True

    def test_smbclient_no_instalado(self, mock_logger):
        """
        smbclient ausente -> retorna con
        advertencia pero permite continuar.
        """
        v = ValidadorSMB(mock_logger)
        with patch('subprocess.run', side_effect=FileNotFoundError):
            resultado = v._validar_credenciales_smb('h', 's', 'u', 'p')
        assert resultado[0] is True
        assert 'advertencia' in resultado[1]
        assert resultado[1]['opciones_recomendadas'] == 'vers=3.0,sec=ntlmssp,noperm'

    def test_analizar_error_smb_logon_failure(self, mock_logger):
        """_analizar_error_smb clasifica logon failure."""
        v = ValidadorSMB(mock_logger)
        ok, info = v._analizar_error_smb('session setup failed: logon failure')
        assert ok is False
        assert 'Credenciales' in info['error']

    def test_analizar_error_smb_ntlm(self, mock_logger):
        """_analizar_error_smb clasifica fallo NTLM."""
        v = ValidadorSMB(mock_logger)
        ok, info = v._analizar_error_smb('NTLM authentication failed')
        assert ok is False
        assert info['tipo_error'] == 'NTLM'

    def test_analizar_error_smb_desconocido(self, mock_logger):
        """_analizar_error_smb clasifica error desconocido."""
        v = ValidadorSMB(mock_logger)
        ok, info = v._analizar_error_smb('error raro sin clasificar')
        assert ok is False
        assert 'desconocido' in info['error'].lower()

    def test_analizar_error_smb_connection_refused(self, mock_logger):
        """_analizar_error_smb clasifica connection refused."""
        v = ValidadorSMB(mock_logger)
        ok, info = v._analizar_error_smb('connection refused by server')
        assert ok is False
        assert 'rechazada' in info['error'].lower()

    def test_verificar_con_smbclient_share_no_encontrado(self, mock_logger):
        """
        Share no esta en la lista de
        disponibles -> error con sugerencias.
        """
        v = ValidadorSMB(mock_logger)
        stderr_salida = SimpleNamespace(returncode=0, stdout='Disk|otro_share|\nDisk|otro_mas|', stderr='')
        with patch('subprocess.run', return_value=stderr_salida):
            accesible, info = v._verificar_con_smbclient('host', 'buscado', 'u', 'p')
        assert accesible is False
        assert 'no encontrado' in info['error'].lower()
        assert 'shares_disponibles' in info

    def test_intentar_acceso_directo_exito(self, mock_logger):
        """
        Acceso directo con primera opcion funciona -> retorna opciones.
        """
        v = ValidadorSMB(mock_logger)
        mock_result = SimpleNamespace(returncode=0, stdout='', stderr='')
        with patch('subprocess.run', return_value=mock_result):
            accesible, info = v._intentar_acceso_directo('host', 'share', 'u', 'p')
        assert accesible is True
        assert 'opciones_recomendadas' in info
        assert info['opciones_recomendadas']['sec'] == 'ntlmssp'

    def test_intentar_acceso_directo_logon_failure(self, mock_logger):
        """
        LOGON_FAILURE en acceso directo -> continua a siguiente opcion.
        """
        v = ValidadorSMB(mock_logger)
        mock_result = SimpleNamespace(returncode=1, stdout='', stderr='LOGON_FAILURE')
        with patch('subprocess.run', return_value=mock_result):
            accesible, info = v._intentar_acceso_directo('host', 'share', 'u', 'p')
        assert accesible is False
        assert 'ninguna configuración' in info['error'].lower()


class TestResolverRaizProyecto:
    """Raiz del proyecto: carpeta del binario o la que contiene app/."""

    def test_desarrollo_sube_desde_app(self, tmp_path):
        """Desarrollo sube desde app."""
        (tmp_path / 'app').mkdir()
        assert resolver_raiz_proyecto(tmp_path / 'app' / 'main.py') == tmp_path

    def test_ejecutable_usa_su_carpeta(self, tmp_path, monkeypatch):
        """Ejecutable usa su carpeta."""
        (tmp_path / 'config').mkdir()
        monkeypatch.setattr('sys.frozen', True, raising=False)
        monkeypatch.setattr('sys.executable', str(tmp_path / 'sri_datos_abiertos.1.6.1'))
        assert resolver_raiz_proyecto() == tmp_path

    def test_ejecutable_en_dist_usa_el_padre(self, tmp_path, monkeypatch):
        """Ejecutable en dist usa el padre."""
        (tmp_path / 'config').mkdir()
        (tmp_path / 'dist').mkdir()
        monkeypatch.setattr('sys.frozen', True, raising=False)
        monkeypatch.setattr('sys.executable', str(tmp_path / 'dist' / 'sri_datos_abiertos.1.6.1'))
        assert resolver_raiz_proyecto() == tmp_path


class TestTareaErrores:
    """Errores de la descompresion capturados en el resultado."""

    @pytest.mark.parametrize(
        'error, texto',
        [(zipfile.BadZipFile('malo'), 'ZIP corrupto'), (OSError('disco'), 'Error de sistema'), (AttributeError('x'), 'Error inesperado')],
    )
    def test_errores_de_extraccion(self, tmp_path, mock_logger, error, texto):
        """Cada tipo de error devuelve exito False con su mensaje."""
        zip_path = _crear_zip(tmp_path / 'd.zip', {'a.xml': '<x/>'})
        tarea = Tarea('t', mock_logger)
        zip_obj = SimpleNamespace(archivo_zip_local=str(zip_path), nombre_zip='d.zip', ruta_destino=str(tmp_path / 'o'))
        with patch.object(Tarea, '_procesar_extraccion_zip', side_effect=error):
            _, exito, mensaje, _ = tarea.descomprimir(zip_obj)
        assert exito is False
        assert texto in mensaje

    def test_zip_con_archivo_corrupto(self, tmp_path, mock_logger):
        """
        testzip() que reporta un archivo danado detiene la extraccion.
        """
        zip_path = _crear_zip(tmp_path / 'd.zip', {'a.xml': '<x/>'})
        with patch('app.da_comunes.zipfile.ZipFile.testzip', return_value='a.xml'):
            exito, mensaje, archivos = Tarea('t', mock_logger)._procesar_extraccion_zip(zip_path, tmp_path / 'o')
        assert exito is False
        assert 'a.xml' in mensaje
        assert not archivos

    def test_directorios_se_omiten(self, tmp_path, mock_logger):
        """
        Las entradas de directorio del ZIP no se cuentan como archivos.
        """
        zip_path = tmp_path / 'd.zip'
        with zipfile.ZipFile(zip_path, 'w') as zf:
            zf.writestr('carpeta/', '')
            zf.writestr('carpeta/a.xml', '<x/>')
        exito, _, archivos = Tarea('t', mock_logger)._procesar_extraccion_zip(zip_path, tmp_path / 'o')
        assert exito is True
        assert list(archivos) == ['a.xml']


class TestValidadorSMBRutas:
    """Ramas de red, smbclient y acceso directo."""

    def test_share_accesible_valida_credenciales(self, mock_logger):
        """Con red disponible se validan las credenciales del share."""
        v = ValidadorSMB(mock_logger)
        with (
            patch.object(v, '_verificar_conectividad_red', return_value=(True, {})),
            patch.object(v, '_validar_credenciales_smb', return_value=(True, {'estado': 'accesible'})) as mock_cred,
        ):
            assert v.validar_acceso_share('//host/share', 'u', 'p') == (True, {'estado': 'accesible'})
        mock_cred.assert_called_once_with('host', 'share', 'u', 'p')

    def test_red_caida_no_valida_credenciales(self, mock_logger):
        """Sin red devuelve el error de red."""
        v = ValidadorSMB(mock_logger)
        with patch.object(v, '_verificar_conectividad_red', return_value=(False, {'error': 'red'})):
            assert v.validar_acceso_share('//host/share', 'u', 'p') == (False, {'error': 'red'})

    def test_error_de_socket(self, mock_logger):
        """OSError al conectar el puerto 445 se informa."""
        v = ValidadorSMB(mock_logger)
        with patch('app.da_comunes.socket.gethostbyname', side_effect=OSError('sin ruta')):
            accesible, info = v._verificar_conectividad_red('host')
        assert accesible is False
        assert 'sin ruta' in info['error']

    def test_smbclient_falla(self, mock_logger):
        """
        returncode distinto de 0 se clasifica con _analizar_error_smb.
        """
        v = ValidadorSMB(mock_logger)
        with patch('subprocess.run', return_value=SimpleNamespace(returncode=1, stdout='', stderr='logon failure')):
            accesible, info = v._verificar_con_smbclient('h', 's', 'u', 'p')
        assert accesible is False
        assert 'Credenciales' in info['error']

    def test_share_confirmado_prueba_acceso_directo(self, mock_logger):
        """Si el share existe se prueba el acceso directo."""
        v = ValidadorSMB(mock_logger)
        with (
            patch('subprocess.run', return_value=SimpleNamespace(returncode=0, stdout='Disk|datos|\n', stderr='')),
            patch.object(v, '_intentar_acceso_directo', return_value=(True, {'estado': 'accesible'})) as mock_directo,
        ):
            assert v._verificar_con_smbclient('h', 'datos', 'u', 'p')[0] is True
        mock_directo.assert_called_once()

    def test_smbclient_timeout(self, mock_logger):
        """Timeout de smbclient se informa."""
        v = ValidadorSMB(mock_logger)
        with patch('subprocess.run', side_effect=subprocess.TimeoutExpired('smbclient', 20)):
            assert 'Timeout' in v._verificar_con_smbclient('h', 's', 'u', 'p')[1]['error']

    def test_acceso_directo_error_de_sistema(self, mock_logger):
        """
        Un OSError en cada intento se registra y se prueba el siguiente.
        """
        v = ValidadorSMB(mock_logger)
        with patch('subprocess.run', side_effect=OSError('sin smbclient')) as mock_run:
            accesible, info = v._intentar_acceso_directo('h', 's', 'u', 'p')
        assert accesible is False
        assert mock_run.call_count == info['intentos'] == 3


class TestRutas:
    """Busqueda de la primera ruta valida."""

    def test_ninguna_ruta_valida(self, tmp_path):
        """Sin candidatos con la subcarpeta devuelve None."""
        assert _buscar_primera_ruta_valida([tmp_path / 'a', tmp_path / 'b']) is None

    def test_primera_ruta_valida(self, tmp_path):
        """Devuelve el primer candidato con la subcarpeta."""
        (tmp_path / 'b' / 'config').mkdir(parents=True)
        assert _buscar_primera_ruta_valida([tmp_path / 'a', tmp_path / 'b']) == tmp_path / 'b'

    def test_ejecutable_sin_config_usa_su_carpeta(self, tmp_path, monkeypatch):
        """
        Sin config/ cerca del binario, la
        raiz es la carpeta del binario.
        """
        monkeypatch.setattr('sys.frozen', True, raising=False)
        monkeypatch.setattr('sys.executable', str(tmp_path / 'bin' / 'sri'))
        assert resolver_raiz_proyecto() == (tmp_path / 'bin').resolve()

    def test_sin_modulo_usa_cwd(self, tmp_path, monkeypatch):
        """Sin ruta de modulo se parte del directorio actual."""
        monkeypatch.chdir(tmp_path)
        assert resolver_raiz_proyecto() == tmp_path


class TestVariablesYClaves:
    """Expansion de variables, referencias de clave y claves SSH."""

    def test_expandir_variables(self, monkeypatch):
        """$VAR y ${VAR} se expanden; las inexistentes quedan igual."""
        monkeypatch.setenv('DA_X', 'uno')
        assert expandir_variables_entorno('$DA_X-${DA_X}-$NO_DEFINIDA_X') == 'uno-uno-$NO_DEFINIDA_X'

    def test_referencia_password(self, monkeypatch, mock_logger):
        """Texto plano, variable existente, inexistente y vacia."""
        monkeypatch.setenv('DA_CLAVE', 's3')
        assert resolver_referencia_password('plano', mock_logger) == 'plano'
        assert resolver_referencia_password('${DA_CLAVE}', mock_logger) == 's3'
        assert resolver_referencia_password('$NO_EXISTE_DA', mock_logger) == ''
        assert resolver_referencia_password('', mock_logger) == ''

    def test_clave_ed25519(self):
        """La primera clase que carga la clave se usa."""
        with patch('app.da_comunes.paramiko.Ed25519Key.from_private_key_file', return_value='clave') as mock_ed:
            assert cargar_clave_privada('/k', 'pw') == 'clave'
        mock_ed.assert_called_once_with('/k', password='pw')

    def test_clave_rsa_si_no_es_ed25519(self):
        """Si Ed25519 falla se prueba RSA."""
        with (
            patch('app.da_comunes.paramiko.Ed25519Key.from_private_key_file', side_effect=paramiko.SSHException('no')),
            patch('app.da_comunes.paramiko.RSAKey.from_private_key_file', return_value='rsa'),
        ):
            assert cargar_clave_privada('/k') == 'rsa'

    def test_clave_con_passphrase_requerida(self):
        """PasswordRequiredException se propaga."""
        with patch('app.da_comunes.paramiko.Ed25519Key.from_private_key_file', side_effect=paramiko.PasswordRequiredException('pw')):
            with pytest.raises(paramiko.PasswordRequiredException):
                cargar_clave_privada('/k')

    def test_clave_ilegible(self):
        """Si ningun tipo carga la clave, ValueError con el detalle."""
        with (
            patch('app.da_comunes.paramiko.Ed25519Key.from_private_key_file', side_effect=paramiko.SSHException('a')),
            patch('app.da_comunes.paramiko.RSAKey.from_private_key_file', side_effect=paramiko.SSHException('b')),
            patch('app.da_comunes.paramiko.ECDSAKey.from_private_key_file', side_effect=paramiko.SSHException('c')),
        ):
            with pytest.raises(ValueError, match='Ed25519, RSA, ECDSA'):
                cargar_clave_privada('/k')

    def test_sin_paramiko(self, monkeypatch):
        """Sin paramiko instalado, ValueError claro."""
        monkeypatch.setattr('app.da_comunes.PARAMIKO_DISPONIBLE', False)
        with pytest.raises(ValueError, match='paramiko no esta instalado'):
            cargar_clave_privada('/k')

    def test_import_sin_paramiko(self, monkeypatch):
        """El modulo carga aunque paramiko no este instalado."""
        monkeypatch.setitem(sys.modules, 'paramiko', None)
        try:
            importlib.reload(modulo)
            assert modulo.PARAMIKO_DISPONIBLE is False
            assert modulo.paramiko is None
        finally:
            monkeypatch.delitem(sys.modules, 'paramiko')
            importlib.reload(modulo)
        assert modulo.PARAMIKO_DISPONIBLE is True
