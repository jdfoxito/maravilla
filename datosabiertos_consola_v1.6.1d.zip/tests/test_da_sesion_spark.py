"""
Tests de la sesion Spark y las opciones JDBC (da_sesion_spark).

SparkSession simulada. Cubre Spark Connect vs master clasico, pyspark
ausente, URL JDBC desde el alias y opciones sin usuario ni clave.
"""

import importlib
import sys
from unittest.mock import MagicMock, patch

import pytest

import app.da_sesion_spark as modulo
from app.da_sesion_spark import crear_sesion_spark, jdbc_desde_alias, opciones_jdbc


class TestCrearSesionSpark:
    """Connect (sc://) o master clasico segun la URL."""

    @staticmethod
    def _builder(mock_ss):
        """Builder fluido simulado."""
        builder = MagicMock()
        mock_ss.builder.appName.return_value = builder
        builder.remote.return_value = builder
        builder.master.return_value = builder
        return builder

    def test_spark_connect(self):
        """Spark connect."""
        with patch('app.da_sesion_spark.SparkSession') as mock_ss:
            builder = self._builder(mock_ss)
            sesion = crear_sesion_spark('sc://localhost:15002')
        builder.remote.assert_called_once_with('sc://localhost:15002')
        builder.master.assert_not_called()
        assert sesion is builder.getOrCreate.return_value

    def test_master_clasico(self):
        """Master clasico."""
        with patch('app.da_sesion_spark.SparkSession') as mock_ss:
            builder = self._builder(mock_ss)
            crear_sesion_spark('local[2]')
        builder.master.assert_called_once_with('local[2]')
        builder.remote.assert_not_called()

    def test_sin_pyspark(self):
        """Sin pyspark."""
        with patch('app.da_sesion_spark.SparkSession', None), pytest.raises(RuntimeError, match='pyspark'):
            crear_sesion_spark('sc://localhost:15002')


class TestJdbc:
    """URL y opciones JDBC autenticadas por wallet."""

    def test_jdbc_desde_alias(self):
        """Jdbc desde alias."""
        assert jdbc_desde_alias('SRIDW_MVEHICULAR') == 'jdbc:oracle:thin:/@SRIDW_MVEHICULAR'

    def test_opciones_sin_usuario_ni_clave(self):
        """Opciones sin usuario ni clave."""
        opts = opciones_jdbc('jdbc:oracle:thin:/@STAR_DESA', '/opt/oracle/wallets', '/opt/oracle/client_home/network/admin', 1000)
        assert opts == {
            'url': 'jdbc:oracle:thin:/@STAR_DESA',
            'driver': 'oracle.jdbc.OracleDriver',
            'oracle.net.wallet_location': '/opt/oracle/wallets',
            'oracle.net.tns_admin': '/opt/oracle/client_home/network/admin',
            'fetchsize': '1000',
        }
        assert 'user' not in opts and 'password' not in opts


class TestImportSinPyspark:
    """El modulo carga aunque pyspark no este instalado."""

    def test_sparksession_none(self, monkeypatch):
        """Sin pyspark, SparkSession queda en None."""
        monkeypatch.setitem(sys.modules, 'pyspark.sql', None)
        try:
            importlib.reload(modulo)
            assert modulo.SparkSession is None
        finally:
            monkeypatch.delitem(sys.modules, 'pyspark.sql')
            importlib.reload(modulo)
        assert modulo.SparkSession is not None
