"""
Tests de la dataclass ConsultaDefinicion (da_modelos).

Logica pura: sin mocks ni Spark. Cubre construccion
directa, valores por defecto, desde_dict() con JSON
completo/minimo, alias en ingles (partition_column,
num_partitions), destino como cadena y campos opcionales.
"""

from app.da_modelos import ConsultaDefinicion, SalidaArchivo, separar_receptores


class TestConstruccionDirecta:
    """Instanciacion directa de la dataclass con campos obligatorios."""

    def test_campos_obligatorios(self):
        """Los 4 campos sin default quedan asignados."""
        consulta = ConsultaDefinicion(id_='q1', nombre='Consulta 1', sql='SELECT 1 FROM DUAL', nombre_archivo='archivo')
        assert consulta.id_ == 'q1'
        assert consulta.nombre == 'Consulta 1'
        assert consulta.sql == 'SELECT 1 FROM DUAL'
        assert consulta.nombre_archivo == 'archivo'

    def test_valores_por_defecto(self):
        """Los opcionales toman sus defaults documentados."""
        consulta = ConsultaDefinicion(id_='q1', nombre='n', sql='s', nombre_archivo='a')
        assert consulta.columna_particion is None
        assert consulta.num_particiones == 1
        assert consulta.delimitador == '|'
        assert consulta.destino == {}
        assert consulta.wallet is None
        assert consulta.spark_url is None
        assert consulta.jdbc_url is None
        assert consulta.config_email is None
        assert consulta.anio is None
        assert consulta.mes_ini is None
        assert consulta.mes_fin is None
        assert consulta.proceso is None
        assert consulta.columnas == {}
        assert consulta.orden == []
        assert consulta.catalogos == {}

    def test_defaults_mutables_no_se_comparten(self):
        """
        field(default_factory): dos instancias
        NO comparten el mismo dict/list.
        """
        a = ConsultaDefinicion(id_='a', nombre='a', sql='s', nombre_archivo='a')
        b = ConsultaDefinicion(id_='b', nombre='b', sql='s', nombre_archivo='b')
        a.destino['tipo'] = 'local'
        a.columnas['x'] = 'X'
        a.orden.append({'columna': 'X'})
        assert b.destino == {}
        assert b.columnas == {}
        assert b.orden == []


class TestDesdeDictMinimo:
    """desde_dict con el JSON mas pequeno posible."""

    def test_json_vacio_usa_desconocido(self):
        """Sin 'id', id_/nombre/nombre_archivo caen en sus defaults."""
        consulta = ConsultaDefinicion.desde_dict({})
        assert consulta.id_ == 'desconocido'
        assert consulta.nombre == 'desconocido'
        assert consulta.nombre_archivo == 'exportacion'
        assert consulta.sql == ''

    def test_nombre_hereda_el_id(self):
        """Sin 'nombre' explicito, nombre = id."""
        consulta = ConsultaDefinicion.desde_dict({'id': 'mi_consulta'})
        assert consulta.nombre == 'mi_consulta'

    def test_nombre_archivo_hereda_el_id(self):
        """Sin 'nombre_archivo', se usa el id."""
        consulta = ConsultaDefinicion.desde_dict({'id': 'mi_consulta'})
        assert consulta.nombre_archivo == 'mi_consulta'

    def test_delimitador_default_pipe(self):
        """El delimitador por defecto es pipe (SDC)."""
        consulta = ConsultaDefinicion.desde_dict({'id': 'q'})
        assert consulta.delimitador == '|'


class TestDesdeDictCompleto:
    """desde_dict con todos los campos en espanol."""

    def test_todos_los_campos_en_espanol(self):
        """Cada clave del JSON cae en su atributo."""
        datos = {
            'id': 'facturacion_sql_historia5',
            'nombre': 'Catastro Vehicular',
            'sql': 'SELECT * FROM t WHERE anio = :ANIO',
            'nombre_archivo': 'Catastro_Vehicular',
            'columna_particion': 'codigo_vehiculo',
            'num_particiones': 8,
            'delimitador': ';',
            'destino': {'tipo': 'sftp', 'directorio_remoto': '/pub'},
            'wallet': '/oracle/wallet',
            'spark': 'sc://192.168.100.5:15002',
            'jdbc_url': 'jdbc:oracle:thin:@DETALLES',
            'email': {'smtp_server': 'localhost'},
            'anio': 2025,
            'mes_ini': 1,
            'mes_fin': 6,
            'proceso': 'proceso_caso2',
            'columnas': {'col_a': 'COL_A'},
            'orden': [{'columna': 'COL_A', 'ascendente': False}],
            'catalogos': {'canton_sql': 'SELECT 1 FROM DUAL'},
        }
        consulta = ConsultaDefinicion.desde_dict(datos)
        assert consulta.id_ == 'facturacion_sql_historia5'
        assert consulta.nombre == 'Catastro Vehicular'
        assert consulta.columna_particion == 'codigo_vehiculo'
        assert consulta.num_particiones == 8
        assert consulta.delimitador == ';'
        assert consulta.destino == {'tipo': 'sftp', 'directorio_remoto': '/pub'}
        assert consulta.wallet == '/oracle/wallet'
        assert consulta.spark_url == 'sc://192.168.100.5:15002'
        assert consulta.jdbc_url == 'jdbc:oracle:thin:@DETALLES'
        assert consulta.config_email == {'smtp_server': 'localhost'}
        assert consulta.anio == 2025
        assert consulta.mes_ini == 1
        assert consulta.mes_fin == 6
        assert consulta.proceso == 'proceso_caso2'
        assert consulta.columnas == {'col_a': 'COL_A'}
        assert consulta.orden == [{'columna': 'COL_A', 'ascendente': False}]
        assert consulta.catalogos == {'canton_sql': 'SELECT 1 FROM DUAL'}


class TestAliasCompatibilidad:
    """Los JSONs historicos en ingles siguen funcionando."""

    def test_partition_column_alias(self):
        """partition_column (ingles) llena columna_particion."""
        consulta = ConsultaDefinicion.desde_dict({'id': 'q', 'partition_column': 'ID_FILA'})
        assert consulta.columna_particion == 'ID_FILA'

    def test_num_partitions_alias(self):
        """num_partitions (ingles) llena num_particiones."""
        consulta = ConsultaDefinicion.desde_dict({'id': 'q', 'num_partitions': 16})
        assert consulta.num_particiones == 16

    def test_espanol_tiene_precedencia_sobre_alias(self):
        """Si vienen ambos, gana el nombre en espanol."""
        consulta = ConsultaDefinicion.desde_dict(
            {'id': 'q', 'columna_particion': 'COL_ES', 'partition_column': 'COL_EN', 'num_particiones': 4, 'num_partitions': 99}
        )
        assert consulta.columna_particion == 'COL_ES'
        assert consulta.num_particiones == 4

    def test_num_partitions_default_es_uno(self):
        """Sin ninguna de las dos claves, num_particiones = 1."""
        consulta = ConsultaDefinicion.desde_dict({'id': 'q'})
        assert consulta.num_particiones == 1


class TestDestinoNormalizacion:
    """destino puede venir como dict o como cadena (ruta remota)."""

    def test_destino_como_diccionario(self):
        """Un dict de destino pasa tal cual."""
        consulta = ConsultaDefinicion.desde_dict({'id': 'q', 'destino': {'tipo': 'sftp', 'directorio_remoto': '/x'}})
        assert consulta.destino == {'tipo': 'sftp', 'directorio_remoto': '/x'}

    def test_destino_como_cadena_se_convierte(self):
        """Una cadena se interpreta como directorio_remoto local."""
        consulta = ConsultaDefinicion.desde_dict({'id': 'q', 'destino': '/servidor/publico'})
        assert consulta.destino == {'tipo': 'local', 'directorio_remoto': '/servidor/publico'}

    def test_destino_ausente_es_dict_vacio(self):
        """Sin destino en el JSON, queda {}."""
        consulta = ConsultaDefinicion.desde_dict({'id': 'q'})
        assert consulta.destino == {}


class TestCamposPipeline:
    """proceso/columnas/orden/catalogos: defaults y carga desde JSON."""

    def test_sin_declaraciones_pipeline_vacio(self):
        """
        JSON historico (historias 1-3): todo el pipeline en vacio/None.
        """
        consulta = ConsultaDefinicion.desde_dict({'id': 'h1', 'sql': 'SELECT 1 FROM DUAL'})
        assert consulta.proceso is None
        assert consulta.columnas == {}
        assert consulta.orden == []
        assert consulta.catalogos == {}

    def test_catalogos_cargan(self):
        """catalogos.canton_sql llega al atributo."""
        consulta = ConsultaDefinicion.desde_dict({'id': 'h5', 'catalogos': {'canton_sql': 'SELECT CODIGO, DESCRIPCION FROM ADM.ADM_CANTON'}})
        assert 'canton_sql' in consulta.catalogos


class TestReceptoresYSufijo:
    """receptores, probar_sufijo y forma del archivo publicado."""

    def test_separar_receptores_coma_y_punto_y_coma(self):
        """Separar receptores coma y punto y coma."""
        assert separar_receptores('a@sri.gob.ec, b@sri.gob.ec; c@sri.gob.ec') == ['a@sri.gob.ec', 'b@sri.gob.ec', 'c@sri.gob.ec']

    def test_separar_receptores_lista_y_vacios(self):
        """Separar receptores lista y vacios."""
        assert separar_receptores(['a@x', ' ', '']) == ['a@x']
        assert separar_receptores('') == []
        assert separar_receptores(None) == []

    def test_receptores_reemplazan_to_addresses(self):
        """
        Los receptores del JSON van a config_email['to_addresses'].
        """
        consulta = ConsultaDefinicion.desde_dict({'id': 'q', 'receptores': 'jagonzalezj@sri.gob.ec', 'email': {'smtp_server': 's'}})
        assert consulta.config_email == {'smtp_server': 's', 'to_addresses': ['jagonzalezj@sri.gob.ec']}

    def test_sin_receptores_ni_email(self):
        """Sin receptores ni email."""
        assert ConsultaDefinicion.desde_dict({'id': 'q'}).config_email is None

    def test_probar_sufijo(self):
        """Probar sufijo."""
        assert ConsultaDefinicion.desde_dict({'id': 'q', 'probar_sufijo': ' _a '}).salida.sufijo == '_a'
        assert ConsultaDefinicion.desde_dict({'id': 'q', 'probar_sufijo': ''}).salida.sufijo == ''

    def test_salida_por_defecto(self):
        """Salida por defecto."""
        assert ConsultaDefinicion.desde_dict({'id': 'q'}).salida == SalidaArchivo()

    def test_salida_desde_json(self):
        """Salida desde json."""
        consulta = ConsultaDefinicion.desde_dict({'id': 'q', 'nombre_csv': 'SRI_x', 'comprimir': False, 'publicar': False})
        assert consulta.salida == SalidaArchivo(nombre_csv='SRI_x', comprimir=False, publicar=False)


class TestConexion:
    """
    La conexion del JSON es el alias TNS y la credencial del wallet.
    """

    def test_conexion_arma_jdbc(self):
        """Conexion arma jdbc."""
        consulta = ConsultaDefinicion.desde_dict({'id': 'q', 'conexion': 'SRIDW_MVEHICULAR'})
        assert consulta.wallet == 'SRIDW_MVEHICULAR'
        assert consulta.jdbc_url == 'jdbc:oracle:thin:/@SRIDW_MVEHICULAR'

    def test_jdbc_url_explicito_gana(self):
        """Jdbc url explicito gana."""
        consulta = ConsultaDefinicion.desde_dict({'id': 'q', 'conexion': 'STAR_DESA', 'jdbc_url': 'jdbc:oracle:thin:/@OTRO'})
        assert consulta.jdbc_url == 'jdbc:oracle:thin:/@OTRO'
