"""
Fixtures compartidas por los tests.

TOML minimo en tmp_path, exportador real con el diagnostico de
conectividad ya resuelto, y fabricas de consultas, servidores y
estados de conectividad de prueba. Se inyectan como fixtures, asi no
dependen de como pytest arme el sys.path.
"""

import json
import logging
from pathlib import Path
from typing import List, Optional
from unittest.mock import patch

import pytest

from app.da_conectividad import EstadoConectividad, EstadoServicio
from app.da_config_manager import ConfigManager
from app.da_exportador import ExportadorDatosAbiertos
from app.da_modelos import ConsultaDefinicion


def _crear_toml(tmp_path: Path) -> Path:
    """
    Escribe el TOML mínimo como texto (no bytes con %) y retorna
    la ruta. Los paths son las rutas reales dentro de tmp_path.
    """
    consultas = str(tmp_path / 'input' / 'consultas').replace('\\', '/')
    temp = str(tmp_path / 'temp').replace('\\', '/')
    logs = str(tmp_path / 'logs').replace('\\', '/')
    destino = str(tmp_path / 'destino_local').replace('\\', '/')

    contenido = '\n'.join(
        [
            '[general]',
            'fuente_config = "toml"',
            'forzar_toml = true',
            '',
            '[spark]',
            'url = "sc://localhost:15002"',
            'wallet_path = "/oracle/wallet"',
            'jdbc_url = "jdbc:oracle:thin:@STAR_BI_DWH"',
            '',
            '[email]',
            'smtp_server = ""',
            'smtp_port = 25',
            'from_address = "da@sri.gob.ec"',
            'to_addresses = ["admin@sri.gob.ec"]',
            '',
            '[rutas]',
            f'consultas = "{consultas}"',
            f'temp_local = "{temp}"',
            f'log_dir    = "{logs}"',
            f'destino_local = "{destino}"',
        ]
    )

    config_dir = tmp_path / 'config'
    config_dir.mkdir(exist_ok=True)
    toml_file = config_dir / 'configtest.toml'
    toml_file.write_text(contenido, encoding='utf-8')
    return toml_file


def _estado_conectividad(correo: bool = True, servidores: Optional[List[str]] = None) -> EstadoConectividad:
    """
    Diagnostico simulado: correo y servidores (ip) con o sin acceso.
    """
    return EstadoConectividad(
        correo=EstadoServicio('Correo', 'smtp:25', correo, 'simulado'),
        servidores=[EstadoServicio(ip, f'{ip}:22', True, 'simulado') for ip in servidores or []],
    )


def _crear_exportador(toml_path: Path, conectividad: Optional[EstadoConectividad] = None) -> ExportadorDatosAbiertos:
    """
    Crea el exportador real con el TOML de test y un diagnostico de
    conectividad ya resuelto (no abre sockets).
    """
    logger = logging.getLogger('test_exportador')
    logger.addHandler(logging.NullHandler())
    gestor = ConfigManager(str(toml_path), logger)
    with patch('app.da_exportador.get_config_manager', return_value=gestor):
        exp = ExportadorDatosAbiertos(str(toml_path), logger)
    exp._conectividad = conectividad or _estado_conectividad()
    return exp


def _consulta_prueba(**override):
    """ConsultaDefinicion de prueba."""
    datos = {'id': 'q_test', 'sql': 'SELECT 1 FROM DUAL'}
    datos.update(override)
    return ConsultaDefinicion.desde_dict(datos)


def _servidor_prueba(**override):
    """Configuracion de un servidor SFTP."""
    base = {'nombre': 'Quito', 'ip': '10.0.0.1', 'usuario': 'da', 'puerto': 22, 'ruta_remota': '/pub/datos'}
    base.update(override)
    return base


@pytest.fixture
def exportador(tmp_path):
    """ExportadorDatosAbiertos listo con TOML de test."""
    toml_path = _crear_toml(tmp_path)
    (tmp_path / 'input' / 'consultas').mkdir(parents=True, exist_ok=True)
    return _crear_exportador(toml_path)


@pytest.fixture
def dir_consultas(tmp_path):
    """Directorio de consultas con el TOML ya creado."""
    _crear_toml(tmp_path)
    directorio = tmp_path / 'input' / 'consultas'
    directorio.mkdir(parents=True, exist_ok=True)
    return directorio, tmp_path


@pytest.fixture
def exportador_con_consultas(tmp_path):
    """Exportador + dos JSONs de consulta cargados."""
    toml_path = _crear_toml(tmp_path)
    dir_c = tmp_path / 'input' / 'consultas'
    dir_c.mkdir(parents=True, exist_ok=True)

    for datos in [
        {'id': 'facturacion_sql_historia1', 'nombre': 'Historia 1', 'sql': 'SELECT * FROM t WHERE anio = :ANIO', 'nombre_archivo': 'SRI_auto'},
        {
            'id': 'facturacion_sql_historia2',
            'nombre': 'Historia 2',
            'sql': 'SELECT * FROM t2 WHERE mes BETWEEN :MES_INI AND :MES_FIN',
            'nombre_archivo': 'Comprobantes_CEL',
        },
    ]:
        (dir_c / f"{datos['id']}.json").write_text(json.dumps(datos), encoding='utf-8')
    return _crear_exportador(toml_path)


@pytest.fixture
def crear_exportador():
    """Fabrica de exportadores a partir de un TOML de prueba."""
    return _crear_exportador


@pytest.fixture
def estado_conectividad():
    """Fabrica de diagnosticos de conectividad simulados."""
    return _estado_conectividad


@pytest.fixture
def consulta_prueba():
    """Fabrica de consultas de prueba."""
    return _consulta_prueba


@pytest.fixture
def servidor_prueba():
    """Fabrica de configuraciones de servidor SFTP de prueba."""
    return _servidor_prueba
