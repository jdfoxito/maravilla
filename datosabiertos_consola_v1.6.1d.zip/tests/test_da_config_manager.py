"""
Tests del ConfigManager (da_config_manager).

TOML reales en tmp_path, sin red. Cubre carga, expansion de
variables ($VAR y ${VAR}), resolucion de claves (variable inexistente
da cadena vacia), getters, deteccion de plataforma, lectura de
parametros desde Oracle simulada y el ConfigManager compartido.
"""

import importlib
import logging
import platform
from pathlib import Path
from unittest.mock import MagicMock

import pytest

import app.da_config_manager as modulo
from app.da_config_manager import ConfigManager, get_config_manager, reiniciar_config_manager


def _escribir_toml(directorio: Path, nombre: str, contenido: str) -> Path:
    """Crea config/<nombre> dentro de directorio y devuelve la ruta."""
    cfg_dir = directorio / 'config'
    cfg_dir.mkdir(exist_ok=True)
    ruta = cfg_dir / nombre
    ruta.write_text(contenido, encoding='utf-8')
    return ruta


_TOML_BASE = (
    '[general]\n'
    'fuente_config = "toml"\n'
    'forzar_toml = true\n'
    '\n'
    '[spark]\n'
    'url = "sc://localhost:15002"\n'
    'wallet_path = "/opt/wallet"\n'
    'jdbc_url = "jdbc:oracle:thin:/@STAR"\n'
    '\n'
    '[email]\n'
    'smtp_server = "mail.sri.ad"\n'
    'smtp_port = 587\n'
    'use_tls = true\n'
    'password = "$PWD_CORREO"\n'
    'from_address = "datosabiertos@sri.ad"\n'
    'to_addresses = ["admin@sri.ad", "dev@sri.ad"]\n'
    '\n'
    '[verificacion]\n'
    'patrones_archivos = ["facturacion"]\n'
    'tamanio_minimo_bytes = 2048\n'
    '\n'
    '[servidor_descarga_1]\n'
    'nombre = "Quito"\n'
    'ip = "10.0.0.1"\n'
    'ruta_remota = "/data"\n'
    'usuario = "sri"\n'
    'password = "plano"\n'
    '\n'
    '[rutas]\n'
    'consultas = "input/consultas"\n'
    'temp_local = "temp"\n'
    'log_dir = "logs"\n'
    'destino_local = "destino_local"\n'
    '\n'
    '[destino_default]\n'
    'tipo = "local"\n'
    'directorio_remoto = "destino_local"\n'
    '\n'
    '[oracle]\n'
    'jdbc_url = "jdbc:oracle:thin:/@STAR"\n'
    'codigo_aplicacion = "DAT"\n'
    'ambiente = "PRO"\n'
)


@pytest.fixture
def mock_logger(tmp_path):
    """Logger real escribiendo a archivo temporal para inspeccion."""
    logger = logging.getLogger('test_config_manager')
    logger.setLevel(logging.DEBUG)
    handler = logging.FileHandler(tmp_path / 'test.log')
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    yield logger
    logger.removeHandler(handler)
    handler.close()


@pytest.fixture(autouse=True)
def _aislar_singleton():
    """Aisla el singleton entre tests."""
    reiniciar_config_manager()
    yield
    reiniciar_config_manager()


@pytest.fixture
def toml_base():
    """Retorna el TOML base como string."""
    return _TOML_BASE


class TestCargaToml:
    """Carga basica del TOML y validacion de ruta."""

    def test_carga_ruta_explicita(self, tmp_path, mock_logger):
        """Con ruta_toml explicita se carga ese archivo."""
        ruta = _escribir_toml(tmp_path, 'config.toml', _TOML_BASE)
        cm = ConfigManager(str(ruta), mock_logger)
        assert cm.get('general')['fuente_config'] == 'toml'
        assert cm.ruta_toml == ruta

    def test_archivo_inexistente_levanta(self, tmp_path, mock_logger):
        """Una ruta inexistente levanta FileNotFoundError."""
        with pytest.raises(FileNotFoundError):
            ConfigManager(str(tmp_path / 'no_existe.toml'), mock_logger)

    def test_carga_con_ruta_none_detecta_automaticamente(self, tmp_path, mock_logger, monkeypatch):
        """Si ruta_toml es None, detecta el archivo segun plataforma."""
        _escribir_toml(tmp_path, 'config.toml', _TOML_BASE)
        monkeypatch.setattr(ConfigManager, '_detectar_ruta_base', lambda self: tmp_path)
        cm = ConfigManager(None, mock_logger)
        assert cm.ruta_toml.exists()

    def test_carga_toml_con_listas_anidadas(self, tmp_path, mock_logger, monkeypatch):
        """
        _procesar_config expande variables dentro de listas anidadas.
        """
        toml = (
            '[general]\n'
            'fuente_config = "toml"\n'
            'forzar_toml = true\n'
            '\n'
            '[lista]\n'
            'items = [{nombre = "a", valor = "$VAR_A"}, {nombre = "b", valor = "$VAR_B"}]\n'
        )
        ruta = _escribir_toml(tmp_path, 'config.toml', toml)
        monkeypatch.setenv('VAR_A', 'uno')
        monkeypatch.setenv('VAR_B', 'dos')
        cm = ConfigManager(str(ruta), mock_logger)
        items = cm.get('lista')['items']
        assert items[0]['valor'] == 'uno'
        assert items[1]['valor'] == 'dos'


class TestExpansionVariables:
    """_expandir_variables, _procesar_config y _resolver_password."""

    def test_expande_password_email(self, tmp_path, mock_logger, monkeypatch):
        """get_email_config resuelve $PWD_CORREO desde el entorno."""
        monkeypatch.setenv('PWD_CORREO', 'sekret')
        ruta = _escribir_toml(tmp_path, 'config.toml', _TOML_BASE)
        cm = ConfigManager(str(ruta), mock_logger)
        assert cm.get_email_config()['password'] == 'sekret'

    def test_expandir_no_str_devuelve_igual(self, tmp_path, mock_logger):
        """
        _expandir_variables sobre tipos
        no-str devuelve el valor original.
        """
        ruta = _escribir_toml(tmp_path, 'config.toml', _TOML_BASE)
        cm = ConfigManager(str(ruta), mock_logger)
        assert cm._expandir_variables(123) == 123
        assert cm._expandir_variables(45.67) == 45.67
        assert cm._expandir_variables(True) is True
        assert cm._expandir_variables(None) is None

    def test_resolver_password_var_inexistente(self, tmp_path, mock_logger):
        """
        _resolver_password con $VAR no definido -> '' (da_comunes).
        """
        ruta = _escribir_toml(tmp_path, 'config.toml', _TOML_BASE)
        cm = ConfigManager(str(ruta), mock_logger)
        assert cm._resolver_password('$NO_DEF_XYZ') == ''

    def test_resolver_password_texto_plano(self, tmp_path, mock_logger):
        """_resolver_password con texto plano lo devuelve igual."""
        ruta = _escribir_toml(tmp_path, 'config.toml', _TOML_BASE)
        cm = ConfigManager(str(ruta), mock_logger)
        assert cm._resolver_password('clave') == 'clave'

    def test_resolver_password_sintaxis_llaves(self, tmp_path, mock_logger, monkeypatch):
        """_resolver_password acepta ${VAR} ademas de $VAR."""
        monkeypatch.setenv('MI_CLAVE', 'valor_llaves')
        ruta = _escribir_toml(tmp_path, 'config.toml', _TOML_BASE)
        cm = ConfigManager(str(ruta), mock_logger)
        assert cm._resolver_password('${MI_CLAVE}') == 'valor_llaves'

    def test_resolver_password_vacio(self, tmp_path, mock_logger):
        """_resolver_password con string vacio retorna ''."""
        ruta = _escribir_toml(tmp_path, 'config.toml', _TOML_BASE)
        cm = ConfigManager(str(ruta), mock_logger)
        assert cm._resolver_password('') == ''

    @pytest.mark.parametrize('entrada,esperado', [('$VAR_A', 'uno'), ('${VAR_A}', 'uno'), ('${VAR_A}_${VAR_B}', 'uno_dos')])
    def test_expandir_variables_parametrizado(self, tmp_path, mock_logger, monkeypatch, entrada, esperado):
        """_expandir_variables con multiples sintaxis de variable.

        Nota: da_comunes.expandir_variables_entorno NO expande variables
        en medio de texto (ej: prefijo_$VAR_sufijo). Solo al inicio o
        como token completo separado por _.
        """
        monkeypatch.setenv('VAR_A', 'uno')
        monkeypatch.setenv('VAR_B', 'dos')
        ruta = _escribir_toml(tmp_path, 'config.toml', _TOML_BASE)
        cm = ConfigManager(str(ruta), mock_logger)
        resultado = cm._expandir_variables(entrada)
        assert resultado == esperado

    def test_procesar_config_con_diccionario_anidado(self, tmp_path, mock_logger, monkeypatch):
        """
        _procesar_config expande recursivamente
        en diccionarios anidados.
        """
        toml = '[general]\nfuente_config = "toml"\nforzar_toml = true\n\n[nivel1]\n[nivel1.nivel2]\nvalor = "$VAR_NEST"\n'
        monkeypatch.setenv('VAR_NEST', 'anidado_ok')
        ruta = _escribir_toml(tmp_path, 'config.toml', toml)
        cm = ConfigManager(str(ruta), mock_logger)
        assert cm.get('nivel1')['nivel2']['valor'] == 'anidado_ok'


@pytest.fixture
def cm(tmp_path, mock_logger):
    """ConfigManager cargado con el TOML base."""
    ruta = _escribir_toml(tmp_path, 'config.toml', _TOML_BASE)
    return ConfigManager(str(ruta), mock_logger)


class TestGetters:
    """Getters de Spark, correo, verificacion y servidores."""

    def test_get_spark_config(self, cm):
        """get_spark_config mapea url, wallet y defaults."""
        spark = cm.get_spark_config()
        assert spark['spark_url'] == 'sc://localhost:15002'
        assert spark['wallet_path'] == '/opt/wallet'
        assert spark['jdbc_url'] == 'jdbc:oracle:thin:/@STAR'
        assert spark['partitions_default'] == 16
        assert spark['fetch_size'] == 500000
        assert spark['driver_memory'] == '8g'
        assert spark['executor_memory'] == '8g'
        assert spark['oracle_home'] == ''

    def test_get_spark_config_warning_wallet_no_definido(self, tmp_path, mock_logger):
        """
        get_spark_config loguea warning si wallet_path no esta definido.
        """
        toml = '[general]\nfuente_config = "toml"\nforzar_toml = true\n[spark]\nurl = "sc://localhost:15002"\n'
        ruta = _escribir_toml(tmp_path, 'config.toml', toml)
        cm = ConfigManager(str(ruta), mock_logger)
        spark = cm.get_spark_config()
        assert spark['wallet_path'] == ''

    def test_get_email_config(self, cm):
        """get_email_config trae todos los campos del TOML."""
        email = cm.get_email_config()
        assert email['smtp_server'] == 'mail.sri.ad'
        assert email['smtp_port'] == 587
        assert email['use_tls'] is True
        assert email['from_address'] == 'datosabiertos@sri.ad'
        assert email['to_addresses'] == ['admin@sri.ad', 'dev@sri.ad']
        assert email['timeout'] == 15
        assert email['username'] == ''

    def test_get_email_config_password_resuelta(self, tmp_path, mock_logger, monkeypatch):
        """
        get_email_config resuelve password desde variable de entorno.
        """
        monkeypatch.setenv('PWD_CORREO', 'super_secreto')
        ruta = _escribir_toml(tmp_path, 'config.toml', _TOML_BASE)
        cm = ConfigManager(str(ruta), mock_logger)
        email = cm.get_email_config()
        assert email['password'] == 'super_secreto'

    def test_get_verificacion_config(self, cm):
        """get_verificacion_config lee patrones y tamanio minimo."""
        ver = cm.get_verificacion_config()
        assert ver['patrones_archivos'] == ['facturacion']
        assert ver['tamanio_minimo_bytes'] == 2048

    def test_get_servidores_descarga(self, cm):
        """Lee dinamicamente [servidor_descarga_1]."""
        servidores = cm.get_servidores_descarga()
        assert len(servidores) == 1
        assert servidores[0]['nombre'] == 'Quito'
        assert servidores[0]['ip'] == '10.0.0.1'
        assert servidores[0]['ruta_remota'] == '/data'
        assert servidores[0]['usuario'] == 'sri'
        assert servidores[0]['password'] == 'plano'
        assert servidores[0]['key_file'] == ''
        assert servidores[0]['puerto'] == 22

    def test_get_servidores_descarga_multiples(self, tmp_path, mock_logger):
        """
        Lee dinamicamente [servidor_descarga_1] y [servidor_descarga_2].
        """
        toml = _TOML_BASE + (
            '\n[servidor_descarga_2]\n'
            'nombre = "Guayaquil"\n'
            'ip = "10.0.0.2"\n'
            'ruta_remota = "/data2"\n'
            'usuario = "sri2"\n'
            'password = "$PWD_GYE"\n'
            'puerto = 2222\n'
        )
        ruta = _escribir_toml(tmp_path, 'config.toml', toml)
        cm = ConfigManager(str(ruta), mock_logger)
        servidores = cm.get_servidores_descarga()
        assert len(servidores) == 2
        assert servidores[1]['nombre'] == 'Guayaquil'
        assert servidores[1]['puerto'] == 2222

    def test_get_servidores_descarga_vacio(self, tmp_path, mock_logger):
        """Sin secciones servidor_descarga_N retorna lista vacia."""
        toml = '[general]\nfuente_config = "toml"\nforzar_toml = true\n'
        ruta = _escribir_toml(tmp_path, 'config.toml', toml)
        cm = ConfigManager(str(ruta), mock_logger)
        servidores = cm.get_servidores_descarga()
        assert servidores == []


class TestGettersDestinoYRutas:
    """Getters de destino, rutas, Oracle y configuracion cruda."""

    def test_get_destino_default_local(self, cm):
        """
        destino_default sin seccion SMB/SFTP
        -> tipo local con directorio.
        """
        destino = cm.get_destino_default()
        assert destino['tipo'] == 'local'
        assert 'directorio_remoto' in destino
        assert 'host' not in destino

    def test_get_destino_default_smb(self, tmp_path, mock_logger, monkeypatch):
        """get_destino_default con tipo smb mapea todos los campos."""
        toml = (
            '[general]\n'
            'fuente_config = "toml"\n'
            'forzar_toml = true\n'
            '\n'
            '[destino_default]\n'
            'tipo = "smb"\n'
            "directorio_remoto = '\\\\srv\\share'\n"
            '\n'
            '[destino_default.smb]\n'
            'host = "srv.sri.ad"\n'
            'puerto = 445\n'
            'share = "datos"\n'
            'usuario = "sri_user"\n'
            'password = "$PWD_SMB"\n'
            'dominio = "SRI"\n'
        )
        monkeypatch.setenv('PWD_SMB', 'smb_secret')
        ruta = _escribir_toml(tmp_path, 'config.toml', toml)
        cm = ConfigManager(str(ruta), mock_logger)
        destino = cm.get_destino_default()
        assert destino['tipo'] == 'smb'
        assert destino['host'] == 'srv.sri.ad'
        assert destino['puerto'] == 445
        assert destino['share'] == 'datos'
        assert destino['usuario'] == 'sri_user'
        assert destino['password'] == 'smb_secret'
        assert destino['dominio'] == 'SRI'

    def test_get_destino_default_sftp(self, tmp_path, mock_logger, monkeypatch):
        """get_destino_default con tipo sftp mapea todos los campos."""
        toml = (
            '[general]\n'
            'fuente_config = "toml"\n'
            'forzar_toml = true\n'
            '\n'
            '[destino_default]\n'
            'tipo = "sftp"\n'
            'directorio_remoto = "/remoto"\n'
            '\n'
            '[destino_default.sftp]\n'
            'host = "sftp.sri.ad"\n'
            'puerto = 22\n'
            'usuario = "sftp_user"\n'
            'password = "$PWD_SFTP"\n'
            'key_file = "/home/user/.ssh/id_rsa"\n'
        )
        monkeypatch.setenv('PWD_SFTP', 'sftp_secret')
        ruta = _escribir_toml(tmp_path, 'config.toml', toml)
        cm = ConfigManager(str(ruta), mock_logger)
        destino = cm.get_destino_default()
        assert destino['tipo'] == 'sftp'
        assert destino['host'] == 'sftp.sri.ad'
        assert destino['puerto'] == 22
        assert destino['usuario'] == 'sftp_user'
        assert destino['password'] == 'sftp_secret'
        assert destino['key_file'] == '/home/user/.ssh/id_rsa'

    def test_get_destino_default_smb_sin_bloque_smb(self, tmp_path, mock_logger):
        """
        tipo smb sin bloque [destino_default.smb]
        solo retorna tipo y directorio.
        """
        toml = (
            '[general]\n'
            'fuente_config = "toml"\n'
            'forzar_toml = true\n'
            '\n'
            '[destino_default]\n'
            'tipo = "smb"\n'
            "directorio_remoto = '\\\\srv\\share'\n"
        )
        ruta = _escribir_toml(tmp_path, 'config.toml', toml)
        cm = ConfigManager(str(ruta), mock_logger)
        destino = cm.get_destino_default()
        assert destino['tipo'] == 'smb'
        assert destino['directorio_remoto'] == r'\\srv\share'
        assert 'host' not in destino
        assert 'puerto' not in destino
        assert 'share' not in destino
        assert 'usuario' not in destino
        assert 'password' not in destino
        assert 'dominio' not in destino

    def test_debe_usar_oracle_false_si_forzado(self, cm):
        """forzar_toml=true -> debe_usar_oracle False."""
        assert cm.debe_usar_oracle() is False

    def test_get_raw_config_es_copia(self, cm):
        """get_raw_config devuelve una copia mutable independiente."""
        raw = cm.get_raw_config()
        raw['general'] = 'mutado'
        assert cm.get('general') != 'mutado'

    def test_get_raw_config_contiene_todo(self, cm):
        """get_raw_config contiene todas las secciones cargadas."""
        raw = cm.get_raw_config()
        assert 'general' in raw
        assert 'spark' in raw
        assert 'email' in raw
        assert 'rutas' in raw
        assert 'oracle' in raw

    def test_get_rutas_crea_directorios(self, cm):
        """get_rutas devuelve Paths y crea los directorios base."""
        rutas = cm.get_rutas()
        assert isinstance(rutas['temp'], Path)
        assert isinstance(rutas['logs'], Path)
        assert isinstance(rutas['destino_local'], Path)
        assert isinstance(rutas['mails'], Path)
        assert isinstance(rutas['consultas'], Path)
        assert isinstance(rutas['base'], Path)
        assert rutas['logs'].exists()
        assert rutas['mails'].exists()

    def test_get_rutas_con_variables_entorno(self, tmp_path, mock_logger, monkeypatch):
        """get_rutas expande variables de entorno en las rutas."""
        monkeypatch.setenv('RUTA_TEMP', str(tmp_path / 'mi_temp'))
        toml = (
            '[general]\n'
            'fuente_config = "toml"\n'
            'forzar_toml = true\n'
            '[rutas]\n'
            'temp_local = "$RUTA_TEMP"\n'
            'log_dir = "logs"\n'
            'consultas = "input"\n'
            'destino_local = "destino"\n'
        )
        ruta = _escribir_toml(tmp_path, 'config.toml', toml)
        cm = ConfigManager(str(ruta), mock_logger)
        rutas = cm.get_rutas()
        assert str(rutas['temp']) == str(tmp_path / 'mi_temp')
        assert rutas['temp'].exists()

    def test_get_oracle_config(self, cm):
        """get_oracle_config retorna la seccion oracle completa."""
        oracle = cm.get_oracle_config()
        assert oracle['jdbc_url'] == 'jdbc:oracle:thin:/@STAR'
        assert oracle['codigo_aplicacion'] == 'DAT'
        assert oracle['ambiente'] == 'PRO'

    def test_get_oracle_config_vacio(self, tmp_path, mock_logger):
        """get_oracle_config retorna {} si no hay seccion oracle."""
        toml = '[general]\nfuente_config = "toml"\nforzar_toml = true\n'
        ruta = _escribir_toml(tmp_path, 'config.toml', toml)
        cm = ConfigManager(str(ruta), mock_logger)
        assert cm.get_oracle_config() == {}

    def test_get_con_default(self, cm):
        """
        get con default retorna el default si la seccion no existe.
        """
        assert cm.get('no_existe', 'default_val') == 'default_val'
        assert cm.get('no_existe') is None


class TestDebeUsarOracle:
    """Logica de debe_usar_oracle segun fuente_config."""

    def test_fuente_oracle_sin_forzar(self, tmp_path, mock_logger, monkeypatch):
        """fuente_config=oracle y forzar_toml=false -> True."""
        toml = '[general]\nfuente_config = "oracle"\nforzar_toml = false\n[spark]\nurl="sc://test"\nwallet_path="/w"\njdbc_url="j"\n'
        ruta = _escribir_toml(tmp_path, 'config.toml', toml)
        monkeypatch.setattr(ConfigManager, '_cargar_desde_oracle', lambda self: None)
        cm = ConfigManager(str(ruta), mock_logger)
        assert cm.debe_usar_oracle() is True

    def test_fuente_ambos_sin_forzar(self, tmp_path, mock_logger, monkeypatch):
        """fuente_config=ambos y forzar_toml=false -> True."""
        toml = '[general]\nfuente_config = "ambos"\nforzar_toml = false\n[spark]\nurl="sc://test"\nwallet_path="/w"\njdbc_url="j"\n'
        ruta = _escribir_toml(tmp_path, 'config.toml', toml)
        monkeypatch.setattr(ConfigManager, '_cargar_desde_oracle', lambda self: None)
        cm = ConfigManager(str(ruta), mock_logger)
        assert cm.debe_usar_oracle() is True

    def test_fuente_toml_sin_forzar(self, tmp_path, mock_logger):
        """fuente_config=toml -> False."""
        toml = '[general]\nfuente_config = "toml"\nforzar_toml = false\n'
        ruta = _escribir_toml(tmp_path, 'config.toml', toml)
        cm = ConfigManager(str(ruta), mock_logger)
        assert cm.debe_usar_oracle() is False

    def test_forzar_toml_anula_fuente_oracle(self, tmp_path, mock_logger):
        """forzar_toml=true anula cualquier fuente_config."""
        toml = '[general]\nfuente_config = "oracle"\nforzar_toml = true\n'
        ruta = _escribir_toml(tmp_path, 'config.toml', toml)
        cm = ConfigManager(str(ruta), mock_logger)
        assert cm.debe_usar_oracle() is False


class TestDeteccionRutas:
    """_detectar_ruta_base en diferentes plataformas."""

    def test_detecta_ruta_linux(self, tmp_path, mock_logger, monkeypatch):
        """En Linux con ruta estandar presente, usa esa ruta."""
        monkeypatch.setattr(platform, 'system', lambda: 'Linux')
        fake_linux = tmp_path / 'sri_datos_abiertos_facturacion'
        fake_linux.mkdir()
        monkeypatch.setattr(ConfigManager, '_detectar_ruta_base', lambda self: fake_linux)
        _escribir_toml(fake_linux, 'configlnx.toml', _TOML_BASE)
        cm = ConfigManager(None, mock_logger)
        assert cm.ruta_base == fake_linux

    def test_detecta_ruta_windows(self, tmp_path, mock_logger, monkeypatch):
        """En Windows con ruta estandar presente, usa esa ruta."""
        monkeypatch.setattr(platform, 'system', lambda: 'Windows')
        fake_win = tmp_path / 'datosabiertos'
        fake_win.mkdir()
        monkeypatch.setattr(ConfigManager, '_detectar_ruta_base', lambda self: fake_win)
        _escribir_toml(fake_win, 'configwin.toml', _TOML_BASE)
        cm = ConfigManager(None, mock_logger)
        assert cm.ruta_base == fake_win


class TestDeteccionArchivo:
    """_detectar_archivo_config segun plataforma."""

    def test_detecta_configlnx_en_linux(self, tmp_path, mock_logger, monkeypatch):
        """
        En Linux con configlnx.toml presente, se selecciona ese archivo.
        """
        monkeypatch.setattr(platform, 'system', lambda: 'Linux')
        _escribir_toml(tmp_path, 'configlnx.toml', _TOML_BASE)
        monkeypatch.setattr(ConfigManager, '_detectar_ruta_base', lambda self: tmp_path)
        cm = ConfigManager(None, mock_logger)
        assert cm.ruta_toml.name == 'configlnx.toml'

    def test_fallback_config_toml_si_configlnx_no_existe(self, tmp_path, mock_logger, monkeypatch):
        """En Linux sin configlnx.toml, fallback a config.toml."""
        monkeypatch.setattr(platform, 'system', lambda: 'Linux')
        _escribir_toml(tmp_path, 'config.toml', _TOML_BASE)
        monkeypatch.setattr(ConfigManager, '_detectar_ruta_base', lambda self: tmp_path)
        cm = ConfigManager(None, mock_logger)
        assert cm.ruta_toml.name == 'config.toml'

    def test_detecta_configwin_en_windows(self, tmp_path, mock_logger, monkeypatch):
        """
        En Windows con configwin.toml
        presente, se selecciona ese archivo.
        """
        monkeypatch.setattr(platform, 'system', lambda: 'Windows')
        _escribir_toml(tmp_path, 'configwin.toml', _TOML_BASE)
        monkeypatch.setattr(ConfigManager, '_detectar_ruta_base', lambda self: tmp_path)
        cm = ConfigManager(None, mock_logger)
        assert cm.ruta_toml.name == 'configwin.toml'

    def test_fallback_config_toml_si_configwin_no_existe(self, tmp_path, mock_logger, monkeypatch):
        """En Windows sin configwin.toml, fallback a config.toml."""
        monkeypatch.setattr(platform, 'system', lambda: 'Windows')
        _escribir_toml(tmp_path, 'config.toml', _TOML_BASE)
        monkeypatch.setattr(ConfigManager, '_detectar_ruta_base', lambda self: tmp_path)
        cm = ConfigManager(None, mock_logger)
        assert cm.ruta_toml.name == 'config.toml'

    def test_warning_si_ninguno_existe(self, tmp_path, mock_logger, monkeypatch):
        """
        Si ningun archivo existe, loguea warning
        y _cargar_toml levanta FileNotFoundError.
        """
        monkeypatch.setattr(platform, 'system', lambda: 'Linux')
        monkeypatch.setattr(ConfigManager, '_detectar_ruta_base', lambda self: tmp_path)
        with pytest.raises(FileNotFoundError):
            ConfigManager(None, mock_logger)


class TestCargaDesdeOracle:
    """
    _cargar_desde_oracle con crear_sesion_spark
    y ParametrosOracle simulados.
    """

    @pytest.fixture
    def toml_oracle(self):
        """
        TOML con fuente_config=oracle para probar carga desde Oracle.
        """
        return (
            '[general]\n'
            'fuente_config = "oracle"\n'
            'forzar_toml = false\n'
            '\n'
            '[spark]\n'
            'url = "sc://spark:15002"\n'
            'wallet_path = "/opt/wallet"\n'
            'jdbc_url = "jdbc:oracle:thin:/@STAR"\n'
            '\n'
            '[oracle]\n'
            'jdbc_url = "jdbc:oracle:thin:/@STAR"\n'
            'codigo_aplicacion = "DAT"\n'
            'ambiente = "PRO"\n'
            '\n'
            '[email]\n'
            'smtp_server = "toml_server"\n'
        )

    def test_carga_desde_oracle_exitosa(self, tmp_path, mock_logger, toml_oracle, monkeypatch):
        """
        _cargar_desde_oracle complementa
        config con parametros de Oracle.
        """
        ruta = _escribir_toml(tmp_path, 'config.toml', toml_oracle)

        mock_spark = MagicMock()
        monkeypatch.setattr('app.da_config_manager.crear_sesion_spark', lambda url: mock_spark)
        monkeypatch.setattr('app.da_config_manager.HAS_PYSPARK', True)

        mock_lector = MagicMock()
        mock_lector.obtener_todos_parametros.return_value = {
            'email': {'smtp_server': 'oracle_server', 'smtp_port': 25},
            'verificacion': {'tamanio_minimo_bytes': 4096},
            'servidor_descarga_1': {'ip': '1.1.1.1'},
            'spark': {'url': 'no_debe_sobreescribirse'},
        }
        monkeypatch.setattr('app.da_config_manager.ParametrosOracle', lambda *args, **kwargs: mock_lector)

        cm = ConfigManager(str(ruta), mock_logger)

        assert cm.get('email')['smtp_server'] == 'oracle_server'
        assert cm.get('spark')['url'] == 'sc://spark:15002'
        assert cm.get('verificacion')['tamanio_minimo_bytes'] == 4096

        mock_spark.stop.assert_called_once()

    def test_carga_desde_oracle_sin_pyspark(self, tmp_path, mock_logger, toml_oracle, monkeypatch):
        """
        Sin pyspark disponible, _cargar_desde_oracle retorna sin error.
        """
        ruta = _escribir_toml(tmp_path, 'config.toml', toml_oracle)
        monkeypatch.setattr('app.da_config_manager.HAS_PYSPARK', False)
        cm = ConfigManager(str(ruta), mock_logger)
        assert cm.get('email')['smtp_server'] == 'toml_server'

    def test_carga_desde_oracle_falta_jdbc_url(self, tmp_path, mock_logger, monkeypatch):
        """
        Sin jdbc_url o spark_url, loguea warning y no consulta Oracle.
        """
        toml = '[general]\nfuente_config = "oracle"\nforzar_toml = false\n[spark]\nurl = ""\nwallet_path = ""\n'
        ruta = _escribir_toml(tmp_path, 'config.toml', toml)
        monkeypatch.setattr('app.da_config_manager.HAS_PYSPARK', True)
        cm = ConfigManager(str(ruta), mock_logger)
        assert cm.get('general')['fuente_config'] == 'oracle'

    def test_carga_desde_oracle_runtime_error(self, tmp_path, mock_logger, toml_oracle, monkeypatch):
        """RuntimeError en Spark se captura y loguea como warning."""
        ruta = _escribir_toml(tmp_path, 'config.toml', toml_oracle)

        monkeypatch.setattr('app.da_config_manager.crear_sesion_spark', MagicMock(side_effect=RuntimeError('Spark caido')))
        monkeypatch.setattr('app.da_config_manager.HAS_PYSPARK', True)

        cm = ConfigManager(str(ruta), mock_logger)
        assert cm.get('general')['fuente_config'] == 'oracle'

    def test_carga_desde_oracle_os_error(self, tmp_path, mock_logger, toml_oracle, monkeypatch):
        """OSError en Spark se captura y loguea como warning."""
        ruta = _escribir_toml(tmp_path, 'config.toml', toml_oracle)

        monkeypatch.setattr('app.da_config_manager.crear_sesion_spark', MagicMock(side_effect=OSError('Socket error')))
        monkeypatch.setattr('app.da_config_manager.HAS_PYSPARK', True)

        cm = ConfigManager(str(ruta), mock_logger)
        assert cm.get('general')['fuente_config'] == 'oracle'

    def test_carga_desde_oracle_value_error(self, tmp_path, mock_logger, toml_oracle, monkeypatch):
        """ValueError en Spark se captura y loguea como warning."""
        ruta = _escribir_toml(tmp_path, 'config.toml', toml_oracle)

        monkeypatch.setattr('app.da_config_manager.crear_sesion_spark', MagicMock(side_effect=ValueError('Invalid URL')))
        monkeypatch.setattr('app.da_config_manager.HAS_PYSPARK', True)

        cm = ConfigManager(str(ruta), mock_logger)
        assert cm.get('general')['fuente_config'] == 'oracle'

    def test_carga_desde_oracle_parametros_oracle_attribute_error(self, tmp_path, mock_logger, toml_oracle, monkeypatch):
        """
        AttributeError en ParametrosOracle se captura como warning y la
        sesion Spark se cierra igual.
        """
        ruta = _escribir_toml(tmp_path, 'config.toml', toml_oracle)

        mock_spark = MagicMock()
        monkeypatch.setattr('app.da_config_manager.crear_sesion_spark', lambda url: mock_spark)
        monkeypatch.setattr('app.da_config_manager.HAS_PYSPARK', True)

        mock_lector = MagicMock()
        mock_lector.obtener_todos_parametros.side_effect = AttributeError('No attribute')
        monkeypatch.setattr('app.da_config_manager.ParametrosOracle', lambda *args, **kwargs: mock_lector)

        cm = ConfigManager(str(ruta), mock_logger)
        assert cm.get('general')['fuente_config'] == 'oracle'
        mock_spark.stop.assert_called_once()

    def test_carga_desde_oracle_parametros_oracle_key_error(self, tmp_path, mock_logger, toml_oracle, monkeypatch):
        """
        KeyError en ParametrosOracle se captura como warning y la sesion
        Spark se cierra igual.
        """
        ruta = _escribir_toml(tmp_path, 'config.toml', toml_oracle)

        mock_spark = MagicMock()
        monkeypatch.setattr('app.da_config_manager.crear_sesion_spark', lambda url: mock_spark)
        monkeypatch.setattr('app.da_config_manager.HAS_PYSPARK', True)

        mock_lector = MagicMock()
        mock_lector.obtener_todos_parametros.side_effect = KeyError('Missing key')
        monkeypatch.setattr('app.da_config_manager.ParametrosOracle', lambda *args, **kwargs: mock_lector)

        cm = ConfigManager(str(ruta), mock_logger)
        assert cm.get('general')['fuente_config'] == 'oracle'
        mock_spark.stop.assert_called_once()


class TestCargaTomlErrores:
    """Errores durante la carga del TOML."""

    def test_toml_mal_formado(self, tmp_path, mock_logger):
        """
        TOML mal formado levanta excepcion (tomllib.TOMLDecodeError).
        """
        ruta = _escribir_toml(tmp_path, 'config.toml', 'esto no es toml [[[')
        with pytest.raises(Exception):
            ConfigManager(str(ruta), mock_logger)

    def test_carga_toml_error_generico_se_propaga(self, tmp_path, mock_logger, monkeypatch):
        """
        Errores genericos en _procesar_config se propagan sin captura.

        El except TrazabilidadExcepciones.CRITICAL_ERRORS
        solo captura excepciones criticas definidas; errores
        genericos como ValueError se propagan directamente.
        """
        ruta = _escribir_toml(tmp_path, 'config.toml', _TOML_BASE)

        monkeypatch.setattr(ConfigManager, '_procesar_config', lambda self, config: (_ for _ in ()).throw(ValueError('Error simulado')))

        with pytest.raises(ValueError, match='Error simulado'):
            ConfigManager(str(ruta), mock_logger)


class TestLog:
    """Tests del metodo interno _log."""

    def test_log_interno_usa_logger(self, tmp_path, mock_logger):
        """_log delega correctamente al logger inyectado."""
        ruta = _escribir_toml(tmp_path, 'config.toml', _TOML_BASE)
        cm = ConfigManager(str(ruta), mock_logger)
        cm._log(logging.INFO, 'Mensaje de prueba %s', 'arg1')
        with open(tmp_path / 'test.log', 'r', encoding='utf-8') as f:
            contenido = f.read()
        assert 'Mensaje de prueba arg1' in contenido

    def test_log_interno_con_exc_info(self, tmp_path, mock_logger):
        """_log con exc_info=True registra la traza."""
        ruta = _escribir_toml(tmp_path, 'config.toml', _TOML_BASE)
        cm = ConfigManager(str(ruta), mock_logger)
        try:
            raise ValueError('Error de prueba')
        except ValueError:
            cm._log(logging.ERROR, 'Error capturado', exc_info=True)
        with open(tmp_path / 'test.log', 'r', encoding='utf-8') as f:
            contenido = f.read()
        assert 'Error capturado' in contenido
        assert 'ValueError' in contenido


class TestSingleton:
    """get_config_manager / reiniciar_config_manager."""

    def test_singleton_reusa_instancia(self, tmp_path, mock_logger):
        """Dos llamadas sin ruta devuelven la misma instancia."""
        ruta = _escribir_toml(tmp_path, 'config.toml', _TOML_BASE)
        a = get_config_manager(str(ruta), mock_logger)
        b = get_config_manager(None, mock_logger)
        assert a is b

    def test_singleton_recrea_con_ruta_distinta(self, tmp_path, mock_logger):
        """
        Una ruta distinta (--config) fuerza
        la recreacion de la instancia.
        """
        ruta1 = _escribir_toml(tmp_path, 'config.toml', _TOML_BASE)
        sub = tmp_path / 'otra'
        sub.mkdir()
        ruta2 = _escribir_toml(sub, 'config.toml', _TOML_BASE)

        a = get_config_manager(str(ruta1), mock_logger)
        b = get_config_manager(str(ruta2), mock_logger)
        assert a is not b
        assert b.ruta_toml.resolve() == ruta2.resolve()

    def test_reiniciar_limpia_singleton(self, tmp_path, mock_logger):
        """Tras reiniciar, se crea una instancia nueva."""
        ruta = _escribir_toml(tmp_path, 'config.toml', _TOML_BASE)
        a = get_config_manager(str(ruta), mock_logger)
        reiniciar_config_manager()
        b = get_config_manager(str(ruta), mock_logger)
        assert a is not b

    def test_singleton_con_ruta_none_ya_cacheada(self, tmp_path, mock_logger):
        """
        get_config_manager(None, logger) reusa instancia ya cacheada.
        """
        ruta = _escribir_toml(tmp_path, 'config.toml', _TOML_BASE)
        a = get_config_manager(str(ruta), mock_logger)
        b = get_config_manager(None, mock_logger)
        c = get_config_manager(None, mock_logger)
        assert a is b is c

    def test_singleton_ruta_igual_no_recrea(self, tmp_path, mock_logger):
        """Misma ruta no fuerza recreacion."""
        ruta = _escribir_toml(tmp_path, 'config.toml', _TOML_BASE)
        a = get_config_manager(str(ruta), mock_logger)
        b = get_config_manager(str(ruta), mock_logger)
        assert a is b


class TestBoundary:
    """Tests boundary con parametrizacion."""

    @pytest.mark.parametrize(
        'seccion,clave,default,esperado',
        [
            ('general', 'fuente_config', None, 'toml'),
            ('general', 'no_existe', 'fallback', 'fallback'),
            ('spark', 'url', None, 'sc://localhost:15002'),
            ('email', 'smtp_port', None, 587),
            ('no_existe', 'nada', 'default', 'default'),
        ],
    )
    def test_get_boundary(self, tmp_path, mock_logger, seccion, clave, default, esperado):
        """get con diferentes secciones y defaults."""
        ruta = _escribir_toml(tmp_path, 'config.toml', _TOML_BASE)
        cm = ConfigManager(str(ruta), mock_logger)
        resultado = cm.get(seccion, {})
        if isinstance(resultado, dict):
            resultado = resultado.get(clave, default)
        assert resultado == esperado

    @pytest.mark.parametrize('entrada,esperado', [('', ''), ('texto_sin_var', 'texto_sin_var'), ('$VAR_NO_DEFINIDA', ''), ('${VAR_NO_DEFINIDA}', '')])
    def test_resolver_password_boundary(self, tmp_path, mock_logger, entrada, esperado):
        """_resolver_password con casos limite.

        Nota: da_comunes.resolver_referencia_password retorna ''
        para variables de entorno no definidas (no el texto original).
        """
        ruta = _escribir_toml(tmp_path, 'config.toml', _TOML_BASE)
        cm = ConfigManager(str(ruta), mock_logger)
        assert cm._resolver_password(entrada) == esperado

    @pytest.mark.parametrize(
        'fuente,forzado,esperado',
        [
            ('toml', False, False),
            ('oracle', False, True),
            ('ambos', False, True),
            ('toml', True, False),
            ('oracle', True, False),
            ('ambos', True, False),
            ('otro', False, False),
        ],
    )
    def test_debe_usar_oracle_parametrizado(self, tmp_path, mock_logger, monkeypatch, fuente, forzado, esperado):
        """
        debe_usar_oracle con todas las
        combinaciones de fuente y forzado.
        """
        toml = f'[general]\nfuente_config = "{fuente}"\nforzar_toml = {str(forzado).lower()}\n'
        ruta = _escribir_toml(tmp_path, 'config.toml', toml)
        monkeypatch.setattr(ConfigManager, '_cargar_desde_oracle', lambda self: None)
        cm = ConfigManager(str(ruta), mock_logger)
        assert cm.debe_usar_oracle() == esperado


class TestPruebaConsultasYPyspark:
    """Configuracion de la prueba previa y carga sin pyspark."""

    def test_prueba_consultas_por_defecto(self, cm):
        """Sin [prueba_consultas] usa una_fila y 600 segundos."""
        assert cm.get_prueba_consultas_config() == {'modo': 'una_fila', 'timeout_segundos': 600}

    def test_prueba_consultas_desde_toml(self, tmp_path, mock_logger):
        """Lee modo y timeout del TOML."""
        ruta = _escribir_toml(tmp_path, 'config.toml', _TOML_BASE + '\n[prueba_consultas]\nmodo = "estructura"\ntimeout_segundos = "30"\n')
        assert ConfigManager(str(ruta), mock_logger).get_prueba_consultas_config() == {'modo': 'estructura', 'timeout_segundos': 30}

    def test_modulo_sin_pyspark_advierte(self, monkeypatch, caplog):
        """Sin pyspark el modulo carga, advierte y usa solo el TOML."""
        monkeypatch.setattr('app.da_sesion_spark.SparkSession', None)
        try:
            with caplog.at_level(logging.WARNING):
                importlib.reload(modulo)
            assert modulo.HAS_PYSPARK is False
            assert 'pyspark no disponible' in caplog.text
        finally:
            monkeypatch.undo()
            importlib.reload(modulo)
