"""
Pruebas de publicacion del exportador (app.da_exportador).

Cubre el flujo completo con Spark simulado, la subida en paralelo a
los servidores, la copia SFTP con comprobacion MD5, la notificacion
por correo y en archivo local, y el resumen de la publicacion.
"""

from pathlib import Path
from unittest.mock import MagicMock, patch
import zipfile

import paramiko
import pytest

from app.da_control_publicacion import md5_archivo
from app.da_exportador import ExportadorDatosAbiertos
from app.da_modelos import ConsultaDefinicion


class TestEjecutarFlujoExportacion:
    """Flujo completo con Spark y SFTP simulados y archivos reales."""

    @staticmethod
    def _preparar(tmp_path):
        """Consulta, config, rutas y nombres de un flujo de prueba."""
        consulta = ConsultaDefinicion.desde_dict({'id': 'q', 'sql': 'SELECT 1', 'nombre': 'Test', 'nombre_archivo': 'test'})
        (tmp_path / 'temp').mkdir(exist_ok=True)
        (tmp_path / 'destino').mkdir(exist_ok=True)
        config = {'spark': {}, 'email': {}, 'rutas': {'mails': tmp_path / 'mails'}}
        temp, destino = tmp_path / 'temp', tmp_path / 'destino'
        rutas = {'csv_tmp': temp / 'test.csv', 'zip_tmp': temp / 'test.zip', 'final': destino / 'test_2026.zip'}
        nombres = {'publicado': 'test_2026.zip', 'csv': 'test_2026.csv'}
        return consulta, config, rutas, nombres

    @staticmethod
    def _spark_que_escribe(filas: int):
        """
        Simula _exportar_con_spark: escribe el CSV y devuelve el conteo.
        """
        def exportar(ruta_salida, **_otros):
            """Exportar."""
            Path(ruta_salida).write_text('A|B\n' + '1|x\n' * filas, encoding='utf-8')
            return filas
        return exportar

    def test_flujo_completo_publica_y_notifica(self, exportador, tmp_path):
        """Con filas: arma el ZIP final, publica y notifica exito."""
        consulta, config, rutas, nombres = self._preparar(tmp_path)
        with (
            patch.object(exportador, '_exportar_con_spark', side_effect=self._spark_que_escribe(3)),
            patch.object(exportador, '_ejecutar_transferencia_sftp', return_value=(True, [])) as mock_sftp,
            patch.object(exportador, '_notificar') as mock_notif,
        ):
            assert exportador._ejecutar_flujo_exportacion(consulta, config, rutas, nombres) is True
        mock_sftp.assert_called_once_with(rutas['final'], 'test_2026.zip')
        with zipfile.ZipFile(rutas['final']) as zf:
            assert zf.namelist() == ['test_2026.csv']
        assert not rutas['csv_tmp'].exists() and not rutas['zip_tmp'].exists()
        assert mock_notif.call_args.kwargs['exito'] is True

    def test_flujo_falla_sftp(self, exportador, tmp_path):
        """SFTP falla -> retorna False pero notifica."""
        consulta, config, rutas, nombres = self._preparar(tmp_path)
        with (
            patch.object(exportador, '_exportar_con_spark', side_effect=self._spark_que_escribe(3)),
            patch.object(exportador, '_ejecutar_transferencia_sftp', return_value=(False, [{'exito': False}])),
            patch.object(exportador, '_notificar') as mock_notif,
        ):
            assert exportador._ejecutar_flujo_exportacion(consulta, config, rutas, nombres) is False
        mock_notif.assert_called_once()

    def test_consulta_sin_filas_no_publica_y_avisa(self, exportador, tmp_path):
        """
        0 filas: se arma el archivo solo con cabecera, no se publica y
        el asunto del correo es SIN DATOS.
        """
        consulta, config, rutas, nombres = self._preparar(tmp_path)
        with (
            patch.object(exportador, '_exportar_con_spark', side_effect=self._spark_que_escribe(0)),
            patch.object(exportador, '_ejecutar_transferencia_sftp') as mock_sftp,
            patch.object(exportador, '_notificar') as mock_notif,
        ):
            assert exportador._ejecutar_flujo_exportacion(consulta, config, rutas, nombres) is True
        mock_sftp.assert_not_called()
        assert mock_notif.call_args.kwargs['asunto'] == 'SIN DATOS'
        with zipfile.ZipFile(rutas['final']) as zf:
            assert zf.read('test_2026.csv') == b'A|B\n'


class TestEjecutarTransferenciaSftp:
    """skip_sftp, servidores sin acceso y subida en paralelo."""

    @staticmethod
    def _gestor(servidores, skip_sftp=False):
        """ConfigManager simulado con los servidores indicados."""
        gestor = MagicMock()
        gestor.get.return_value = {'skip_sftp': skip_sftp}
        gestor.get_servidores_descarga.return_value = servidores
        return gestor

    def test_skip_sftp_devuelve_exito_sin_servidores(self, exportador, tmp_path):
        """Skip sftp devuelve exito sin servidores."""
        exportador._gestor_config = self._gestor([], skip_sftp=True)
        assert exportador._ejecutar_transferencia_sftp(tmp_path / 'a.zip', 'a.zip') == (True, [])

    def test_todos_los_servidores_ok(self, exportador, tmp_path, estado_conectividad, servidor_prueba):
        """
        Resultados en el orden del TOML; MD5 local calculado una vez.
        """
        archivo = tmp_path / 'a.zip'
        archivo.write_bytes(b'PK')
        exportador._gestor_config = self._gestor([servidor_prueba(nombre='Quito'), servidor_prueba(nombre='Guayaquil', ip='10.0.0.2')])
        exportador._conectividad = estado_conectividad(servidores=['10.0.0.1', '10.0.0.2'])

        def copiar(_archivo_local, srv, _nombre, md5_local):
            """Copiar."""
            return {'exito': True, 'servidor': srv['nombre'], 'md5': md5_local}

        with patch.object(exportador, '_copiar_a_servidor', side_effect=copiar):
            exito, resultados = exportador._ejecutar_transferencia_sftp(archivo, 'a.zip')
        assert exito is True
        assert [r['servidor'] for r in resultados] == ['Quito', 'Guayaquil']
        assert resultados[0]['md5'] == resultados[1]['md5'] == md5_archivo(archivo)

    def test_un_fallo_marca_exito_global_falso(self, exportador, tmp_path, estado_conectividad, servidor_prueba):
        """Un fallo marca exito global falso."""
        archivo = tmp_path / 'a.zip'
        archivo.write_bytes(b'PK')
        exportador._gestor_config = self._gestor([servidor_prueba(nombre='Quito'), servidor_prueba(nombre='Guayaquil', ip='10.0.0.2')])
        exportador._conectividad = estado_conectividad(servidores=['10.0.0.1', '10.0.0.2'])

        def copiar(_archivo_local, srv, _nombre, _md5_local):
            """Copiar."""
            return {'exito': srv['nombre'] == 'Quito', 'servidor': srv['nombre']}

        with patch.object(exportador, '_copiar_a_servidor', side_effect=copiar):
            exito, resultados = exportador._ejecutar_transferencia_sftp(archivo, 'a.zip')
        assert exito is False
        assert len(resultados) == 2

    def test_servidor_sin_acceso_se_omite(self, exportador, tmp_path, estado_conectividad, servidor_prueba):
        """
        Un servidor sin acceso no se intenta y queda omitido; publicar
        en uno solo es error (los nodos quedarian distintos).
        """
        archivo = tmp_path / 'a.zip'
        archivo.write_bytes(b'PK')
        exportador._gestor_config = self._gestor([servidor_prueba(nombre='Quito'), servidor_prueba(nombre='Guayaquil', ip='10.0.0.2')])
        exportador._conectividad = estado_conectividad(servidores=['10.0.0.1'])
        with patch.object(exportador, '_copiar_a_servidor', return_value={'exito': True, 'servidor': 'Quito'}) as mock_copiar:
            exito, resultados = exportador._ejecutar_transferencia_sftp(archivo, 'a.zip')
        mock_copiar.assert_called_once()
        assert resultados[1]['omitido'] is True
        assert exito is False

    def test_sin_acceso_a_ningun_servidor_queda_local(self, exportador, tmp_path, estado_conectividad, servidor_prueba):
        """
        Sin acceso a ninguno: no se sube nada y el proceso es exitoso.
        """
        exportador._gestor_config = self._gestor([servidor_prueba(nombre='Quito'), servidor_prueba(nombre='Guayaquil', ip='10.0.0.2')])
        exportador._conectividad = estado_conectividad(servidores=[])
        with patch.object(exportador, '_copiar_a_servidor') as mock_copiar:
            exito, resultados = exportador._ejecutar_transferencia_sftp(tmp_path / 'a.zip', 'a.zip')
        mock_copiar.assert_not_called()
        assert exito is True
        assert all(r['omitido'] for r in resultados)


class TestCopiarAServidor:
    """Subida SFTP con paramiko simulado y comprobacion MD5."""

    @staticmethod
    def _montar_paramiko(mock_paramiko):
        """Transport y SFTP falsos; conserva las excepciones reales."""
        mock_paramiko.AuthenticationException = paramiko.AuthenticationException
        mock_paramiko.SSHException = paramiko.SSHException
        transporte = MagicMock()
        sftp = MagicMock()
        mock_paramiko.Transport.return_value = transporte
        mock_paramiko.SFTPClient.from_transport.return_value = sftp
        return transporte, sftp

    @patch('app.da_exportador.comprobar_copia', return_value=(True, 'MD5 OK abc'))
    @patch('app.da_exportador.paramiko')
    def test_subida_exitosa_con_password(self, mock_paramiko, mock_comprobar, exportador, tmp_path, servidor_prueba):
        """
        put a .subiendo, posix_rename al
        nombre final y comprobacion MD5.
        """
        transporte, sftp = self._montar_paramiko(mock_paramiko)
        zip_local = tmp_path / 'a.zip'
        zip_local.write_bytes(b'PK')

        resultado = exportador._copiar_a_servidor(zip_local, servidor_prueba(password='secreto'), 'a.zip', 'abc')

        assert resultado['exito'] is True
        assert 'MD5 OK abc' in resultado['mensaje']
        transporte.connect.assert_called_once_with(username='da', password='secreto')
        sftp.put.assert_called_once_with(str(zip_local), '/pub/datos/a.zip.subiendo')
        sftp.posix_rename.assert_called_once_with('/pub/datos/a.zip.subiendo', '/pub/datos/a.zip')
        mock_comprobar.assert_called_once_with(transporte, '/pub/datos/a.zip', zip_local, 'abc')
        sftp.close.assert_called_once()
        transporte.close.assert_called_once()

    @patch('app.da_exportador.comprobar_copia', return_value=(False, 'MD5 distinto'))
    @patch('app.da_exportador.paramiko')
    def test_md5_distinto_marca_error(self, mock_paramiko, _mock_comprobar, exportador, tmp_path, servidor_prueba):
        """
        Si el MD5 del servidor no coincide, el servidor queda en error.
        """
        self._montar_paramiko(mock_paramiko)
        zip_local = tmp_path / 'a.zip'
        zip_local.write_bytes(b'PK')
        resultado = exportador._copiar_a_servidor(zip_local, servidor_prueba(password='x'), 'a.zip', 'abc')
        assert resultado['exito'] is False
        assert 'MD5 distinto' in resultado['mensaje']

    @patch('app.da_exportador.comprobar_copia', return_value=(True, 'MD5 OK'))
    @patch('app.da_exportador.paramiko')
    def test_subida_exitosa_con_key_file(self, mock_paramiko, _mock_comprobar, exportador, tmp_path, servidor_prueba):
        """
        Con key_file existente se autentica con pkey, no con password.
        """
        transporte, _ = self._montar_paramiko(mock_paramiko)
        llave = tmp_path / 'id_ed25519'
        llave.write_text('clave', encoding='utf-8')
        zip_local = tmp_path / 'a.zip'
        zip_local.write_bytes(b'PK')

        with patch('app.da_exportador.cargar_clave_privada', return_value='PKEY') as mock_clave:
            resultado = exportador._copiar_a_servidor(zip_local, servidor_prueba(key_file=str(llave), password='pass'), 'a.zip', 'abc')

        assert resultado['exito'] is True
        mock_clave.assert_called_once_with(str(llave), 'pass')
        transporte.connect.assert_called_once_with(username='da', pkey='PKEY')

    @patch('app.da_exportador.paramiko')
    def test_sin_credenciales_retorna_error(self, mock_paramiko, exportador, tmp_path, servidor_prueba):
        """
        Sin key_file ni password: ValueError capturado en el resultado.
        """
        self._montar_paramiko(mock_paramiko)
        resultado = exportador._copiar_a_servidor(tmp_path / 'a.zip', servidor_prueba(), 'a.zip', 'abc')
        assert resultado['exito'] is False
        assert 'Sin credenciales' in resultado['mensaje']

    @patch('app.da_exportador.paramiko')
    def test_error_autenticacion_ssh(self, mock_paramiko, exportador, tmp_path, servidor_prueba):
        """
        AuthenticationException -> mensaje de autenticacion fallida.
        """
        transporte, _ = self._montar_paramiko(mock_paramiko)
        transporte.connect.side_effect = paramiko.AuthenticationException('negada')
        resultado = exportador._copiar_a_servidor(tmp_path / 'a.zip', servidor_prueba(password='mala'), 'a.zip', 'abc')
        assert resultado['exito'] is False
        assert 'Autenticacion SSH fallida' in resultado['mensaje']

    @pytest.mark.parametrize('error', [OSError('timeout'), paramiko.SSHException('Error reading SSH protocol banner')])
    @patch('app.da_exportador.paramiko')
    def test_error_de_red_o_ssh(self, mock_paramiko, error, exportador, tmp_path, servidor_prueba):
        """
        OSError o SSHException -> error del
        servidor, sin tumbar la corrida.
        """
        transporte, _ = self._montar_paramiko(mock_paramiko)
        transporte.connect.side_effect = error
        resultado = exportador._copiar_a_servidor(tmp_path / 'a.zip', servidor_prueba(password='x'), 'a.zip', 'abc')
        assert resultado['exito'] is False
        assert 'Error red' in resultado['mensaje']

    @patch('app.da_exportador.comprobar_copia', return_value=(True, 'MD5 OK'))
    @patch('app.da_exportador.paramiko')
    def test_posix_rename_falla_y_usa_rename(self, mock_paramiko, _mock_comprobar, exportador, tmp_path, servidor_prueba):
        """
        Si posix_rename no esta soportado, remove + rename clasico.
        """
        _, sftp = self._montar_paramiko(mock_paramiko)
        sftp.posix_rename.side_effect = OSError('no soportado')
        zip_local = tmp_path / 'a.zip'
        zip_local.write_bytes(b'PK')

        resultado = exportador._copiar_a_servidor(zip_local, servidor_prueba(password='x'), 'a.zip', 'abc')
        assert resultado['exito'] is True
        sftp.remove.assert_called_once_with('/pub/datos/a.zip')
        sftp.rename.assert_called_once_with('/pub/datos/a.zip.subiendo', '/pub/datos/a.zip')


class TestGuardarNotificacionLocal:
    """Archivo de texto de respaldo en rutas.mails."""

    def _config(self, tmp_path):
        """Config."""
        return {'rutas': {'mails': tmp_path / 'mails'}, 'email': {}}

    def test_crea_archivo_ok_con_contenido(self, exportador, tmp_path):
        """Crea archivo ok con contenido."""
        exportador._guardar_notificacion_local(
            consulta_id='q1',
            exito=True,
            config=self._config(tmp_path),
            resultado={
                'archivo_destino': 'a.zip',
                'tamanio_mb': 1.5,
                'mensaje': 'OK',
                'servidores': [{'exito': True, 'servidor': 'Quito', 'ip': '10.0.0.1', 'mensaje': 'listo'}],
            },
            detalles_spark={'total_registros': 1000, 'tiempo_total': 5.0, 'velocidad': 200.0},
            correo_enviado=True,
        )
        archivos = list((tmp_path / 'mails').glob('*_q1_OK.txt'))
        assert len(archivos) == 1
        contenido = archivos[0].read_text(encoding='utf-8')
        assert 'Estado   : EXITO' in contenido
        assert 'Correo   : Enviado' in contenido
        assert 'a.zip' in contenido
        assert 'OK Quito (10.0.0.1): listo' in contenido
        assert 'Registros : 1,000' in contenido

    def test_archivo_error_incluye_mensaje(self, exportador, tmp_path):
        """Archivo error incluye mensaje."""
        exportador._guardar_notificacion_local(consulta_id='q2', exito=False, config=self._config(tmp_path), error='ORA-00933')
        archivos = list((tmp_path / 'mails').glob('*_q2_ERROR.txt'))
        assert len(archivos) == 1
        contenido = archivos[0].read_text(encoding='utf-8')
        assert 'Estado   : ERROR' in contenido
        assert 'ORA-00933' in contenido
        assert 'No enviado' in contenido

    def test_crea_directorio_mails_si_no_existe(self, exportador, tmp_path):
        """Crea directorio mails si no existe."""
        assert not (tmp_path / 'mails').exists()
        exportador._guardar_notificacion_local(consulta_id='q3', exito=True, config=self._config(tmp_path))
        assert (tmp_path / 'mails').is_dir()


class TestNotificar:
    """Correo (si hay smtp_server) + archivo local, siempre."""

    def _config(self, tmp_path, smtp_server=''):
        """Config."""
        return {'rutas': {'mails': tmp_path / 'mails'}, 'email': {'smtp_server': smtp_server}}

    @patch('app.da_exportador.NotificadorEmail')
    def test_sin_smtp_no_intenta_correo_pero_guarda_local(self, mock_notif, exportador, tmp_path):
        """Sin smtp no intenta correo pero guarda local."""
        exportador._notificar(consulta_id='q1', exito=True, config=self._config(tmp_path))
        mock_notif.assert_not_called()
        assert list((tmp_path / 'mails').glob('*_q1_OK.txt'))

    @patch('app.da_exportador.NotificadorEmail')
    def test_con_smtp_envia_correo(self, mock_notif, exportador, tmp_path):
        """Con smtp envia correo."""
        mock_notif.return_value.enviar_notificacion.return_value = True
        exportador._notificar(consulta_id='q1', exito=True, config=self._config(tmp_path, smtp_server='localhost'))
        mock_notif.return_value.enviar_notificacion.assert_called_once()
        kwargs = mock_notif.return_value.enviar_notificacion.call_args.kwargs
        assert kwargs['asunto'] == 'COMPLETADO'
        assert kwargs['consulta_id'] == 'q1'

    @patch('app.da_exportador.NotificadorEmail')
    def test_fallo_en_correo_no_detiene_guardado_local(self, mock_notif, exportador, tmp_path):
        """
        Una excepcion no critica del correo
        se captura y se guarda local.
        """
        mock_notif.return_value.enviar_notificacion.side_effect = ValueError('boom')
        exportador._notificar(consulta_id='q1', exito=False, config=self._config(tmp_path, smtp_server='localhost'), error='fallo')
        assert list((tmp_path / 'mails').glob('*_q1_ERROR.txt'))


class TestMensajePublicacion:
    """Resumen de la publicacion segun los servidores."""

    def test_todos_ok(self, tmp_path):
        """Todos ok."""
        assert ExportadorDatosAbiertos._mensaje_publicacion([{'exito': True}, {'exito': True}], tmp_path)[0] is True

    def test_todos_omitidos_es_exito_local(self, tmp_path):
        """Todos omitidos es exito local."""
        exito, mensaje = ExportadorDatosAbiertos._mensaje_publicacion([{'exito': False, 'omitido': True}] * 2, tmp_path)
        assert exito is True
        assert str(tmp_path) in mensaje

    def test_parcial_es_error(self, tmp_path):
        """Parcial es error."""
        resultados = [{'exito': True}, {'exito': False, 'omitido': True}]
        assert ExportadorDatosAbiertos._mensaje_publicacion(resultados, tmp_path)[0] is False


class TestArchivoFinalYPublicacion:
    """CSV sin comprimir, publicar=false y rename sin archivo previo."""

    def test_csv_sin_comprimir(self, exportador, tmp_path):
        """comprimir=false copia el CSV tal cual como archivo final."""
        consulta = ConsultaDefinicion.desde_dict({'id': 'v', 'nombre_archivo': 'SRI_Vehiculos_Nuevos', 'comprimir': False})
        csv = tmp_path / 'tmp.csv'
        csv.write_text('A|B\n1|x\n', encoding='utf-8')
        rutas = {'csv_tmp': csv, 'zip_tmp': tmp_path / 'tmp.zip', 'final': tmp_path / 'SRI_Vehiculos_Nuevos_2026.csv'}
        exportador._generar_archivo_final(consulta, rutas, {'publicado': rutas['final'].name, 'csv': rutas['final'].name})
        assert rutas['final'].read_text(encoding='utf-8') == 'A|B\n1|x\n'
        assert not rutas['zip_tmp'].exists()

    def test_publicar_false_no_sube(self, exportador, tmp_path):
        """publicar=false deja el archivo solo en destino_local."""
        consulta = ConsultaDefinicion.desde_dict({'id': 'q', 'publicar': False})
        with patch.object(exportador, '_ejecutar_transferencia_sftp') as mock_sftp:
            exito, resultados, mensaje = exportador._publicar(consulta, tmp_path / 'a.zip', 'a.zip', 10)
        mock_sftp.assert_not_called()
        assert (exito, resultados) == (True, [])
        assert str(tmp_path) in mensaje

    def test_rename_sin_archivo_previo(self):
        """
        Si posix_rename falla y no hay archivo previo, igual renombra.
        """
        sftp = MagicMock()
        sftp.posix_rename.side_effect = OSError('no soportado')
        sftp.remove.side_effect = IOError('no existe')
        ExportadorDatosAbiertos._subir_atomico(sftp, Path('/l/a.zip'), '/r/a.zip')
        sftp.rename.assert_called_once_with('/r/a.zip.subiendo', '/r/a.zip')


class TestNotificarSinCorreo:
    """Correo sin acceso o rechazado: queda el archivo local."""

    def test_sin_acceso_al_correo(self, exportador, tmp_path, estado_conectividad):
        """Sin acceso al SMTP no se intenta enviar."""
        exportador._conectividad = estado_conectividad(correo=False)
        with patch('app.da_exportador.NotificadorEmail') as mock_notif:
            exportador._notificar(consulta_id='q1', exito=True, config={'rutas': {'mails': tmp_path / 'm'}, 'email': {'smtp_server': 's'}})
        mock_notif.assert_not_called()
        assert list((tmp_path / 'm').glob('*_q1_OK.txt'))

    def test_correo_rechazado(self, exportador, tmp_path):
        """Si el SMTP rechaza, la notificacion local dice No enviado."""
        with patch('app.da_exportador.NotificadorEmail') as mock_notif:
            mock_notif.return_value.enviar_notificacion.return_value = False
            exportador._notificar(consulta_id='q2', exito=True, config={'rutas': {'mails': tmp_path / 'm'}, 'email': {'smtp_server': 's'}})
        assert 'No enviado' in next((tmp_path / 'm').glob('*_q2_OK.txt')).read_text(encoding='utf-8')
