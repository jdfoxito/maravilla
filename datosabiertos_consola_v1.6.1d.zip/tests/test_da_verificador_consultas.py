"""
Tests de la prueba previa de consultas (da_verificador_consultas).

Sesion Spark simulada. Cubre la credencial contra tnsnames.ora, la
prueba de una fila con limit bajado a Oracle, el modo estructura, el
resumen de errores ORA y la tabla de resultados.
"""

import logging
from unittest.mock import MagicMock, patch

import pytest

from app.da_modelos import ConsultaDefinicion
from app.da_verificador_consultas import (
    ESTADO_ERROR_CONSULTA,
    ESTADO_OK,
    ESTADO_SIN_CREDENCIAL,
    ESTADO_SIN_SPARK,
    ResultadoPrueba,
    resumir_error,
    tabla_texto,
    VerificadorConsultas,
)


@pytest.fixture
def wallet(tmp_path):
    """Directorio con un tnsnames.ora de dos alias."""
    (tmp_path / 'tnsnames.ora').write_text('STAR_DESA =\n (D)\nSRIDW_DWH =\n (D)\n', encoding='utf-8')
    return tmp_path


def _verificador(wallet, modo='una_fila'):
    """Verificador con la carpeta del wallet de prueba."""
    config_spark = {'spark_url': 'sc://localhost:15002', 'wallet_path': str(wallet), 'network_admin': str(wallet)}
    return VerificadorConsultas(config_spark, {'modo': modo, 'timeout_segundos': 30}, logging.getLogger('test_verificador'))


def _consulta(conexion='STAR_DESA', cid='h2'):
    """Consulta con su conexion (alias TNS)."""
    datos = {'id': cid, 'nombre': cid, 'sql': 'SELECT 1 FROM DUAL'}
    if conexion:
        datos['conexion'] = conexion
    return ConsultaDefinicion.desde_dict(datos)


def _spark(filas=1, columnas=('A', 'B')):
    """Spark simulado cuya lectura devuelve 'filas' filas."""
    spark = MagicMock()
    lector = spark.read.format.return_value.options.return_value
    lector.option.return_value = lector
    df = lector.load.return_value
    df.limit.return_value.collect.return_value = [object()] * filas
    df.columns = list(columnas)
    return spark, lector, df


class TestResumirError:
    """Errores de Spark/JDBC reducidos a una linea."""

    def test_prioriza_codigo_ora(self):
        """Prioriza codigo ora."""
        exc = RuntimeError('java.sql.SQLException\nORA-00942: table or view does not exist\n\tat oracle')
        assert resumir_error(exc) == 'ORA-00942: table or view does not exist'

    def test_sin_ora_usa_primera_linea(self):
        """Sin ora usa primera linea."""
        assert resumir_error(ValueError('primera\nsegunda')) == 'primera'


class TestCredencial:
    """La conexion del JSON debe ser un alias de tnsnames.ora."""

    def test_modo_invalido(self, wallet):
        """Modo invalido."""
        with pytest.raises(ValueError, match='no valido'):
            _verificador(wallet, modo='todo')

    def test_alias_disponibles(self, wallet):
        """Alias disponibles."""
        assert _verificador(wallet).alias_disponibles() == ['STAR_DESA', 'SRIDW_DWH']

    def test_sin_tnsnames_lista_vacia(self, tmp_path):
        """Sin tnsnames lista vacia."""
        assert _verificador(tmp_path).alias_disponibles() == []

    def test_credencial_existente(self, wallet):
        """Credencial existente."""
        assert _verificador(wallet).verificar_credencial(_consulta('star_desa'), ['STAR_DESA']) is None

    def test_credencial_inexistente(self, wallet):
        """Credencial inexistente."""
        resultado = _verificador(wallet).verificar_credencial(_consulta('SRIDW_MVEHICULAR'), ['STAR_DESA'])
        assert resultado.estado == ESTADO_SIN_CREDENCIAL
        assert 'SRIDW_MVEHICULAR' in resultado.detalle

    def test_json_sin_conexion(self, wallet):
        """Json sin conexion."""
        resultado = _verificador(wallet).verificar_credencial(_consulta(None), ['STAR_DESA'])
        assert 'no declara "conexion"' in resultado.detalle


class TestProbar:
    """Ejecucion de la prueba con Spark simulado."""

    def test_sin_credencial_no_abre_spark(self, wallet):
        """Sin credencial no abre spark."""
        with patch('app.da_verificador_consultas.crear_sesion_spark') as mock_sesion:
            resultados = _verificador(wallet).probar([_consulta('NO_EXISTE')], lambda c: c.sql)
        mock_sesion.assert_not_called()
        assert resultados[0].estado == ESTADO_SIN_CREDENCIAL

    def test_una_fila_ok(self, wallet):
        """limit(1) con pushDownLimit: Oracle devuelve una sola fila."""
        spark, lector, df = _spark()
        with patch('app.da_verificador_consultas.crear_sesion_spark', return_value=spark):
            resultado = _verificador(wallet).probar([_consulta()], lambda c: 'SQL RESUELTO')[0]
        assert resultado.estado == ESTADO_OK
        assert '2 columnas, 1 fila(s)' in resultado.detalle
        lector.option.assert_any_call('pushDownLimit', 'true')
        lector.option.assert_any_call('query', 'SQL RESUELTO')
        df.limit.assert_called_once_with(1)
        spark.stop.assert_called_once()

    def test_sin_datos_en_el_periodo(self, wallet):
        """Sin datos en el periodo."""
        spark, _, _ = _spark(filas=0)
        with patch('app.da_verificador_consultas.crear_sesion_spark', return_value=spark):
            resultado = _verificador(wallet).probar([_consulta()], lambda c: c.sql)[0]
        assert resultado.estado == ESTADO_OK
        assert 'sin datos para el periodo' in resultado.detalle

    def test_modo_estructura_no_lee_filas(self, wallet):
        """Modo estructura no lee filas."""
        spark, _, df = _spark()
        with patch('app.da_verificador_consultas.crear_sesion_spark', return_value=spark):
            resultado = _verificador(wallet, modo='estructura').probar([_consulta()], lambda c: c.sql)[0]
        assert resultado.estado == ESTADO_OK
        df.limit.assert_not_called()

    def test_error_oracle(self, wallet):
        """Error oracle."""
        spark, lector, _ = _spark()
        lector.load.side_effect = RuntimeError('ORA-00942: table or view does not exist')
        with patch('app.da_verificador_consultas.crear_sesion_spark', return_value=spark):
            resultado = _verificador(wallet).probar([_consulta()], lambda c: c.sql)[0]
        assert resultado.estado == ESTADO_ERROR_CONSULTA
        assert resultado.detalle.startswith('ORA-00942')

    def test_spark_no_disponible(self, wallet):
        """Spark no disponible."""
        with patch('app.da_verificador_consultas.crear_sesion_spark', side_effect=RuntimeError('Connection refused')):
            resultado = _verificador(wallet).probar([_consulta()], lambda c: c.sql)[0]
        assert resultado.estado == ESTADO_SIN_SPARK

    def test_resultados_en_el_orden_recibido(self, wallet):
        """Resultados en el orden recibido."""
        spark, _, _ = _spark()
        consultas = [_consulta('NO_EXISTE', 'h1'), _consulta('STAR_DESA', 'h2'), _consulta('SRIDW_DWH', 'h3')]
        with patch('app.da_verificador_consultas.crear_sesion_spark', return_value=spark) as mock_sesion:
            resultados = _verificador(wallet).probar(consultas, lambda c: c.sql)
        assert [r.consulta_id for r in resultados] == ['h1', 'h2', 'h3']
        mock_sesion.assert_called_once()


class TestTablaTexto:
    """Tabla de consola, log y archivo."""

    def test_resumen_final(self):
        """Resumen final."""
        resultados = [
            ResultadoPrueba('h1', 'H1', 'SRIDW_DWH', ESTADO_OK, '5 columnas', 1.2),
            ResultadoPrueba('h5', 'H5', 'SRIDW_MVEHICULAR', ESTADO_SIN_CREDENCIAL, 'no existe'),
        ]
        texto = tabla_texto(resultados)
        assert 'Funcionaran: 1 de 2' in texto
        assert 'SRIDW_MVEHICULAR' in texto
