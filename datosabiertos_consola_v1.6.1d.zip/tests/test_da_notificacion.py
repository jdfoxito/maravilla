"""
Tests del NotificadorEmail (da_notificacion).

Frontera simulada: smtplib.SMTP. Cubre modo intranet,
modo externo TLS+auth, fallo SMTP capturado,
smtp_server vacio y generacion de HTML (exito/error).
"""

import logging
import smtplib
from unittest.mock import patch, MagicMock

import pytest

from app.da_notificacion import NotificadorEmail


def _config(**override):
    """Config base de correo; override puntual por test."""
    base = {
        'smtp_server': 'localhost',
        'smtp_port': 25,
        'timeout': 5,
        'username': '',
        'password': '',
        'from_address': 'python@sri.ad',
        'to_addresses': ['dest@sri.ad'],
        'use_tls': False,
    }
    base.update(override)
    return base


@pytest.fixture
def mock_logger():
    """Logger real con NullHandler para tests de notificacion."""
    logger = logging.getLogger('test_notificacion')
    logger.setLevel(logging.DEBUG)
    handler = logging.NullHandler()
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)
    yield logger
    logger.removeHandler(handler)


@pytest.fixture
def transferencia_ok():
    """Resultado de transferencia exitoso minimo."""
    return {
        'exito': True,
        'tipo': 'sftp',
        'archivo_destino': 'f.zip',
        'tamanio_mb': 1.5,
        'tamanio_bytes': 1572864,
        'ruta_destino': '/r/f.zip',
        'mensaje': 'OK',
    }


class TestModoDeteccion:
    """Deteccion de modo intranet vs externo en el constructor."""

    def test_modo_intranet_detectado(self, mock_logger):
        """Sin TLS, sin password y puerto 25 -> modo intranet."""
        notif = NotificadorEmail(_config(), mock_logger)
        assert notif._modo_intranet is True

    def test_modo_externo_por_tls(self, mock_logger):
        """use_tls=True desactiva el modo intranet."""
        notif = NotificadorEmail(_config(use_tls=True, smtp_port=587), mock_logger)
        assert notif._modo_intranet is False

    def test_modo_externo_por_password(self, mock_logger):
        """Con password definido no es modo intranet."""
        notif = NotificadorEmail(_config(password='secreto'), mock_logger)
        assert notif._modo_intranet is False


class TestEnviarNotificacion:
    """Flujo de envio con la frontera smtplib simulada."""

    @patch('app.da_notificacion.smtplib.SMTP')
    def test_envio_exitoso_intranet(self, mock_smtp, transferencia_ok, mock_logger):
        """
        Modo intranet: no llama starttls ni login, pero si sendmail.
        """
        servidor = MagicMock()
        mock_smtp.return_value.__enter__.return_value = servidor

        notif = NotificadorEmail(_config(), mock_logger)
        enviado = notif.enviar_notificacion('COMPLETADO', 'q1', transferencia_ok)

        assert enviado is True
        servidor.starttls.assert_not_called()
        servidor.login.assert_not_called()
        servidor.sendmail.assert_called_once()

    @patch('app.da_notificacion.smtplib.SMTP')
    def test_envio_externo_con_tls_y_auth(self, mock_smtp, transferencia_ok, mock_logger):
        """Modo externo: llama starttls y login."""
        servidor = MagicMock()
        mock_smtp.return_value.__enter__.return_value = servidor

        notif = NotificadorEmail(_config(use_tls=True, smtp_port=587, username='u', password='p'), mock_logger)
        enviado = notif.enviar_notificacion('COMPLETADO', 'q1', transferencia_ok)

        assert enviado is True
        servidor.starttls.assert_called_once()
        servidor.login.assert_called_once_with('u', 'p')

    @patch('app.da_notificacion.smtplib.SMTP')
    def test_fallo_smtp_se_captura(self, mock_smtp, transferencia_ok, mock_logger):
        """
        Si SMTP lanza SMTPException, enviar_notificacion devuelve False.
        """

        mock_smtp.side_effect = smtplib.SMTPException('caido')

        notif = NotificadorEmail(_config(), mock_logger)
        enviado = notif.enviar_notificacion('ERROR', 'q1', transferencia_ok)

        assert enviado is False

    @patch('app.da_notificacion.smtplib.SMTP')
    def test_fallo_red_oserror_se_captura(self, mock_smtp, transferencia_ok, mock_logger):
        """
        OSError en la conexion tambien se captura (devuelve False).
        """
        mock_smtp.side_effect = OSError('sin ruta')
        notif = NotificadorEmail(_config(), mock_logger)
        assert notif.enviar_notificacion('ERROR', 'q1', transferencia_ok) is False

    def test_smtp_server_vacio_omite_envio(self, transferencia_ok, mock_logger):
        """Sin smtp_server, no se intenta enviar y devuelve False."""
        notif = NotificadorEmail(_config(smtp_server=''), mock_logger)
        assert notif.enviar_notificacion('X', 'q1', transferencia_ok) is False


class TestGenerarHtml:
    """Generacion del cuerpo HTML (sin red)."""

    def test_html_exito_contiene_consulta_id(self, transferencia_ok, mock_logger):
        """El HTML de exito incluye el id de la consulta."""
        notif = NotificadorEmail(_config(), mock_logger)
        html = notif._generar_html('mi_consulta', transferencia_ok, None, None)
        assert 'mi_consulta' in html
        assert 'EXITO' in html

    def test_html_error_incluye_mensaje(self, transferencia_ok, mock_logger):
        """Con error, el HTML muestra ERROR y el texto del error."""
        notif = NotificadorEmail(_config(), mock_logger)
        html = notif._generar_html('q', transferencia_ok, None, 'fallo X')
        assert 'ERROR' in html
        assert 'fallo X' in html

    def test_html_incluye_detalles_spark(self, transferencia_ok, mock_logger):
        """Si hay detalles_spark, aparecen en el HTML."""
        notif = NotificadorEmail(_config(), mock_logger)
        spark = {'total_registros': 1000, 'tiempo_lectura': 2, 'tiempo_total': 5, 'velocidad': 200}
        html = notif._generar_html('q', transferencia_ok, spark, None)
        assert 'Detalles Spark' in html


class TestEnviarTabla:
    """Reporte tabular (prueba de consultas)."""

    @patch('app.da_notificacion.smtplib.SMTP')
    def test_envia_tabla(self, mock_smtp, mock_logger):
        """Envia tabla."""
        servidor = MagicMock()
        mock_smtp.return_value.__enter__.return_value = servidor
        notif = NotificadorEmail(_config(), mock_logger)
        assert notif.enviar_tabla('PRUEBA OK', 'Prueba', ('Consulta', 'Estado'), [('h1', 'OK')], False) is True
        servidor.sendmail.assert_called_once()

    def test_html_escapa_valores(self):
        """Un detalle con < o & no rompe el HTML del correo."""
        html = NotificadorEmail._generar_html_tabla('T', ('Detalle',), [('ORA-00942 <tabla> & otra',)], True)
        assert 'ORA-00942 &lt;tabla&gt; &amp; otra' in html
        assert '#d32f2f' in html

    def test_smtp_vacio_no_envia(self, mock_logger):
        """Smtp vacio no envia."""
        assert NotificadorEmail(_config(smtp_server=''), mock_logger).enviar_tabla('X', 'T', ('A',), [], False) is False


class TestEnviarTablaFallo:
    """Fallo SMTP al enviar el reporte tabular."""

    @patch('app.da_notificacion.smtplib.SMTP', side_effect=OSError('sin ruta'))
    def test_fallo_devuelve_false(self, _mock_smtp, mock_logger):
        """Un OSError al conectar devuelve False."""
        assert NotificadorEmail(_config(), mock_logger).enviar_tabla('X', 'T', ('A',), [('1',)], True) is False
