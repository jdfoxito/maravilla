"""
Tests del diagnostico de correo y servidores (da_conectividad).

Puertos reales en localhost para probar_puerto; SMTP y SFTP simulados.
Cubre correo sin configurar, puerto cerrado, autenticacion SSH
rechazada, ruta remota accesible, diagnostico en paralelo y el
resumen para consola.
"""

import logging
import socket
import time
from unittest.mock import MagicMock, patch

import paramiko
import pytest

from app.da_conectividad import (
    DiagnosticoConectividad,
    EstadoConectividad,
    EstadoServicio,
    lineas_resumen,
    probar_correo,
    probar_puerto,
    probar_servidor_descarga,
)

_SERVIDOR = {'nombre': 'Quito', 'ip': '127.0.0.1', 'puerto': 22, 'usuario': 'u', 'password': 'p', 'ruta_remota': '/pub'}


@pytest.fixture
def puerto_abierto():
    """Socket escuchando en localhost; devuelve su puerto."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as servidor:
        servidor.bind(('127.0.0.1', 0))
        servidor.listen(1)
        yield servidor.getsockname()[1]


@pytest.fixture
def puerto_cerrado():
    """Puerto libre de localhost en el que nadie escucha."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as temporal:
        temporal.bind(('127.0.0.1', 0))
        return temporal.getsockname()[1]


class TestProbarPuerto:
    """probar_puerto: cadena vacia si responde, motivo si no."""

    def test_puerto_abierto(self, puerto_abierto):
        """Puerto abierto."""
        assert probar_puerto('127.0.0.1', puerto_abierto, timeout=2) == ''

    def test_puerto_cerrado(self, puerto_cerrado):
        """Puerto cerrado."""
        assert f'puerto {puerto_cerrado} sin respuesta' in probar_puerto('127.0.0.1', puerto_cerrado, timeout=2)


class TestProbarCorreo:
    """probar_correo con SMTP simulado."""

    def test_sin_smtp_server(self):
        """Sin smtp server."""
        estado = probar_correo({'smtp_server': ''})
        assert estado.disponible is False
        assert 'vacio' in estado.detalle

    def test_puerto_sin_respuesta(self, puerto_cerrado):
        """Puerto sin respuesta."""
        estado = probar_correo({'smtp_server': '127.0.0.1', 'smtp_port': puerto_cerrado}, timeout=2)
        assert estado.disponible is False
        assert estado.destino == f'127.0.0.1:{puerto_cerrado}'

    def test_smtp_responde(self):
        """Smtp responde."""
        with patch('app.da_conectividad.probar_puerto', return_value=''), patch('app.da_conectividad.smtplib.SMTP') as mock_smtp:
            estado = probar_correo({'smtp_server': '10.1.0.27', 'smtp_port': 25})
        assert estado.disponible is True
        mock_smtp.return_value.__enter__.return_value.noop.assert_called_once()


class TestProbarServidorDescarga:
    """Puerto SSH, autenticacion y ruta remota."""

    def test_puerto_cerrado(self, puerto_cerrado):
        """Puerto cerrado."""
        estado = probar_servidor_descarga({**_SERVIDOR, 'puerto': puerto_cerrado}, timeout=2)
        assert estado.disponible is False
        assert 'sin respuesta' in estado.detalle

    def test_autenticacion_rechazada(self):
        """Autenticacion rechazada."""
        with (
            patch('app.da_conectividad.probar_puerto', return_value=''),
            patch('app.da_conectividad.abrir_transporte_sftp', side_effect=paramiko.AuthenticationException()),
        ):
            estado = probar_servidor_descarga(_SERVIDOR)
        assert estado.disponible is False
        assert 'autenticacion SSH rechazada' in estado.detalle

    def test_ruta_remota_accesible(self):
        """Ruta remota accesible."""
        transporte = MagicMock()
        with (
            patch('app.da_conectividad.probar_puerto', return_value=''),
            patch('app.da_conectividad.abrir_transporte_sftp', return_value=transporte),
            patch('app.da_conectividad.paramiko.SFTPClient.from_transport') as mock_sftp,
        ):
            estado = probar_servidor_descarga(_SERVIDOR)
        assert estado.disponible is True
        mock_sftp.return_value.stat.assert_called_once_with('/pub')
        transporte.close.assert_called_once()

    def test_ruta_remota_inexistente(self):
        """Ruta remota inexistente."""
        transporte = MagicMock()
        with (
            patch('app.da_conectividad.probar_puerto', return_value=''),
            patch('app.da_conectividad.abrir_transporte_sftp', return_value=transporte),
            patch('app.da_conectividad.paramiko.SFTPClient.from_transport') as mock_sftp,
        ):
            mock_sftp.return_value.stat.side_effect = FileNotFoundError('No such file')
            estado = probar_servidor_descarga(_SERVIDOR)
        assert estado.disponible is False
        transporte.close.assert_called_once()


class TestDiagnosticoConectividad:
    """Diagnostico completo: paralelo y omision de servidores."""

    def test_pruebas_en_paralelo(self):
        """
        Correo y dos servidores de 0.5 s
        cada uno tardan ~0.5 s, no 1.5 s.
        """
        def lento(*_args, **_kwargs):
            """Lento."""
            time.sleep(0.5)
            return EstadoServicio('x', 'x:1', False, 'sin respuesta')

        servidores = [_SERVIDOR, {**_SERVIDOR, 'nombre': 'Guayaquil'}]
        with patch('app.da_conectividad.probar_correo', side_effect=lento), patch('app.da_conectividad.probar_servidor_descarga', side_effect=lento):
            inicio = time.monotonic()
            estado = DiagnosticoConectividad({}, servidores, '/data/output', logging.getLogger('test')).ejecutar()
            duracion = time.monotonic() - inicio
        assert len(estado.servidores) == 2
        assert duracion < 1.2

    def test_skip_sftp_no_prueba_servidores(self):
        """Skip sftp no prueba servidores."""
        with (
            patch('app.da_conectividad.probar_correo', return_value=EstadoServicio('Correo', 'x', True, 'ok')),
            patch('app.da_conectividad.probar_servidor_descarga') as mock_srv,
        ):
            estado = DiagnosticoConectividad({}, [_SERVIDOR], '/data/output', logging.getLogger('test')).ejecutar(incluir_servidores=False)
        mock_srv.assert_not_called()
        assert estado.servidores == []


class TestLineasResumen:
    """Resumen de consola y su efecto."""

    def test_todo_disponible(self):
        """Todo disponible."""
        estado = EstadoConectividad(EstadoServicio('Correo', 'smtp:25', True, 'ok'), [EstadoServicio('Quito', 'q:22', True, 'ok')])
        lineas = lineas_resumen(estado, '/data/output')
        assert not any(linea.startswith('->') for linea in lineas)

    def test_sin_correo_ni_servidores(self):
        """Sin correo ni servidores."""
        estado = EstadoConectividad(EstadoServicio('Correo', 'smtp:25', False, 'timeout'), [EstadoServicio('Quito', 'q:22', False, 'timeout')])
        texto = '\n'.join(lineas_resumen(estado, '/data/output'))
        assert 'SIN ACCESO - timeout' in texto
        assert 'Sin correo' in texto
        assert 'el archivo queda en /data/output' in texto


class TestCasosRestantes:
    """SMTP que rechaza y servidor disponible en el diagnostico."""

    def test_smtp_rechaza(self):
        """Puerto abierto pero SMTP con error: sin acceso al correo."""
        with patch('app.da_conectividad.probar_puerto', return_value=''), patch('app.da_conectividad.smtplib.SMTP', side_effect=OSError('reset')):
            estado = probar_correo({'smtp_server': '10.1.0.27'})
        assert estado.disponible is False
        assert 'SMTP no responde (reset)' in estado.detalle

    def test_diagnostico_con_todo_disponible(self, caplog):
        """Correo y servidor disponibles quedan informados en el log."""
        ok = EstadoServicio('x', 'h:1', True, 'ok')
        with (
            patch('app.da_conectividad.probar_correo', return_value=ok),
            patch('app.da_conectividad.probar_servidor_descarga', return_value=ok),
            caplog.at_level(logging.INFO),
        ):
            estado = DiagnosticoConectividad({}, [_SERVIDOR], '/data/output', logging.getLogger('test')).ejecutar()
        assert estado.servidores[0].disponible is True
        assert 'Servidor de descarga x disponible' in caplog.text
