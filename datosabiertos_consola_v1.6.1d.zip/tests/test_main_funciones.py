"""
Tests de las funciones de main.py que test_main.py reemplaza.

Aqui corren las versiones reales de _iniciar, _probar_consultas,
_mostrar_conectividad y _consultas_sin_credencial, con el exportador,
la configuracion y el correo simulados.
"""

import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
import runpy
from unittest.mock import MagicMock, patch

import pytest

from app.da_conectividad import EstadoConectividad, EstadoServicio
from app.da_modelos import ConsultaDefinicion
from app.da_verificador_consultas import ESTADO_OK, ESTADO_SIN_CREDENCIAL, ResultadoPrueba, VerificadorConsultas
from app.main import (
    _agregar_log_archivo,
    _comando_cron,
    _consultas_sin_credencial,
    _crear_verificador,
    _detectar_comando_base,
    _iniciar,
    _mostrar_conectividad,
    _notificar_prueba,
    _pantalla_ayuda,
    _probar_consultas,
    _sembrar_consultas_empaquetadas,
)


@pytest.fixture
def logger():
    """Logger aislado sin handlers previos."""
    log = logging.getLogger('test_main_funciones')
    log.handlers.clear()
    yield log
    for handler in list(log.handlers):
        handler.close()
        log.removeHandler(handler)


@pytest.fixture
def gestor(tmp_path):
    """ConfigManager simulado con rutas en tmp_path."""
    gestor_mock = MagicMock()
    (tmp_path / 'mails').mkdir()
    gestor_mock.get_rutas.return_value = {'logs': tmp_path, 'mails': tmp_path / 'mails', 'destino_local': tmp_path / 'output'}
    gestor_mock.get_email_config.return_value = {'smtp_server': 'smtp', 'to_addresses': ['toml@sri.ad']}
    gestor_mock.get_spark_config.return_value = {'spark_url': 'sc://h:1', 'wallet_path': str(tmp_path)}
    gestor_mock.get_prueba_consultas_config.return_value = {'modo': 'una_fila', 'timeout_segundos': 5}
    with patch('app.main.get_config_manager', return_value=gestor_mock):
        yield gestor_mock


def _resultados(con_error=False):
    """Resultados de prueba: uno OK y opcionalmente uno con error."""
    resultados = [ResultadoPrueba('h2', 'H2', 'STAR_DESA', ESTADO_OK, '3 columnas', 1.0)]
    if con_error:
        resultados.append(ResultadoPrueba('h5', 'H5', 'SRIDW_MVEHICULAR', ESTADO_SIN_CREDENCIAL, 'no existe'))
    return resultados


class TestSembrar:
    """Siembra del TOML y las consultas empaquetadas en el binario."""

    def test_en_desarrollo_no_hace_nada(self, logger, tmp_path):
        """Sin sys.frozen no se copia nada."""
        with patch('app.main._detectar_ruta_base', return_value=tmp_path):
            _sembrar_consultas_empaquetadas(logger)
        assert not (tmp_path / 'config').exists()

    def test_ejecutable_siembra_lo_que_falta(self, logger, tmp_path, monkeypatch):
        """Copia lo que falta y nunca reemplaza lo existente."""
        paquete, disco = tmp_path / 'meipass', tmp_path / 'disco'
        (paquete / 'config').mkdir(parents=True)
        (paquete / 'data' / 'input' / 'consultas').mkdir(parents=True)
        (paquete / 'config' / 'configlnx.toml').write_text('empaquetado', encoding='utf-8')
        (paquete / 'data' / 'input' / 'consultas' / 'h1.json').write_text('{}', encoding='utf-8')
        (disco / 'config').mkdir(parents=True)
        (disco / 'config' / 'configlnx.toml').write_text('editado', encoding='utf-8')
        monkeypatch.setattr('sys.frozen', True, raising=False)
        monkeypatch.setattr('sys._MEIPASS', str(paquete), raising=False)
        with patch('app.main._detectar_ruta_base', return_value=disco):
            _sembrar_consultas_empaquetadas(logger)
        assert (disco / 'config' / 'configlnx.toml').read_text(encoding='utf-8') == 'editado'
        assert (disco / 'data' / 'input' / 'consultas' / 'h1.json').exists()

    def test_error_al_sembrar_continua(self, logger, tmp_path, monkeypatch, caplog):
        """Un error de disco se registra y no detiene el programa."""
        monkeypatch.setattr('sys.frozen', True, raising=False)
        monkeypatch.setattr('sys._MEIPASS', str(tmp_path), raising=False)
        with (
            patch('app.main._detectar_ruta_base', return_value=tmp_path),
            patch('app.main.Path.mkdir', side_effect=PermissionError('solo lectura')),
            caplog.at_level(logging.WARNING),
        ):
            _sembrar_consultas_empaquetadas(logger)
        assert 'No se pudo sembrar' in caplog.text


class TestLogEInicio:
    """Archivo de log y arranque."""

    @pytest.mark.usefixtures('gestor')
    def test_agrega_log_rotativo_una_vez(self, logger, tmp_path):
        """Agrega logs/sri_datos_abiertos.log y no lo duplica."""
        _agregar_log_archivo(logger, None)
        _agregar_log_archivo(logger, None)
        handlers = [h for h in logger.handlers if isinstance(h, RotatingFileHandler)]
        assert len(handlers) == 1
        assert Path(handlers[0].baseFilename) == tmp_path / 'sri_datos_abiertos.log'

    def test_iniciar(self, logger):
        """Crea el logger, siembra y abre el log en archivo."""
        with (
            patch('app.main._crear_logger', return_value=logger),
            patch('app.main._sembrar_consultas_empaquetadas') as mock_sembrar,
            patch('app.main._agregar_log_archivo') as mock_log,
        ):
            assert _iniciar('/c.toml') is logger
        mock_sembrar.assert_called_once_with(logger)
        mock_log.assert_called_once_with(logger, '/c.toml')


class TestComandos:
    """Comando base, cron y ayuda segun como se invoco el programa."""

    @pytest.mark.parametrize(
        'argv0, esperado',
        [
            ('/opt/x/sri_datos_abiertos.1.6.1', './sri_datos_abiertos.1.6.1'),
            ('/p/.venv/bin/exportador', 'pdm run start'),
            ('/usr/lib/app/main.py', 'python -m app.main'),
        ],
    )
    def test_comando_base(self, monkeypatch, argv0, esperado):
        """Binario, PDM o python -m."""
        monkeypatch.setattr('sys.argv', [argv0])
        assert _detectar_comando_base() == esperado

    def test_cron_ejecutable(self, monkeypatch, tmp_path):
        """Como ejecutable, cron usa la ruta absoluta del binario."""
        monkeypatch.setattr('sys.frozen', True, raising=False)
        monkeypatch.setattr('sys.executable', str(tmp_path / 'sri_datos_abiertos.1.6.1'))
        assert _comando_cron() == str((tmp_path / 'sri_datos_abiertos.1.6.1').resolve())

    def test_cron_desarrollo(self, tmp_path):
        """En desarrollo, cron usa el python del .venv del proyecto."""
        with patch('app.main._detectar_ruta_base', return_value=tmp_path):
            assert _comando_cron() == f'{tmp_path / ".venv" / "bin" / "python"} -m app.main'

    @pytest.mark.parametrize('cmd', ['./sri_datos_abiertos.1.6.1', 'pdm run start'])
    def test_ayuda(self, cmd, capsys):
        """La ayuda se adapta al comando con que se invoco."""
        _pantalla_ayuda(cmd)
        assert 'pdm run' in capsys.readouterr().out


class TestPruebaReal:
    """Prueba previa con el verificador y el correo simulados."""

    @pytest.mark.usefixtures('gestor')
    def test_mostrar_conectividad(self, capsys):
        """Muestra cada servicio y el efecto de no tener acceso."""
        exportador = MagicMock()
        exportador.diagnosticar_conectividad.return_value = EstadoConectividad(
            EstadoServicio('Correo', 'smtp:25', False, 'timeout'), [EstadoServicio('Quito', 'q:22', True, 'ok')]
        )
        _mostrar_conectividad(exportador, None)
        salida = capsys.readouterr().out
        assert 'SIN ACCESO - timeout' in salida and 'Sin correo' in salida

    @pytest.mark.usefixtures('gestor')
    def test_crear_verificador(self):
        """Arma el verificador con la configuracion del TOML."""
        assert isinstance(_crear_verificador(logging.getLogger('t'), None), VerificadorConsultas)

    @pytest.mark.usefixtures('gestor')
    def test_notificar_sin_correo(self, logger, tmp_path):
        """Sin acceso al correo solo guarda el reporte local."""
        with patch('app.main.NotificadorEmail') as mock_notif:
            _notificar_prueba(_resultados(), [], False, None, logger)
        mock_notif.assert_not_called()
        assert list((tmp_path / 'mails').glob('*_prueba_consultas_OK.txt'))

    @pytest.mark.usefixtures('gestor')
    def test_notificar_con_correo_y_error(self, logger, tmp_path):
        """Con correo envia la tabla a los receptores de los JSON."""
        consultas = [ConsultaDefinicion.desde_dict({'id': 'h5', 'receptores': 'jagonzalezj@sri.gob.ec'})]
        with patch('app.main.NotificadorEmail') as mock_notif:
            mock_notif.return_value.enviar_tabla.return_value = True
            _notificar_prueba(_resultados(con_error=True), consultas, True, None, logger)
        assert mock_notif.call_args.args[0]['to_addresses'] == ['jagonzalezj@sri.gob.ec']
        assert 'CON PROBLEMAS - 1 de 2' in mock_notif.return_value.enviar_tabla.call_args.kwargs['asunto']
        assert list((tmp_path / 'mails').glob('*_prueba_consultas_ERROR.txt'))

    def test_notificar_sin_smtp(self, gestor, logger):
        """Con correo disponible pero sin smtp_server no envia."""
        gestor.get_email_config.return_value = {'smtp_server': ''}
        with patch('app.main.NotificadorEmail') as mock_notif:
            _notificar_prueba(_resultados(), [], True, None, logger)
        mock_notif.assert_not_called()

    @pytest.mark.parametrize('con_error, esperado', [(False, True), (True, False)])
    def test_probar_consultas(self, logger, con_error, esperado, capsys):
        """
        Devuelve True solo si todas funcionaran; los problemas se ven.
        """
        exportador = MagicMock()
        verificador = MagicMock()
        verificador.probar.return_value = _resultados(con_error)
        with (
            patch('app.main._mostrar_conectividad'),
            patch('app.main._crear_verificador', return_value=verificador),
            patch('app.main._notificar_prueba') as mock_notif,
        ):
            assert _probar_consultas(exportador, [], None, logger) is esperado
        verificador.probar.assert_called_once_with([], exportador.sql_para_ejecucion)
        mock_notif.assert_called_once()
        assert ('SIN CREDENCIAL' in capsys.readouterr().out) is con_error

    def test_consultas_sin_credencial(self):
        """Marca las consultas cuya conexion no esta en tnsnames.ora."""
        exportador = MagicMock()
        exportador.cargar_consultas.return_value = [ConsultaDefinicion.desde_dict({'id': 'h2'}), ConsultaDefinicion.desde_dict({'id': 'h5'})]
        verificador = MagicMock()
        verificador.alias_disponibles.return_value = ['STAR_DESA']
        verificador.verificar_credencial.side_effect = lambda consulta, _alias: None if consulta.id_ == 'h2' else MagicMock(alias='SRIDW_MVEHICULAR')
        with patch('app.main._crear_verificador', return_value=verificador):
            assert _consultas_sin_credencial(exportador, None) == {'h5': 'SRIDW_MVEHICULAR'}


class TestEjecucionComoPrograma:
    """python -m app.main arranca la CLI."""

    def test_python_m_app_main(self, monkeypatch, capsys):
        """El bloque __main__ invoca la CLI (aqui con --help)."""
        monkeypatch.setattr('sys.argv', ['app.main', '--help'])
        with pytest.raises(SystemExit) as salida:
            runpy.run_module('app.main', run_name='__main__')
        assert salida.value.code == 0
        assert 'probar' in capsys.readouterr().out
