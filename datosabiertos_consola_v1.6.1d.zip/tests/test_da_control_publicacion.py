"""
Tests del control de publicacion (da_control_publicacion).

Archivos reales en tmp_path; canal SSH y SFTP simulados. Cubre
conteo de filas en CSV y ZIP, MD5 local y remoto, comprobacion de la
copia (MD5 o tamano), control contra la version vigente e historico.
"""

from datetime import datetime
import hashlib
import io
import logging
import os
import time
from types import SimpleNamespace
import zipfile

import pytest

from app.da_control_publicacion import (
    ControlPublicacion,
    comprobar_copia,
    contar_filas_archivo,
    md5_archivo,
    md5_remoto,
    VERSIONES_HISTORICO,
)


class _Canal:
    """Canal SSH simulado: salida y codigo de md5sum."""

    def __init__(self, salida: str, codigo: int):
        """Init."""
        self.salida, self.codigo, self.comando = salida, codigo, ''

    def settimeout(self, _segundos):
        """Sin efecto."""

    def exec_command(self, comando):
        """Guarda el comando ejecutado."""
        self.comando = comando

    def makefile(self, _modo):
        """Salida estandar del comando."""
        return io.StringIO(self.salida)

    def recv_exit_status(self):
        """Codigo de salida del comando."""
        return self.codigo

    def close(self):
        """Sin efecto."""


class _Transporte:
    """Transporte paramiko simulado con canal y cliente SFTP."""

    def __init__(self, salida: str = '', codigo: int = 0, tamanio: int = 0, error: Exception = None):
        """Init."""
        self.canal, self.tamanio, self.error = _Canal(salida, codigo), tamanio, error

    def open_session(self, **_opciones):
        """Abre el canal o lanza el error configurado."""
        if self.error:
            raise self.error
        return self.canal

    def open_sftp_client(self):
        """Cliente SFTP que informa el tamano remoto."""
        tamanio = self.tamanio
        return SimpleNamespace(stat=lambda _ruta: SimpleNamespace(st_size=tamanio), close=lambda: None)


def _zip_con_filas(ruta, filas: int, mtime: datetime = None):
    """Crea un ZIP con un CSV de cabecera + filas."""
    with zipfile.ZipFile(ruta, 'w') as zf:
        zf.writestr('datos.csv', 'A|B\n' + '1|x\n' * filas)
    if mtime:
        marca = time.mktime(mtime.timetuple())
        os.utime(ruta, (marca, marca))
    return ruta


class TestContarFilas:
    """Filas de datos sin la cabecera."""

    def test_csv(self, tmp_path):
        """Csv."""
        csv = tmp_path / 'a.csv'
        csv.write_text('A|B\n1|x\n2|y\n', encoding='utf-8')
        assert contar_filas_archivo(csv) == 2

    def test_csv_solo_cabecera(self, tmp_path):
        """Csv solo cabecera."""
        csv = tmp_path / 'a.csv'
        csv.write_text('A|B\n', encoding='utf-8')
        assert contar_filas_archivo(csv) == 0

    def test_zip(self, tmp_path):
        """Zip."""
        assert contar_filas_archivo(_zip_con_filas(tmp_path / 'a.zip', 5)) == 5

    def test_zip_sin_csv(self, tmp_path):
        """Zip sin csv."""
        ruta = tmp_path / 'a.zip'
        with zipfile.ZipFile(ruta, 'w') as zf:
            zf.writestr('leeme.txt', 'x')
        with pytest.raises(FileNotFoundError):
            contar_filas_archivo(ruta)


class TestMd5:
    """MD5 local y remoto."""

    def test_md5_local(self, tmp_path):
        """Md5 local."""
        archivo = tmp_path / 'f.zip'
        archivo.write_bytes(b'contenido' * 1000)
        assert md5_archivo(archivo) == hashlib.md5(archivo.read_bytes()).hexdigest()

    def test_md5_remoto(self):
        """Md5 remoto."""
        transporte = _Transporte('d41d8cd98f00b204e9800998ecf8427e  /r/f.zip\n')
        assert md5_remoto(transporte, '/r/f.zip') == 'd41d8cd98f00b204e9800998ecf8427e'

    def test_md5_remoto_sin_comando(self):
        """Si md5sum no existe o falla, None."""
        assert md5_remoto(_Transporte('', 127), '/r/f.zip') is None

    def test_ruta_remota_escapada(self):
        """La ruta va entre comillas: sin inyeccion de comandos."""
        transporte = _Transporte('', 127)
        md5_remoto(transporte, "/r/a b'; rm -rf x.zip")
        assert transporte.canal.comando == """md5sum '/r/a b'"'"'; rm -rf x.zip'"""


class TestComprobarCopia:
    """Comparacion del archivo subido con el local."""

    @pytest.fixture
    def archivo(self, tmp_path):
        """Archivo."""
        ruta = tmp_path / 'f.zip'
        ruta.write_bytes(b'x' * 9000)
        return ruta

    def test_md5_igual(self, archivo):
        """Md5 igual."""
        md5 = md5_archivo(archivo)
        assert comprobar_copia(_Transporte(f'{md5}  /r/f.zip'), '/r/f.zip', archivo, md5) == (True, f'MD5 OK {md5}')

    def test_md5_distinto(self, archivo):
        """Md5 distinto."""
        coincide, detalle = comprobar_copia(_Transporte('0' * 32 + '  /r/f.zip'), '/r/f.zip', archivo, md5_archivo(archivo))
        assert coincide is False
        assert 'MD5 distinto' in detalle

    def test_sin_md5sum_compara_tamano(self, archivo):
        """Sin md5sum compara tamano."""
        coincide, detalle = comprobar_copia(_Transporte('', 127, tamanio=9000), '/r/f.zip', archivo, 'abc')
        assert coincide is True
        assert 'tamano OK' in detalle

    def test_tamano_distinto(self, archivo):
        """Tamano distinto."""
        assert comprobar_copia(_Transporte('', 127, tamanio=1), '/r/f.zip', archivo, 'abc')[0] is False

    def test_canal_falla_usa_tamano(self, archivo):
        """Si no se puede abrir el canal SSH, se compara el tamano."""
        coincide, detalle = comprobar_copia(_Transporte(tamanio=9000, error=OSError('canal cerrado')), '/r/f.zip', archivo, 'abc')
        assert coincide is True
        assert 'canal cerrado' in detalle


class TestControlPublicacion:
    """Conteo contra la version vigente e historico."""

    @pytest.fixture
    def control(self):
        """Control."""
        return ControlPublicacion(logging.getLogger('test_control'))

    def test_sin_vigente_no_compara(self, control, tmp_path):
        """Sin vigente no compara."""
        control.validar_contra_vigente(tmp_path / 'no_existe.zip', 10, 'q')

    def test_mes_anterior_debe_crecer(self, control, tmp_path):
        """Mes anterior debe crecer."""
        vigente = _zip_con_filas(tmp_path / 'v.zip', 50, datetime(2020, 1, 5))
        control.validar_contra_vigente(vigente, 51, 'q')
        with pytest.raises(ValueError, match='deberia crecer'):
            control.validar_contra_vigente(vigente, 50, 'q')

    def test_mismo_mes_tolera_uno_por_ciento(self, control, tmp_path):
        """Re-ejecucion del mes: se acepta hasta 1% menos."""
        vigente = _zip_con_filas(tmp_path / 'v.zip', 100)
        control.validar_contra_vigente(vigente, 99, 'q')
        with pytest.raises(ValueError, match='menos del 99%'):
            control.validar_contra_vigente(vigente, 98, 'q')

    def test_archivar_vigente(self, control, tmp_path):
        """Archivar vigente."""
        vigente = _zip_con_filas(tmp_path / 'FACTURACION_FISICA_2026.zip', 3)
        control.archivar_vigente(vigente)
        assert not vigente.exists()
        assert len(list((tmp_path / 'historico').glob('*_FACTURACION_FISICA_2026.zip'))) == 1

    def test_historico_conserva_las_ultimas(self, control, tmp_path):
        """Historico conserva las ultimas."""
        historico = tmp_path / 'historico'
        historico.mkdir()
        for mes in range(1, VERSIONES_HISTORICO + 3):
            (historico / f'2025{mes:02d}01_000000_X_2026.zip').write_bytes(b'x')
        control.archivar_vigente(_zip_con_filas(tmp_path / 'X_2026.zip', 1))
        assert len(list(historico.glob('*_X_2026.zip'))) == VERSIONES_HISTORICO
