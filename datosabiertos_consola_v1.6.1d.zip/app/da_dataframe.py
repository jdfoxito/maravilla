"""Procesamiento de DataFrames Spark despues de la extraccion Oracle.

app/da_dataframe.py

Transformaciones de negocio sobre el DataFrame leido de Oracle, antes
de escribir el CSV. Una historia nueva con reglas propias se agrega
aqui como proceso_casoN y se declara en el JSON de la consulta.

Claves opcionales del JSON:
  "proceso":   nombre del proceso registrado (ej. "proceso_caso2").
  "columnas":  {"col_origen": "COLUMNA_FINAL"}; renombra, ordena y
               descarta las columnas no listadas.
  "orden":     [{"columna": "CATEGORIA", "ascendente": false}].
  "catalogos": {"canton_sql": "SELECT ..."}; SQL auxiliares.

Sin esas claves el DataFrame pasa sin cambios (historias 1 a 3). El
orden es: proceso (nombres originales del SQL), columnas y orden.

Redondeo: la proteccion x1.5 usa round() de Spark (HALF_UP). Con
676163 x 1.5 = 1014244.5 el SDC espera 1014245; el round() de Python
daria 1014244.

Historial:
+--------------------+---------+------------------------------------------+
| Autor              | Version | Cambios                                  |
+--------------------+---------+------------------------------------------+
| Jim A. Gonzalez    | 1.0.0   | Dispatcher + proceso_caso1 +             |
|                    |         | proceso_caso2 (Catastro Vehicular SDC)   |
| Jim A. Gonzalez    | 1.1.0   | normalizar_decimales: NUMBER de Oracle   |
|                    |         | sin ceros decimales en el CSV            |
| Jim A. Gonzalez    | 1.1.1   | Decimales en una sola proyeccion         |
| Jim A. Gonzalez    | 1.1.2   | Autoprueba movida a tests/               |
+--------------------+---------+------------------------------------------+
"""

from dataclasses import dataclass
from functools import reduce
import logging
from typing import Any, Callable, Dict, List, Optional

from pyspark.sql import DataFrame
from pyspark.sql import functions as fn
from pyspark.sql.types import DecimalType

from app.da_modelos import ConsultaDefinicion

_FACTOR_PROTECCION = 1.5
_COLUMNAS_PROTEGIDAS = ('codigo_vehiculo', 'codigo_sub_categoria')
_COL_CANTON = 'codigo_canton'
_COL_PERSONA = 'tipo_identificac_potenc_prop'
_MAPA_PERSONA = {'C': 'NATURAL', 'P': 'NATURAL', 'R': 'JURÍDICA'}


@dataclass
class ContextoProceso:
    """Datos de apoyo que un proceso de negocio puede necesitar.

    Atributos:
        spark: Sesion Spark Connect activa (la misma de la extraccion).
        jdbc_opts: Opciones JDBC en uso (url, wallet, driver) para leer
                   catalogos auxiliares desde la MISMA base.
        consulta: ConsultaDefinicion con las declaraciones del JSON.
        logger: Logger compartido del proceso.
        lector_catalogos: Inyeccion opcional para pruebas unitarias;
                   funcion (sql) -> DataFrame. Si es None, se lee via
                   JDBC con jdbc_opts.
    """

    spark: Any
    jdbc_opts: Dict[str, str]
    consulta: ConsultaDefinicion
    logger: logging.Logger
    lector_catalogos: Optional[Callable[[str], DataFrame]] = None


def _leer_catalogo(ctx: ContextoProceso, sql: str) -> DataFrame:
    """
    Lee un catalogo auxiliar (ADM) con la misma conexion de la consulta.

    Args:
        ctx: Contexto del proceso.
        sql: Consulta SQL del catalogo (declarada en el JSON).

    Returns:
        DataFrame Spark con el catalogo.
    """
    if ctx.lector_catalogos is not None:
        return ctx.lector_catalogos(sql)
    return ctx.spark.read.format('jdbc').options(**ctx.jdbc_opts).option('query', sql).load()


def normalizar_decimales(df: DataFrame, logger: logging.Logger) -> DataFrame:
    """Escribe los NUMBER de Oracle sin ceros decimales sobrantes.

    Oracle NUMBER sin precision (COUNT, SUM, EXTRACT, ROUND) llega a
    Spark como Decimal(38,10) y el CSV mostraba 2026.0000000000. Se
    convierte a texto sin ceros: 2026, 1084868, 12.5. Las columnas que
    ya son texto (TO_CHAR del avaluo) no se tocan.

    Args:
        df: DataFrame leido desde Oracle.
        logger: Logger compartido.

    Returns:
        DataFrame con las columnas decimales normalizadas.
    """
    columnas = [campo.name for campo in df.schema.fields if isinstance(campo.dataType, DecimalType) and campo.dataType.scale > 0]
    if not columnas:
        return df
    logger.info('Decimales normalizados: %s', ', '.join(columnas))
    return df.withColumns({nombre: _texto_sin_ceros(nombre) for nombre in columnas})


def _texto_sin_ceros(nombre: str) -> Any:
    """
    Expresion que convierte un decimal a texto sin ceros a la derecha.
    """
    sin_ceros = fn.regexp_replace(fn.col(f'`{nombre}`').cast('string'), r'(\.\d*?[1-9])0+$', '$1')
    return fn.regexp_replace(sin_ceros, r'\.0+$', '')


def proceso_caso1(df: DataFrame, ctx: ContextoProceso) -> DataFrame:
    """Caso 1 - Facturacion (historias 1 a 3): sin transformaciones.

    No tiene reglas de negocio: retorna el DataFrame tal cual.

    Args:
        df: DataFrame leido desde Oracle.
        ctx: Contexto del proceso.

    Returns:
        El mismo DataFrame, sin cambios.
    """
    ctx.logger.info('proceso_caso1: sin transformaciones de negocio')
    return df


def proceso_caso2(df: DataFrame, ctx: ContextoProceso) -> DataFrame:
    """Caso 2 - Catastro Vehicular (historia 5, SDC 29/10/2025).

    Reglas aplicadas sobre los nombres ORIGINALES del SQL:
      1. Proteccion de datos: codigo_vehiculo y codigo_sub_categoria
         se multiplican por 1.5 con redondeo HALF_UP a unidad
         (round de Spark, no el de Python).
      2. Tipo de persona: C/P -> NATURAL, R -> JURIDICA.
      3. Canton: codigo_canton se reemplaza por la descripcion del
         catalogo ADM (catalogos.canton_sql en el JSON). Si no hay
         catalogo configurado, se conserva el codigo y se registra
         una advertencia.

    El renombre de columnas y el ordenamiento NO
    van aqui: se declaran en el JSON ("columnas" y
    "orden") y los aplica el dispatcher despues.

    Args:
        df: DataFrame leido desde Oracle.
        ctx: Contexto del proceso.

    Returns:
        DataFrame con las reglas de negocio aplicadas.
    """
    ctx.logger.info('proceso_caso2: aplicando reglas Catastro Vehicular')
    return _aplicar_catalogo_canton(_aplicar_mapa_persona(_aplicar_proteccion(df, ctx), ctx), ctx)


def _aplicar_proteccion(df: DataFrame, ctx: ContextoProceso) -> DataFrame:
    """Multiplica por 1.5 y redondea a unidad las columnas protegidas.

    Usa fn.round (HALF_UP) y castea a long para que el CSV no muestre
    decimales. Los nulos se conservan.

    Args:
        df: DataFrame de entrada.
        ctx: Contexto del proceso.

    Returns:
        DataFrame con las columnas protegidas transformadas.
    """
    for columna in _COLUMNAS_PROTEGIDAS:
        if columna in df.columns:
            df = df.withColumn(columna, fn.round(fn.col(columna).cast('double') * fn.lit(_FACTOR_PROTECCION), 0).cast('long'))
            ctx.logger.info('proceso_caso2: %s protegido (x%.1f, redondeo unidad)', columna, _FACTOR_PROTECCION)
        else:
            ctx.logger.warning('proceso_caso2: columna protegida %s no existe en el resultado', columna)
    return df


def _aplicar_mapa_persona(df: DataFrame, ctx: ContextoProceso) -> DataFrame:
    """Mapea el tipo de persona: C/P -> NATURAL, R -> JURIDICA.

    Los valores no contemplados se conservan tal cual (no se pierde
    informacion) y se deja traza en el log.

    Args:
        df: DataFrame de entrada.
        ctx: Contexto del proceso.

    Returns:
        DataFrame con la columna de persona mapeada.
    """
    if _COL_PERSONA not in df.columns:
        ctx.logger.warning('proceso_caso2: columna %s no existe, se omite mapeo persona', _COL_PERSONA)
        return df

    normalizada = fn.upper(fn.trim(fn.col(_COL_PERSONA)))
    expresion = fn.col(_COL_PERSONA)
    for codigo, descripcion in _MAPA_PERSONA.items():
        expresion = fn.when(normalizada == codigo, fn.lit(descripcion)).otherwise(expresion)

    ctx.logger.info('proceso_caso2: %s mapeado (%s)', _COL_PERSONA, ', '.join(f'{k}->{v}' for k, v in _MAPA_PERSONA.items()))
    return df.withColumn(_COL_PERSONA, expresion)


def _aplicar_catalogo_canton(df: DataFrame, ctx: ContextoProceso) -> DataFrame:
    """Reemplaza codigo_canton por su descripcion del catalogo ADM.

    El SQL del catalogo se declara en el JSON (catalogos.canton_sql)
    y debe devolver (codigo, descripcion) en ese orden. El join es
    LEFT con broadcast: si un codigo no tiene descripcion, se
    conserva el codigo original (no se pierde el dato).

    Args:
        df: DataFrame de entrada.
        ctx: Contexto del proceso.

    Returns:
        DataFrame con codigo_canton reemplazado por la descripcion.
    """
    if _COL_CANTON not in df.columns:
        return df

    catalogos = ctx.consulta.catalogos or {}
    sql_catalogo = catalogos.get('canton_sql', '')
    if not sql_catalogo:
        ctx.logger.warning('proceso_caso2: sin catalogos.canton_sql en el JSON; %s se conserva como codigo', _COL_CANTON)
        return df

    catalogo = _leer_catalogo(ctx, sql_catalogo)
    cols_catalogo = catalogo.columns
    if len(cols_catalogo) < 2:
        raise ValueError(f'Catalogo de cantones invalido: se esperaban >= 2 columnas (codigo, descripcion), llegaron: {cols_catalogo}')

    cat = catalogo.select(fn.col(cols_catalogo[0]).cast('string').alias('_cat_codigo'), fn.col(cols_catalogo[1]).cast('string').alias('_cat_desc'))
    unidos = df.join(fn.broadcast(cat), df[_COL_CANTON].cast('string') == cat['_cat_codigo'], 'left')
    ctx.logger.info('proceso_caso2: %s mapeado con catalogo ADM (%s filas)', _COL_CANTON, sql_catalogo[:60])
    return unidos.withColumn(_COL_CANTON, fn.coalesce(unidos['_cat_desc'], unidos[_COL_CANTON])).drop('_cat_codigo', '_cat_desc')


class ProcesadorDataFrame:
    """Aplica el pipeline de transformaciones declarado en el JSON.

    Registro de procesos de negocio disponibles. Para una historia
    nueva: se escribe la funcion proceso_casoN y se agrega aqui; el
    JSON la referencia por nombre con la clave "proceso".
    """

    PROCESOS: Dict[str, Callable[[DataFrame, ContextoProceso], DataFrame]] = {}

    def __init__(self, logger: logging.Logger):
        """Inicializa el procesador.

        Args:
            logger: Logger compartido de la aplicacion.
        """
        self._logger = logger

    def _log(self, level: int, msg: str, *args: object, exc_info: bool = False) -> None:
        """Registra un mensaje en el log."""
        self._logger.log(level, msg, *args, exc_info=exc_info)

    def aplicar(self, df: DataFrame, ctx: ContextoProceso) -> DataFrame:
        """Ejecuta el pipeline: proceso -> columnas -> orden.

        Args:
            df: DataFrame leido desde Oracle.
            ctx: Contexto con la consulta y sus declaraciones JSON.

        Returns:
            DataFrame transformado.

        Raises:
            ValueError: Si el proceso declarado no esta registrado o
                        falta alguna columna requerida.
        """
        return reduce(lambda actual, paso: paso(actual), self._pipeline(ctx), df)

    def _pipeline(self, ctx: ContextoProceso) -> List[Callable[[DataFrame], DataFrame]]:
        """
        Construye los pasos del pipeline segun lo declarado en el JSON.

        Solo se incluyen los pasos declarados; si el JSON no declara
        nada, la lista queda vacia y el DataFrame pasa sin cambios.
        """
        pasos: List[Callable[[DataFrame], DataFrame]] = []

        nombre = (ctx.consulta.proceso or '').strip()
        if nombre:
            pasos.append(lambda actual: self._aplicar_proceso(actual, ctx, nombre))

        if ctx.consulta.columnas:
            pasos.append(lambda actual: self._aplicar_columnas(actual, ctx.consulta.columnas))

        if ctx.consulta.orden:
            pasos.append(lambda actual: self._aplicar_orden(actual, ctx.consulta.orden))

        return pasos

    def _aplicar_proceso(self, df: DataFrame, ctx: ContextoProceso, nombre: str) -> DataFrame:
        """Resuelve y ejecuta el proceso de negocio por nombre.

        Args:
            df: DataFrame de entrada.
            ctx: Contexto del proceso.
            nombre: Nombre declarado en el JSON.

        Returns:
            DataFrame con las reglas de negocio aplicadas.

        Raises:
            ValueError: Si el nombre no esta registrado.
        """
        funcion = self.PROCESOS.get(nombre)
        if funcion is None:
            raise ValueError(f'Proceso "{nombre}" no registrado. Disponibles: {sorted(self.PROCESOS)}')
        self._log(logging.INFO, 'Aplicando proceso de negocio: %s', nombre)
        return funcion(df, ctx)

    def _aplicar_columnas(self, df: DataFrame, columnas: Dict[str, str]) -> DataFrame:
        """Renombra, reordena y selecciona columnas segun el JSON.

        Solo quedan las columnas listadas, en el orden del mapeo y con
        su nombre final. Si falta alguna columna origen se detiene con
        error y el exportador envia la alerta.

        Args:
            df: DataFrame de entrada.
            columnas: Mapeo {nombre_origen: NOMBRE_FINAL}.

        Returns:
            DataFrame con las columnas finales.

        Raises:
            ValueError: Si alguna columna origen no existe.
        """
        faltantes = [c for c in columnas if c not in df.columns]
        if faltantes:
            raise ValueError(f'Columnas no encontradas para renombrar: {faltantes}. Disponibles: {df.columns}')
        self._log(logging.INFO, 'Columnas finales: %s renombradas/seleccionadas', len(columnas))
        return df.select([fn.col(origen).alias(destino) for origen, destino in columnas.items()])

    def _aplicar_orden(self, df: DataFrame, orden: List[Dict[str, Any]]) -> DataFrame:
        """Ordena el DataFrame segun la declaracion del JSON.

        Args:
            df: DataFrame de entrada.
            orden: Lista de {"columna": nombre, "ascendente": bool}.

        Returns:
            DataFrame ordenado.

        Raises:
            ValueError: Si alguna columna de ordenamiento no existe.
        """
        criterios = []
        for item in orden:
            columna = item.get('columna', '')
            if columna not in df.columns:
                raise ValueError(f'Columna de ordenamiento no existe: "{columna}". Disponibles: {df.columns}')
            ascendente = bool(item.get('ascendente', True))
            criterios.append(fn.col(columna).asc() if ascendente else fn.col(columna).desc())
        self._log(logging.INFO, 'Ordenamiento aplicado: %s', orden)
        return df.orderBy(criterios)


ProcesadorDataFrame.PROCESOS.update({'proceso_caso1': proceso_caso1, 'proceso_caso2': proceso_caso2})
