"""Grupos de excepciones del sistema.

app/da_excepciones.py

Cada grupo es una tupla de clases, valida en isinstance() y en la
clausula except.

Historial:
+--------------------+---------+------------------------------------------+
| Autor              | Version | Cambios                                  |
+--------------------+---------+------------------------------------------+
| Jim A. Gonzalez    | 1.0.0   | Version inicial                          |
| Jim A. Gonzalez    | 2.0.0   | Renombrado espanol, alias compatibilidad |
| Jim A. Gonzalez    | 2.1.0   | Metaclase _MetaGrupo para isinstance()   |
| Jim A. Gonzalez    | 2.2.0   | Eliminado defusedxml; lxml.etree directo |
| Jim A. Gonzalez    | 3.0.0   | Tuplas planas: except si captura         |
| Jim A. Gonzalez    | 3.1.0   | Sin setattr dinamico en el modulo        |
+--------------------+---------+------------------------------------------+
"""

from lxml.etree import DocumentInvalid, ParseError, XMLSyntaxError
from sqlalchemy.exc import SQLAlchemyError


class TrazabilidadExcepciones:
    """
    Agrupador de excepciones del sistema.

    Los atributos son tuplas de clases. Los nombres en ingles se
    conservan por compatibilidad con codigo existente.
    """

    ERRORES_BD = (SQLAlchemyError,)
    ERRORES_SISTEMA = (OSError, RuntimeError)
    ERRORES_XML = (ParseError, XMLSyntaxError, DocumentInvalid)
    ERRORES_TIPO = (TypeError, ValueError, AttributeError)
    ERRORES_RED = (ConnectionError, TimeoutError)
    ERRORES_POOL = (AttributeError, RuntimeError)
    ERRORES_VALIDACION = (ValueError, TypeError, KeyError, IndexError)
    ERRORES_CRITICOS = (SystemExit, KeyboardInterrupt, MemoryError)
    ERRORES_BD_SISTEMA = ERRORES_BD + ERRORES_SISTEMA
    TODOS_NO_CRITICOS = tuple(
        dict.fromkeys(ERRORES_BD + ERRORES_SISTEMA + ERRORES_XML + ERRORES_TIPO + ERRORES_RED + ERRORES_POOL + ERRORES_VALIDACION)
    )

    DB_ERRORS = ERRORES_BD
    SYSTEM_ERRORS = ERRORES_SISTEMA
    XML_ERRORS = ERRORES_XML
    TYPE_ERRORS = ERRORES_TIPO
    NETWORK_ERRORS = ERRORES_RED
    POOL_ERRORS = ERRORES_POOL
    VALIDATION_ERRORS = ERRORES_VALIDACION
    CRITICAL_ERRORS = ERRORES_CRITICOS
    DB_SYSTEM_ERRORS = ERRORES_BD_SISTEMA
    ALL_NON_CRITICAL = TODOS_NO_CRITICOS

    @staticmethod
    def es_error_bd(exc: Exception) -> bool:
        """Retorna True si la excepcion es de base de datos."""
        return isinstance(exc, TrazabilidadExcepciones.ERRORES_BD)

    @staticmethod
    def es_error_sistema(exc: Exception) -> bool:
        """Retorna True si la excepcion es de sistema operativo."""
        return isinstance(exc, TrazabilidadExcepciones.ERRORES_SISTEMA)

    @staticmethod
    def es_error_xml(exc: Exception) -> bool:
        """Retorna True si la excepcion es de analisis XML."""
        return isinstance(exc, TrazabilidadExcepciones.ERRORES_XML)

    @staticmethod
    def es_error_pool(exc: Exception) -> bool:
        """Retorna True si la excepcion es de pool de conexiones."""
        return isinstance(exc, TrazabilidadExcepciones.ERRORES_POOL)

    @staticmethod
    def es_error_critico(exc: BaseException) -> bool:
        """
        Retorna True si el error es critico y debe detener la ejecucion.
        """
        return isinstance(exc, TrazabilidadExcepciones.ERRORES_CRITICOS)

    @staticmethod
    def obtener_categoria(exc: BaseException) -> str:
        """Retorna la categoria del error como texto."""
        categorias = (
            (TrazabilidadExcepciones.ERRORES_CRITICOS, 'CRITICO'),
            (TrazabilidadExcepciones.ERRORES_BD, 'BASE_DATOS'),
            (TrazabilidadExcepciones.ERRORES_SISTEMA, 'SISTEMA'),
            (TrazabilidadExcepciones.ERRORES_XML, 'XML'),
            (TrazabilidadExcepciones.ERRORES_POOL, 'POOL_CONEXION'),
        )
        return next((etiqueta for clases, etiqueta in categorias if isinstance(exc, clases)), 'OTRO_NO_CRITICO')
