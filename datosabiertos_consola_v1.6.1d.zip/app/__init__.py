"""Para el modulo."""
