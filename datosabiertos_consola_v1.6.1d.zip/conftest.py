"""
Conftest de la raiz del proyecto.

Su presencia hace que pytest agregue esta carpeta al sys.path, asi los
tests importan app/ aunque el CI no use la configuracion de pytest del
pyproject.toml ni tests/__init__.py.
"""
